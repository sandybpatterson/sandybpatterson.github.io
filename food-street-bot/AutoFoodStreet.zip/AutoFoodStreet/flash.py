"""FLASH -- Fast Live Access to Screen History (owner 11/1).

STEP 2 (owner 11/1: "add in the setting"): Settings > Speed > "FLASH fast capture" (`flash_capture`, default
off) sets ON. Then adb_helper.screenshot() asks `grab()` first: a PrintWindow copy of LDPlayer's game window
(works behind other windows, not when minimised), checked (not black, game shape) and resized to the adb
picture size; anything wrong -> None -> the normal adb screenshot, logged `[flash] ...` at most every 5 min.
Taps still go through adb. The step-1 test below keeps comparing both pictures every 10 min.

STEP 1: LOG-ONLY TEST.

Today every look at the game is `adb exec-out screencap`: a new adb process, ~5.8 MB of raw pixels
through adb, 1.8 s on a fresh emulator and 3.9 s after a few hours (10/31 logs). FLASH option B
copies the LDPlayer window with Windows itself (no adb), which should take a few hundredths of a
second. This module only MEASURES that: every TEST_GAP_SEC it captures the window, takes a normal
adb screenshot, captures the window again, and logs how long each took, whether the window
picture came back black, and how closely it matches the adb picture.

It never taps, never changes what the bot sees, and is called from the run loop
(`tick(log)`) whatever job is ticked. Two capture methods are tried:
  printwindow  -- PrintWindow(PW_RENDERFULLCONTENT): works even when the window is covered,
                  but GPU-drawn windows sometimes come back black
  screen       -- copy the window's spot from the screen (BitBlt): only right when the window
                  is visible and not covered
Log lines: `[flash test] ...`. The first pictures per run go to templates/tests (Send logs).
"""
import os
import sys
import time

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TEST_GAP_SEC = 600          # one measurement every 10 min
PICS_PER_RUN = 2            # picture pairs saved per run
BLACK_MEAN = 12             # mean brightness below this = a black capture
SAME_DIFF = 6.0             # mean pixel difference below this = "same picture"
WINDOW_TRIES = 3            # captures per method, timed, best kept

SPEED_GAP_SEC = 900         # the [speed test] line every 15 min (11/1: auto restart every 30 min meant the hourly line never came)

_last = {"t": 0.0, "pics": 0, "listed": False, "n": 0, "sums": {}}

ON = False                  # step 2: set every cycle by afsd_core._apply_settings from the Settings switch
LOG = None                  # afsd_core sets its log function here
SHAPE_TOL = 0.04            # the window copy's width/height may differ this much from the game's shape
FALLBACK_NOTE_SEC = 300     # "[flash] ... using adb" at most every 5 min
_grab = {"hwnd": None, "found_at": 0.0, "size": None, "client": None, "n": 0, "total": 0.0,
         "fails": 0, "noted": 0.0}
# 11/3 FROZEN FRAME GUARD: 03:00-09:00 the window copy kept returning ONE old picture (a Pumpkin timer card) while
# the real game moved on -- the bot was blind for 6 h and its own 10-min check said "DIFFERENT from adb" every time.
# A window copy that has not changed at all for FROZEN_SEC is checked against ONE adb screenshot; different = the
# copy is stale -> adb screenshots only for STALE_REST_SEC.
FROZEN_DIFF = 0.6           # mean grey difference (80x45) below this = the very same picture
FROZEN_SEC = 20             # same picture this long -> check it against adb
STALE_DIFF = 15.0           # adb this different from the copy = the copy is stale
STALE_REST_SEC = 600        # then adb only for 10 min
_stale = {"small": None, "since": 0.0, "verify": None, "checked": 0.0, "rest_until": 0.0, "count": 0}
_speed = {"t": None, "shots": None, "acts": None, "fast": (0, 0.0)}


# ---------------------------------------------------------------- pure parts (tested offline)

def is_black(img):
    return img is None or float(np.mean(img)) < BLACK_MEAN


def trim_black(img, level=4):
    """Crop away the empty (black) right/bottom part of an oversized capture. None if nothing is drawn."""
    g = img.max(axis=2) > level
    rows, cols = np.where(g.any(axis=1))[0], np.where(g.any(axis=0))[0]
    if not len(rows) or not len(cols):
        return None
    return img[:rows[-1] + 1, :cols[-1] + 1]


def pick_render(children, aspect):
    """children: [(hwnd, class, title, w, h)] -> the hwnd whose shape is closest to the game's
    aspect (w/h of the adb picture), biggest first on a tie; None if nothing is big enough."""
    best, key = None, None
    for hwnd, _cls, _title, w, h in children:
        if w < 320 or h < 180:
            continue
        k = (round(abs(w / h - aspect), 2), -(w * h))
        if key is None or k < key:
            best, key = hwnd, k
    return best


def compare(adb_img, win_img):
    """Window picture vs adb picture -> {"diff": mean abs difference after resizing the window
    picture to the adb size, "black": bool, "size": (w, h) of the window picture}."""
    if win_img is None:
        return {"diff": None, "black": True, "size": None}
    h, w = adb_img.shape[:2]
    size = (win_img.shape[1], win_img.shape[0])
    res = cv2.resize(win_img, (w, h), interpolation=cv2.INTER_AREA)
    diff = float(np.mean(cv2.absdiff(cv2.cvtColor(res, cv2.COLOR_BGR2GRAY),
                                     cv2.cvtColor(adb_img, cv2.COLOR_BGR2GRAY))))
    return {"diff": round(diff, 1), "black": is_black(win_img), "size": size}


def verdict(r):
    if r["size"] is None:
        return "FAILED (no picture)"
    if r["black"]:
        return "BLACK"
    if r["diff"] is not None and r["diff"] < SAME_DIFF:
        return "SAME as adb"
    return "DIFFERENT from adb"


# ---------------------------------------------------------------- Windows capture (ctypes only)

_TYPED = []


def _win():
    """ctypes + wintypes, with 64-bit-safe handle types set once (the default c_int return
    would cut a 64-bit handle)."""
    import ctypes
    from ctypes import wintypes as wt
    if not _TYPED:
        u, g = ctypes.windll.user32, ctypes.windll.gdi32
        H, P = ctypes.c_void_p, ctypes.c_void_p
        for fn, res, args in (
                (u.GetDC, H, [H]), (u.ReleaseDC, ctypes.c_int, [H, H]),
                (u.GetClientRect, wt.BOOL, [H, P]), (u.ClientToScreen, wt.BOOL, [H, P]),
                (u.PrintWindow, wt.BOOL, [H, H, wt.UINT]), (u.IsWindowVisible, wt.BOOL, [H]),
                (u.GetWindowTextW, ctypes.c_int, [H, wt.LPWSTR, ctypes.c_int]),
                (u.GetClassNameW, ctypes.c_int, [H, wt.LPWSTR, ctypes.c_int]),
                (g.CreateCompatibleDC, H, [H]), (g.CreateCompatibleBitmap, H, [H, ctypes.c_int, ctypes.c_int]),
                (g.SelectObject, H, [H, H]), (g.DeleteObject, wt.BOOL, [H]), (g.DeleteDC, wt.BOOL, [H]),
                (g.BitBlt, wt.BOOL, [H, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, H,
                                     ctypes.c_int, ctypes.c_int, wt.DWORD]),
                (g.GetDIBits, ctypes.c_int, [H, H, wt.UINT, wt.UINT, P, P, wt.UINT])):
            fn.restype, fn.argtypes = res, args
        _TYPED.append(True)
    return ctypes, wt


def find_windows():
    """[(hwnd, class, title, w, h)] of top-level visible windows that look like LDPlayer."""
    ctypes, wt = _win()
    u = ctypes.windll.user32
    out = []

    def _info(hwnd):
        buf = ctypes.create_unicode_buffer(256)
        u.GetWindowTextW(hwnd, buf, 256)
        title = buf.value
        u.GetClassNameW(hwnd, buf, 256)
        r = wt.RECT()
        u.GetClientRect(hwnd, ctypes.byref(r))
        return hwnd, buf.value, title, r.right - r.left, r.bottom - r.top

    cb_t = ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)

    def _top(hwnd, _):
        if u.IsWindowVisible(hwnd):
            i = _info(hwnd)
            if "ldplayer" in (i[1] + " " + i[2]).lower():
                out.append(i)
        return True
    u.EnumWindows(cb_t(_top), 0)
    return out, _info, cb_t


def children_of(hwnd):
    ctypes, _wt = _win()
    u = ctypes.windll.user32
    _, _info, cb_t = find_windows()
    kids = []

    def _kid(h, _):
        kids.append(_info(h))
        return True
    u.EnumChildWindows(ctypes.c_void_p(hwnd), cb_t(_kid), 0)
    return kids, _info(hwnd)


def capture(hwnd, method, size=None):
    """Window client area -> BGR picture (or None). method 'printwindow' or 'screen'.
    size: the drawn size learned earlier (step 2) -- copies exactly that instead of the 2x safety bitmap."""
    ctypes, wt = _win()
    u, g = ctypes.windll.user32, ctypes.windll.gdi32
    r = wt.RECT()
    u.GetClientRect(hwnd, ctypes.byref(r))
    w, h = r.right - r.left, r.bottom - r.top
    if w <= 0 or h <= 0:
        return None
    if method == "printwindow" and size:
        w, h = size
    elif method == "printwindow":
        # 11/1 live: the game is drawn LARGER than the client size Windows reports (display scaling), so a
        # client-sized bitmap held only its top-left part. Draw into a bitmap 2x as big and trim the black rest.
        w, h = min(w * 2, 4096), min(h * 2, 2304)
    src = u.GetDC(hwnd) if method == "printwindow" else u.GetDC(0)
    mem = g.CreateCompatibleDC(src)
    bmp = g.CreateCompatibleBitmap(src, w, h)
    old = g.SelectObject(mem, bmp)
    try:
        if method == "printwindow":
            ok = u.PrintWindow(hwnd, mem, 3)            # PW_CLIENTONLY | PW_RENDERFULLCONTENT
        else:
            pt = wt.POINT(0, 0)
            u.ClientToScreen(hwnd, ctypes.byref(pt))
            ok = g.BitBlt(mem, 0, 0, w, h, src, pt.x, pt.y, 0x00CC0020)   # SRCCOPY
        if not ok:
            return None

        class BIH(ctypes.Structure):
            _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG),
                        ("biPlanes", wt.WORD), ("biBitCount", wt.WORD), ("biCompression", wt.DWORD),
                        ("biSizeImage", wt.DWORD), ("biXPelsPerMeter", wt.LONG),
                        ("biYPelsPerMeter", wt.LONG), ("biClrUsed", wt.DWORD), ("biClrImportant", wt.DWORD)]
        bi = BIH()
        bi.biSize, bi.biWidth, bi.biHeight = ctypes.sizeof(BIH), w, -h   # top-down rows
        bi.biPlanes, bi.biBitCount = 1, 32
        buf = (ctypes.c_ubyte * (w * h * 4))()
        g.GetDIBits(mem, bmp, 0, h, buf, ctypes.byref(bi), 0)
        img = cv2.cvtColor(np.frombuffer(buf, dtype=np.uint8).reshape(h, w, 4), cv2.COLOR_BGRA2BGR)
        return trim_black(img) if method == "printwindow" else img
    finally:
        g.SelectObject(mem, old)
        g.DeleteObject(bmp)
        g.DeleteDC(mem)
        u.ReleaseDC(hwnd if method == "printwindow" else 0, src)


def _timed(hwnd, method):
    best, secs = None, []
    for _ in range(WINDOW_TRIES):
        t0 = time.time()
        try:
            img = capture(hwnd, method)
        except Exception:                               # noqa: BLE001
            img = None
        secs.append(time.time() - t0)
        if img is not None:
            best = img
    return best, min(secs)


def _save(name, img):
    try:
        d = os.path.join(HERE, "templates", "tests")
        os.makedirs(d, exist_ok=True)
        cv2.imwrite(os.path.join(d, time.strftime("%Y%m%d_%H%M%S_") + name + ".jpg"), img,
                    [cv2.IMWRITE_JPEG_QUALITY, 80])
    except Exception:                                   # noqa: BLE001
        pass


def measure(log, screenshot):
    """One measurement. screenshot() = the normal adb screenshot.
    11/1 live: Windows display scaling (125%) made GetClientRect report 724x407 while the game is drawn at ~905x509,
    so only the top-left 80% was copied. The window work now runs DPI-aware on THIS thread only (Tk's thread untouched)."""
    if sys.platform != "win32":
        return
    old_ctx = None
    try:
        import ctypes
        f = ctypes.windll.user32.SetThreadDpiAwarenessContext
        f.restype, f.argtypes = ctypes.c_void_p, [ctypes.c_void_p]
        old_ctx = f(ctypes.c_void_p(-4))                # PER_MONITOR_AWARE_V2 (Windows 10 1703+)
    except Exception:                                   # noqa: BLE001 -- older Windows: measure unscaled
        f = None
    try:
        _measure(log, screenshot)
    finally:
        if f is not None and old_ctx:
            try:
                f(ctypes.c_void_p(old_ctx))
            except Exception:                           # noqa: BLE001
                pass


def _measure(log, screenshot):
    tops, _i, _c = find_windows()
    if not tops:
        log("[flash test] no LDPlayer window found -- nothing to measure")
        return
    t0 = time.time()
    adb_img = screenshot()
    adb_sec = time.time() - t0
    if adb_img is None:
        return
    aspect = adb_img.shape[1] / adb_img.shape[0]
    kids, top_info = children_of(tops[0][0])
    ctypes, _wt = _win()
    if ctypes.windll.user32.IsIconic(ctypes.c_void_p(tops[0][0])):     # 11/1 live: 157x26 = minimised
        log("[flash test] LDPlayer is MINIMISED -- a window copy can only see a visible window "
            "(restore it to get a real result)")
    if not _last["listed"]:
        _last["listed"] = True
        log("[flash test] LDPlayer window " + str(top_info[1:]) + "; inner windows: "
            + ", ".join(f"{c[1]}/'{c[2]}' {c[3]}x{c[4]}" for c in kids[:12]))
    target = pick_render(kids, aspect) or tops[0][0]
    parts = [f"adb {adb_sec:.2f} s"]
    save = _last["pics"] < PICS_PER_RUN
    for method in ("printwindow", "screen"):
        img, sec = _timed(target, method)
        r = compare(adb_img, img)
        s = _last["sums"].setdefault(method, [0, 0.0])
        s[0] += 1
        s[1] += sec
        parts.append(f"{method} {sec:.3f} s {r['size'][0]}x{r['size'][1]} ({100 * r['size'][0] / adb_img.shape[1]:.0f}% of the game size) "
                     if r["size"] else f"{method} {sec:.3f} s ")
        parts[-1] += f"{verdict(r)}" + (f" (diff {r['diff']})" if r["diff"] is not None else "")
        if method == "printwindow" and r["diff"] is not None and r["diff"] >= 30 and ON:
            _stale["rest_until"], _stale["small"] = time.time() + STALE_REST_SEC, None   # 11/3: stale copy
            _stale["count"] += 1
            parts[-1] += f" -> using adb for {STALE_REST_SEC // 60} min"
        if save and img is not None:
            _save("flash_" + method, img)
    if save:
        _save("flash_adb", adb_img)
        _last["pics"] += 1
    _last["n"] += 1
    avg = "; ".join(f"{m} avg {v[1] / v[0]:.3f} s" for m, v in _last["sums"].items())
    log("[flash test] " + " | ".join(parts) + f" | run so far: {_last['n']} checks, {avg}")


def speed_line(minutes, shots, shot_sec, acts, act_sec, fast=0, fast_sec=0.0, taps_fast=0, taps_fast_sec=0.0,
               sleeps=None, cpu_sec=None):
    """Pure: the '[speed test]' text from counts and seconds spent. sleeps = {"module:line": [n, sec]} for the
    period -> the fixed pauses that cost the most (FLASH step 3, log-only)."""
    def part(n, sec, what):
        avg = sec / n if n else 0.0
        return f"{n} {what} x {avg:.2f} s = {sec / 60:.1f} min"
    extra = f"{part(fast, fast_sec, 'FLASH looks')}; " if fast else ""
    tf = f" (of them {part(taps_fast, taps_fast_sec, 'fast')})" if taps_fast else ""
    slept = sum(v[1] for v in (sleeps or {}).values())
    line = (f"[speed test] last {minutes:.0f} min: {part(shots, shot_sec, 'screenshots')}; {extra}"
            f"{part(acts, act_sec, 'taps/swipes')}{tf}; "
            f"together {100 * (shot_sec + fast_sec + act_sec) / max(1.0, minutes * 60):.0f}% of the time")
    if slept > 0:
        top = sorted(sleeps.items(), key=lambda kv: -kv[1][1])[:5]
        line += (f"; fixed pauses {slept / 60:.1f} min ({100 * slept / max(1.0, minutes * 60):.0f}%), most: "
                 + ", ".join(f"{k} {v[0]}x {v[1]:.0f} s" for k, v in top))
    if cpu_sec is not None:                             # 11/2 step 5: AFSD's own CPU use (100% = one full core)
        line += f"; AFSD CPU {100 * cpu_sec / max(1.0, minutes * 60):.0f}% of one core"
    return line


def _speed_tick(log, now):
    import adb_helper
    shots = (adb_helper._SHOT["n"], adb_helper._SHOT["total"])
    acts = (adb_helper.ACTIONS["n"], adb_helper.ACTIONS["total"])
    if _speed["t"] is None or shots[0] < _speed["shots"][0] or acts[0] < _speed["acts"][0]:
        _speed.update({"t": now, "shots": shots, "acts": acts, "fast": (_grab["n"], _grab["total"]),
                       "taps_fast": _fast_taps(), "sleeps": _sleeps(), "cpu": time.process_time()})
        return
    if now - _speed["t"] < SPEED_GAP_SEC:
        return
    fast = (_grab["n"], _grab["total"])
    f0 = _speed.get("fast") or (0, 0.0)
    tf, tf0 = _fast_taps(), _speed.get("taps_fast") or (0, 0.0)
    sl, sl0 = _sleeps(), _speed.get("sleeps") or {}
    diff = {k: [v[0] - sl0.get(k, [0, 0.0])[0], v[1] - sl0.get(k, [0, 0.0])[1]] for k, v in sl.items()}
    diff = {k: v for k, v in diff.items() if v[1] > 0}
    log(speed_line((now - _speed["t"]) / 60, shots[0] - _speed["shots"][0], shots[1] - _speed["shots"][1],
                   acts[0] - _speed["acts"][0], acts[1] - _speed["acts"][1],
                   max(0, fast[0] - f0[0]), max(0.0, fast[1] - f0[1]),
                   max(0, tf[0] - tf0[0]), max(0.0, tf[1] - tf0[1]), diff,
                   cpu_sec=(time.process_time() - _speed["cpu"]) if _speed.get("cpu") is not None else None))
    _speed.update({"t": now, "shots": shots, "acts": acts, "fast": fast, "taps_fast": tf, "sleeps": sl,
                   "cpu": time.process_time()})


def _fast_taps():
    try:
        import fast_input
        s = fast_input.stats()
        return (s["ok"], s["sec"])
    except Exception:                                   # noqa: BLE001
        return (0, 0.0)


def _sleeps():
    try:
        import find_and_center
        return {k: list(v) for k, v in find_and_center.SLEEPS.items()}
    except Exception:                                   # noqa: BLE001
        return {}


def shape_ok(img, target_wh):
    """Pure: a usable window copy = a picture, not black, at least 40% of the game's width, and the game's shape."""
    if img is None or is_black(img):
        return False
    h, w = img.shape[:2]
    tw, th = target_wh
    return w >= 0.4 * tw and abs((w / h) / (tw / th) - 1) <= SHAPE_TOL


def _note(why):
    _grab["fails"] += 1
    now = time.time()
    _grab["fail_t"] = now
    if LOG and now - _grab["noted"] >= FALLBACK_NOTE_SEC:
        _grab["noted"] = now
        try:
            LOG(f"[flash] window copy not usable ({why}) -- using the adb screenshot "
                f"({_grab['fails']} fallbacks, {_grab['n']} fast looks this run)")
        except Exception:                               # noqa: BLE001
            pass


def _find_game_window(target_wh):
    tops, _i, _c = find_windows()
    if not tops:
        return None, "no LDPlayer window"
    ctypes, _wt = _win()
    if ctypes.windll.user32.IsIconic(ctypes.c_void_p(tops[0][0])):
        return None, "LDPlayer is minimised"
    kids, _top = children_of(tops[0][0])
    return pick_render(kids, target_wh[0] / target_wh[1]) or tops[0][0], None


def grab(target_wh=(1600, 900)):
    """STEP 2: the game picture from LDPlayer's window, resized to target_wh -- or None (caller uses adb)."""
    if not ON or sys.platform != "win32":
        return None
    if time.time() < _stale["rest_until"]:              # 11/3: the copy was found frozen -- adb for now
        _grab["fail_t"] = time.time()
        return None
    import ctypes
    old_ctx, f = None, None
    try:
        f = ctypes.windll.user32.SetThreadDpiAwarenessContext
        f.restype, f.argtypes = ctypes.c_void_p, [ctypes.c_void_p]
        old_ctx = f(ctypes.c_void_p(-4))
    except Exception:                                   # noqa: BLE001
        f = None
    t0 = time.time()
    try:
        if not _grab["hwnd"] or time.time() - _grab["found_at"] > 60:
            hwnd, why = _find_game_window(target_wh)
            if not hwnd:
                _grab["hwnd"] = None
                return _note(why)
            _grab["hwnd"], _grab["found_at"] = hwnd, time.time()
        _c, wt = _win()
        r = wt.RECT()
        ctypes.windll.user32.GetClientRect(ctypes.c_void_p(_grab["hwnd"]), ctypes.byref(r))
        client = (r.right - r.left, r.bottom - r.top)
        if client != _grab["client"]:                   # window resized -> learn the drawn size again
            _grab["client"], _grab["size"] = client, None
        img = capture(_grab["hwnd"], "printwindow", size=_grab["size"])
        if not shape_ok(img, target_wh):
            _grab["hwnd"], _grab["size"] = None, None
            return _note("black or wrong shape" if img is not None else "no picture")
        if _grab["size"] is None:
            _grab["size"] = (img.shape[1], img.shape[0])
        out = cv2.resize(img, target_wh, interpolation=cv2.INTER_CUBIC)
        if stale_step(_stale, small_grey(out), time.time()) == "verify":
            return None                                 # this one look goes to adb; note_adb() decides
        _grab["n"] += 1
        _grab["total"] += time.time() - t0
        _grab["ok_t"] = time.time()
        return out
    except Exception as e:                              # noqa: BLE001 -- never break a screenshot
        _grab["hwnd"] = None
        return _note(f"error {e!r}"[:120])
    finally:
        if f is not None and old_ctx:
            try:
                f(ctypes.c_void_p(old_ctx))
            except Exception:                           # noqa: BLE001
                pass


def small_grey(img):
    """Pure: a tiny grey copy for 'is it the same picture' checks."""
    g = img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return cv2.resize(g, (80, 45), interpolation=cv2.INTER_AREA).astype(np.float32)


def stale_step(st, small, now):
    """Pure-ish (state in st): a new window copy arrived. -> 'ok' (use it) or 'verify' (check it against adb first)."""
    prev = st["small"]
    if prev is None or float(np.abs(prev - small).mean()) >= FROZEN_DIFF:
        st["small"], st["since"] = small, now
        return "ok"
    if now - st["since"] >= FROZEN_SEC and now - st["checked"] >= FROZEN_SEC:
        st["verify"], st["checked"] = small, now
        return "verify"
    return "ok"


def stale_verdict(st, adb_small, now):
    """Pure-ish: the adb picture taken for a 'verify'. -> True when the window copy was stale (rest set)."""
    v, st["verify"] = st["verify"], None
    if v is None or adb_small is None:
        return False
    if float(np.abs(v - adb_small).mean()) > STALE_DIFF:
        st["rest_until"], st["count"] = now + STALE_REST_SEC, st["count"] + 1
        st["small"] = None
        return True
    return False


def note_adb(img):
    """adb_helper calls this with every adb screenshot taken while FLASH is on."""
    if _stale["verify"] is None or img is None:
        return
    try:
        if stale_verdict(_stale, small_grey(img), time.time()):
            _grab["fail_t"] = time.time()
            if LOG:
                LOG(f"[flash] the window copy is FROZEN -- the same picture for {FROZEN_SEC}+ s while adb shows "
                    f"something else; adb screenshots only for {STALE_REST_SEC // 60} min "
                    f"({_stale['count']}x this run)")
    except Exception:                                   # noqa: BLE001
        pass


def tick(log, screenshot=None):
    """Called every cycle; measures at most every TEST_GAP_SEC. Never raises."""
    now = time.time()
    try:
        _speed_tick(log, now)
    except Exception:                                   # noqa: BLE001
        pass
    if now - _last["t"] < TEST_GAP_SEC:
        return
    _last["t"] = now
    try:
        if screenshot is None:
            import adb_helper
            screenshot = getattr(adb_helper, "adb_screenshot", adb_helper.screenshot)   # the real adb picture
        measure(log, screenshot)
    except Exception as e:                              # noqa: BLE001
        log(f"[flash test] failed: {e!r}")


def reset():
    _last.update({"t": 0.0, "pics": 0, "listed": False, "n": 0, "sums": {}})
    _speed.update({"t": None, "shots": None, "acts": None, "fast": (0, 0.0), "taps_fast": (0, 0.0), "sleeps": {}})
    _grab.update({"hwnd": None, "size": None, "client": None, "n": 0, "total": 0.0, "fails": 0, "noted": 0.0})
    _stale.update({"small": None, "since": 0.0, "verify": None, "checked": 0.0, "count": 0})   # rest is kept


def light(flash_on, fast_on, fast_resting, ok_t, fail_t, now=None):
    """Pure (11/2 speed light): (colour, text) for the window. green = FLASH looks working, amber = it fell back
    to adb in the last 2 min (LDPlayer minimised / hidden) or fast taps are resting, grey = off."""
    now = now or time.time()
    if not flash_on:
        return "grey", "FLASH off" + (" · fast taps on" if fast_on and not fast_resting else "")
    if fail_t and now - fail_t < 120 and (not ok_t or fail_t >= ok_t):
        return "amber", "FLASH falling back to adb -- is LDPlayer minimised?"
    if fast_on and fast_resting:
        return "amber", "FLASH on · fast taps resting after a failure"
    if not ok_t or now - ok_t > 300:
        return "grey", "FLASH on · no window looks yet"
    return "green", "FLASH on" + (" · fast taps on" if fast_on else "")


def light_now():
    try:
        import fast_input
        resting = time.time() < fast_input._st.get("rest_until", 0)
        return light(ON, fast_input.ON, resting, _grab.get("ok_t"), _grab.get("fail_t"))
    except Exception:                                   # noqa: BLE001
        return light(ON, False, False, _grab.get("ok_t"), _grab.get("fail_t"))
