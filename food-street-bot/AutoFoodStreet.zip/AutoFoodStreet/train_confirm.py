"""Companion to train_step.py: call after viewing train_step_panel.png
and deciding the dish name + where its card sits (or --skip if it can't
be safely identified, e.g. a raw ingredient rather than a cooked dish).
Adds the item to the persisted skip list either way, closes the panel,
and releases the session lock that train_step.py deliberately left held.

Two ways to specify the card position:
  <name> <card_index>   -- legacy, for a standard 3-card station
                            (assumes cx = RECIPE_CARD_X[card_index])
  <name> --cx <x>        -- for ANY station (including 4/5-card ones like
                            Soup Station): the exact x-coordinate of the
                            dish's card in train_step_panel.png, read
                            directly off that screenshot. This also
                            captures the dish's own panel illustration at
                            that position, so find_dish_in_panel can
                            locate its card by sight from now on instead
                            of trusting a fixed position.
"""
import os
import sys
import pickle

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

SKIP_PICKLE = os.path.join(BASE_DIR, "train_step_skip.pkl")
CURRENT_PICKLE = os.path.join(BASE_DIR, "train_step_current.pkl")
PANEL_SHOT = os.path.join(BASE_DIR, "event_pdf_extract", "train_step_panel.png")


def load_skip():
    if os.path.exists(SKIP_PICKLE):
        with open(SKIP_PICKLE, "rb") as f:
            return pickle.load(f)
    return []


def save_skip(skip):
    with open(SKIP_PICKLE, "wb") as f:
        pickle.dump(skip, f)


if __name__ == "__main__":
    # Real live-emulator actions below -- guarded the same way train_step.py
    # now is, after the 9/26 accidental-import incident (see CLAUDE.md).
    import cv2
    import session_lock
    from adb_helper import tap
    from find_and_center import CLOSE_X_LOC
    import order_fulfill as of

    if not os.path.exists(CURRENT_PICKLE):
        print("No pending item from train_step.py to confirm -- run that first.")
        sys.exit(1)

    with open(CURRENT_PICKLE, "rb") as f:
        current = pickle.load(f)

    args = sys.argv[1:]
    try:
        if args and args[0] == "--skip":
            print("Skipping this item without training it.")
        elif len(args) == 3 and args[1] == "--cx":
            name, cx = args[0], int(args[2])
            panel_img = cv2.imread(PANEL_SHOT)
            of.train_dish(current["icon"], name, card_index=None, panel_img=panel_img, panel_cx=cx)
            print(f"Trained '{name}' with a panel illustration at cx={cx} -- "
                  "future lookups will find its card by sight.")
        elif len(args) == 2:
            name, card_index = args[0], int(args[1])
            of.train_dish(current["icon"], name, card_index)
            print(f"Trained '{name}' -> card_index {card_index} (legacy fixed-position fallback).")
        else:
            print("Usage: python train_confirm.py <name> <card_index>")
            print("   OR: python train_confirm.py <name> --cx <x>")
            print("   OR: python train_confirm.py --skip")
            sys.exit(1)

        skip = load_skip()
        skip.append(current["slot_key"])
        save_skip(skip)

        tap(*CLOSE_X_LOC)
    finally:
        os.remove(CURRENT_PICKLE)
        session_lock.release()
