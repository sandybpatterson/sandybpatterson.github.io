"""11/2 (owner, approved 10/21 #15 c-e): Prep tab Favorites + History. Pure file helpers (testable without Tk).
File .prep_lists.json: {"favorites": {name: {item: qty}}, "history": [{"t": epoch, "items": {item: qty}}]}"""
import json
import os
import time

FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".prep_lists.json")
HISTORY_MAX = 10


# 11/2 (owner: "make me a recommended prep list in the favorites"): the ingredients behind the clipboard orders seen
# most in the logs (eggs: omelette / French toast / cornbread; milk + cheese: mac & cheese, Caprese; whipped cream:
# cream of mushroom; bread: French toast; cabbage: milk + salads) + the daily pet food (carrots, apples). All quick
# cooks (3-15 min) -- nothing that blocks a station for hours.
RECOMMENDED_NAME = "\u2b50 Recommended"
RECOMMENDED = {"egg": 4, "milk": 3, "cheese": 2, "whipped_cream": 2, "bread": 2, "cabbage": 4, "carrot": 4,
               "apple": 4}


def load(path=None):
    try:
        with open(path or FILE, encoding="utf-8") as f:
            d = json.load(f)
        d = {"favorites": dict(d.get("favorites") or {}), "history": list(d.get("history") or []),
             "seeded": bool(d.get("seeded"))}
    except Exception:                                   # noqa: BLE001
        d = {"favorites": {}, "history": [], "seeded": False}
    if not d["seeded"]:                                 # added once; a deleted Recommended stays deleted
        d["favorites"].setdefault(RECOMMENDED_NAME, dict(RECOMMENDED))
        d["seeded"] = True
    return d


def save(d, path=None):
    try:
        with open(path or FILE, "w", encoding="utf-8") as f:
            json.dump(d, f)
        return True
    except OSError:
        return False


def add_history(d, items, now=None):
    """Newest first, no back-to-back duplicate, max HISTORY_MAX."""
    items = {k: int(v) for k, v in (items or {}).items() if int(v) > 0}
    if not items:
        return d
    hist = [h for h in d["history"] if h.get("items") != items]
    d["history"] = ([{"t": now or time.time(), "items": items}] + hist)[:HISTORY_MAX]
    return d


def set_favorite(d, name, items):
    name = (name or "").strip()[:40]
    if name and items:
        d["favorites"][name] = {k: int(v) for k, v in items.items() if int(v) > 0}
    return d


def delete_favorite(d, name):
    d["favorites"].pop(name, None)
    return d


def describe(items, names=None, limit=4):
    """'Bread 3, Egg 4, +2 more' for a menu label."""
    names = names or {}
    parts = [f"{names.get(k, k.replace('_', ' ').title())} {n}" for k, n in items.items()]
    more = len(parts) - limit
    return ", ".join(parts[:limit]) + (f", +{more} more" if more > 0 else "")
