"""Street Food Truck (the teal truck that parks on the street beside the crop plots) -- v1, 10/4.

Finds the truck on the map like Pig Pen (multi-scale template + find_and_center), opens its
panel, and for every order slot taps the slot and then the green check mark, which hands the
items you already have to the truck (slots that are complete or that you cannot fill are left
alone). It NEVER taps the blue hand (request beacon), "Dismiss Truck", or anything gem-priced;
a gem-buy dialog is declined. Crops/lemons/fish for it still come from the other features
(Garden Plot, trees, boat). 10/17: one missing DISH per run is fast-travelled to and made (chase_one).
Built from rec_20261004_104156; NOT tested live."""
import json
import os
import time

import cv2
import numpy as np

import adb_helper
from adb_helper import screenshot, tap, swipe, pinch
import order_fulfill as of
from find_and_center import (find_and_center, StopRequested, close_any_open_panel,
                             check_stop, interruptible_sleep, dismiss_error_dialog, frame_diff)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(BASE_DIR, "run_log.txt")
TRUCK_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "street_truck.png"))
TITLE_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "street_truck_title.png"))
MATCH_THRESHOLD = 0.66                          # 10/17: real truck 0.68-0.88 (0.68+ even zoomed out); two false hits at 0.60/0.61 got tapped
SCALES = [0.55, 0.7, 0.85, 1.0, 1.15, 1.3]
FAST_SCALES = [0.6, 0.8, 1.0, 1.2]

# panel geometry on the 1600x900 emulator (from the 10/4 recording)
SLOT_CENTERS = [(405, 265), (588, 265), (770, 265),
                (405, 455), (588, 455), (770, 455),
                (405, 645), (588, 645), (770, 645)]
CHECK_BUTTON = (1166, 638)                      # green check = hand in what you have
DISH_PICTURE = (1075, 470)                      # big dish picture on the right: tapping it shows "Get Bread from the Bread Oven [?]"
DISH_ICON_BOX = (975, 365, 1175, 545)           # x1, y1, x2, y2 of that picture (for the not-trained picture save)
COUNT_BOX = (1000, 530, 1150, 590)              # the "0/4" under it
QUEUED_PAUSE_SEC = 8 * 60                       # a queued dish: give it time to cook before travelling again
CHASE_PAUSE_SEC = 5 * 60                        # a dish whose trip got nowhere is not chased again for 5 min
                                                # (11/9 owner: 30 min left ready milk + plantable greens idle)
REST_MAX_SEC = 5 * 60                           # 11/9: never rest longer than this without one real look
CHECK_REGION = (1070, 590, 1260, 690)           # x1, y1, x2, y2 -- lime when the button is usable
# NEVER TAP: blue hand (985,638), Dismiss Truck (1130,810)


def log(msg):
    ts = time.strftime("%Y-%m-%dT%H:%M:%S")
    line = f"[{ts}] [truck] {msg}"
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass
    try:
        print(line)
    except (AttributeError, OSError):
        pass


def _match(img, tpl, scales):
    best, loc = 0.0, None
    th, tw = tpl.shape[:2]
    for s in scales:
        w, h = int(tw * s), int(th * s)
        if w < 20 or h < 20 or w >= img.shape[1] or h >= img.shape[0]:
            continue
        r = cv2.matchTemplate(img, cv2.resize(tpl, (w, h)), cv2.TM_CCOEFF_NORMED)
        _, v, _, l = cv2.minMaxLoc(r)
        if v > best:
            best, loc = float(v), (l[0] + w // 2, l[1] + h // 2)
    return loc, best


def find_street_truck(img, fast=False):
    """find_fn for find_and_center: (loc, confidence); loc None below the threshold."""
    if TRUCK_TEMPLATE is None:
        return None, 0.0
    if fast:
        small = cv2.resize(img, (img.shape[1] // 2, img.shape[0] // 2))
        loc, v = _match(small, cv2.resize(TRUCK_TEMPLATE, None, fx=0.5, fy=0.5), FAST_SCALES)
        if loc is not None:
            loc = (loc[0] * 2, loc[1] * 2)
    else:
        loc, v = _match(img, TRUCK_TEMPLATE, SCALES)
    return (loc if v >= MATCH_THRESHOLD else None), v


def panel_open(img):
    """The 'Food Truck' panel: its title text top-left."""
    if TITLE_TEMPLATE is None:
        return False
    region = img[100:200, 280:540]
    if region.shape[0] < TITLE_TEMPLATE.shape[0] or region.shape[1] < TITLE_TEMPLATE.shape[1]:
        return False
    r = cv2.matchTemplate(region, TITLE_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    return float(r.max()) >= 0.8


def check_button_ready(img):
    """True when the green check (hand in) is showing and lime/usable."""
    x1, y1, x2, y2 = CHECK_REGION
    hsv = cv2.cvtColor(img[y1:y2, x1:x2], cv2.COLOR_BGR2HSV)
    lime = cv2.inRange(hsv, (35, 150, 140), (60, 255, 255))
    return int((lime > 0).sum()) > 4000


def _decline_gem_dialog(stop_flag=None):
    no, _ = of.find_no_button(screenshot())
    if no is not None:
        log("A gem-buy dialog appeared -- declining (No).")
        tap(*no)
        interruptible_sleep(1.0, stop_flag)
        return True
    return False


# --- Way back from a fast-travel trip (10/17) ------------------------------------------------------
# After "Get Bread from the Bread Oven [?]" the camera sits at the Bread Oven and the truck is out of
# sight: a full search took minutes. So the search's own moves (at max zoom-out) are remembered per
# destination, and the next time the bot comes back from that station it zooms out and replays them.
ROUTES_FILE = os.path.join(BASE_DIR, ".truck_routes.json")
ROUTE_ANCHOR = (900, 450)                       # where the search's swipes start (find_and_center)
ROUTE_HOP_PX = 300                              # replay in hops no longer than this
_back_from = None                               # the station the last trip went to (camera is there now)


def _routes():
    try:
        with open(ROUTES_FILE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _route_key(where):
    return " ".join("".join(ch if ch.isalnum() else " " for ch in str(where).lower()).split())


def _find_route(where):
    import difflib
    routes, key = _routes(), _route_key(where)
    if key in routes:
        return key, routes[key]
    close = difflib.get_close_matches(key, list(routes), n=1, cutoff=0.8)   # "Bread Ovem" = "Bread Oven"
    return (close[0], routes[close[0]]) if close else (key, None)


def _zoom_out_max(stop_flag=None):
    for _ in range(3):
        before = screenshot()
        pinch(800, 450, 350, 80, steps=15)
        interruptible_sleep(1, stop_flag)
        if frame_diff(before, screenshot()) < 15.0:
            return


def _replay(vec, stop_flag=None):
    """Moves the camera by the finger vector (dx, dy) in short swipes, like the search does."""
    import math
    dx, dy = vec
    n = max(1, math.ceil(math.hypot(dx, dy) / ROUTE_HOP_PX))
    for _ in range(n):
        check_stop(stop_flag)
        x0, y0 = ROUTE_ANCHOR
        swipe(x0, y0, int(x0 + dx / n), int(y0 + dy / n), 500)
        interruptible_sleep(0.7, stop_flag)


def _net(moves):
    return [sum(m[0] for m in moves), sum(m[1] for m in moves)]


def open_truck_panel(stop_flag=None):
    global _back_from
    img = screenshot()
    if panel_open(img):
        _back_from = None
        return True
    try:                                            # 11/8: the gold truck icon in the bottom bar opens the panel
        import truck_panel
        loc, sc = truck_panel.find_icon(img)
        if loc is not None:
            log(f"[food truck] tapping the truck icon in the bottom bar at {loc} (match {sc:.2f}).")
            tap(*loc)
            for _ in range(4):
                interruptible_sleep(1.0, stop_flag)
                dismiss_error_dialog()
                if panel_open(screenshot()):
                    _back_from = None
                    return True
            log("[food truck] the icon did not open the Food Truck panel (truck not here yet?) -- closing, never 'Get Truck Now'.")
            close_any_open_panel(quiet=True, thorough=True)
            return False
    except StopRequested:
        raise
    except Exception as e:                          # noqa: BLE001
        log(f"[food truck] icon check failed (ignored): {e!r}")
    back, replayed = _back_from, None
    _back_from = None
    if not back and time.time() < _SEARCH_REST[0]:          # 11/9: a full search just missed -- rest, then retry
        log(f"[food truck] not searching the map again until {time.strftime('%H:%M', time.localtime(_SEARCH_REST[0]))} "
            "(the last full search found nothing; it will try again then -- a miss does not mean the truck left).")
        return False
    if back:
        key, route = _find_route(back)
        if route:
            log(f"Coming back from {back}: zooming out and taking the remembered way back {route}.")
            _zoom_out_max(stop_flag)
            _replay(route, stop_flag)
            replayed = route
        else:
            log(f"Coming back from {back}: no way back remembered yet -- searching (the moves get remembered).")
    if not back and PLOTS_FIRST:
        _plots_first(stop_flag)
    trail = []
    t_search = time.time()
    # 11/10 (Muse): the final zoom-in lost the truck 6 of 6 times (the panel opened from the pre-zoom spot anyway) -> off.
    loc, conf = find_and_center(find_street_truck, label="Food Truck", zoom_in_after=False, stop_flag=stop_flag, trail=trail,
                                max_sec=SEARCH_MAX_SEC, probe_min=SEARCH_PROBE_MIN, skip_zoom_at=SKIP_ZOOM_AT)
    _SEARCH_REST[0] = 0.0 if loc is not None else time.time() + SEARCH_REST_SEC
    if _PLOTS_HOP[0]:
        _PLOTS_HOP[0] = False
        log(f"[food truck] from the crop plots: {'found' if loc is not None else 'not found'} after "
            f"{time.time() - t_search:.0f} s of searching" + ("" if loc is not None else " -- the spiral ran too"))
    if back and loc is not None:
        moves = [m for m in trail if m != "zoomout"]
        if replayed is not None or "zoomout" in trail:     # both measured at max zoom-out
            net = _net(([replayed] if replayed else []) + moves)
            routes = _routes()
            routes[key] = net
            try:
                with open(ROUTES_FILE, "w", encoding="utf-8") as fh:
                    json.dump(routes, fh)
                log(f"Way back from {back} remembered: {net}" + (" (unchanged)" if net == replayed else "."))
            except OSError:
                pass
    if loc is None:
        log(f"Street food truck not found on the map (best match {conf:.2f}) -- it may not be parked "
            "right now. Nothing done.")
        return False
    log(f"Truck found at {loc} (confidence {conf:.2f}) -- tapping it.")
    tap(*loc)
    for _ in range(4):
        interruptible_sleep(1.0, stop_flag)
        dismiss_error_dialog()
        if panel_open(screenshot()):
            return True
    log("Tapped the truck but the Food Truck panel did not open.")
    return False


# 11/9 (Muse muse/truck-search-fix.md, fixes 3-5): the map spiral took 373-752 s per search and lost the truck on the
# final zoom-in 3 of 3 times. Successful finds today took <= 125 s, so the spiral gets SEARCH_MAX_SEC; partial matches
# under SEARCH_PROBE_MIN are not probed (0.3-0.45 were decorations); a match >= SKIP_ZOOM_AT is tapped without the final
# zoom-in; after a miss the map is not searched again for SEARCH_REST_SEC (a time-boxed retry, never a permanent rest --
# the morning's misses were search failures, the truck was there all day). Coming back from a trip always searches.
SEARCH_MAX_SEC = 150
SEARCH_PROBE_MIN = 0.45
SKIP_ZOOM_AT = 0.8
SEARCH_REST_SEC = 20 * 60
_SEARCH_REST = [0.0]
# 11/9 (owner: "Muse seemed to think that we just had to zoom out"): the search ALREADY zooms out first, but from
# wherever the camera is. Today zoom-out found the truck 6 times (only when the camera was already near it), the spiral
# ~20 times after 2-10 min, and ~10 searches missed. The truck parks next to the crop plots (owner 10/17), so a fresh
# search first fast-travels to the Garden Plot (the Orders-board route the plot round uses), then searches -- its first
# look and its zoom-out now start right next to the truck. Coming back from a trip keeps the remembered way back.
PLOTS_FIRST = True
_PLOTS_HOP = [False]


def _plots_first(stop_flag=None):
    """Hop to the crop plots before a fresh truck search. Never raises; a failed hop just searches from here."""
    try:
        import garden_check as gc
        log("[food truck] hopping to the crop plots first (the truck parks next to them), then zooming out.")
        if gc.travel_via_orders_board(stop_flag, max_trips=2):
            _PLOTS_HOP[0] = True
            close_any_open_panel(quiet=True, thorough=True)
            return True
        log("[food truck] could not reach the crop plots from the Orders board -- searching from here.")
    except StopRequested:
        raise
    except Exception as e:                          # noqa: BLE001
        log(f"[food truck] plot hop failed (searching from here): {e!r}")
    return False

_chase_paused = []                                  # [(dish picture, time it may be chased again)]
_PAUSED = {}                                        # 11/9: dish name -> time its paused chase may start again
_REST_SINCE = [0.0]                                 # 11/9: when the current rest began (REST_MAX_SEC cap)


def _read_count(img):
    """(have, need) from the '0/4' under the dish picture, or None."""
    try:
        import re
        import popup_ocr
        m = re.search(r"(\d+)\s*/\s*(\d+)", popup_ocr.read_text(img, COUNT_BOX) or "")
        return (int(m.group(1)), int(m.group(2))) if m else None
    except Exception:                              # noqa: BLE001
        return None


def _tooltip_name(img, x, y, stop_flag=None):
    """11/8: the selected slot's dish name from the game's own tooltip -- tap the dish picture, read "Get X from the
    Y", do NOT tap the '?' (no travel), tap the slot again to close it. Learned once per picture (truck_panel)."""
    import event_orders
    import truck_panel
    try:
        tap(*DISH_PICTURE)
        interruptible_sleep(0.3, stop_flag)
        t_img = screenshot()
        q, _qc = event_orders.find_tooltip_question(t_img)
        if q is None:
            _decline_gem_dialog(stop_flag)
            return None
        import popup_ocr
        bx = event_orders.TOOLTIP_BOX
        info = event_orders.parse_tooltip(popup_ocr.read_text(
            t_img, (q[0] + bx[0], q[1] + bx[1], q[0] + bx[2], q[1] + bx[3])) or "")
        tap(x, y)                                  # close the tooltip (the slot stays selected)
        interruptible_sleep(0.4, stop_flag)
        if info and info.get("name"):
            truck_panel.learn_name(img, x, y, info["name"])
            return info["name"]
    except StopRequested:
        raise
    except Exception as e:                         # noqa: BLE001
        log(f"[food truck] name read failed (ignored): {e!r}")
    return None


CROP_PAUSE_SEC = 30 * 60


def _is_crop(name):
    try:
        import recipe_book as rb
        return rb.load()["items"][rb.resolve(name)].get("kind") == "crop"
    except Exception:                              # noqa: BLE001
        return False


def grew_while_waiting(since):
    """True when this trip ended on a crop at 0 that is still growing (order_fulfill.GROWING_WAIT newer than since)."""
    try:
        return float(of.GROWING_WAIT.get("t") or 0) >= since
    except Exception:                                 # noqa: BLE001
        return False


def chase_one(missing, stop_flag=None, slots=None):
    """Fast travel from the truck to ONE missing dish and make it there, through order_fulfill's
    live-tested after-travel path (panel, collection blocker, ingredients, Make). Same rules as the
    clipboard: no gems, never Skip / Unlock / buy. Returns the trip's status, or None if no trip."""
    global _back_from
    import event_orders
    for i, (x, y) in missing:
        check_stop(stop_flag)
        tap(x, y)
        interruptible_sleep(0.7, stop_flag)
        before = screenshot()
        x1, y1, x2, y2 = DISH_ICON_BOX
        icon = before[y1:y2, x1:x2].copy()
        now = time.time()
        _chase_paused[:] = [(p, u) for p, u in _chase_paused if u > now]
        if any(until > now and event_orders._icon_score(p, icon) >= 0.9 for p, until in _chase_paused):
            log(f"Slot {i}: this dish's last trip got nowhere -- trying a different slot.")
            continue
        try:
            import truck_panel
            count = truck_panel.read_have_need(before) or _read_count(before)
        except Exception:                          # noqa: BLE001
            count = _read_count(before)
        tap(*DISH_PICTURE)
        interruptible_sleep(0.3, stop_flag)
        img = screenshot()
        q, qc = event_orders.find_tooltip_question(img)
        if q is None:
            if not _decline_gem_dialog(stop_flag):
                log(f"Slot {i}: no travel tooltip after tapping the dish picture (best '?' {qc:.2f}).")
            continue
        tap(*q)                                    # the tooltip lasts ~4 s: travel first, read its text after
        bx = event_orders.TOOLTIP_BOX
        try:
            import popup_ocr
            text = popup_ocr.read_text(img, (q[0] + bx[0], q[1] + bx[1], q[0] + bx[2], q[1] + bx[3]))
        except Exception:                          # noqa: BLE001
            text = ""
        info = event_orders.parse_tooltip(text)
        interruptible_sleep(1.0, stop_flag)
        if not info or info["plot"]:
            why = (f"could not read the travel tooltip ({text!r})" if not info else
                   f"{info['name']} is a crop -- the Garden Plot feature grows those")
            # 11/10 (owner): Corn came first every run and ended it here, so Cream (whipped cream) never got a turn.
            # Now: pause that dish (crops for CROP_PAUSE_SEC -- the plot rounds grow them) and try the next one.
            log(f"Slot {i}: {why}; trying the next dish.")
            _chase_paused.append((icon, time.time() + (CROP_PAUSE_SEC if info else CHASE_PAUSE_SEC)))
            close_any_open_panel(quiet=True, thorough=True)
            continue
        name = info["name"]
        try:
            import truck_panel
            truck_panel.learn_name(before, x, y, name)        # 11/8: the tab shows the dish by name from now on
        except Exception:                          # noqa: BLE001
            pass
        deficit = (count[1] - count[0]) if count and count[1] > count[0] else None
        try:                                       # 11/8: plan for every slot of this dish, not just this one
            import truck_panel
            tot = truck_panel.total_short(slots or [], name, count[0] if count else None)
            if tot and (deficit is None or tot > deficit):
                n_sl = sum(1 for s_ in (slots or []) if s_.get("state") == "order"
                           and (s_.get("name") or "").lower() == name.lower())
                log(f"[food truck] {n_sl} slots want {name} -- cooking for {tot} in all, not just this slot's "
                    f"{deficit if deficit is not None else '?'}.")
                deficit = tot
        except Exception:                          # noqa: BLE001
            pass
        try:
            import truck_panel as _tp
            _tp.update(working=name)
        except Exception:                          # noqa: BLE001
            pass
        log(f"Slot {i}: the truck wants {name}" + (f" ({count[0]}/{count[1]})" if count else "") +
            f" -- fast travel to {info['where']}.")
        item = {"tap_loc": (x, y), "icon": icon, "slot_key": f"truck:{name}", "deficit": deficit}
        t_trip = time.time()
        r = of.cook_after_travel(item, stop_flag, still_open=panel_open, dish_name=name)
        status = r.get("status") if isinstance(r, dict) else str(r)
        if status == "recursed_ingredient" and grew_while_waiting(t_trip):
            status = "crop_growing"            # 11/11: onion at 0 while growing -> re-chased every 3 min; pause it like a block
            log(f"[food truck] {name}: its crop is still growing (none to plant) -- leaving it for {CHASE_PAUSE_SEC // 60} min.")
        log(f"Slot {i}: trip result for {name}: {status}.")
        if status in ("queued", "already_cooking"):  # cooking now: don't travel to it again until it is done
            _chase_paused.append((icon, time.time() + QUEUED_PAUSE_SEC))
            note_cooking(name)
        elif status not in ("recursed_ingredient", "retry_next_ingredient", "collected_blocker"):
            _chase_paused.append((icon, time.time() + CHASE_PAUSE_SEC))
            _PAUSED[name.lower()] = time.time() + CHASE_PAUSE_SEC     # 11/9: rest_until counts it as "busy"
        close_any_open_panel(quiet=True, thorough=True)
        # Way back (review fix 10/17): walk back to the truck NOW, from the station itself, so the
        # remembered route really starts at that station -- and only when the trip ended there.
        if status in ("queued", "not_trained", "dish_card_not_found", "collected_blocker", "panel_not_opened"):
            _back_from = info["where"]
            if open_truck_panel(stop_flag):
                log(f"Back at the truck after the {info['where']} trip.")
                if status != "collected_blocker":    # 11/8: collected dishes -> main() hands them in now
                    close_any_open_panel(quiet=True, thorough=True)
        _back_from = None
        return status
    return None


HOLD_PRESS_MS = 250                             # 11/9: held press on the check when a quick tap did not take
HANDIN_RETRY_SEC = 10 * 60
_HANDIN_FAILED = {}                                 # dish name (lower) -> no hand-in tap before this time
_PICS_SAVED = {}


def _save_truck_pic(img, tag, per_run=3):
    """A few pictures per tag per run in templates/food_truck/seen (they go out with Send logs)."""
    try:
        if img is None or _PICS_SAVED.get(tag, 0) >= per_run:
            return
        _PICS_SAVED[tag] = _PICS_SAVED.get(tag, 0) + 1
        folder = os.path.join(BASE_DIR, "templates", "food_truck", "seen")
        os.makedirs(folder, exist_ok=True)
        cv2.imwrite(os.path.join(folder, f"{time.strftime('%Y%m%d_%H%M%S')}_{tag}.jpg"), img,
                    [cv2.IMWRITE_JPEG_QUALITY, 70])
    except Exception:                              # noqa: BLE001
        pass


_COOKING = {}                                       # dish name (lower) -> time its batch should be ready
_REST_LOGGED = [None]
_RACE_LOGGED = [None]


def _cook_secs(name):
    """Recipe-book cook time of a dish by name (None when unknown)."""
    try:
        import recipe_book as rb
        return rb.load()["items"][rb.resolve(name)].get("cook_sec")
    except Exception:                              # noqa: BLE001
        return None


def note_cooking(name, now=None):
    """11/8 (owner picked idea 1): a queued truck dish -> remember when its batch is ready."""
    if not name:
        return
    now = time.time() if now is None else now
    secs = _cook_secs(name) or QUEUED_PAUSE_SEC
    _COOKING[name.lower()] = now + max(60, min(secs, 3 * 3600))
    try:
        import truck_panel
        truck_panel.update(cooking={k: v for k, v in _COOKING.items() if v > now})
    except Exception:                              # noqa: BLE001
        pass


LEAVE_MARGIN_SEC = 120                              # a dish must be ready this long before the truck leaves


def race_plan(names, leaving_sec, cook_of, elapsed=0):
    """Pure (11/8, owner picked idea 2): which short dishes to chase, quickest first, and which to skip because they
    can't be ready before the truck leaves. names = dish names; cook_of(name) -> seconds or None (unknown dishes go
    after the known ones and are never skipped). Returns (ordered, skipped)."""
    left = None if not leaving_sec else leaving_sec - elapsed
    known, unknown, skipped = [], [], []
    for n in names:
        c = cook_of(n)
        if c is None:
            unknown.append(n)
        elif left is not None and c > left - LEAVE_MARGIN_SEC:
            skipped.append(n)
        else:
            known.append((c, n))
    return [n for _c, n in sorted(known, key=lambda z: z[0])] + unknown, skipped


def busy_until(cooking, paused, now=None):
    """Pure (11/9): name -> when it is worth looking again -- the later of its batch being ready and its pause ending."""
    now = time.time() if now is None else now
    out = {}
    for d in (cooking or {}, paused or {}):
        for k, v in d.items():
            if v and v > now:
                out[k.lower()] = max(out.get(k.lower(), 0), v)
    return out


def rest_until(state, cooking, now=None):
    """Pure (11/8): every dish the truck is still short of is already cooking -> (time to come back, names); else
    (None, None). Nothing to rest on when no state was read in the last 2 hours."""
    now = time.time() if now is None else now
    if not state or now - state.get("t", 0) > 2 * 3600:
        return None, None
    try:
        import truck_panel
        rows = truck_panel.dish_rows(state.get("slots", []))
    except Exception:                              # noqa: BLE001
        return None, None
    short = [r for r in rows if r.get("have") is None or not r.get("need") or r["have"] < r["need"]]
    left = (state.get("leaving_sec") or 0) - (now - state.get("t", now)) if state.get("leaving_sec") else None
    _ok, late = race_plan([r.get("name") for r in short], left, _cook_secs)
    short = [r for r in short if r.get("name") not in late]
    if not short:
        return None, None
    ready = []
    for r in short:
        until = cooking.get((r.get("name") or "").lower())
        if not until or until <= now:
            return None, None
        ready.append(until)
    return min(ready), [r["name"] for r in short]


def group_need(slots, fallback=None):
    """Pure (11/8): how many of one dish the truck takes in one hand-in = the sum of every open slot's need."""
    total = 0
    for s in slots:
        n = s.get("need") or s.get("want") or fallback
        if not n:
            return fallback
        total += n
    return total


def _hand_in_pass(stop_flag=None):
    """Read the open truck panel, hand in every slot we have enough for, return (state, missing slots, module)."""
    try:                                            # 11/8: read the panel for the Food Truck tab
        import truck_panel
        st_ = truck_panel.read_panel(screenshot())
        prev = truck_panel.load()
        kept, odd = truck_panel.sane_leaving(st_.get("leaving_sec"), prev)
        if odd:
            log(f"[food truck] 'Leaving in' read as {st_.get('leaving_sec')} s "
                f"({truck_panel.LAST_LEAVING_TEXT[0]!r}) -- far off the clock, keeping {kept} s until it reads the same "
                "again.")
        st_["leaving_sec"], st_["leaving_odd"] = kept, odd
    except Exception as e:                          # noqa: BLE001
        truck_panel = None
        st_ = {"leaving_sec": None, "slots": [{"i": i, "state": "order", "want": None, "name": None}
                                              for i in range(1, len(SLOT_CENTERS) + 1)]}
        log(f"[food truck] panel read failed (ignored): {e!r}")
    handed = 0
    missing = []                                    # slots the truck still wants and we do not have
    # 11/8 (owner: "it keeps cycling through all the food truck orders clicking on them"): every slot of one
    # dish shows the SAME storage count, so tap ONE slot per dish. Only when we have enough is the next slot of
    # that dish tapped (to hand it in too); otherwise its count is copied to the rest of the group untapped.
    groups = truck_panel.dish_groups(st_["slots"]) if truck_panel else [[sl] for sl in st_["slots"]
                                                                        if sl.get("state") == "order"]
    for group in groups:
        short = False
        for sl in group:
            i = sl["i"]
            x, y = SLOT_CENTERS[i - 1]
            if short:                                # same dish, same storage count: no need to tap it
                sl["have"], sl["need"] = group[0].get("have"), sl.get("need") or group[0].get("need")
                sl["name"] = sl.get("name") or group[0].get("name")
                continue                             # one chase per dish is enough (chase_one cooks for all of them)
            check_stop(stop_flag)
            dismiss_error_dialog()
            if not panel_open(screenshot()):
                log("The truck panel closed unexpectedly -- stopping.")
                break
            tap(x, y)
            interruptible_sleep(0.7, stop_flag)
            img = screenshot()
            hn = (truck_panel.read_have_need(img) if truck_panel else None) or _read_count(img)
            if hn:
                sl["have"], sl["need"] = hn
            if not sl.get("name") and sl is not group[0]:
                sl["name"] = group[0].get("name")    # same picture as the slot already tapped
            if truck_panel and not sl.get("name"):
                sl["name"] = _tooltip_name(img, x, y, stop_flag)
            what = f"{sl.get('name') or 'dish'}" + (f" {hn[0]}/{hn[1]}" if hn else " (count not read)")
            # 11/8 live: the green check is lime even when we have too few -- tapping it then asks for gems.
            # 11/8 (owner): every slot of a dish shows the same storage count, and each ORDER (slot) is handed in on its
            # own -- 3 in stock with two Mac & Cheese orders of 3 is enough for ONE of them. Hand in this slot when the
            # count covers it; the next slot of the dish is tapped afterwards and shows what is left.
            if hn and hn[0] < hn[1]:
                n_more = len(group) - group.index(sl) - 1
                log(f"Slot {i}: {what} -- not enough yet" +
                    (f" (same stock for its {n_more} other order(s), not tapping them)" if n_more else "") + ".")
                missing.append((i, (x, y)))
                short = True
                continue
            key = (sl.get("name") or "").lower()
            if _HANDIN_FAILED.get(key, 0) > time.time():
                log(f"Slot {i}: {what} -- its last hand-in tap did not take; not tapping the check again yet.")
                missing.append((i, (x, y)))
                short = True
                continue
            if check_button_ready(img):
                _save_truck_pic(img, "handin_before")
                tap(*CHECK_BUTTON)
                interruptible_sleep(1.2, stop_flag)
                if _decline_gem_dialog(stop_flag):
                    log(f"Slot {i}: {what} -- hand-in opened a gem dialog -- declined, nothing handed in.")
                    missing.append((i, (x, y)))
                    short = True
                    continue
                # 11/8 (owner: "it said it was handed in but it didn't submit it"): only call it handed in when the
                # slot really shows the game's big check mark afterwards.
                after = screenshot()
                if truck_panel and truck_panel.done_score(after, x, y) < truck_panel.DONE_MIN:
                    interruptible_sleep(1.0, stop_flag)
                    after = screenshot()
                if truck_panel and truck_panel.done_score(after, x, y) < truck_panel.DONE_MIN:
                    # 11/9: the quick tap only cleared the selection ("Select an order on the left") -- pick the slot
                    # again, let the pane settle, then HOLD the same green check for a moment (same button, no
                    # new spot; a gem question is still declined).
                    log(f"Slot {i}: {what} -- quick tap on the check did not hand it in; trying a held press.")
                    tap(x, y)
                    interruptible_sleep(1.5, stop_flag)
                    again = screenshot()
                    if check_button_ready(again):
                        _save_truck_pic(again, "handin_retry_before")
                        swipe(CHECK_BUTTON[0], CHECK_BUTTON[1], CHECK_BUTTON[0], CHECK_BUTTON[1], HOLD_PRESS_MS)
                        interruptible_sleep(1.5, stop_flag)
                        if _decline_gem_dialog(stop_flag):
                            log(f"Slot {i}: {what} -- the held press opened a gem dialog -- declined.")
                        after = screenshot()
                    else:
                        log(f"Slot {i}: {what} -- after picking the slot again the check button was not there.")
                if truck_panel is None or truck_panel.done_score(after, x, y) >= truck_panel.DONE_MIN:
                    handed += 1
                    sl["state"] = "done"
                    log(f"Slot {i}: {what} -- HANDED IN (the slot shows the check mark now).")
                else:
                    log(f"Slot {i}: {what} -- tapped the green check but the slot did NOT turn done; not counting it "
                        f"and not trying this dish again for {HANDIN_RETRY_SEC // 60} min.")
                    missing.append((i, (x, y)))
                    short = True
                    _HANDIN_FAILED[key] = time.time() + HANDIN_RETRY_SEC
                    _save_truck_pic(after, "handin_failed")
            else:
                log(f"Slot {i}: {what} -- check button not available.")
    if truck_panel:
        truck_panel.save(st_)
        log(f"[food truck] {truck_panel.summary(st_)}")
    log(f"Handed in on {handed} slot(s).")
    return st_, missing


def _race_order(missing, st_):
    """11/8 idea 2: put the missing slots in race_plan order and drop dishes that can't make it before the truck leaves."""
    by_i = {sl["i"]: sl.get("name") for sl in st_.get("slots", [])}
    names = []
    for i, _xy in missing:
        if by_i.get(i) not in names:
            names.append(by_i.get(i))
    order, late = race_plan(names, st_.get("leaving_sec"), lambda n: _cook_secs(n) if n else None)
    if late:
        left = st_.get("leaving_sec") or 0
        log(f"[food truck] skipping {', '.join(late)} -- it cooks longer than the {left // 60} min left before the "
            "truck leaves.")
    if len(order) > 1 and _RACE_LOGGED[0] != (tuple(order), tuple(late)):
        _RACE_LOGGED[0] = (tuple(order), tuple(late))
        log(f"[food truck] quickest first: {', '.join(n or 'a dish' for n in order)}.")
    try:
        import truck_panel
        truck_panel.update(skipped=[n for n in late if n], order=[n for n in order if n])
    except Exception:                              # noqa: BLE001
        pass
    order = [n for n in order if not _is_crop(n)] + [n for n in order if _is_crop(n)]   # 11/10: crops last
    rank = {n: k for k, n in enumerate(order)}
    return sorted([m for m in missing if by_i.get(m[0]) in rank], key=lambda m: rank[by_i.get(m[0])])


def main(stop_flag=None):
    # 11/8 (owner picked idea 1): every dish the truck is short of is already cooking -> don't open the truck,
    # travel or re-read anything until the soonest batch is ready; the other ticked jobs get that time.
    try:
        import truck_panel
        # 11/9 (logs 19:16-19:19: the truck was opened every ~18 s while both dishes were blocked -- cheese waiting
        # on milk, no ripe apples): a dish whose last trip got nowhere is paused CHASE_PAUSE_SEC, and a paused dish
        # counts like a cooking one here, so the job rests until the first pause / batch ends.
        # 11/9 (owner: "i would rather it keep busy" -- it rested 26 min while milk waited to be collected and greens
        # could be planted): only COOKING dishes count again (a paused dish no longer rests the job), and one real
        # look happens at least every REST_MAX_SEC -- that look collects, plants and cooks what it can.
        until, names = rest_until(truck_panel.load(), _COOKING)
        now = time.time()
        if until and _REST_SINCE[0] and now - _REST_SINCE[0] >= REST_MAX_SEC:
            until, names = None, None                  # rested long enough: take a real look now
        if until and not _REST_SINCE[0]:
            _REST_SINCE[0] = now
        if not until:
            _REST_SINCE[0] = 0.0
    except Exception:                               # noqa: BLE001
        until, names = None, None
    if until:
        key = (round(until), tuple(names))
        if _REST_LOGGED[0] != key:
            _REST_LOGGED[0] = key
            log(f"[food truck] resting -- {', '.join(n or 'a dish' for n in names)} cooking; next look at "
                f"{time.strftime('%H:%M', time.localtime(min(until, _REST_SINCE[0] + REST_MAX_SEC)))}.")
        return
    log("=== street food truck run start ===")
    try:
        close_any_open_panel(thorough=True)
        if not open_truck_panel(stop_flag):
            close_any_open_panel(quiet=True, thorough=True)
            log("=== street food truck run end (no panel) ===")
            return
        st_, missing = _hand_in_pass(stop_flag)
        # one picture of the final panel state per run, for training / debugging
        try:
            folder = os.path.join(BASE_DIR, "templates", "street_truck_debug")
            os.makedirs(folder, exist_ok=True)
            cv2.imwrite(os.path.join(folder, f"{int(time.time())}.png"), screenshot())
        except Exception:                          # noqa: BLE001
            pass
        if missing:
            missing = _race_order(missing, st_)
        if missing and panel_open(screenshot()):
            r = chase_one(missing, stop_flag, slots=st_.get("slots"))           # 10/17: fast travel to make one missing dish
            if r == "collected_blocker" and panel_open(screenshot()):
                # 11/8 (owner picked idea 3): the trip collected finished dishes and walked back to the truck --
                # hand them in now instead of at the next run.
                log("[food truck] the trip collected finished dishes -- handing them in right away.")
                _hand_in_pass(stop_flag)
                close_any_open_panel(quiet=True, thorough=True)
            if r is not None:
                log(f"=== street food truck run end (trip: {r}) ===")
                return
        close_any_open_panel(quiet=True, thorough=True)
        log("=== street food truck run end ===")
    except StopRequested:
        log("=== street food truck run stopped early by user ===")
        raise
