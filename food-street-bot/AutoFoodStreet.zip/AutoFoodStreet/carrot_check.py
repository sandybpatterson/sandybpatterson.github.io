"""Runs locally, unattended, via Windows Task Scheduler — no AI/API calls.
Finds the 3x3 crop grid (anchored off the already-reliable Pig Pen
detector, since matching on crop appearance directly is unreliable — plant
growth stage changes constantly), taps all 9 plots (harvests anything
ready, no-ops on anything still growing, opens the planting bar on any
empty plot), then fills every empty plot with Carrot using the game's own
auto-advance-to-next-empty-plot behavior. Logs everything. Never touches
gem-spend UI.
"""
import os
import sys
import time
import datetime
import cv2

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
import numpy as np
from adb_helper import screenshot, tap, swipe, pinch, back
from pig_pen_check import find_pig_pen, spiral_moves, MAX_SEARCH_STEPS, HOP_PX

LOG = os.path.join(BASE_DIR, "run_log.txt")
PLANTING_BAR_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "planting_bar.png"))
BAR_MATCH_THRESHOLD = 0.8  # fixed screen-space UI, so this can be strict

# Calibrated from the farm cluster on 9/23: grid center relative to Pig
# Pen's matched location, expressed at scale=1.0 so it can be scaled by
# whatever zoom level Pig Pen was actually found at.
GRID_OFFSET_AT_SCALE1 = (-371.1, 230.0)

# The 9 cell centers relative to the grid's own center, also at scale=1.0.
CELL_OFFSETS_AT_SCALE1 = [
    (-44.4, -27.8), (33.3, -44.4), (111.1, -61.1),   # back row
    (-77.8, 16.7), (0.0, 0.0), (77.8, -16.7),         # middle row
    (-111.1, 61.1), (-33.3, 44.4), (44.4, 27.8),      # front row
]

CARROT_ICON = (1265, 270)  # fixed HUD position within the planting bar


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] {msg}\n")
    try:
        print(f"[{ts}] {msg}")
    except (AttributeError, OSError):
        pass  # no console attached (e.g. launched via pythonw.exe) — log file still gets it


def planting_bar_open(img):
    region = img[95:130, 550:1050]
    res = cv2.matchTemplate(region, PLANTING_BAR_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    return max_val >= BAR_MATCH_THRESHOLD


def unexpected_dialog_open(img):
    """A stray tap can land on a decoration and open its info card — a
    big solid-gradient panel, very different from the busy, colorful map.
    Cheap variance check catches this without needing a template for
    every possible decoration in the game."""
    region = img[150:750, 400:1200]
    return float(np.std(region)) < 25.0


def main():
    log("=== carrot run start ===")
    img = screenshot()
    loc, conf, scale = find_pig_pen(img, return_scale=True)

    if loc is None:
        log(f"Pig Pen not visible (best match {conf:.2f}) — zooming out, then searching...")
        pinch(800, 450, 350, 80, steps=15)
        time.sleep(1)
        img = screenshot()
        loc, conf, scale = find_pig_pen(img, return_scale=True)

    if loc is None:
        cx, cy = 900, 450
        for i, (dx, dy) in enumerate(spiral_moves(MAX_SEARCH_STEPS), 1):
            swipe(cx, cy, cx + dx * HOP_PX, cy + dy * HOP_PX, 500)
            time.sleep(1.1)
            img = screenshot()
            loc, conf, scale = find_pig_pen(img, return_scale=True)
            if loc is not None:
                log(f"Found Pig Pen (and therefore the crop grid nearby) on "
                    f"search step {i}/{MAX_SEARCH_STEPS} (confidence {conf:.2f})")
                break

    if loc is None:
        log(f"Pig Pen not found after {MAX_SEARCH_STEPS} search steps "
            f"(best match {conf:.2f}) — can't locate the crop grid either. "
            "Giving up this run — no changes made. Please check manually.")
        return

    # The offset math is only calibrated near scale~0.9. If the camera is
    # too zoomed in, zoom out once and re-find before trusting the offset.
    if scale > 1.0:
        log(f"Pig Pen found at scale {scale} — too zoomed in for reliable "
            "offset math. Zooming out once and re-checking.")
        pinch(800, 450, 350, 150, steps=12)
        time.sleep(1)
        img = screenshot()
        new_loc, new_conf, new_scale = find_pig_pen(img, return_scale=True)
        if new_loc is not None:
            loc, conf, scale = new_loc, new_conf, new_scale
            log(f"After zoom-out: Pig Pen at {loc} (scale {scale}).")
        else:
            log("Lost Pig Pen after zooming out — continuing with the "
                "original detection anyway.")

    grid_cx = loc[0] + GRID_OFFSET_AT_SCALE1[0] * scale
    grid_cy = loc[1] + GRID_OFFSET_AT_SCALE1[1] * scale
    log(f"Pig Pen at {loc} (scale {scale}) — crop grid estimated at "
        f"({grid_cx:.0f}, {grid_cy:.0f}).")

    # Safety bounds: the offset-scaling math is only calibrated near
    # scale~0.9-1.0. At other zoom levels it can drift enough to land a
    # tap off-screen or, worse, on the fixed bottom UI icon row (social/
    # skip buttons etc). Refuse to tap anything outside a safe interior
    # region rather than risk an unintended UI action.
    SAFE_X, SAFE_Y = (20, 1580), (140, 770)

    def in_bounds(x, y):
        return SAFE_X[0] <= x <= SAFE_X[1] and SAFE_Y[0] <= y <= SAFE_Y[1]

    if not in_bounds(grid_cx, grid_cy):
        log(f"Computed grid center ({grid_cx:.0f}, {grid_cy:.0f}) falls "
            "outside the safe tap region at this zoom level — refusing "
            "to guess. Giving up this run — no changes made.")
        return

    bar_found_mid_sweep = False
    cells_done = 0
    skipped = 0
    for (ox, oy) in CELL_OFFSETS_AT_SCALE1:
        x = int(grid_cx + ox * scale)
        y = int(grid_cy + oy * scale)
        if not in_bounds(x, y):
            log(f"Skipping a cell tap at ({x}, {y}) — outside the safe "
                "region, won't risk it.")
            skipped += 1
            continue
        tap(x, y)
        time.sleep(0.8)
        cells_done += 1
        img = screenshot()
        if planting_bar_open(img):
            log(f"Planting bar opened on cell {cells_done}/9 — stopping "
                "the sweep early, moving to the planting phase.")
            bar_found_mid_sweep = True
            break
        if unexpected_dialog_open(img):
            log(f"Cell {cells_done}/9 tap opened an unrelated panel "
                "(likely a nearby decoration) — dismissing with BACK.")
            back()
            time.sleep(0.6)
    if not bar_found_mid_sweep:
        log(f"Tapped all {cells_done} grid cells (harvests anything "
            "ready, opens the planting bar on any empty cell).")

    img = screenshot()
    if planting_bar_open(img):
        log("Planting bar is open — filling empty plots with Carrot.")
        for _ in range(9):
            tap(*CARROT_ICON)
            time.sleep(0.8)
        img = screenshot()
        if planting_bar_open(img):
            log("Bar still open after 9 taps — likely ran out of Carrot "
                "stock to plant with, or an unexpected plot remained. "
                "Leaving it as-is rather than guessing further.")
        else:
            log("All empty plots filled with Carrot — bar closed on its own.")
    else:
        log("No planting bar appeared — nothing was empty this run "
            "(everything was either still growing or already harvested "
            "with no free plot revealed).")

    log("=== carrot run end ===")


if __name__ == "__main__":
    main()
