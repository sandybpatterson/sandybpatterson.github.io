"""Live-reloadable core of AFSD's automation cycle.

Split out of autofoodstreet.py on 9/29 because the in-app Reload button
only ever re-imports plain modules like this one -- it can never touch
autofoodstreet.py itself, the __main__ script that builds the Tkinter
window and owns the one running AutoFoodStreetApp instance for the whole
process's life. Any cycle logic that lived directly in that file's
run_loop method needed a full app close-and-relaunch to change, which is
exactly the gap that motivated this split: a fix to how often the Stats
overlay updates (passing on_item= into process_all_visible) required a
full restart on 9/29, even though Stop -> Reload -> Start looked like it
should have been enough.

run_loop(app) takes the live AutoFoodStreetApp instance and drives it --
reads its checkbox Vars, calls its set_status/set_log/set_missing/set_stats
methods -- exactly as the method did when its body lived on the class
itself. autofoodstreet.py's own AutoFoodStreetApp.run_loop is now a
one-line wrapper: `afsd_core.run_loop(self)`. Because that wrapper does a
fresh module-attribute lookup on every call (not a reference baked in at
import time), a Reload that re-imports THIS file takes effect on the very
next Start -- no app restart needed for anything that lives here.

Every automation module below is imported in its plain `import X` form
(never `from X import Y`) specifically so that Reload-ing just THAT module
(without also reloading afsd_core itself) still picks up its changes --
importlib.reload() mutates a module's existing object in place rather than
replacing it, so `X.foo(...)`'s attribute lookup at call time always sees
the current version, the same reasoning documented in autofoodstreet.py's
reload_modules() for why garden_check needs reloading after order_fulfill
(garden_check uses `from order_fulfill import find_question_button`,
which WOULD go stale without a garden_check reload -- the modules here
avoid that trap by never importing names that way)."""
import os
import sys
import json
import importlib
import subprocess
import threading
import time
import datetime
import traceback

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import pig_pen_check
import dairy_check
import garden_check
import order_fulfill
import run_trace
import delivery_event
import chef_challenge
import food_truck_event
import event_orders
import street_truck
import trade_sell
import fishing_topup
import adb_helper
import adb_resilience
import find_and_center
import session_lock
from find_and_center import StopRequested

LOG = os.path.join(BASE_DIR, "run_log.txt")
CHECK_INTERVAL_SEC = 0   # 5 min -> 60s (9/26) -> 15s (10/2) -> 0 (10/6, user: "get rid of the 15 second delay").
                          # A cycle already takes minutes of real work, so the pause between cycles was pure waste.
MIN_CYCLE_SEC = 3        # but never spin: a cycle that finished faster than this (nothing to do, board not open) waits out the rest
ERROR_GAP_SEC = 5        # and after a cycle that ended in an exception (adb down...) wait a few seconds before retrying


def log(msg):
    """Same shared run_log.txt / "[afsd]" tag as autofoodstreet.py's own
    log() -- kept as an identical local copy rather than importing across
    the boundary (autofoodstreet.py imports this module, so this module
    must not import autofoodstreet.py back), matching the project-wide
    convention of every automation module owning its own local log()."""
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] [afsd] {msg}\n")
    try:
        print(f"[{ts}] [afsd] {msg}")
    except (AttributeError, OSError):
        pass


def _setlog(app, msg):
    app.set_log(msg)


_RELOADABLE = None
_MODULE_MTIMES = {}


def _reloadable():
    # Same order the Reload button uses: find_and_center FIRST (others do
    # `from find_and_center import ...`), then order_fulfill, then its importers.
    # adb_helper first of all (10/17): its screenshot speed-up / log fix only loaded on a full app restart.
    import picked_trees                          # 10/25: imported lazily elsewhere; listed so an Update reloads them
    import replant                               # 11/9: O.R.C.H.A.R.D. step 4
    import unbuilt
    import no_progress                           # 10/26
    import recipe_book                           # 10/28: learned recipes (recipes_learned.json)
    import recipe_learner                        # 10/28: needs order_fulfill reloaded first
    import flash                                 # 11/1: FLASH step 1 (log-only capture test)
    import ad_player                             # 11/1: ads
    import worth                                 # 11/2: W.O.R.T.H. test (log only)
    import busy                                  # 11/10 B.U.S.Y. price test
    import sprout                                # 11/6: S.P.R.O.U.T. step 1 (log only)
    import prize_watch                           # 11/14: prize collecting
    import job_order                             # 11/10 (Muse): O.R.D.E.R. -- was never reloaded, so the 11/9
    import soups                                 # starvation guard never ran until AFSD was reopened
    import truck_panel
    import event_icon_search                     # 11/12: finds a new event icon by itself
    import cleanup                               # 11/14: old debug pictures / git history
    import crops                                 # 11/15 C.R.O.P.S.
    # 11/17: these were in afsd_tools.RELOADABLE (so an Update never asked for a reopen) but were never reloaded here
    import stock_digits, prep_route, kitchen_model, unstuck, log_digest
    return [adb_helper, stock_digits, prep_route, kitchen_model, unstuck, log_digest,
            cleanup, crops, flash, ad_player, worth, sprout, prize_watch, busy, replant, picked_trees, unbuilt, no_progress, recipe_book, find_and_center, pig_pen_check, dairy_check,
            run_trace, truck_panel, job_order, order_fulfill, recipe_learner, soups,
            garden_check,
            delivery_event, chef_challenge, food_truck_event, event_orders, event_icon_search, street_truck,
            trade_sell, fishing_topup]


def _reload_all():
    """Reloads every automation module; returns (reloaded_names, failures)."""
    done, failed = [], []
    for m in _reloadable():
        try:
            importlib.reload(m)
            done.append(m.__name__)
            _MODULE_MTIMES[m.__name__] = os.path.getmtime(m.__file__)
        except Exception as e:                     # noqa: BLE001 -- keep the old module, keep running
            failed.append(f"{m.__name__}: {e}")
    return done, failed


def reload_modules_at_start():
    """Start picks up code edits by itself (found 10/2: Stop -> Start without Reload kept
    a stale event_orders running 25 minutes). afsd_core itself and autofoodstreet.py
    cannot reload themselves while running -- those still need the Reload button."""
    done, failed = _reload_all()
    log(f"Auto-reloaded {len(done)} modules at Start" + (f"; FAILED to reload: {failed}" if failed else "."))
    try:                                                   # 10/18: which code is really running (update check)
        import hashlib
        here = os.path.dirname(os.path.abspath(__file__))
        tags = []
        for f in ("event_orders.py", "afsd_core.py", "order_fulfill.py"):
            with open(os.path.join(here, f), "rb") as fh:
                h = hashlib.md5(fh.read().replace(b"\r\n", b"\n")).hexdigest()[:6]
            tags.append(f"{f.split('.')[0]} {h}")
        log("Code version: " + ", ".join(tags))
    except Exception:                                      # noqa: BLE001
        pass


def hot_reload_if_changed():
    """Called at the START of every cycle (never mid-action): if any automation file was
    edited since it was loaded, reload them all. Found 10/2: AFSD ran all night on code
    from before the fixes, stuck on a popup a newer file already handled. A half-written
    file that fails to import is skipped and retried next cycle."""
    changed = []
    for m in _reloadable():
        try:
            mt = os.path.getmtime(m.__file__)
        except OSError:
            continue
        if _MODULE_MTIMES.get(m.__name__, mt) < mt:
            changed.append(m.__name__)
        _MODULE_MTIMES.setdefault(m.__name__, mt)
    if changed:
        done, failed = _reload_all()
        log(f"Hot-reloaded {len(done)} modules because files changed: {changed}"
            + (f"; FAILED (will retry): {failed}" if failed else ""))
        for name in changed:                       # failed ones keep their old mtime -> retried
            pass


# ---------------------------------------------------------------------------
# One runner per feature; run_loop executes the ticked ones in the order they are listed in the
# app window (autofoodstreet.list_rows). Keys == the checkbox texts in autofoodstreet.py.
# ---------------------------------------------------------------------------

def _run_garden(app, stop, cycle):
    app.set_status("Checking Garden Plot (Carrots)...")
    try:
        keep = int(str(app.restock_var.get()).strip())
        keep = max(1, min(keep, 99))
    except Exception:              # noqa: BLE001 -- bad/missing field: use the default
        keep = None
    garden_check.main(stop_flag=stop, min_stock=keep)
    _setlog(app, f"Last Carrot check: {time.strftime('%I:%M:%S %p')}")


def _run_pork(app, stop, cycle):
    app.set_status("Checking Pork...")
    pig_pen_check.main(stop_flag=stop)
    _setlog(app, f"Last Pork check: {time.strftime('%I:%M:%S %p')}")


def _run_cream(app, stop, cycle):
    app.set_status("Checking Whipped Cream...")
    dairy_check.main(stop_flag=stop)
    _setlog(app, f"Last Cream check: {time.strftime('%I:%M:%S %p')}")


_EMPTY_READS = set()          # plan times of empty board reads in a row (10/27)


def _publish_clipboard(results=None, served=0):
    """Orders window (10/16): the clipboard board as last planned + what each order item got. Display only."""
    try:
        import orders_view as ov
        items = order_fulfill.LAST_ORDER_PLAN.get("items") or []

        def pretty(n):
            return str(n or "").replace("_", " ").strip().title() or None
        orders = []
        for no, its in enumerate(items, start=1):
            row = []
            for it in its:
                have, need = it.get("have"), it.get("need")
                e = {"name": pretty(it.get("name")), "have": have, "need": need}
                lb = it.get("label")
                if e["name"] is None and lb:                 # 10/25: name read from the game's tooltip
                    e["name"] = lb.get("name")
                    e["status"] = lb.get("note") or "the bot can't make this yet"
                    e["kind"] = "stuck"
                if have is not None and need is not None and have >= need:
                    e.update(status="ready", kind="done")
                row.append(e)
            orders.append({"no": no, "items": row})
        try:                                         # 10/21: header signature, for the Dismiss button
            sigs = order_fulfill.LAST_ORDER_PLAN.get("sigs") or []
            for o in orders:
                if o["no"] - 1 < len(sigs) and sigs[o["no"] - 1] is not None:
                    o["sig"] = sigs[o["no"] - 1]
        except Exception:                            # noqa: BLE001
            pass
        try:                                         # 10/23: dismissed orders vanish at once, queued ones say so
            keep = []
            for o in orders:
                st = order_fulfill.dismiss_state(o.get("sig")) if o.get("sig") is not None else None
                if st == "gone":
                    continue
                o["dismissing"] = st == "queued"
                keep.append(o)
            orders = keep
        except Exception:                            # noqa: BLE001
            pass
        try:                                         # 10/21 (owner): time estimate per order, from the plan's recipe book
            import recipe_book as _rb
            for po in order_fulfill.LAST_ORDER_PLAN.get("orders") or []:
                if po.get("ready") or not po.get("priced") or not po.get("wall"):
                    continue
                for o in orders:
                    if o["no"] == po["n"]:
                        busy = sorted((po.get("busy") or {}).items(), key=lambda kv: -kv[1])
                        o["eta"] = f"~{_rb.fmt(po['wall'])} left" + (
                            f" · {busy[0][0]} {_rb.fmt(busy[0][1])}" if busy and busy[0][1] >= 1800 else "")
                        o["eta_long"] = po["wall"] >= 2 * 3600
            if order_fulfill.QUICK_FIRST:                # 10/22: the order the bot is on now
                for o in orders:                         # 10/27: by signature -- _LAST_ORDER_NO is the board SLOT,
                    o["next_up"] = order_fulfill._same_sig(o.get("sig"), order_fulfill._LAST_ORDER_SIG)  # not the card no.
        except Exception:                            # noqa: BLE001 -- a display extra must never break the run
            pass
        plan_t = order_fulfill.LAST_ORDER_PLAN.get("time")
        if items:
            _EMPTY_READS.clear()
        elif plan_t:                                 # 10/27: the board read empty -- old cards stayed up forever.
            _EMPTY_READS.add(plan_t)                 # Two empty reads in a row (one can be a misread) clear them.
            if len(_EMPTY_READS) >= 2:
                ov.set_orders(ov.CLIPBOARD, [], note="No orders on the board right now.")
        if orders:
            ov.set_orders(ov.CLIPBOARD, orders, note="" if order_fulfill.LAST_ORDER_PLAN.get("reliable")
                          else "Some items could not be read on this pass.")
            try:                                     # 10/19 freetime: Prep work route test (watch-only, logs only)
                import prep_route
                prep_route.watch([it.get("name") for its in items for it in its], log)
            except Exception:                        # noqa: BLE001
                pass
        if served:
            ov.add_completed(ov.CLIPBOARD, served)
        norm = lambda x: "".join(ch for ch in str(x or "").lower() if ch.isalnum())     # noqa: E731
        for r in results or []:
            no, dish = r.get("order"), norm(r.get("dish"))
            try:                                     # 10/27: r["order"] is the board SLOT -- find the card by signature
                rsig = (r.get("slot_key") or {}).get("sig")
                if rsig is not None:
                    no = next((o["no"] for o in orders if order_fulfill._same_sig(o.get("sig"), rsig)), None)
            except Exception:                        # noqa: BLE001
                pass
            if not no or not dish:
                continue
            for o in orders:
                if o["no"] != no:
                    continue
                for k, it in enumerate(o["items"]):
                    if norm(it["name"]) == dish:
                        text, kind = ov.friendly(r.get("status"))
                        ov.set_item(ov.CLIPBOARD, no, k, status=text, kind=kind)
    except Exception:                                              # noqa: BLE001 -- the window must never break a cycle
        pass


ORDERS_TURN_MAX_SEC = 300      # Auto Fulfill's time per cycle while Food Club is ticked too


def untick_stop(fallback, ticked):
    """11/12: a clipboard turn ends early when the owner unticks Clipboard Orders -- but never in the Food Club
    fallback turn (Clipboard Orders is unticked there on purpose)."""
    if fallback or ticked:
        return None
    return "Clipboard Orders was unticked -- ending this turn after the current item."


def _run_orders(app, stop, cycle, fallback=False):
    app.set_status("Serving ready orders...")
    order_fulfill.ON_PLAN_CHANGE = _publish_clipboard        # 10/25: mid-turn serves redraw the Orders tab at once
    served = order_fulfill.serve_ready_orders(stop_flag=stop)
    try:
        run_trace.stat("served", "orders", served or 0)             # 10/10 run trace
    except Exception:                                              # noqa: BLE001
        pass
    plan_text = order_fulfill.LAST_ORDER_PLAN.get("text", "")
    if plan_text:
        app.set_stats(plan_text)
    app.set_status("Checking Orders board...")
    # Live progress in the Stats overlay -- pushed after EVERY item, not just once the whole
    # (possibly several-minutes-long) batch finishes (found live 9/29).
    _publish_clipboard(served=served)

    def on_item(so_far):
        app.set_stats((plan_text + "\n\n" if plan_text else "") + order_fulfill.format_run_report(so_far, served=served))
        _publish_clipboard(so_far)
    try:                                               # 10/19 Settings tab: keep long cooks off Food Club stations
        lim = int(app.long_cook_limit_var.get())                   # 10/23: one number, 0 = off
        on = bool(lim > 0 and app.event_orders_var.get())
        order_fulfill.LONG_COOK_GUARD.update(limit_sec=lim * 60 if on else None,
                                             stations=event_orders.food_club_stations())
    except Exception:                                  # noqa: BLE001
        order_fulfill.LONG_COOK_GUARD["limit_sec"] = None
    t0 = time.time()

    def should_stop():
        if _express_now(app):
            return True
        try:                                           # 10/25 (owner): unticked while running -- end the turn now
            # 11/12: NOT for the Food Club fallback turn -- there Clipboard Orders is unticked on purpose, and this
            # check ended every fallback turn after ONE item (espresso, blocked on coffee) -> 0 serves all night.
            why = untick_stop(fallback, app.orders_var.get())
            if why:
                return why
        except Exception:                              # noqa: BLE001
            pass
        if order_fulfill.DISMISS_REQUESTS:             # 10/21 (owner): Dismiss pressed -- end this turn now, dismiss next
            return "the owner pressed Dismiss on an order -- stopping this turn to dismiss it first."
        # 10/19 (owner: yes): one clipboard turn ran 12-20 min, so Food Club got one pass per cycle (~65 pts/h
        # overnight vs ~350 alone). With Food Club ticked too, the clipboard gets ORDERS_TURN_MAX_SEC per cycle.
        try:
            fc = bool(app.event_orders_var.get())
        except Exception:                              # noqa: BLE001
            fc = False
        if fc and time.time() - t0 > ORDERS_TURN_MAX_SEC:
            return (f"clipboard turn used its {ORDERS_TURN_MAX_SEC // 60} min -- back to Food Club, the rest "
                    "waits for the next cycle.")
        return False
    if order_fulfill.DISMISS_REQUESTS:                 # 10/21: dismiss BEFORE working the board
        order_fulfill.run_dismiss_requests(stop)
    results = order_fulfill.process_all_visible(stop_flag=stop, on_item=on_item, should_stop=should_stop)
    if order_fulfill.DISMISS_REQUESTS:
        order_fulfill.run_dismiss_requests(stop)
    _publish_clipboard(results)
    while order_fulfill.SET_ASIDE_NOTES:               # 10/22: tell the owner an order was set aside
        note = order_fulfill.SET_ASIDE_NOTES.pop(0)
        try:
            app._tool_done(True, note)
        except Exception:                              # noqa: BLE001
            pass
    _pantry_relief(app, stop, should_stop)
    _stall_fill(app, stop, should_stop)                # 10/27: keep the trade stall stocked (owner: yes)
    _plot_round(app, stop, results, should_stop)
    queued = sum(1 for r in results if r["status"] == "queued")
    status_counts = {}
    for r in results:
        status_counts[r["status"]] = status_counts.get(r["status"], 0) + 1
    log(f"cycle {cycle}: Orders -- served {served}, {len(results)} item(s) "
        f"processed, breakdown {status_counts}")
    _setlog(app, f"Orders: served {served}, queued {queued}/{len(results)} "
                 f"at {time.strftime('%I:%M:%S %p')}")
    summary = order_fulfill.summarize_missing(results)
    log(f"cycle {cycle}: missing-ingredients summary -- "
        f"ingredients {summary['ingredient_counts']}, "
        f"dishes {summary['dish_counts']}")
    app.set_missing(summary)
    app.set_stats((plan_text + "\n\n" if plan_text else "") + order_fulfill.format_run_report(results, served=served))
    # 10/14: "always be fishing" used to run here unconditionally; since 10/15 it is its own switch,
    # "Keep fishing (sell extras)" (_run_fishing below).


PLOT_ROUND_SEC = 20 * 60
_last_plot_round = 0.0


_relief_next = [0.0]
PANTRY_RELIEF_GAP_SEC = 10 * 60


PANTRY_RELIEF_MIN_GAP_SEC = 3 * 60


def _pantry_relief(app, stop, should_stop, keep_for=None):
    """10/25 (owner): the Pantry is full -> sell a few of a crop that grows in under 10 min (never saws). Max every
    10 min, only after the "Your Pantry is full!" popup was seen in the last 10 min, never during an express."""
    try:
        import find_and_center as fac
        if not fac.pantry_full_recent():
            return
        try:
            if not app.pantry_relief_var.get():                 # 11/1 Settings switch (default on)
                return
        except AttributeError:
            pass
        # 10/29 (owner): a NEW full popup since the last try -> relieve now (min 3 min apart), else every 10 min
        if time.time() < _relief_next[0] and not (fac.pantry_relief_wanted()
                                                  and time.time() - fac.RELIEF_TRIED_AT[0] >= PANTRY_RELIEF_MIN_GAP_SEC):
            return
        if should_stop and should_stop() is True:               # an express is waiting
            return
        _relief_next[0] = time.time() + PANTRY_RELIEF_GAP_SEC
        fac.RELIEF_TRIED_AT[0] = time.time()
        import trade_sell
        app.set_status("Pantry is full -- selling a few quick crops to make room...")
        log("[pantry relief] the Pantry is full -- trying to sell a few of a crop that grows in under 10 min.")
        # 10/26 live: keeping "reserve + what open orders need" (8 wheat, 17 cabbage) sold nothing while the Pantry was
        # full -- and a full Pantry can't take those crops in anyway. Quick crops regrow in 45 s - 7 min: keep only the
        # crop reserve (Settings "Keep at least this many of each crop") while the Pantry is full.
        trade_sell.pantry_relief(keep_for or _prep_keep(), stop)
    except Exception as e:                                      # noqa: BLE001
        if type(e).__name__ == "StopRequested":
            raise
        log(f"[pantry relief] failed (ignored): {e!r}")


_stall_next = [0.0]
STALL_FILL = True                    # 10/27 (owner: yes) keep the trade stall stocked with quick-crop extras
STALL_FILL_GAP_SEC = 30 * 60         # normally every 30 min ...
STALL_HELP_GAP_SEC = 10 * 60         # ... every 10 min while a picked tree waits for a visitor's help


def _stall_fill(app, stop, should_stop):
    """10/27 (owner: yes to "sell extras from the stock take"): after a clipboard turn, list quick-crop extras into free
    trade slots (keeps the crop reserve + what the open orders need; never saws, never anything but quick crops).
    Never during an express; skipped while the Pantry is full (pantry relief handles that)."""
    try:
        if not STALL_FILL or time.time() < _stall_next[0]:
            return
        if should_stop and should_stop() is True:               # an express is waiting
            return
        import find_and_center as fac
        if fac.pantry_full_recent():
            return
        import picked_trees
        import trade_sell
        helping = picked_trees.waiting_for_help()
        try:
            if not app.stall_wait_var.get() or not helping:     # 11/1 (owner): only while a tree waits for help
                return
        except AttributeError:
            pass
        _stall_next[0] = time.time() + (STALL_HELP_GAP_SEC if helping else STALL_FILL_GAP_SEC)
        app.set_status("Stocking the trade stall with spare quick crops...")
        log("[stall fill] listing spare quick crops" + (" (a picked tree is waiting for a visitor's help)" if helping else "") + ".")
        targets = order_fulfill.crop_targets(order_fulfill.CROP_RESERVE)
        n = trade_sell.stall_fill(lambda c: targets.get(c, order_fulfill.CROP_RESERVE), stop)
        log(f"[stall fill] done -- {n} listing(s) made.")
    except Exception as e:                                      # noqa: BLE001
        if type(e).__name__ == "StopRequested":
            raise
        log(f"[stall fill] failed (ignored): {e!r}")


def _plot_round(app, stop, results, should_stop):
    """10/22 (owner): while orders wait on ingredients, walk the crop plots -- harvest what is ready, plant the empty
    plots from stock (Settings > Clipboard Orders "Plant empty plots while waiting"). At most every PLOT_ROUND_SEC."""
    global _last_plot_round
    try:
        if not app.plant_wait_var.get():
            return
    except Exception:                                  # noqa: BLE001
        return
    waiting = [r for r in results if r.get("status") in ("blocked_on_ingredient", "crop_growing",
                                                          "recursed_ingredient", "retry_next_ingredient")]
    if (not waiting and not order_fulfill.set_aside_keys()) or time.time() - _last_plot_round < PLOT_ROUND_SEC:
        return
    try:
        if should_stop():
            return
    except Exception:                                  # noqa: BLE001
        pass
    _last_plot_round = time.time()
    try:
        keep = max(1, min(int(app.crop_reserve_var.get()), 99))    # 10/23: the one crop number (was Garden 'keep')
    except Exception:                                  # noqa: BLE001
        keep = None
    app.set_status("Walking the crop plots (harvest + plant)...")
    try:
        try:
            targets = order_fulfill.crop_targets(keep or 0)             # 10/23: reserve + what the orders need
        except Exception:                              # noqa: BLE001
            targets = None
        garden_check.tend_plots(stop_flag=stop, min_stock=keep, targets=targets)
    except StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001
        log(f"[plots] plot round failed (ignored): {e!r}")


def _run_fishing(app, stop, cycle):
    """Boat visit (collect catches, queue Mystery Catches, keep 2 hooks) at most every 15 min, then sell
    extra fish/seaweed at most hourly, keeping the window's "keep N each". With Auto Fulfill Orders ticked
    the orders' own need is kept on top of N (and the sell is skipped if that plan was not read reliably);
    with it off, everything above N is sold -- see fishing_topup.run."""
    try:
        keep = int(str(app.fish_keep_var.get()).strip())
        keep = max(1, min(keep, 99))
    except Exception:              # noqa: BLE001 -- bad/missing field: fishing_topup's default
        keep = None
    orders_on = bool(getattr(app, "orders_var", None) and app.orders_var.get())
    try:
        app.set_status("Keep fishing (sell extras)...")
        fishing_topup.run(stop, keep=keep, use_orders=orders_on)
    except StopRequested:
        raise
    except Exception as e:                                          # noqa: BLE001 -- never let this break the cycle
        log(f"fishing top-up failed (ignored): {e!r}")


def _run_delivery(app, stop, cycle):
    app.set_status("Checking Delivery Event...")
    delivery_event.main(stop_flag=stop)
    _setlog(app, f"Last Delivery Event check: {time.strftime('%I:%M:%S %p')}")


def _run_food_truck(app, stop, cycle):
    app.set_status("Checking Food Truck Event...")
    food_truck_event.main(stop_flag=stop)
    _setlog(app, f"Last Food Truck check: {time.strftime('%I:%M:%S %p')}")


def _run_chef(app, stop, cycle):
    app.set_status("Checking Chef Challenge...")
    chef_challenge.main(stop_flag=stop)
    _setlog(app, f"Last Chef Challenge check: {time.strftime('%I:%M:%S %p')}")


def truck_crops_short():
    """11/11: crops the truck still needs (job_order's truck claim, recipe-book kind crop) -> {name: units}."""
    try:
        import job_order
        return {n: q for n, q in job_order.claim_truck().items() if street_truck._is_crop(n)}
    except Exception:                                  # noqa: BLE001
        return {}


def _run_street_truck(app, stop, cycle):
    app.set_status("Checking the street Food Truck...")
    street_truck.main(stop_flag=stop)
    _setlog(app, f"Last Food Truck (street) check: {time.strftime('%I:%M:%S %p')}")
    # 11/11 (logs 07:00-09:50, truck alone): it wanted 18 mushrooms; the truck job skips crops ("the plots grow those")
    # and only the clipboard's plot round planted them -> 0 of 9 all morning. Now the truck walks the plots itself
    # (same plot round, same PLOT_ROUND_SEC limit; crop_targets already adds the truck's crops).
    crops = truck_crops_short()
    if crops:
        if time.time() - _last_plot_round >= PLOT_ROUND_SEC:
            log("[food truck] the truck still needs crops (" + ", ".join(f"{n} {q}" for n, q in crops.items())
                + ") -- walking the crop plots to plant them.")
        _plot_round(app, stop, [{"status": "crop_growing"}], lambda: stop.is_set())


# Food Club Event board not found -> after this many failed cycles in a row, work the normal clipboard
# orders instead (10/10). While in that mode the event board is looked for again every Nth cycle, so a
# new event (or an icon that was only hidden) is picked up again by itself.
EVENT_BOARD_MISS_LIMIT = 5
EVENT_REPROBE_EVERY = 6
# 11/13 (owner: "the event is still going on. i dont want it doing clipboard orders. it needs to try harder to find
# the event board"): Settings > Food Club "Clipboard orders when the event board can't be found" (default OFF). Off ->
# no clipboard fallback; each failed board look climbs a rescue ladder instead (board_rescue_step).
EVENT_CLIP_FALLBACK = False
RESCUE_GAME_GAP_SEC = 15 * 60          # game restarts for the board at most this often
_rescue = {"game_at": 0.0, "games": 0}


def board_rescue_step(misses, now, game_at, games):
    """Pure: what to do after the Food Club board failed to open `misses` times in a row.
    "screen" = Back key + close panels + tap empty space; "game" = restart the game; "ldplayer" = cold start
    LDPlayer (after 2 game restarts did not bring the board back); None = just look again next cycle."""
    if misses <= 0:
        return None
    if misses in (1, 2):
        return "screen"
    if now - game_at < RESCUE_GAME_GAP_SEC:
        return "screen"
    return "ldplayer" if games >= 2 else "game"


def _decline_question(adb_helper):
    """11/14: a Yes/No question on screen (Back on the plain map asks "Do you really want to quit the game?") -> No."""
    try:
        import order_fulfill
        no, _c = order_fulfill.find_no_button(adb_helper.screenshot())
        if no is not None:
            log("[board rescue] a Yes/No question came up after the Back key -- tapping No.")
            adb_helper.tap(*no)
            time.sleep(0.8)
            return True
    except Exception as e:                                         # noqa: BLE001
        log(f"[board rescue] could not check for a question: {e!r}")
    return False


def _rescue_board(stop, set_status, misses):
    """11/13: try harder to get the Food Club board back (no clipboard fallback)."""
    import adb_helper
    import find_and_center as fac
    step = board_rescue_step(misses, time.time(), _rescue["game_at"], _rescue["games"])
    if step == "screen":
        log(f"[board rescue] board not found ({misses}x) -- Back key, closing panels, tapping empty space.")
        try:
            adb_helper.back()
            time.sleep(1.0)
            _decline_question(adb_helper)                          # Back on the plain map asks "quit the game?"
            fac.close_any_open_panel(quiet=True, thorough=True)
            adb_helper.tap(60, 420)
            time.sleep(0.8)
        except Exception as e:                                     # noqa: BLE001
            log(f"[board rescue] screen clean-up failed: {e!r}")
    elif step == "game":
        _rescue["game_at"], _rescue["games"] = time.time(), _rescue["games"] + 1
        log(f"[board rescue] board not found ({misses}x) -- restarting the game "
            f"(restart {_rescue['games']} for the board).")
        ensure_game_ready(stop, set_status, force_restart=True)
    elif step == "ldplayer":
        _rescue["game_at"], _rescue["games"] = time.time(), 0
        log(f"[board rescue] board not found ({misses}x) and 2 game restarts did not bring it back -- "
            "cold-starting LDPlayer.")
        if hard_restart_emulator(say=log, why="Food Club board not found after 2 game restarts"):
            ensure_game_ready(stop, set_status, _hard_done=True)
_event_misses = 0
_event_fallback = False
_event_fallback_cycles = 0


def _event_board_missing(results):
    """True when the pass could not open the event board at all (the placeholder result, not an express miss)."""
    return any(r.get("status") == "board_not_opened" and r.get("item") == "-" for r in results)


def _run_event_orders(app, stop, cycle):
    global _event_misses, _event_fallback, _event_fallback_cycles
    if _event_fallback and not EVENT_CLIP_FALLBACK:
        _event_fallback = False                                    # switched off in Settings while falling back
    if _event_fallback:
        _event_fallback_cycles += 1
        if _event_fallback_cycles % EVENT_REPROBE_EVERY != 0:
            if not app.orders_var.get():                     # (if Auto Fulfill Orders is ticked it already runs this cycle)
                log(f"cycle {cycle}: Food Club Event board not found -- working the normal clipboard orders instead.")
                _run_orders(app, stop, cycle, fallback=True)
            return
        log(f"cycle {cycle}: looking for the Food Club Event board again...")
    app.set_status("Food Club Event...")
    ev_served, ev_results = event_orders.main(stop_flag=stop)
    try:
        run_trace.stat("event completed", "orders", ev_served or 0)
    except Exception:                                              # noqa: BLE001
        pass
    _setlog(app, f"Food Club Event: completed {ev_served}, chased {len(ev_results)} "
                 f"at {time.strftime('%I:%M:%S %p')}")
    try:                                                           # 11/15 C.R.O.P.S.: Crop Farmer trade near full
        import crops
        if crops.due(event_orders._storage_used(), time.time(), event_orders.express_active()):
            app.set_status("Food Club storage nearly full -- trading crops at the Crop Farmer...")
            crops.swap(stop, log)
    except Exception as e:                                         # noqa: BLE001 -- never stops Food Club
        log(f"[crops] farmer trade failed (ignored): {e!r}")
    if any(str(r.get("item", "")).startswith("EXPRESS") for r in ev_results):
        try:
            app.set_stats(event_orders.format_report(ev_served, ev_results))
        except Exception:          # noqa: BLE001
            pass
    if _event_board_missing(ev_results):
        _event_misses += 1
        if not EVENT_CLIP_FALLBACK:
            try:
                _rescue_board(stop, app.set_status, _event_misses)
            except Exception as e:                                 # noqa: BLE001
                log(f"[board rescue] failed: {e!r}")
        elif not _event_fallback and _event_misses >= EVENT_BOARD_MISS_LIMIT:
            _event_fallback = True
            _event_fallback_cycles = 0
            log(f"cycle {cycle}: Food Club Event board not found {_event_misses} times in a row -- "
                "switching to the normal clipboard orders (the event board is re-checked every "
                f"{EVENT_REPROBE_EVERY} cycles).")
    else:
        if _event_fallback:
            log(f"cycle {cycle}: Food Club Event board found again -- back to event orders.")
        if _event_misses and not EVENT_CLIP_FALLBACK:
            log(f"[board rescue] the Food Club board opened again after {_event_misses} miss(es).")
            _rescue["games"] = 0
        _event_misses = 0
        _event_fallback = False
        _event_fallback_cycles = 0
    # 10/29 live (Food Club only ticked): "Your Pantry is full!" 63x in an hour -- pantry relief only ran after a
    # clipboard turn. Run it after a Food Club pass too (never during an express; Clipboard Orders does it itself).
    if not app.orders_var.get():
        _pantry_relief(app, stop, lambda: _express_now(app))


_prep_note_t = 0.0


def _prep_keep(prep_engine=None):
    """keep_for(crop) for pantry relief: while a Prep list is placed, keep what it wants of an item plus what its dishes
    need of it (one level down: Tomato Soup x4 keeps 2 x 4 tomatoes), at least the crop reserve. 10/31 (owner): every
    relief honours it, not only Prep's own (Food Club's relief sold Prep's wheat back down to 2)."""
    want = {}
    try:
        if prep_engine is None:
            import prep_engine
        order = prep_engine._load()
        if order.get("placed"):
            import recipe_book
            items = recipe_book.load()["items"]
            for k, q in (order.get("items") or {}).items():
                want[k] = want.get(k, 0) + int(q)
                for ing, n in (items.get(k, {}).get("ingredients") or []):
                    want[ing] = want.get(ing, 0) + int(q) * int(n)
    except Exception:                                  # noqa: BLE001
        want = {}
    return lambda c: max(order_fulfill.CROP_RESERVE, want.get(c, 0))


PREP_READY_SOON_SEC = 60      # a Food Club batch ready within this -> no Prep turn (collect it first)


def prep_gate(order, last_pass, batch_readies, now, job="Prep work"):
    """Pure (11/16, owner: "if Food Club is above Prep it should only do prep work when it is waiting on something to
    cook, and not keep going when it needs to collect something") -> (ok, why). Only when Food Club Event is ticked and
    ABOVE Prep work: the last Food Club pass must have done nothing (everything cooking / growing / waiting) and none of
    its batches may be ready now or within PREP_READY_SOON_SEC."""
    club, prep = "Food Club Event", job          # 11/17: Busy Mode uses the same gate
    if club not in order or prep not in order or order.index(club) > order.index(prep):
        return True, ""
    if last_pass.get("busy") is None:
        return False, "Food Club has not looked at its board yet"
    if last_pass.get("busy"):
        return False, "Food Club still had work last pass"
    soon = [r for r in batch_readies if r <= now + PREP_READY_SOON_SEC]
    if soon:
        return False, "a Food Club batch is ready (or nearly) -- collecting comes first"
    return True, ""


def _run_prep(app, stop, cycle):
    """Prep work (10/19, owner): runs in its spot in the job list, never during an express. One item per turn --
    see prep_engine.py (clipboard '?' route -> station -> the clipboard bot's own cook step)."""
    try:
        import job_order
        import worth
        eo = sys.modules.get("event_orders")
        readies = [r for rs in (getattr(eo, "_my_batches", {}) or {}).values() for r in rs] if eo else []
        ok, why = prep_gate(list(job_order.ORDER), dict(worth._last_pass), readies, time.time())
        if not ok:
            msg = f"Prep work: waiting -- {why}."
            if _PREP_WAIT_LOG[0] != why:
                _PREP_WAIT_LOG[0] = why
                log(f"[prep] not this cycle: {why} (Food Club is higher in the jobs list).")
            try:
                app.set_status(msg)
            except Exception:                          # noqa: BLE001
                pass
            return
        _PREP_WAIT_LOG[0] = None
    except Exception as e:                             # noqa: BLE001
        log(f"[prep] gate check failed (running Prep anyway): {e!r}")
    try:
        import importlib
        import prep_engine
        importlib.reload(prep_engine)
        # 10/30 (owner): "prep work can sell crops, fruit, beans etc to free up storage" -- a full Pantry is relieved
        # first, keeping at least what the Prep list wants of each item (and the crop reserve for everything else).
        _pantry_relief(app, stop, None, keep_for=_prep_keep(prep_engine))
        msg = prep_engine.run(app, stop)
    except find_and_center.StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001 -- a Prep failure must never end the run
        msg = f"Prep work failed this turn: {e!r}"
        log(f"[prep] {msg}\n{traceback.format_exc()}")
        try:
            order_fulfill.close_any_open_panel(quiet=True, thorough=True)
        except Exception:                              # noqa: BLE001
            pass
    try:
        app.set_status(msg)
        app.refresh_prep_status()
    except Exception:                                  # noqa: BLE001
        pass
    log(f"cycle {cycle}: {msg}")


def _only_job(app, key):
    """True when `key` is the only ticked job in FEATURES."""
    try:
        on = [k for k, (var, _r, _e) in FEATURES.items() if getattr(app, var, None) is not None and getattr(app, var).get()]
        return on == [key]
    except Exception:                                  # noqa: BLE001
        return False


BUSY_GAP_SEC = 10 * 60
_PREP_WAIT_LOG = [None]
_BUSY_T = [0.0]


def _busy_keep():
    """keep_for(item) for Busy Mode sales: the Prep list's wants, the crop reserve, and every higher job's claim
    (O.R.D.E.R.: jobs above Busy Mode in the list keep what they still need)."""
    base = _prep_keep()
    try:
        import job_order
        res = job_order.reserved_for("Busy Mode")
    except Exception:                                  # noqa: BLE001
        res = {}

    def keep(item):
        k = base(item)
        try:
            import job_order
            u = res.get(job_order.key_of(item))
            if u:
                k = max(k, int(u[0]))
        except Exception:                              # noqa: BLE001
            pass
        return k
    return keep


_BUSY_WAIT_LOG = [None]


def _run_busy(app, stop, cycle):
    """B.U.S.Y. job. 11/15 (owner) LIVE: sells quick items (under 15 min to make) at the max price every 3 min,
    collecting sold slots first, and makes them (plus one of every slower item that has no price yet) through the
    Prep engine on its own list. Keeps the Prep list, the crop reserve and higher jobs' needs. Never during an express."""
    try:
        import busy
        import job_order
        import worth
        eo = sys.modules.get("event_orders")
        readies = [r for rs in (getattr(eo, "_my_batches", {}) or {}).values() for r in rs] if eo else []
        ok, why = prep_gate(list(job_order.ORDER), dict(worth._last_pass), readies, time.time(), job="Busy Mode")
        if not ok:                                     # 11/17 (owner): selling ate Food Club's time while storage was full
            if _BUSY_WAIT_LOG[0] != why:
                _BUSY_WAIT_LOG[0] = why
                log(f"[busy] not this cycle: {why} (Food Club is higher in the jobs list).")
            try:
                app.set_status(f"Busy Mode: waiting -- {why}.")
            except Exception:                          # noqa: BLE001
                pass
            return
        _BUSY_WAIT_LOG[0] = None
        msg = busy.live_tick(app, log, stop, _busy_keep(), express=_express_now(app))
        try:
            app.set_status(msg)
        except Exception:                              # noqa: BLE001
            pass
        if _only_job(app, "Busy Mode") and ("waiting" in msg or "in stock" in msg):
            end = time.time() + 45
            while time.time() < end and not stop.is_set():
                time.sleep(2)
    except find_and_center.StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001
        log(f"[busy] skipped: {e!r}")


def _run_tests(app, stop, cycle):
    """Tests job (10/20, owner): one planned test per turn (tests_job.py), never during an express."""
    try:
        import importlib
        import tests_job
        importlib.reload(tests_job)
        _apply_test_switches(app, tests_job)
        msg = tests_job.run(app, stop)
        if msg.startswith("Tests: nothing due") and _only_job(app, "Tests"):
            # 10/31: Tests alone spun "all done" every 5 s for 2.5 h -- rest until the next test is due (max 5 min)
            end = time.time() + min(300, tests_job.idle_seconds())
            while time.time() < end and not stop.is_set():
                time.sleep(2)
    except find_and_center.StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001 -- a test must never end the run
        msg = f"Tests failed this turn: {e!r}"
        log(f"[tests] {msg}\n{traceback.format_exc()}")
        try:
            order_fulfill.close_any_open_panel(quiet=True, thorough=True)
        except Exception:                              # noqa: BLE001
            pass
    try:
        app.set_status(msg)
        app.refresh_tests_status()
    except Exception:                                  # noqa: BLE001
        pass
    log(f"cycle {cycle}: {msg}")


def _apply_test_switches(app, tests_job):
    for key, _lab in tests_job.TESTS:
        var = getattr(app, f"test_{key}_var", None)
        try:
            tests_job.ENABLED[key] = bool(var.get()) if var is not None else True
        except Exception:                              # noqa: BLE001
            tests_job.ENABLED[key] = True


# 10/20 freetime TIME TEST (watch-only): where does each hour go? Seconds per job, the pause between cycles and
# the rest (start-of-cycle checks, error back-off), plus event points gained that hour. Overnight runs scored
# 25-62 pts/h vs ~240-350 by day (scorecard lab-s5c1v) -- this shows which job eats the night. Changes nothing.
_tt = {"since": time.time(), "jobs": {}, "gap": 0.0, "pts0": None}


def _time_test(log):
    now = time.time()
    if now - _tt["since"] < 3600:
        return
    try:
        import event_orders as _eo
        pts = _eo._score.get("gained", 0)
    except Exception:                                # noqa: BLE001
        pts = None
    total = now - _tt["since"]
    jobs = sum(_tt["jobs"].values())
    other = max(0.0, total - jobs - _tt["gap"])
    parts = ", ".join(f"{k} {v / 60:.0f}m" for k, v in sorted(_tt["jobs"].items(), key=lambda x: -x[1]))
    if pts is not None and _tt["pts0"] is not None and pts < _tt["pts0"]:
        _tt["pts0"] = 0                              # the score counter restarted with this run
    got = (f"; event points this hour {pts - _tt['pts0']}" if pts is not None and _tt["pts0"] is not None else "")
    log(f"[time test] last {total / 60:.0f} min: {parts or 'no job ran'}; pause between cycles {_tt['gap'] / 60:.0f}m; "
        f"other (checks, errors, restarts) {other / 60:.0f}m{got}")
    _tt.update(since=now, jobs={}, gap=0.0, pts0=pts)


def _apply_settings(app):
    """10/19 (owner): numbers from the Settings tab, read once per cycle."""
    global ORDERS_TURN_MAX_SEC, EVENT_CLIP_FALLBACK

    def num(var, default):
        try:
            return int(getattr(app, var).get())
        except Exception:                              # noqa: BLE001
            return default
    event_orders.EXPRESS_BUFFER = {}                                       # 10/30 (owner): express berry/wheat settings removed
    event_orders.SEED_RESERVE = num("seed_reserve_var", 2)
    event_orders.STORAGE_GUARD_AT = num("storage_guard_var", 27)          # 10/20: 0 = off
    event_orders.PRESTOCK_EACH = num("prestock_var", 2)                    # 10/30: 0 = off
    try:
        EVENT_CLIP_FALLBACK = bool(app.event_clip_fallback_var.get())      # 11/13 Settings > Food Club
    except Exception:                                  # noqa: BLE001
        EVENT_CLIP_FALLBACK = False
    try:
        event_orders.HOLD_SERVE = bool(app.hold_serve_var.get())            # 11/13: "Hold serving" next to the job
    except Exception:                                  # noqa: BLE001
        event_orders.HOLD_SERVE = False
    try:
        event_orders.PRESTOCK_HOLD = bool(app.prestock_hold_var.get())       # 10/31: Settings "Prestock before serving"
    except Exception:                                  # noqa: BLE001
        event_orders.PRESTOCK_HOLD = True
    try:
        event_orders.STORAGE_FULL_PURGE = bool(app.storage_purge_var.get())  # 11/17: Settings "Delete an order ..."
    except Exception:                                  # noqa: BLE001
        event_orders.STORAGE_FULL_PURGE = True
    try:                                               # 11/1 FLASH step 2: Settings "FLASH fast capture"
        import flash
        want = bool(app.flash_var.get())
        flash.LOG = log
        if want != flash.ON:
            flash.ON = want
            log("[flash] fast capture " + ("ON -- the bot looks at LDPlayer's window; adb only when that fails "
                                           "(keep LDPlayer open, not minimised)" if want else "OFF -- adb screenshots"))
    except Exception:                                  # noqa: BLE001
        pass
    try:                                               # 11/8 O.R.C.H.A.R.D.: Settings > Orchard "Remove spent ..."
        import picked_trees
        picked_trees.CUT_LIVE = bool(app.orchard_cut_var.get())
        import replant
        replant.LIVE = bool(getattr(app, "orchard_replant_var", None).get()) if hasattr(app, "orchard_replant_var") \
            else True
    except Exception:                                  # noqa: BLE001
        pass
    try:                                               # 11/1 ADS: Settings > Ads "Watch ads for free rewards"
        import ad_player
        want = bool(app.watch_ads_var.get())
        ad_player.LOG = log
        try:
            ad_player.MIN_LEFT_SEC = max(60, int(app.ads_min_var.get()) * 60)   # 11/2 Settings "Only when ... more than"
        except Exception:                              # noqa: BLE001
            pass
        try:
            ad_player.EVENT_ONLY = bool(app.ads_event_var.get())          # 11/6 "Save ads for event dishes"
        except Exception:                              # noqa: BLE001
            pass
        if want != ad_player.ON:
            ad_player.ON = want
            log("[ads] watching ads " + ("ON -- timer cards with more than 1 min left get the free video ad" if want
                                         else "OFF"))
    except Exception:                                  # noqa: BLE001
        pass
    try:                                               # 11/1 FLASH step 3: Settings "FLASH fast taps"
        import fast_input
        want = bool(app.fast_taps_var.get())
        fast_input.LOG = log
        if want != fast_input.ON:
            fast_input.ON = want
            if not want:
                fast_input.reset()                     # closes the open adb shell
            log("[flash] fast taps " + ("ON -- taps go through one adb shell that stays open; the old way only "
                                        "when that fails" if want else "OFF -- one adb per tap, as before"))
    except Exception:                                  # noqa: BLE001
        pass
    ORDERS_TURN_MAX_SEC = max(60, num("clip_turn_var", 5) * 60)
    giveup = num("dismiss_min_var", 30)                                    # 10/23: one clock, then dismiss / skip 1 h
    if num("giveup_dismiss_var", 1):
        order_fulfill.SET_ASIDE_MIN, order_fulfill.DISMISS_MIN = 0, giveup
    else:
        order_fulfill.SET_ASIDE_MIN, order_fulfill.DISMISS_MIN = giveup, 0
    order_fulfill.CROP_RESERVE = num("crop_reserve_var", 2)                # 10/23: 0 = off
    order_fulfill.LONG_ORDER_MIN = num("long_order_min_var", 90)           # 10/26: 0 = off
    order_fulfill.KEEP_LINK = "apple_juice" if num("test_sell_apple_juice_var", 0) else None   # 10/25 Sell Apple Juice
    try:                                                                   # 11/9 O.R.D.E.R.: list = priority
        import job_order
        ticked = [k for k in _feature_order(app)
                  if getattr(app, FEATURES[k][0], None) is not None and getattr(app, FEATURES[k][0]).get()]
        on = bool(num("truck_first_var", 1))
        if (on, ticked) != (job_order.ON, job_order.ORDER):
            ranked = [job_order.short_name(k) for k in ticked if k in job_order.CLAIMS]
            log("[o.r.d.e.r.] " + (f"jobs list = priority: {' > '.join(ranked)} -- a lower job leaves alone what a "
                                   "higher job still needs" if on and len(ranked) > 1 else
                                   "off -- every job uses what it finds" if not on else
                                   "only one job with needs is ticked -- nothing to rank"))
        job_order.ON, job_order.ORDER = on, ticked
        order_fulfill.TRUCK_FIRST = on and "Food Truck (street)" in ticked
    except Exception:                                  # noqa: BLE001
        order_fulfill.TRUCK_FIRST = False
    try:
        _pick = int(app.quick_first_var.get())                             # 10/22; 10/27: 2 = best coins/hour
        order_fulfill.QUICK_FIRST = _pick in (1, 2)
        order_fulfill.RANK_BY_COINS = _pick == 2
    except Exception:                                  # noqa: BLE001
        order_fulfill.QUICK_FIRST, order_fulfill.RANK_BY_COINS = True, False
    try:
        event_orders.ALARM_ON = bool(app.alarm_var.get())
    except Exception:                                  # noqa: BLE001
        event_orders.ALARM_ON = True
    global DAILY_WHEEL, WHEEL_HOURS
    try:                                               # 10/31 (owner): Settings > Daily rewards
        DAILY_WHEEL = bool(app.wheel_var.get())
        WHEEL_HOURS = max(1, int(app.wheel_hours_var.get()))
    except Exception:                                  # noqa: BLE001
        DAILY_WHEEL, WHEEL_HOURS = True, 24


def _express_now(app):
    """True while Food Club Event is ticked and an express card is on its board (checked between jobs)."""
    try:
        return bool(app.event_orders_var.get() and event_orders.express_active())
    except Exception:                                  # noqa: BLE001
        return False


def chat_waiting(app):
    """11/14 (owner: "message never sent"): a phone message waits -> the chat job runs once even when the Chat update
    job is not ticked (Chat relay on in Settings)."""
    try:
        if not app.chat_on_var.get():
            return False
        import chat_relay
        return bool(chat_relay.pending(chat_relay.load()))
    except Exception:                                    # noqa: BLE001
        return False


def _run_chat(app, stop, cycle):
    """11/14 (owner): Chat relay -- open the club chat when due, save a picture for the phone page, close it."""
    try:
        if not app.chat_on_var.get() or _express_now(app):
            return
        import adb_helper
        import chat_relay
        import find_and_center as fac
        chat_relay.run(getattr(stop, "is_set", stop), log, adb_helper.screenshot, adb_helper.tap, adb_helper.back,
                       lambda: _decline_question(adb_helper), lambda: fac.close_any_open_panel(quiet=True),
                       type_text=lambda t: adb_helper._run(["shell", "input text '%s'" % t.replace(" ", "%s")]))
    except Exception as e:                             # noqa: BLE001 -- the chat must never stop AFSD
        log(f"[chat] job failed (ignored): {e!r}")


# key (checkbox text) -> (app attribute holding its BooleanVar, runner, runs during an express emergency)
FEATURES = {
    "Pork (Ham)": ("pork_var", _run_pork, False),
    "Whipped Cream": ("cream_var", _run_cream, False),
    "Garden Plot": ("carrot_var", _run_garden, False),
    "Auto Fulfill Orders": ("orders_var", _run_orders, False),
    "Keep fishing (sell extras)": ("fishing_var", _run_fishing, False),
    "Delivery Event": ("delivery_var", _run_delivery, False),
    "Food Truck Event (not yet functional)": ("food_truck_var", _run_food_truck, False),
    "Chef Challenge": ("chef_challenge_var", _run_chef, False),
    "Food Club Event": ("event_orders_var", _run_event_orders, True),
    "Food Truck (street)": ("street_truck_var", _run_street_truck, False),
    "Prep work": ("prep_var", _run_prep, False),
    "Tests": ("tests_var", _run_tests, False),
    "Busy Mode": ("busy_var", _run_busy, False),
    "Chat update": ("chat_var", _run_chat, False),
}


DAILY_WHEEL = True                    # 10/31: spin the free daily prize wheel while one of WHEEL_JOBS runs (Settings)
WHEEL_HOURS = 24                      # 10/31: Settings 'Spin it every' -- hours between visits
WHEEL_JOBS = ("Food Club Event", "Auto Fulfill Orders", "Prep work", "Tests", "Chef Challenge")


OLD_KEY_NAMES = {"Event Orders (current event board)": "Food Club Event",
                 "Food Club Event (current event board)": "Food Club Event"}


def _feature_order(app):
    """Keys in the order the app window lists them (falls back to FEATURES order)."""
    try:
        keys = [OLD_KEY_NAMES.get(k, k) for k, _ in app.list_rows]      # an app window started before the 10/10 rename still says "Event Orders"
        keys = [k for k in keys if k in FEATURES]
    except Exception:              # noqa: BLE001
        keys = []
    return keys + [k for k in FEATURES if k not in keys]


# ---------------------------------------------------------------------------
# Start LDPlayer and the game by itself (10/5). Called once when Start is pressed, before the first cycle.
# Does nothing when the emulator is running and the game is already in front.
# ---------------------------------------------------------------------------
DNCONSOLE = os.path.join(adb_helper.LDPLAYER_DIR, "dnconsole.exe")
GAME_PACKAGE = "com.supersolid.honestfood"
EMULATOR_BOOT_TIMEOUT_SEC = 300
GAME_LOAD_TIMEOUT_SEC = 240


def emulator_running():
    """True when LDPlayer's window (dnplayer.exe) or VM (Ld9BoxHeadless.exe) is running."""
    try:
        out = subprocess.run(["tasklist"], capture_output=True, text=True, errors="replace", timeout=15).stdout.lower()
        return "dnplayer.exe" in out or "ld9boxheadless.exe" in out
    except Exception:                                  # noqa: BLE001
        return True                                    # unknown -> assume yes, never launch a second one


def portrait_check(stop, set_status=None):
    """11/12 (Muse: 3 dead 30-min windows): the game is landscape; a PORTRAIT screen means an ad was left in front
    (LDPlayer turns with it). Sit the ad out / close the game with it and start the game again (ensure_game_ready)."""
    try:
        img = adb_helper.screenshot()
    except Exception:                                    # noqa: BLE001
        return False
    if img is None or img.ndim < 2 or img.shape[0] <= img.shape[1]:
        return False
    try:
        import ad_player
        if ad_player.ACTIVE:
            return False                                 # an ad is being watched on purpose
    except Exception:                                    # noqa: BLE001
        pass
    log(f"[ads] the screen is PORTRAIT ({img.shape[1]}x{img.shape[0]}) -- an ad was left in front; clearing it and "
        "starting the game again.")
    return ensure_game_ready(stop, set_status=set_status)


def _focused_app():
    import adb_helper
    try:
        r = adb_helper._run(["shell", "dumpsys window | grep mCurrentFocus"])
        return (r.stdout or b"").decode("utf-8", "ignore").strip()
    except Exception:                                  # noqa: BLE001
        return ""


def _adb_up():
    """True when `adb devices` lists the emulator as a ready device (short, direct call: no retries/back-off)."""
    import adb_helper
    try:
        out = adb_resilience.safe_run([adb_helper.ADB, "devices"], 10, text=True).stdout
        return any(ln.strip().endswith("\tdevice") for ln in out.splitlines()[1:])
    except Exception:                                  # noqa: BLE001
        return False


def _android_ready():
    """True once adb can talk to the emulator AND Android has finished booting. Uses plain short adb calls
    (10 s timeouts) so a half-booted emulator cannot stall this wait for minutes (10/5: the first real launch
    went silent for over a minute inside the sturdier retry/back-off path)."""
    import adb_helper
    try:
        if not _adb_up():
            adb_resilience.safe_run([adb_helper.ADB, "connect", adb_helper.PREFERRED_DEVICE], 10)
            if not _adb_up():
                return False
        adb_helper.DEVICE = None
        dev = adb_helper._resolve_device()
        r = adb_resilience.safe_run([adb_helper.ADB, "-s", dev, "shell", "getprop", "sys.boot_completed"], 10)
        return (r.stdout or b"").decode("utf-8", "ignore").strip() == "1"
    except Exception:                                  # noqa: BLE001
        return False


def _wait(seconds, stop):
    for _ in range(int(seconds)):
        if stop.is_set():
            raise StopRequested()
        time.sleep(1)


VM_DEAD_AFTER_SEC = 60
VM_RESTART_COOLDOWN_SEC = 30 * 60
_last_vm_restart = 0.0


def vm_alive():
    """True when LDPlayer's VM process (Ld9BoxHeadless.exe) is running. dnplayer.exe alone is just the window."""
    try:
        out = subprocess.run(["tasklist"], capture_output=True, text=True, errors="replace", timeout=15).stdout.lower()
        return "ld9boxheadless.exe" in out
    except Exception:                                  # noqa: BLE001
        return True                                    # unknown -> assume alive, never kill on a guess


# 10/29: every program LDPlayer 9 runs (window, multi-instance manager, VM, VM service) -- a leftover VM service
# kept a relaunched LDPlayer from ever booting (10/26 night, 10/29 morning after the PC slept).
LD_PROCS = ("dnplayer.exe", "dnmultiplayer.exe", "Ld9BoxHeadless.exe", "Ld9BoxSVC.exe",
            "LdVBoxHeadless.exe", "LdVBoxSVC.exe", "LdBoxHeadless.exe", "LdBoxSVC.exe")


def adb_hard_reset():
    """10/29 (Muse + owner): after the PC slept, LDPlayer sat on the Android Home Screen while adb said "no devices"
    for hours -- `adb connect` alone never brought it back. Stop the adb server, close EVERY adb.exe (LDPlayer starts
    its own, older adb that can hold the port), start a fresh server and reconnect. True = the emulator is seen again."""
    import adb_helper
    log("[hard restart] resetting adb: stop the server, close every adb.exe, start fresh, reconnect.")
    for cmd in ([adb_helper.ADB, "kill-server"],):
        try:
            adb_resilience.safe_run(cmd, 10)
        except Exception:                              # noqa: BLE001
            pass
    try:
        subprocess.run(["taskkill", "/F", "/IM", "adb.exe"], capture_output=True, text=True, errors="replace", timeout=20)
    except Exception:                                  # noqa: BLE001
        pass
    time.sleep(2)
    try:
        adb_resilience.safe_run([adb_helper.ADB, "start-server"], 30)
    except Exception as e:                             # noqa: BLE001
        log(f"[hard restart] adb start-server failed: {e!r}")
    for addr in (adb_helper.PREFERRED_DEVICE, "127.0.0.1:5555", "127.0.0.1:5554"):
        try:
            adb_resilience.safe_run([adb_helper.ADB, "connect", addr], 10)
        except Exception:                              # noqa: BLE001
            pass
    adb_helper.DEVICE = None
    time.sleep(2)
    ok = _adb_up()
    log("[hard restart] adb reset: " + ("the emulator is visible again." if ok else "still no emulator."))
    return ok


HARD_RESTART_COOLDOWN_SEC = 20 * 60
_hard = {"last": 0.0}


def hard_restart_emulator(say=lambda m: None, why=""):
    """Close EVERYTHING LDPlayer runs + reset adb, so the next launch is a true cold start. True = all closed."""
    now = time.time()
    if now - _hard["last"] < HARD_RESTART_COOLDOWN_SEC:
        log(f"[hard restart] already did one {int((now - _hard['last']) // 60)} min ago -- not again yet.")
        return False
    _hard["last"] = now
    log(f"[hard restart] {why} -- closing every LDPlayer program and adb, then a cold start.")
    say("Hard restart of LDPlayer...")
    closed = kill_emulator()
    try:
        adb_hard_reset()
    except Exception:                                  # noqa: BLE001
        pass
    time.sleep(5)
    log("[hard restart] LDPlayer " + ("fully closed." if closed and not emulator_running() else
                                     "did NOT fully close (Windows may want administrator rights)."))
    return not emulator_running()


def kill_emulator():
    """Close a dead LDPlayer so it can be launched fresh. LDPlayer was started elevated, so a plain taskkill may be
    refused -- then ask Windows to run it elevated (a Windows prompt appears; click Yes)."""
    ok = True
    try:                                               # 10/29: ask LDPlayer to close every instance first
        adb_resilience.safe_run([DNCONSOLE, "quitall"], 20)
        time.sleep(3)
    except Exception:                                  # noqa: BLE001
        pass
    for exe in LD_PROCS:
        try:
            r = subprocess.run(["taskkill", "/F", "/T", "/IM", exe], capture_output=True, text=True, errors="replace", timeout=20)
            if r.returncode not in (0, 128):           # 128 = process not found
                ok = False
        except Exception:                              # noqa: BLE001
            ok = False
    if not ok:
        try:
            import ctypes
            ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe",
                                                "/c " + " & ".join(f"taskkill /F /T /IM {x}" for x in LD_PROCS), None, 0)
        except Exception as e:                         # noqa: BLE001
            log(f"Could not ask Windows to close LDPlayer: {e}")
    time.sleep(5)
    return not emulator_running()


# --- Watchdog (10/20, owner 10/19: "if you can look back over the logs to prove it will help you can build it") ---
# Proof, logs 10/20: adb dropped out 7 times overnight; 6 came back by themselves within 24-383 s, but at 04:22 the
# emulator vanished from `adb devices` for good. The stall guard's restart (04:43, 05:13) only force-stops the GAME,
# which needs adb, then waits 300 s for Android while LDPlayer sits frozen -- 1 h 40 min lost until the owner pressed
# Stop at 06:02. Now, when the stall guard asks for a restart (only after ~20 min of failing, so the short drop-outs
# never trigger it) and LDPlayer is running but adb has no device, LDPlayer itself is closed and launched fresh.
# At most WATCHDOG_MAX_PER_RUN times per run, WATCHDOG_COOLDOWN_SEC apart.
WATCHDOG_COOLDOWN_SEC = 25 * 60
WATCHDOG_MAX_PER_RUN = 4
_watchdog = {"last": 0.0, "count": 0}


def watchdog_restart(say=lambda m: None, why="LDPlayer is running but adb lists no emulator"):
    """Close a frozen LDPlayer (ldconsole quit, then taskkill). True = closed (the launch code starts it again)."""
    now = time.time()
    if _watchdog["count"] >= WATCHDOG_MAX_PER_RUN or now - _watchdog["last"] < WATCHDOG_COOLDOWN_SEC:
        log(f"[watchdog] LDPlayer is frozen, but it was already restarted {_watchdog['count']}x this run / "
            f"{int((now - _watchdog['last']) // 60)} min ago -- not again yet.")
        return True
    if adb_hard_reset():                               # 10/29: often only adb lost the emulator -- no restart needed
        log("[watchdog] the adb reset found the emulator again -- not restarting LDPlayer.")
        return True
    _watchdog["last"], _watchdog["count"] = now, _watchdog["count"] + 1
    log(f"[watchdog] {why} -- closing LDPlayer and launching it fresh "
        f"(restart {_watchdog['count']} of max {WATCHDOG_MAX_PER_RUN} this run).")
    say("Emulator frozen -- restarting LDPlayer...")
    try:
        adb_resilience.safe_run([DNCONSOLE, "quit", "--index", "0"], 20)
    except Exception as e:                             # noqa: BLE001 -- 740 = needs administrator; taskkill below
        log(f"[watchdog] ldconsole quit did not work ({e!r}) -- closing it with taskkill.")
    for _ in range(10):
        if not emulator_running():
            break
        time.sleep(2)
    if emulator_running() and not kill_emulator():
        log("[watchdog] Could not close LDPlayer (Windows may want administrator rights -- start AFSD with "
            "'Run as administrator' so this works while nobody is at the PC).")
        return False
    log("[watchdog] LDPlayer closed -- launching it again.")
    return True


GAME_SIZE = (1600, 900)
_size_warned = {"t": 0.0}


def screen_size_check(img, now=None):
    """11/2 live: after an LDPlayer restart the emulator came back at 1920x1080 -- every template, spot and tap is
    made for 1600x900, so the board icon was never found. Warn loudly (log + toast-style alarm) at most every 30 min."""
    if img is None:
        return True
    h, w = img.shape[:2]
    if (w, h) == GAME_SIZE:
        try:                                             # 11/8: any 16:9 size is scaled to 1600x900 by adb_helper
            import adb_helper
            sc = adb_helper.SCALE[0]
            now = time.time() if now is None else now
            if abs(sc - 1.0) > 1e-6 and now - _size_warned.get("scaled", 0) >= 1800:
                _size_warned["scaled"] = now
                log(f"[screen] LDPlayer's screen is {round(1600 * sc)}x{round(900 * sc)} -- the bot scales it to "
                    f"1600x900 (taps x{sc:.2f}). 1600x900 itself is still the best-tested size.")
        except Exception:                                # noqa: BLE001
            pass
        return True
    now = time.time() if now is None else now
    if now - _size_warned["t"] >= 1800:
        _size_warned["t"] = now
        log(f"[screen] the emulator screen is {w}x{h} -- not a 16:9 shape, so the bot cannot scale it; set LDPlayer "
            f"Settings > Advanced > Resolution to {GAME_SIZE[0]}x{GAME_SIZE[1]} (or another 16:9 size) and restart it.")
        try:
            import no_progress
            no_progress.alarm(text=f"LDPlayer's screen is {w}x{h}, which is not 16:9 -- AFSD cannot use it.\n\n"
                                   "In LDPlayer: Settings > Advanced > Resolution -> 1600x900, save, restart LDPlayer.")
        except Exception:                                # noqa: BLE001
            pass
    return False


def ensure_game_ready(stop, set_status=None, force_restart=False, _hard_done=False):
    """Make sure LDPlayer is running, Android is up and the game is on its map. Returns True when the
    game's plain map is showing, False when it gave up (it logs why; the normal cycle still runs and its
    own popup/launcher handlers keep trying)."""
    import adb_helper
    say = set_status or (lambda m: None)
    if force_restart and emulator_running() and _adb_up():
        # stall guard (pass 5): the game is frozen / showing a stale picture -- start it fresh
        log("Force-stopping the game so it starts fresh (stall guard).")
        say("Restarting the game...")
        try:
            adb_helper._run(["shell", "am", "force-stop", GAME_PACKAGE])
        except Exception as e:                         # noqa: BLE001
            log(f"Could not force-stop the game: {e}")
        time.sleep(3)
    if force_restart and emulator_running() and not _adb_up():
        if not watchdog_restart(say):
            return False
    if not emulator_running():
        if not os.path.exists(DNCONSOLE):
            log(f"LDPlayer is not running and {DNCONSOLE} was not found -- start it by hand.")
            return False
        log("LDPlayer is not running -- launching it (dnconsole launch --index 0).")
        say("Launching LDPlayer...")
        try:
            subprocess.Popen([DNCONSOLE, "launch", "--index", "0"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except OSError as e:
            if getattr(e, "winerror", None) == 740:
                # LDPlayer's launcher needs administrator rights and AFSD was not started as administrator.
                # Ask Windows to run it elevated: a "Do you want to allow this app" prompt appears -- click Yes.
                # (Start AFSD with "Run as administrator" to never see the prompt.)
                log("LDPlayer needs administrator permission -- a Windows prompt should appear; click Yes "
                    "(or start AFSD with 'Run as administrator' to skip the prompt).")
                say("Click Yes on the Windows prompt to start LDPlayer...")
                try:
                    import ctypes
                    rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", DNCONSOLE, "launch --index 0", None, 0)
                    if rc <= 32:
                        log(f"Windows refused to start LDPlayer (code {rc}) -- start it by hand.")
                        return False
                except Exception as e2:                # noqa: BLE001
                    log(f"Could not ask Windows to start LDPlayer: {e2}")
                    return False
            else:
                log(f"Could not launch LDPlayer: {e}")
                return False
        except Exception as e:                         # noqa: BLE001
            log(f"Could not launch LDPlayer: {e}")
            return False
    t_start = time.time()
    last_note = -15
    adb_reset_at = 0
    while not _android_ready():
        waited = int(time.time() - t_start)
        if waited >= EMULATOR_BOOT_TIMEOUT_SEC:
            if not _hard_done and hard_restart_emulator(say, f"Android did not come up within {EMULATOR_BOOT_TIMEOUT_SEC}s"):
                return ensure_game_ready(stop, set_status=set_status, _hard_done=True)
            log(f"Android did not come up within {EMULATOR_BOOT_TIMEOUT_SEC}s -- giving up on the launch step.")
            return False
        # 10/29: the emulator can be up (Home Screen) while adb sees nothing -- reset adb hard every 90 s of that
        if waited >= 60 and waited - adb_reset_at >= 90 and not _adb_up():
            adb_reset_at = waited
            if adb_hard_reset():
                continue
            # 10/29 live 13:24: LDPlayer open on its Home Screen, the game says "try again later", and even a hard adb
            # reset sees no emulator = LDPlayer's network is broken (after the PC slept). Only a cold start fixes it
            # -- do it now instead of waiting out the full boot timeout.
            if not _hard_done and emulator_running() and hard_restart_emulator(
                    say, "LDPlayer is open but neither adb nor a hard adb reset can reach it"):
                return ensure_game_ready(stop, set_status=set_status, _hard_done=True)
        global _last_vm_restart
        if (waited >= VM_DEAD_AFTER_SEC and not vm_alive()
                and time.time() - _last_vm_restart > VM_RESTART_COOLDOWN_SEC):
            _last_vm_restart = time.time()
            log("LDPlayer's window is open but its VM (Ld9BoxHeadless.exe) is not running -- the emulator "
                "is dead. Closing it and launching it fresh.")
            say("Emulator is dead -- restarting LDPlayer...")
            if kill_emulator():
                return ensure_game_ready(stop, set_status=set_status)
            log("Could not close the dead LDPlayer -- close its window by hand, then press Start.")
        if waited - last_note >= 15:
            last_note = waited
            log(f"Waiting for the emulator to boot ({waited}s)...")
            say(f"Waiting for the emulator ({waited}s)...")
        if _adb_up():
            try:                                       # boot-time dialogs ("System UI isn't responding" ...)
                find_and_center.dismiss_error_dialog()
            except StopRequested:
                raise
            except Exception:                          # noqa: BLE001
                pass
        _wait(3, stop)
    if GAME_PACKAGE not in _focused_app():
        log("The game is not in front -- starting it.")
        say("Starting Food Street...")
        try:
            adb_helper._run(["shell", "monkey", "-p", GAME_PACKAGE, "-c", "android.intent.category.LAUNCHER", "1"])
        except Exception as e:                         # noqa: BLE001
            log(f"Could not start the game: {e}")
            return False
    import event_orders
    waited = 0
    black_since = None
    t_load = time.time()        # 10/26 live: each pass took ~60 s of adb time-outs, so counting +5 per pass made
    while waited < GAME_LOAD_TIMEOUT_SEC:          # "240 s" last 46 min -- the wall clock decides now
        try:
            try:                                                  # 11/2 live: Stop came mid-ad, the ad stayed in
                import ad_player                                  # front and every look here failed (cvtColor)
                ad_kind = ad_player.classify_focus(_focused_app())
                if ad_kind in ("applovin", "facebook"):
                    log(f"[ads] an ad ({ad_kind}) is in front at Start -- sitting it out before the game check.")
                    ad_player.LOG = ad_player.LOG or log          # 11/12: its step lines were silent at Start
                    ad_player.sit_out(stop, "left-over ad", ad_kind, already=ad_player.APPLOVIN_EXIT_AFTER_SEC)
                    if GAME_PACKAGE not in _focused_app():        # 11/12: the ad closed the game -> start it again
                        log("[ads] the game is not in front after the ad -- starting it.")
                        adb_helper._run(["shell", "monkey", "-p", GAME_PACKAGE, "-c",
                                         "android.intent.category.LAUNCHER", "1"])
                        _wait(8, stop)
            except StopRequested:
                raise
            except Exception as e:                               # noqa: BLE001
                log(f"[ads] left-over ad check failed: {e!r}")
            pre = adb_helper.screenshot()                         # 10/29: Whoops has an OK button the popup closer
            if waited >= 10 and whoops_by_picture(pre):           # would tap forever -- look for it first
                img, handled = pre, False
            else:
                handled = find_and_center.dismiss_error_dialog()     # launcher / loading / popups are handled in here
                img = adb_helper.screenshot()
            focus = _focused_app()
            if event_orders.hud_is_bright(img) and GAME_PACKAGE in focus:
                log(f"The game's map is showing (after {waited}s of waiting).")
                screen_size_check(img)
                _whoops["n"] = 0
                return True
            if GAME_PACKAGE in focus and _panel_x_showing(img):
                # 10/17: a station panel left open dims the map -- it waited 6 min on one. The game is
                # loaded; the cycle's normal panel closer taps its red X.
                log(f"The game is up with a panel open (red X found) -- starting; the panel gets closed first.")
                screen_size_check(img)
                return True
            if not handled and waited >= 10 and (whoops_by_picture(img) or (waited % 15 == 0 and _whoops_showing(img))):
                # 10/29 (owner): "Whoops, something went wrong. Please try again later" -- the game cannot reach its
                # server (emulator network lost after the PC slept, or the servers are down).
                # owner 10/29: "when it says that we know we need to go into the hard restart" -- no game restart first.
                _emulator_net_check()
                adb_helper.tap(*WHOOPS_OK)
                if not _hard_done and hard_restart_emulator(say, "the game says 'Whoops ... try again later'"):
                    return ensure_game_ready(stop, set_status=set_status, _hard_done=True)
                log("[whoops] still 'try again later' after a cold LDPlayer start (or one ran < 20 min ago) -- the "
                    "game's servers or the PC's internet are probably down. Backing off; later cycles try again.")
                return False
            if dead_screen(img, focus):
                # 11/12 live: after the game was closed to end a stuck ad, Android showed an ALL-BLACK screen with no
                # window in front (mCurrentFocus=null) for 30+ min; game relaunches and the adb reset did nothing
                # (the adb reset found the emulator, so LDPlayer was never restarted). A cold LDPlayer start is the cure.
                black_since = black_since or time.time()
                if time.time() - black_since >= BLACK_SCREEN_SEC and not _hard_done and hard_restart_emulator(
                        say, f"the screen has been all black with nothing in front for "
                             f"{time.time() - black_since:.0f} s"):
                    return ensure_game_ready(stop, set_status=set_status, _hard_done=True)
            else:
                black_since = None
            if not handled and waited and waited % 30 == 0:
                # Not the map and nothing we know how to close: probably a launch ad for another game
                # (LDPlayer shows them sometimes). Keep a picture + the focused app so it can be trained.
                log(f"Waiting for the game; the screen is not the map (focus: {focus.split('{')[-1].strip('} ')}).")
                try:
                    event_orders.save_unknown_screen(img)
                except Exception:                      # noqa: BLE001
                    pass
        except StopRequested:
            raise
        except Exception as e:                         # noqa: BLE001
            log(f"(waiting for the game: {e})")
        if waited % 30 == 0:
            say(f"Waiting for the game to load ({waited}s)...")
        _wait(5, stop)
        waited = max(waited + 5, int(time.time() - t_load) // 5 * 5)
    log(f"The game's map did not show within {GAME_LOAD_TIMEOUT_SEC}s -- continuing anyway.")
    return False


_whoops = {"n": 0}
BLACK_SCREEN_SEC = 90


def _ladder_ldplayer(stop, set_status):
    """Unstuck ladder's last rung. 11/12: watchdog_restart skips LDPlayer when the adb reset finds the emulator --
    right for an adb drop-out, useless for a dead (all-black, nothing in front) display -> a real cold start then."""
    try:
        img = adb_helper.screenshot()
        if dead_screen(img, _focused_app()):
            if hard_restart_emulator(set_status, "unstuck ladder: the screen is all black with nothing in front"):
                return ensure_game_ready(stop, set_status, _hard_done=True)
            return False
    except StopRequested:
        raise
    except Exception:                                   # noqa: BLE001
        pass
    return watchdog_restart(set_status, "unstuck ladder: a covered screen nothing else cleared") and \
        ensure_game_ready(stop, set_status)


def dead_screen(img, focus):
    """Pure (11/12): an all-black picture while Android has NO window in front (mCurrentFocus=null) = the emulator's
    display is dead, not a loading screen (the game's own loading screens are bright)."""
    try:
        black = img is not None and float(img.mean()) < 3.0
    except Exception:                                   # noqa: BLE001
        black = False
    return bool(black and "null" in (focus or "").lower() and GAME_PACKAGE not in (focus or ""))


def _whoops_showing(img):
    """10/29: the game's "Whoops, something went wrong. Please try again later" screen (read with Windows OCR)."""
    if whoops_by_picture(img):
        return True
    try:
        import popup_ocr
        t = (popup_ocr.read_text(img, (200, 150, 1400, 800)) or "").lower()
    except Exception:                                  # noqa: BLE001
        return False
    return is_whoops_text(t)


WHOOPS_TPL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "whoops_title.png")
WHOOPS_OK = (801, 729)                 # its green OK button (owner's 10/29 screenshot, scaled to 1600x900)
_whoops_tpl = {}


def whoops_by_picture(img):
    """The 'Whoops! Something went wrong! Please try again later!' title, by picture (templates/whoops_title.png)."""
    import cv2
    try:
        if "t" not in _whoops_tpl:
            t = cv2.imread(WHOOPS_TPL, 0)
            _whoops_tpl["t"] = t
        t = _whoops_tpl["t"]
        if t is None or img is None:
            return False
        g = cv2.cvtColor(img[80:400, 350:1250], cv2.COLOR_BGR2GRAY)
        return cv2.minMaxLoc(cv2.matchTemplate(g, t, cv2.TM_CCOEFF_NORMED))[1] >= 0.75
    except Exception:                                  # noqa: BLE001
        return False


UNABLE_LIMIT = 6                     # 10/31: this many "Unable to connect to server" popups ...
UNABLE_WINDOW_SEC = 600              # ... within this long = the network is out, not a blip
OFFLINE_WAIT_SEC = 300               # the PC itself is offline / the servers are down: rest this long, then look again
_unable_rest = [0.0]


def offline_kind(pc_online, emu_online):
    """What a run of 'Unable to connect' popups means (pure, tested): 'pc' = the PC has no internet (nothing in the
    bot can fix it -- wait), 'emulator' = only LDPlayer lost it (cold restart), 'servers' = both online (wait)."""
    if pc_online is False:
        return "pc"
    if emu_online is False:
        return "emulator"
    return "servers"


def _pc_net_check():
    """True when the PC itself can reach the internet (one ping), None when the check could not run."""
    try:
        flag = "-n" if os.name == "nt" else "-c"
        r = subprocess.run(["ping", flag, "1", "8.8.8.8"], capture_output=True, text=True, errors="replace", timeout=10)
        return r.returncode == 0
    except Exception:                                  # noqa: BLE001
        return None


def unable_check(stop, say=lambda m: None):
    """10/31 (logs 03:00-09:00: 'Unable to connect to server' 600+ times, the board could not open for ~5 h -- only the
    Whoops screen led to a restart). A run of these popups -> check the PC's and the emulator's internet: emulator
    only -> cold-start LDPlayer (hard_restart_emulator, its own 20-min limit); PC offline or servers down -> rest
    OFFLINE_WAIT_SEC instead of tapping OK 160 times an hour. Returns True when it acted."""
    now = time.time()
    if now < _unable_rest[0]:
        return False
    recent = [t for t in find_and_center.UNABLE_TIMES if now - t < UNABLE_WINDOW_SEC]
    if len(recent) < UNABLE_LIMIT:
        return False
    find_and_center.UNABLE_TIMES.clear()
    kind = offline_kind(_pc_net_check(), _emulator_net_check())
    log(f"[offline] 'Unable to connect to server' {len(recent)}x in {UNABLE_WINDOW_SEC // 60} min -- "
        + {"pc": "the PC itself has NO INTERNET; nothing to restart, resting 5 min.",
           "emulator": "the PC is online but LDPlayer is not -- cold-starting LDPlayer.",
           "servers": "the PC and LDPlayer are online -- probably the game's servers; resting 5 min."}[kind])
    if kind == "emulator" and hard_restart_emulator(say, "'Unable to connect to server' again and again"):
        ensure_game_ready(stop, set_status=say, _hard_done=True)
        return True
    _unable_rest[0] = time.time() + OFFLINE_WAIT_SEC
    say("Offline -- resting 5 min, then trying again.")
    end = time.time() + OFFLINE_WAIT_SEC
    while time.time() < end:
        if stop.is_set():
            break
        time.sleep(2)
    return True


def whoops_check(stop, say=lambda m: None):
    """10/29 (owner): the Whoops screen during normal play = LDPlayer lost its network -> cold-start LDPlayer.
    Returns True when it acted. A hard restart ran < 20 min ago -> only tap OK (the popup closer's old way)."""
    import adb_helper
    if unable_check(stop, say):
        return True
    try:
        if not whoops_by_picture(adb_helper.screenshot()):
            return False
    except StopRequested:
        raise
    except Exception:                                  # noqa: BLE001
        return False
    log("[whoops] 'Whoops! Something went wrong! Please try again later!' during play -- LDPlayer lost its network.")
    _emulator_net_check()
    adb_helper.tap(*WHOOPS_OK)
    if hard_restart_emulator(say, "the game says 'Whoops ... try again later'"):
        ensure_game_ready(stop, set_status=say, _hard_done=True)
    return True


def is_whoops_text(t):
    t = " ".join((t or "").lower().split())
    return "went wrong" in t or "try again later" in t or "whoops" in t


def _emulator_net_check():
    """Log whether the emulator itself can reach the internet (tells 'servers down' apart from 'network lost')."""
    import adb_helper
    try:
        r = adb_helper._run(["shell", "ping", "-c", "1", "-W", "3", "8.8.8.8"])
        out = (r.stdout or b"").decode("utf-8", "ignore")
        ok = " 0% packet loss" in out or "1 received" in out
        log("[whoops] emulator internet check: " + ("OK -- probably the game's servers." if ok else
                                                   "NO INTERNET inside the emulator -- LDPlayer's network is down."))
        return ok
    except Exception as e:                             # noqa: BLE001
        log(f"[whoops] emulator internet check failed: {e!r}")
        return None


def _panel_x_showing(img):
    """True when a panel's red close-X sits in the top-right corner (the panel closer's own search box)."""
    import cv2
    tpl = find_and_center.CLOSE_X_TEMPLATE
    res = cv2.matchTemplate(img[50:250, 1150:1580], tpl, cv2.TM_CCOEFF_NORMED)
    return cv2.minMaxLoc(res)[1] >= 0.9


def run_loop(app):
    # Capture THIS run's stop flag once: autofoodstreet gives every Start a
    # fresh Event, so an old loop that is slow to exit keeps seeing its own
    # (already set) flag instead of the new run's.
    stop = app.stop_flag
    reload_modules_at_start()
    try:                                         # 10/21 (owner): every test runs once per Start, not once a day
        import tests_job
        tests_job.reset_today()
    except Exception:                            # noqa: BLE001
        pass
    try:                                         # 10/26 workstream A: the no-progress clock starts fresh
        import no_progress
        no_progress.reset()
    except Exception:                            # noqa: BLE001
        pass
    try:                                         # 10/25 (owner): "not built" dishes are checked again after every Start
        import unbuilt
        unbuilt.forget_all()
    except Exception:                            # noqa: BLE001
        pass
    try:                                         # 11/1 FLASH step 1: fresh test counts every Start
        import flash
        flash.reset()
        import fast_input
        fast_input.reset()
        import find_and_center as _fac
        _fac.SLEEPS.clear()
    except Exception:                            # noqa: BLE001
        pass
    try:                                         # 11/14 (owner: "my PC is filling up"): old debug pictures out
        if getattr(app, "auto_clean_var", None) is None or app.auto_clean_var.get():
            import cleanup
            _paths, _size = cleanup.plan(days=cleanup.AUTO_DAYS)
            if _paths:
                _gone, _freed = cleanup.delete(_paths)
                log(f"[cleanup] deleted {_gone} debug pictures older than {cleanup.AUTO_DAYS} days "
                    f"({cleanup.gb(_freed)}).")
    except Exception as e:                       # noqa: BLE001
        log(f"[cleanup] skipped: {e!r}")
    try:
        import keep_awake
        keep_awake.start()
        log("Keeping Windows awake (display + system) while AFSD runs.")
    except Exception as e:                       # noqa: BLE001
        log(f"keep_awake not started: {e}")
    try:
        ensure_game_ready(stop, set_status=app.set_status)
    except StopRequested:
        app.set_status("Stopped.")
        return
    except Exception as e:                           # noqa: BLE001
        log(f"Launch step failed (continuing): {e}")
    try:                                             # gems / coins / ticket log (10/10): baseline at Start
        import currency_log
        currency_log.start_run()
    except Exception as e:                           # noqa: BLE001
        log(f"currency log start failed (ignored): {e}")
    cycle = 0
    _watchdog.update(last=0.0, count=0)              # 10/20 watchdog: fresh limit every run
    _tt.update(since=time.time(), jobs={}, gap=0.0, pts0=0)
    err_since = None                                 # 11/12: when the current run of erroring cycles began
    err_streak = 0                                   # 10/13: consecutive cycles that ended in an exception (emulator gone...) -> back off, quieter log
    while not stop.is_set():
        hot_reload_if_changed()
        cycle += 1
        cycle_t0 = time.time()
        errored = False
        log(f"--- cycle {cycle} start ---")
        try:
            import orders_view
            orders_view.note_cycle(cycle)            # 10/17: the progress line under Status
        except Exception:                            # noqa: BLE001
            pass
        try:                                    # stall guard (pass 5)
            import stall_guard
            if stall_guard.check_progress(log) == "restart_game":
                ensure_game_ready(stop, set_status=app.set_status, force_restart=True)
        except StopRequested:
            break
        except Exception as e:                  # noqa: BLE001
            log(f"Stall guard step failed (ignored): {e}")
        try:                                    # 10/26 workstream A: no REAL progress for 30/60/90 min -> ladder
            import no_progress
            act = no_progress.check(log, app._active_checkboxes(), err_since=err_since)
            if act == "restart_game":
                ensure_game_ready(stop, set_status=app.set_status, force_restart=True)
            elif act == "restart_ldplayer":
                if watchdog_restart(app.set_status, why="[no progress] nothing done for an hour, the game restart did "
                                                         "not help"):
                    ensure_game_ready(stop, set_status=app.set_status)
            elif act == "alarm":
                no_progress.alarm()
        except StopRequested:
            break
        except Exception as e:                  # noqa: BLE001
            log(f"[no progress] step failed (ignored): {e!r}")
        session_lock.acquire(owner="afsd_gui")  # refresh timestamp each cycle so a
                                                  # long-running session never reads
                                                  # as stale to session_lock.status()
        try:
            # The game's own "Whoops! Something went wrong" dialog (found live
            # 10/2) blocks every tap; clear it before any module runs.
            whoops_check(stop, lambda m: app.set_status(m))
            portrait_check(stop, app.set_status)
            for _ in range(4):  # several can stack (ANR -> Whoops -> reward...)
                if not find_and_center.dismiss_error_dialog():
                    break
            # EXPRESS ORDER = state of emergency (10/3): while the gold card is on the event
            # board only Event Orders runs; every other feature is paused.
            _apply_settings(app)
            try:                                   # 10/20 simulator plan, step 2/3: log-only kitchen snapshot
                import kitchen_model
                kitchen_model.tick(log)
            except Exception:                      # noqa: BLE001
                pass
            try:                                   # 11/9 O.R.D.E.R.: how often lower jobs held back
                import job_order
                job_order.tick(log)
            except Exception:                      # noqa: BLE001
                pass
            try:                                   # 11/1 FLASH step 1: window capture vs adb, log-only, every 10 min
                import flash
                flash.tick(log)
            except Exception:                      # noqa: BLE001
                pass
            if order_fulfill.DISMISS_REQUESTS:     # 10/21 (owner): Dismiss pressed on a clipboard order
                try:
                    order_fulfill.run_dismiss_requests(stop)
                except find_and_center.StopRequested:
                    raise
                except Exception as e:             # noqa: BLE001
                    log(f"DISMISS failed: {e!r}")
            try:                                   # 10/20 unstuck test (log only): notices a stuck screen, says what it WOULD try
                import unstuck
                unstuck.tick(log, act={                # 10/22: LIVE ladder for covered screens
                    "restart_game": lambda: ensure_game_ready(stop, app.set_status, force_restart=True),
                    "restart_ldplayer": lambda: _ladder_ldplayer(stop, app.set_status),
                })
            except Exception:                      # noqa: BLE001
                pass
            emergency = False
            try:
                emergency = bool(app.event_orders_var.get() and event_orders.express_active())
            except Exception:                  # noqa: BLE001
                pass
            if emergency:
                log(f"cycle {cycle}: EXPRESS ORDER ACTIVE -- emergency mode, only Event Orders runs.")
                app.set_status("EXPRESS ORDER -- emergency mode")
            # Run the ticked features in the ORDER THEY ARE LISTED in the app window (drag the
            # "\u2261" handle to reorder; 10/3). During an emergency only Event Orders runs.
            for key in _feature_order(app):
                var_name, runner, exempt = FEATURES[key]
                if not emergency and _express_now(app):
                    # 10/19 live: an express that appears MID-cycle used to wait while the jobs listed after
                    # Food Club (Auto Fulfill: 15 min) ran -- the express was missed. Check before every job.
                    emergency = True
                    log(f"cycle {cycle}: an EXPRESS order appeared during this cycle -- skipping the other jobs.")
                if emergency and not exempt:
                    continue
                var = getattr(app, var_name, None)
                if (var is None or not var.get()) and not (key == "Chat update" and chat_waiting(app)):
                    continue
                _t0 = time.time()
                try:
                    import job_order                         # 11/9 O.R.D.E.R.: which job is cooking right now
                    job_order.CURRENT[0] = key
                except Exception:                            # noqa: BLE001
                    pass
                try:
                    runner(app, stop, cycle)
                finally:
                    _tt["jobs"][key] = _tt["jobs"].get(key, 0.0) + time.time() - _t0
                    try:
                        job_order.CURRENT[0] = None
                    except Exception:                        # noqa: BLE001
                        pass
            if DAILY_WHEEL and not emergency and any(getattr(app, FEATURES[k][0], None) is not None
                                                      and getattr(app, FEATURES[k][0]).get() for k in WHEEL_JOBS):
                try:                                 # 10/31 (owner): the daily prize wheel, now a feature (once a day)
                    import importlib
                    import tests_job
                    importlib.reload(tests_job)
                    tests_job.daily_wheel_feature(stop, hours=WHEEL_HOURS)
                except StopRequested:
                    raise
                except Exception as e:               # noqa: BLE001
                    if type(e).__name__ == "StopRequested":
                        raise
                    log(f"[daily wheel] failed (ignored): {e!r}")
            try:
                import currency_log
                currency_log.snapshot("cycle")       # at most one reading per 10 min
            except Exception:                        # noqa: BLE001
                pass
            try:
                import prize_watch
                prize_watch.check()                  # logs PRIZE READY when an event icon shows a green check (every 2 min)
                if prize_watch.READY and not event_orders.express_active():
                    prize_watch.collect(stop)        # 11/14 (owner): collect it (free buttons only)
            except Exception:                        # noqa: BLE001
                pass
            try:
                run_trace.cycle_summary(cycle, cycle_t0)             # 10/10 run trace: one line per cycle
            except Exception:                                      # noqa: BLE001
                pass
            log(f"--- cycle {cycle} end (ok) ---")
            try:
                import stall_guard
                stall_guard.on_cycle_ok()
            except Exception:                   # noqa: BLE001
                pass
            app.set_status("Checked. Waiting for next check.")
        except StopRequested:
            log(f"cycle {cycle}: stopped by user mid-cycle.")
            break
        except Exception as e:
            if type(e).__name__ == "StopRequested":
                # 10/16: Start reloads find_and_center, so a Stop raised by the reloaded module is a different
                # StopRequested class than the one imported above -- it used to be logged as an EXCEPTION.
                log(f"cycle {cycle}: stopped by user mid-cycle.")
                break
            # Previously only ever shown in the status label -- lost the
            # instant it scrolled past or the app closed. This is the
            # single biggest gap for diagnosing an unattended run after
            # the fact, so log the full traceback, not just str(e).
            err_streak += 1
            err_since = err_since or time.time()
            if err_streak <= 3 or err_streak % 50 == 0:
                log(f"cycle {cycle}: EXCEPTION -- {e}\n{traceback.format_exc()}")
            elif err_streak == 4:
                log(f"cycle {cycle}: same kind of error again -- further repeats are logged only every 50th cycle until a cycle succeeds (waiting longer between tries).")
            try:
                import stall_guard
                stall_guard.on_cycle_error(str(e))
            except Exception:                   # noqa: BLE001
                pass
            app.set_status(f"Error during check: {e}")
            errored = True
        # no fixed pause between cycles (10/6): wait only if the cycle was suspiciously quick or failed
        if not errored:
            err_streak = 0
            err_since = None
        try:
            _time_test(log)
        except Exception:                            # noqa: BLE001
            pass
        gap = min(120, ERROR_GAP_SEC * max(1, err_streak - 3)) if errored else max(CHECK_INTERVAL_SEC, MIN_CYCLE_SEC - (time.time() - cycle_t0))
        _g0 = time.time()
        for _ in range(int(gap + 0.999)):
            if stop.is_set():
                break
            time.sleep(1)
        _tt["gap"] += time.time() - _g0
    try:
        import keep_awake
        keep_awake.stop()
    except Exception:                            # noqa: BLE001
        pass
    try:
        import currency_log
        currency_log.end_run()                       # "earned +N" summary
    except Exception as e:                           # noqa: BLE001
        log(f"currency summary failed (ignored): {e}")
    log("run_loop exited.")
    app.set_status("Stopped.")
