"""PROPOSED (pass 5, 10/5): notice when AFSD is running but getting nothing done, and fix it by itself.

Why: overnight 10/4 21:36 -> 10/5 07:44 AFSD logged 315 "ok" cycles and did NOTHING useful (0 queued, 0 planted,
0 completed; every board item "no travel tooltip appeared", 3,200 "Leftover open panel" taps at (1540,130)).
Windows' own System log shows why: the laptop entered Modern Standby at 21:25:35 (the first adb screencap time-out is
at 21:28:30) and only left it when the user woke the PC at 07:43:52. The emulator window stops drawing while the
display is off, so every screenshot was stale and every tap landed on nothing. Nothing in AFSD noticed.
keep_awake.py (pass 1) prevents most of it; this is the safety net for the rest (lid closed, power button, an
unplugged laptop with a short battery timeout...).

What it does (all from inside AFSD's own loop, never touches the game itself):
  * counts consecutive cycles that ended in an adb time-out / "no adb devices" exception;
  * reads the tail of run_loop's own log (since the last "Start pressed") and looks for "failing without ever
    getting anything done": >= 6 failure lines and no progress line for 20 minutes;
  * level 1 (2 failed cycles, or 3 min of failing): "wake_display()" = tell Windows the display is in use and nudge
    the mouse 1 pixel (turns an off display back on); at most once per 3 minutes;
  * level 2 (8 failed cycles, or 20 min of failing): returns "restart_game" once per 30 minutes; afsd_core then
    force-stops the game and starts it again through the normal launch code (ensure_game_ready);
  * logs a one-line explanation each time, including whether the PC is on battery.
It never taps anything in the game and never spends anything.
"""
import ctypes
import datetime
import os
import re
import time

BASE = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE, "run_log.txt")

WINDOW_MIN = 20              # no progress for this long, while failing -> restart the game
WAKE_AFTER_MIN = 3           # failing this long -> nudge the display awake
MIN_FAILURES = 6             # a quiet log with no failures is just "waiting on cooks", never a stall
RESTART_COOLDOWN_SEC = 30 * 60
WAKE_COOLDOWN_SEC = 3 * 60
ERR_STREAK_WAKE = 2
ERR_STREAK_RESTART = 8
TAIL_BYTES = 600_000

ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002

_PROGRESS = re.compile(
    r"queued \d+ batch|queued x\d|: queued$|planted \d|planted x\d|: planted$|tapping Complete|"
    r"harvested(?! \(or nothing)|"
    r"Merchant stock: queued|queued successfully|\bserved [1-9]|completed [1-9]", re.I)
_FAILURE = re.compile(
    r"travel_failed|no travel tooltip|Still detecting a panel|Board did not open|board_not_opened|"
    r"screencap.{0,40}timed out|No adb devices", re.I)
_TS = re.compile(r"^\[(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)\]")

_state = {"err_streak": 0, "last_wake": 0.0, "last_restart": 0.0}


# ---------------------------------------------------------------- pure analysis (tested offline)
def _ts(line):
    m = _TS.match(line)
    if not m:
        return None
    try:
        return datetime.datetime.strptime(m.group(1), "%Y-%m-%dT%H:%M:%S")
    except ValueError:
        return None


def analyze(lines, now):
    """lines: log lines (oldest first); now: datetime. Only lines after the LAST 'Start pressed' count
    (an old run's failures must never restart a fresh Start). Returns
    {failures, minutes, last_progress, stalled}."""
    start = 0
    for i, ln in enumerate(lines):
        if "Start pressed" in ln:
            start = i
    last_progress = None
    first_fail_after = None
    failures = 0
    for ln in lines[start:]:
        t = _ts(ln)
        if t is None:
            continue
        if _PROGRESS.search(ln):
            last_progress = t
            failures = 0
            first_fail_after = None
        elif _FAILURE.search(ln):
            failures += 1
            if first_fail_after is None:
                first_fail_after = t
    # time spent failing = from the first failure after the last progress line
    minutes = (now - first_fail_after).total_seconds() / 60.0 if first_fail_after else 0.0
    return {"failures": failures, "minutes": minutes, "last_progress": last_progress,
            "stalled": failures >= MIN_FAILURES and minutes >= WINDOW_MIN}


def decide(res, err_streak, now_ts, last_wake, last_restart):
    """-> 'ok' | 'wake' | 'restart_game' (pure; unit-tested)."""
    failing = res["failures"] >= MIN_FAILURES
    if now_ts - last_restart >= RESTART_COOLDOWN_SEC and (
            err_streak >= ERR_STREAK_RESTART or (failing and res["minutes"] >= WINDOW_MIN)):
        return "restart_game"
    if now_ts - last_wake >= WAKE_COOLDOWN_SEC and (
            err_streak >= ERR_STREAK_WAKE or (failing and res["minutes"] >= WAKE_AFTER_MIN)):
        return "wake"
    return "ok"


# ---------------------------------------------------------------- Windows helpers
def on_battery():
    """True/False, or None if unknown."""
    try:
        class _SPS(ctypes.Structure):
            _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                        ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                        ("BatteryLifeTime", ctypes.c_ulong), ("BatteryFullLifeTime", ctypes.c_ulong)]
        s = _SPS()
        if ctypes.windll.kernel32.GetSystemPowerStatus(ctypes.byref(s)):
            return {0: True, 1: False}.get(s.ACLineStatus)
    except Exception:                                  # noqa: BLE001
        pass
    return None


def wake_display():
    """One-shot 'the display is in use' + a 1-pixel mouse nudge there and back. Harmless."""
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(ES_DISPLAY_REQUIRED | ES_SYSTEM_REQUIRED)
        u = ctypes.windll.user32
        u.mouse_event(0x0001, 1, 0, 0, 0)
        u.mouse_event(0x0001, -1, 0, 0, 0)
        return True
    except Exception:                                  # noqa: BLE001
        return False


# ---------------------------------------------------------------- hooks used by afsd_core.run_loop
def on_cycle_ok():
    _state["err_streak"] = 0


def on_cycle_error(msg):
    m = (msg or "").lower()
    if "timed out" in m or "screencap" in m or "no adb devices" in m or "screenshot returned no data" in m:
        _state["err_streak"] += 1
    else:
        _state["err_streak"] = 0


def _read_tail(path, nbytes=TAIL_BYTES):
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - nbytes))
            return f.read().decode("utf-8", "replace").splitlines()
    except OSError:
        return []


def check_progress(logf=print, log_path=None, now=None):
    """Call at the start of every cycle. Returns 'ok', 'wake' or 'restart_game' (the caller restarts the game)."""
    try:
        now = now or datetime.datetime.now()
        res = analyze(_read_tail(log_path or LOG_PATH), now)
        action = decide(res, _state["err_streak"], time.time(), _state["last_wake"], _state["last_restart"])
        if action == "ok":
            return "ok"
        batt = on_battery()
        why = (f"{_state['err_streak']} cycle(s) in a row ended in an adb time-out; "
               f"{res['failures']} failure line(s) over {res['minutes']:.0f} min with no progress")
        hint = " The PC is running on BATTERY (it may be going to sleep)." if batt else ""
        if action == "wake":
            _state["last_wake"] = time.time()
            ok = wake_display()
            logf(f"Stall guard: AFSD is running but not getting anything done ({why}). Windows may have turned "
                 f"the display off / entered standby, which freezes the emulator picture. Nudged the display "
                 f"{'awake' if ok else '(nudge failed)'}.{hint}")
            return "wake"
        _state["last_restart"] = time.time()
        _state["last_wake"] = time.time()
        wake_display()
        _state["err_streak"] = 0
        logf(f"Stall guard: still stuck ({why}). Restarting the game through the normal launch steps.{hint}")
        return "restart_game"
    except Exception as e:                             # noqa: BLE001
        try:
            logf(f"Stall guard error (ignored): {e}")
        except Exception:                              # noqa: BLE001
            pass
        return "ok"
