"""First draft of persistent map-based navigation, inspired by the user's
robot-vacuum comparison. Scope, deliberately kept honest and small:

We do NOT yet do real dead-reckoning/world-coordinates. What this DOES do:
remember each station's screen position the last time it was seen (always
at the same self-verified reference zoom level, so positions are at least
comparable to each other), and try that remembered spot FIRST before
paying for a full zoom-out+spiral search. The remembered position is
always re-confirmed with a real detection before being trusted — a cache
miss just falls back to the existing, already-reliable full search. It
never trusts a stale hint blindly.

Every read/write is logged with enough detail to diagnose problems later
(see CLAUDE.md's "map failure modes" section this was built to address):
old vs new value on writes, hit/miss on reads, and the confidence of
whatever confirmed or rejected a cached hint.
"""
import os
import json
import time
import datetime
import cv2

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MAP_FILE = os.path.join(BASE_DIR, "world_map.json")
LOG = os.path.join(BASE_DIR, "run_log.txt")

HINT_CONFIRM_THRESHOLD = 0.6  # same bar as a normal accepted match — a
                               # cached hint gets no special leniency


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] {msg}\n")
    try:
        print(f"[{ts}] {msg}")
    except (AttributeError, OSError):
        pass


def _load():
    if not os.path.exists(MAP_FILE):
        return {}
    try:
        with open(MAP_FILE) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        log(f"[world_map] Map file unreadable ({e}) — treating as empty rather than crashing.")
        return {}


def _save(data):
    with open(MAP_FILE, "w") as f:
        json.dump(data, f, indent=2)


def get_hint(label):
    """Returns (loc, conf, age_seconds) from the last time this station
    was confirmed, or None if we've never seen it."""
    data = _load()
    entry = data.get(label)
    if entry is None:
        log(f"[world_map] No cached position for '{label}' — first time seeing this station.")
        return None
    age = time.time() - entry["timestamp"]
    age_str = f"{age:.0f}s ago" if age < 120 else f"{age/60:.1f}m ago" if age < 3600 else f"{age/3600:.1f}h ago"
    # Added 9/27 after a log review found Pig Pen/Dairy searches failing
    # constantly through an unattended afternoon/evening -- a stale cache
    # entry (hours old) was being retried exactly like a fresh one, with
    # no visibility into how old it actually was without checking the raw
    # JSON. Logging age in readable units (not just raw seconds) makes a
    # "this cache is probably useless by now" pattern visible at a glance.
    log(f"[world_map] Cached position for '{label}': {entry['loc']} "
        f"(confidence {entry['confidence']:.2f} when saved, {age_str}).")
    return entry["loc"], entry["confidence"], age


def record_sighting(label, loc, conf, zoom_diff_floor):
    """Save/update where a station was actually confirmed. Logs the old
    value alongside the new one so a bad overwrite is traceable, per the
    'never trust the log alone' lesson from earlier this session — the
    log itself needs to show enough to catch its OWN mistakes later."""
    data = _load()
    old = data.get(label)
    data[label] = {
        "loc": list(loc),
        "confidence": conf,
        "zoom_diff_floor": zoom_diff_floor,
        "timestamp": time.time(),
        "saved_at_readable": datetime.datetime.now().isoformat(timespec="seconds"),
    }
    _save(data)
    if old is None:
        log(f"[world_map] Recorded first-ever position for '{label}': {loc} (confidence {conf:.2f}).")
    else:
        log(f"[world_map] Updated '{label}': {old['loc']} (conf {old['confidence']:.2f}) "
            f"-> {loc} (conf {conf:.2f}).")


def try_hint(find_fn, label):
    """Attempt the fast path: if we have a cached position, check ONLY
    that spot (not a full-screen search) with a real detection call.
    Returns (loc, conf) if confirmed, or None if there's no hint or it
    didn't pan out — caller should fall back to the full search either
    way, this never blocks that fallback."""
    hint = get_hint(label)
    if hint is None:
        return None
    from adb_helper import screenshot
    img = screenshot()
    loc, conf = find_fn(img, fast=True)
    if loc is not None and conf >= HINT_CONFIRM_THRESHOLD:
        hx, hy = hint[0]
        dist = ((loc[0] - hx) ** 2 + (loc[1] - hy) ** 2) ** 0.5
        log(f"[world_map] Cache HIT for '{label}': confirmed at {loc} "
            f"(confidence {conf:.2f}), {dist:.0f}px from the cached spot.")
        return loc, conf
    log(f"[world_map] Cache MISS for '{label}' — current view doesn't confirm it "
        f"(best confidence {conf:.2f}). Falling back to full search.")
    return None
