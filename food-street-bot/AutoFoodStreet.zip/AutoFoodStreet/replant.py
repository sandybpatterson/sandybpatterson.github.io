"""O.R.C.H.A.R.D. step 4 -- REPLANT (owner 11/9: "lets work on #7", Let Me Play play_20261108_190920).

What the owner did (19 taps, coins 25,921 -> 25,886 -> 25,851, 35 per tree):
  build button (paintbrush, bottom-left ~97,815) -> Farming tab (495,268) -> drag the Apple Tree card ("11/20", 35
  coins) onto an empty green grid spot -> a green CHECK + red X appear above the new tree -> tap the check -> the menu
  comes back -> its red X (504,825; while placing it is the narrow column's X at 82,825). A spot that is not allowed
  shows red tiles and a GREY check -> red X cancels. The new tree then shows "Apple Tree 59m 54s [Skip gem 4]" --
  never tap Skip.

The bot replants right after it CUT a spent tree (picked_trees._cut), on the spot the cut tree stood on:
  1. drag the map so that spot sits at TARGET (clear of the build menu, which covers x < 560);
  2. build button -> Farming tab -> find the Apple Tree card (picture);
  3. drag the card onto TARGET -> green check (picture + green colour) = tap it; grey/none = red X, give up;
  4. close the build menu; read coins/gems before and after (gems must not move -- else replanting stops for the run).
Apple trees only for now (the only card picture we have). Max REPLANT_MAX_PER_DAY. Every step logs `[orchard]` and
saves a picture to templates/orchard/seen/ (Send logs).
"""
import os
import time

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TPL = os.path.join(BASE_DIR, "templates", "orchard", "replant")

LIVE = True                      # Settings > Orchard "Replant next to the same trees" (afsd_core)
REPLANT_MAX_PER_DAY = 3
TARGET = (900, 560)              # where the cut tree's spot is dragged to before placing (right of the build menu)
FARMING_TAB = (495, 268)
MENU_X = (504, 825)              # full build menu's red X
COLUMN_X = (82, 825)             # narrow column's red X while placing
BRUSH_MIN = 0.7
CARD_MIN = 0.8
CHECK_MIN = 0.65
CHECK_GREEN_MIN = 0.3            # green share inside the check: real 0.45-0.48, grey "not allowed" 0.00
X_MIN = 0.8
CARDS = {"apple": "apple_tree_card.png"}

_tpl = {}
_stopped = [None]                # reason replanting was switched off for this run (gems moved)


def _t(name):
    if name not in _tpl:
        _tpl[name] = cv2.imread(os.path.join(TPL, name))
    return _tpl[name]


def find(img, name, region=None):
    """Best match of a template -> (score, (cx, cy)) in full-screen coordinates."""
    t = _t(name)
    if img is None or t is None:
        return 0.0, None
    x1, y1, x2, y2 = region or (0, 0, img.shape[1], img.shape[0])
    sub = img[y1:y2, x1:x2]
    if sub.shape[0] < t.shape[0] or sub.shape[1] < t.shape[1]:
        return 0.0, None
    r = cv2.matchTemplate(sub, t, cv2.TM_CCOEFF_NORMED)
    _, m, _, loc = cv2.minMaxLoc(r)
    return float(m), (x1 + loc[0] + t.shape[1] // 2, y1 + loc[1] + t.shape[0] // 2)


def green_share(img, xy, r=30):
    x, y = xy
    crop = img[max(0, y - r):y + r, max(0, x - r):x + r]
    if crop.size == 0:
        return 0.0
    g = cv2.inRange(cv2.cvtColor(crop, cv2.COLOR_BGR2HSV), (40, 120, 120), (80, 255, 255))
    return float((g > 0).mean())


def placement(img):
    """Pure: after dropping the card -> ("ok", check_xy) | ("not_allowed", x_xy) | ("none", None)."""
    sc, xy = find(img, "check.png", (200, 80, 1600, 760))
    if sc >= CHECK_MIN and xy and green_share(img, xy) >= CHECK_GREEN_MIN:
        return "ok", xy
    sx, xxy = find(img, "cancel_x.png", (200, 80, 1600, 760))
    if sx >= X_MIN:
        return "not_allowed", xxy
    return "none", None


def kind_of(name):
    n = (name or "").lower()
    return next((k for k in CARDS if k in n), None)


def _hud(img):
    try:
        import coin_digits
        return coin_digits.read_hud(img) or {}
    except Exception:                          # noqa: BLE001
        return {}


def _pic(img, tag):
    try:
        import picked_trees
        return picked_trees._orchard_pic(img, tag)
    except Exception:                          # noqa: BLE001
        return None


def _close_menu(tap, sleep, screenshot):
    for _ in range(3):
        img = screenshot()
        if find(img, "build_button.png", (0, 700, 260, 900))[0] >= BRUSH_MIN:
            return True                        # map with the paintbrush = menu closed
        s1, xy1 = find(img, "cancel_x.png", (420, 740, 600, 900))
        s2, xy2 = find(img, "cancel_x.png", (0, 740, 180, 900))
        xy = xy1 if s1 >= s2 else xy2
        if max(s1, s2) < X_MIN:
            return False
        tap(*xy)
        sleep(1.2)
    return False


def after_cut(name, tap_xy, st, log, tap=None, sleep=None, screenshot=None, swipe=None):
    """Replant one tree where `name` was just cut. Returns True when the game took the new tree."""
    kind = kind_of(name)
    if not LIVE or not kind or not tap_xy:
        if LIVE and not kind:
            log(f"[orchard] replant: no card picture for '{name}' yet -- only apple trees are replanted.")
        return False
    if _stopped[0]:
        log(f"[orchard] replant: off for this run -- {_stopped[0]}.")
        return False
    today = time.strftime("%Y-%m-%d")
    done = st.setdefault("replants", {}).get(today, 0)
    if done >= REPLANT_MAX_PER_DAY:
        log(f"[orchard] replant: {done} already today (max {REPLANT_MAX_PER_DAY}) -- leaving the spot empty.")
        return False
    if tap is None or screenshot is None or swipe is None:
        from adb_helper import tap as _tap, screenshot as _shot, swipe as _swipe
        tap, screenshot, swipe = tap or _tap, screenshot or _shot, swipe or _swipe
    sleep = sleep or time.sleep
    x, y = tap_xy
    if abs(x - TARGET[0]) > 30 or abs(y - TARGET[1]) > 30:
        swipe(x, y, TARGET[0], TARGET[1], 900)     # the spot follows the finger to TARGET
        sleep(1.5)
    img = screenshot()
    sb, bxy = find(img, "build_button.png", (0, 700, 260, 900))
    if sb < BRUSH_MIN:
        log(f"[orchard] replant: build button not found (match {sb:.2f}) -- not replanting; picture "
            f"{_pic(img, 'replant_no_brush')}.")
        return False
    before = _hud(img)
    tap(*bxy)
    sleep(1.5)
    tap(*FARMING_TAB)
    sleep(1.2)
    img = screenshot()
    card = CARDS[kind]
    sc, cxy = find(img, card, (0, 0, 460, 900))
    if sc < CARD_MIN:
        log(f"[orchard] replant: '{name}' card not on the Farming list (match {sc:.2f}) -- closing the build menu; "
            f"picture {_pic(img, 'replant_no_card')}.")
        _close_menu(tap, sleep, screenshot)
        return False
    swipe(cxy[0], cxy[1], TARGET[0], TARGET[1], 1200)
    sleep(1.5)
    img = screenshot()
    what, pxy = placement(img)
    pic = _pic(img, "replant_drop")
    if what != "ok":
        log(f"[orchard] replant: the game did not accept the spot ({what}) -- cancelling; picture {pic}.")
        if pxy:
            tap(*pxy)
            sleep(1.2)
        _close_menu(tap, sleep, screenshot)
        return False
    tap(*pxy)
    sleep(1.5)
    after = screenshot()
    try:
        import order_fulfill as of
        no, _c = of.find_no_button(after)
        if no is not None:                     # a buy question (out of coins -> gems?) -- never Yes
            tap(*no)
            sleep(1.0)
            _stopped[0] = "the check asked a buy question (answered No)"
            log(f"[orchard] replant: confirming asked a buy question -- tapped No, replanting off for this run.")
            _close_menu(tap, sleep, screenshot)
            return False
    except Exception:                          # noqa: BLE001
        pass
    _close_menu(tap, sleep, screenshot)
    end = screenshot()
    now_hud = _hud(end)
    gems_b, gems_a = before.get("gems"), now_hud.get("gems")
    coins_b, coins_a = before.get("coins"), now_hud.get("coins")
    if gems_b is not None and gems_a is not None and gems_a < gems_b:
        _stopped[0] = f"gems went {gems_b} -> {gems_a}"
        log(f"[orchard] replant: GEMS DROPPED {gems_b} -> {gems_a} -- replanting off for this run.")
    paid = (coins_b - coins_a) if (coins_b is not None and coins_a is not None) else None
    st["replants"][today] = done + 1
    log(f"[orchard] REPLANTED '{name}' where the old one stood ({done + 1} today)"
        + (f"; coins {coins_b} -> {coins_a} (-{paid})" if paid is not None else "")
        + f"; pictures {pic} -> {_pic(end, 'replant_after')}.")
    return True
