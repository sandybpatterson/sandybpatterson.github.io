"""Runs locally, unattended, via Windows Task Scheduler — no AI/API calls.
Finds the Pig Pen on the map (searching if needed), checks whether a Ham
batch queue slot is free, and queues another batch if so. Logs everything.
Never touches gem-spend UI (Skip/Unlock buttons) under any circumstance.
"""
import os
import sys
import time
import datetime
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from adb_helper import screenshot, tap, swipe, pinch
from find_and_center import find_and_center, StopRequested, check_stop, close_any_open_panel, dismiss_buy_missing_dialog

LOG = os.path.join(BASE_DIR, "run_log.txt")
# Two templates at different zoom levels, since template matching isn't
# scale-invariant and the camera zoom varies depending on how the user last
# left it.
PIG_PEN_TEMPLATES = [
    cv2.imread(os.path.join(BASE_DIR, "templates", "pig_pen.png")),
    cv2.imread(os.path.join(BASE_DIR, "templates", "pig_pen_zoomed.png")),
]
MATCH_THRESHOLD = 0.6

MAX_SEARCH_STEPS = 40  # thorough — try many hops before giving up
HOP_PX = 160  # controlled drag distance (calibrated earlier: ~150-200px avoids fling)


def spiral_moves(max_steps):
    """Expanding square spiral: right, down, left x2, up x2, right x3, ...
    Covers a widening area around the starting point so a bounded search
    still reaches far-away stations eventually, without needing to know
    the map's actual size."""
    directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]  # right, down, left, up
    moves = []
    seg_len = 1
    d = 0
    while len(moves) < max_steps:
        for _ in range(2):
            dx, dy = directions[d % 4]
            for _ in range(seg_len):
                moves.append((dx, dy))
                if len(moves) >= max_steps:
                    return moves
            d += 1
        seg_len += 1
    return moves


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] {msg}\n")
    try:
        print(f"[{ts}] {msg}")
    except (AttributeError, OSError):
        pass  # no console attached (e.g. launched via pythonw.exe) — log file still gets it


SCALES = [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4]


FAST_SCALES = [0.4, 0.6, 0.8, 1.0, 1.2, 1.4]  # coarser set, for search only


def find_pig_pen(img, return_scale=False, fast=False):
    """Multi-scale template match — the camera's zoom level varies, and
    plain matchTemplate isn't scale-invariant, so try each template at
    several sizes and keep the best-scoring one. With return_scale=True,
    also returns the winning scale factor.

    fast=True downsamples the search image 2x and uses a coarser scale
    list — full-res matching measured at ~4.2s per call (22 scale x
    template combos against a 1600x900 image), which made a 40-step
    spiral search take minutes. Use fast=True while searching/scanning;
    only the final confirming check (once roughly centered) needs full
    precision."""
    search_img = img
    factor = 1.0
    scales = SCALES
    if fast:
        factor = 0.5
        search_img = cv2.resize(img, (int(img.shape[1] * factor), int(img.shape[0] * factor)))
        scales = FAST_SCALES

    best_loc, best_val, best_scale = None, 0.0, None
    for template in PIG_PEN_TEMPLATES:
        th, tw = template.shape[:2]
        for scale in scales:
            eff_scale = scale * factor
            w, h = int(tw * eff_scale), int(th * eff_scale)
            if w < 10 or h < 10 or w > search_img.shape[1] or h > search_img.shape[0]:
                continue
            resized = cv2.resize(template, (w, h))
            res = cv2.matchTemplate(search_img, resized, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
            if max_val > best_val:
                best_val = max_val
                best_loc = (int((max_loc[0] + w // 2) / factor), int((max_loc[1] + h // 2) / factor))
                best_scale = scale
    found = best_val >= MATCH_THRESHOLD
    loc = best_loc if found else None
    if return_scale:
        return loc, best_val, (best_scale if found else None)
    return loc, best_val


HAM_READY_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "ham_ready.png"))
READY_SCALES = [0.7, 0.85, 1.0, 1.15, 1.3]  # narrower range — checked right after
                                             # find_and_center's fixed zoom-in, so
                                             # scale is already fairly consistent
READY_THRESHOLD = 0.6


def find_ready_ham(img):
    """The finished-batch 'ready to collect' indicator — a giant ham icon
    floating near the station, tappable directly without even opening the
    panel. Distinct from is_slot_empty, which only tells us whether a
    NEW batch can be queued; this catches an already-finished batch that
    needs collecting first, which was a real gap — a batch sitting
    uncollected keeps its queue slot occupied forever, so Produce would
    never get re-triggered for it."""
    best_loc, best_val = None, 0.0
    th, tw = HAM_READY_TEMPLATE.shape[:2]
    for scale in READY_SCALES:
        w, h = int(tw * scale), int(th * scale)
        if w < 10 or h < 10 or w > img.shape[1] or h > img.shape[0]:
            continue
        resized = cv2.resize(HAM_READY_TEMPLATE, (w, h))
        res = cv2.matchTemplate(img, resized, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val > best_val:
            best_val = max_val
            best_loc = (max_loc[0] + w // 2, max_loc[1] + h // 2)
    if best_val >= READY_THRESHOLD:
        return best_loc, best_val
    return None, best_val


def is_slot_empty(img, x1, y1, x2, y2):
    """Empty queue slots show plain white 'EMPTY' text on a dark box;
    occupied ones show a colorful ham icon + timer, which has
    meaningfully more pixel variance. Recalibrated 9/23 against a real
    panel screenshot: occupied measured ~85 std, empty ~56 std — the old
    threshold (18.0) was calibrated against the wrong screen region
    entirely (see the coordinate fix above) and was meaningless here."""
    region = img[y1:y2, x1:x2]
    return float(np.std(region)) < 70.0


def main(stop_flag=None):
    log("=== run start ===")
    try:
        check_stop(stop_flag)
        close_any_open_panel()

        # Check for a ready-to-collect Ham BEFORE searching for Pig Pen —
        # the ham icon floats on top of the barn/fence shape our Pig Pen
        # template relies on, which can drop match confidence below
        # threshold (observed: 0.4 vs the 0.6 cutoff) while the ham sits
        # there uncollected. Clearing it first un-blocks the view.
        img = screenshot()
        ready_loc, ready_conf = find_ready_ham(img)
        if ready_loc is not None:
            log(f"Ready-to-collect Ham visible before searching for Pig Pen "
                f"(at {ready_loc}, confidence {ready_conf:.2f}) — collecting "
                "it first so it doesn't block Pig Pen detection.")
            tap(*ready_loc)
            time.sleep(1)
        else:
            log(f"No ready-to-collect Ham visible up front (best match "
                f"{ready_conf:.2f}). Proceeding to find Pig Pen normally.")

        loc, conf = find_and_center(find_pig_pen, label="Pig Pen", stop_flag=stop_flag)

        if loc is None:
            log("Pig Pen not found. Giving up this run — no changes made. "
                "Please check manually.")
            return

        log(f"Pig Pen located and centered at {loc} (confidence {conf:.2f}).")

        # Check for a finished batch sitting uncollected BEFORE opening the
        # panel — a real gap found during testing: an uncollected ready batch
        # keeps its queue slot occupied forever, so is_slot_empty would never
        # see it as free and Produce would never fire again for that slot.
        img = screenshot()
        ready_loc, ready_conf = find_ready_ham(img)
        if ready_loc is not None:
            log(f"Ready-to-collect Ham found at {ready_loc} (confidence "
                f"{ready_conf:.2f}) — collecting it.")
            tap(*ready_loc)
            time.sleep(1)
        else:
            log(f"No ready-to-collect Ham visible (best match {ready_conf:.2f}).")

        check_stop(stop_flag)
        log("Opening panel.")
        tap(*loc)
        time.sleep(1)
        img = screenshot()

        # These offsets are relative to the Pig Pen panel's fixed layout.
        # RECALIBRATED 9/23 ~2:42 PM — the original coordinates (slot boxes
        # at x:255-645,y:570-745, produce at 370,503) were simply wrong and
        # silently sampled the wrong screen region this whole time, so
        # is_slot_empty was returning bogus results and the Produce tap was
        # landing on nothing. Verified against a real panel screenshot:
        # slot1 box ~x:510-695,y:650-825, slot2 box ~x:705-890,y:650-825,
        # Produce button for the 45m Ham recipe at (620,585).
        slot1_box = (510, 650, 695, 825)
        slot2_box = (705, 650, 890, 825)
        produce_button = (620, 585)

        slot1_empty = is_slot_empty(img, *slot1_box)
        slot2_empty = is_slot_empty(img, *slot2_box)
        log(f"Slot1 empty={slot1_empty}, Slot2 empty={slot2_empty}")

        if slot1_empty or slot2_empty:
            log("Free queue slot detected — tapping Produce (Ham, 45m, 2 carrots).")
            tap(*produce_button)
            time.sleep(1)
            # Insufficient ingredients trigger a "Buy missing ingredients?"
            # gem-spend prompt right here — check for it immediately
            # rather than waiting for the next run's startup check.
            dismiss_buy_missing_dialog()
        else:
            log("Both queue slots occupied — nothing to do this run.")

        close_button = (1541, 124)
        tap(*close_button)
        log("=== run end ===")
    except StopRequested:
        log("=== run stopped early by user ===")
        raise


if __name__ == "__main__":
    main()
