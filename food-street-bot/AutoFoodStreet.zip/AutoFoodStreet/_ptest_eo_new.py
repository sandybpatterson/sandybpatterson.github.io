"""Auto Fulfill Orders for time-limited EVENTS (first built 10/2 for the
Storybook Cafe event). Designed so a different event with different art
still works: nothing here depends on event-specific templates.

Generic anchors used instead of per-event art:
  * the lime-green action buttons (Complete / Make / Gather / ...) -- found
    by colour + shape, never by their label text;
  * red/green count-text blobs for ingredient rows (a card with N
    ingredients shows N coloured blobs, wherever they sit);
  * SIFT feature matching to link a small board/ingredient icon to the big
    art on a station card (the two are different art assets at different
    scales, so plain template matching never works -- see CLAUDE.md);
  * the game's own "?" quick-travel tooltip for routing.

Safety rules baked in: never tap trash buttons, the hearts "+" upgrade,
the queue "Unlock" button, or any gem button. Never spend gems.
"""
import os
import sys
import time
import datetime

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import adb_helper
import order_fulfill as of
import event_digits
import find_and_center as fac
from find_and_center import StopRequested

LOG = os.path.join(BASE_DIR, "run_log.txt")

# Where the event's "orders list" icon sits on the bottom nav (the shoes icon
# for Storybook Cafe). Per-event; update here (or a future profile file) when
# a new event starts. None-safe: open_board() fails soft if it is wrong.
BOARD_ICON_LOC = (1055, 822)

# Board geometry (1600x900), measured live 10/2 on the Storybook board.
CARD_BTN_Y = 830            # centre y of the Complete buttons
CARD_BTN_TO_CX = -46        # card centre x = button centre x + this
SLOT_DX = (-70, 70)         # icon column offsets from card centre
ROW_ICON_Y = (570, 710)     # icon centre y per row
ROW_TEXT_Y = (618, 758)     # count-text centre y per row

SIFT_MIN_INLIERS = 20
SIFT_MIN_RATIO = 3.0


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] [event] {msg}\n")
    try:
        print(f"[{ts}] [event] {msg}")
    except (AttributeError, OSError):
        pass


# --------------------------------------------------------------------------
# Generic vision helpers
# --------------------------------------------------------------------------

def find_green_buttons(img, y1=0, y2=900, min_w=150, max_w=330, min_h=40, max_h=95):
    """Finds lime-green rounded action buttons. Returns [(cx, cy, w, h)],
    left-to-right then top-to-bottom. Colour + shape only, so it works for
    any label (Make / Gather / Complete / Produce...)."""
    band = img[y1:y2]
    hsv = cv2.cvtColor(band, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (35, 150, 140), (60, 255, 255))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, _, stats, cents = cv2.connectedComponentsWithStats(mask)
    out = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if min_w <= w <= max_w and min_h <= h <= max_h and area > 0.45 * w * h:
            out.append((int(x + w / 2), int(y + h / 2) + y1, int(w), int(h)))
    out.sort(key=lambda b: (b[1] // 40, b[0]))
    return out


def sift_match_score(small_bgr, big_bgr):
    """RANSAC inlier count of SIFT matches between a small icon and a larger
    card art. Higher = more likely the same picture. 0 on any failure."""
    def prep(im):
        h, w = im.shape[:2]
        s = 240.0 / max(h, w)
        im = cv2.resize(im, (max(1, int(w * s)), max(1, int(h * s))),
                        interpolation=cv2.INTER_CUBIC)
        return cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    try:
        sift = cv2.SIFT_create()
        k1, d1 = sift.detectAndCompute(prep(small_bgr), None)
        k2, d2 = sift.detectAndCompute(prep(big_bgr), None)
        if d1 is None or d2 is None or len(k1) < 2 or len(k2) < 2:
            return 0
        bf = cv2.BFMatcher()
        good = []
        for pair in bf.knnMatch(d1, d2, k=2):
            if len(pair) == 2 and pair[0].distance < 0.8 * pair[1].distance:
                good.append(pair[0])
        if len(good) < 4:
            return 0
        src = np.float32([k1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst = np.float32([k2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
        _, inl = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC,
                                             ransacReprojThreshold=6)
        return int(inl.sum()) if inl is not None else 0
    except cv2.error:
        return 0


def _hs_hist(im):
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)
    h = cv2.calcHist([hsv], [0, 1], None, [18, 8], [0, 180, 0, 256]).flatten()
    return h / (h.sum() + 1e-9)


# Weaker-evidence tiers (found live 10/2: soft low-texture icons -- a Dairy
# "Whipped Cream" swirl gave SIFT 12 vs 4, a tiny smooth Cow Shed "Milk" bottle
# gave SIFT 5 vs 2 -- right card, under the 20-inlier bar):
#  tier 2: SIFT top >= 10 and >= 2.5x runner-up AND the colour-histogram vote
#          (HS intersection) picks the SAME card with >= 0.35 and >= 1.5x.
#  tier 3: colour alone, when it is decisive (>= 0.30 and >= 2x the runner-up)
#          AND SIFT does not contradict it (no other card with SIFT >= 8).
# Histograms use the top 70% of the icon so a count-text overlay at its bottom
# edge ("0/1") does not pollute the colours.
SIFT_WEAK_MIN = 10
SIFT_WEAK_RATIO = 2.5
HIST_MIN = 0.35
HIST_RATIO = 1.5
HIST_ONLY_MIN = 0.30
HIST_ONLY_RATIO = 2.0
SIFT_CONTRADICT = 8


def pick_best(small_bgr, candidates):
    """candidates = [(key, big_bgr)]. Returns (best_key_or_None, scores).
    Accepts on strong SIFT, or weaker SIFT + colour agreement, or decisive
    colour that SIFT does not contradict."""
    scores = [(k, sift_match_score(small_bgr, b)) for k, b in candidates]
    ranked = sorted(scores, key=lambda kv: kv[1], reverse=True)
    if not ranked:
        return None, scores
    best, bs = ranked[0]
    rs = ranked[1][1] if len(ranked) > 1 else 0
    if bs >= SIFT_MIN_INLIERS and bs >= SIFT_MIN_RATIO * max(rs, 1):
        return best, scores
    if len(candidates) < 2:
        return None, scores
    ih = _hs_hist(small_bgr[:max(1, int(small_bgr.shape[0] * 0.7))])
    hs = sorted(((k, float(np.minimum(ih, _hs_hist(b)).sum())) for k, b in candidates),
                key=lambda kv: kv[1], reverse=True)
    hk, hv = hs[0]
    hr = max(hs[1][1], 1e-9)
    if bs >= SIFT_WEAK_MIN and bs >= SIFT_WEAK_RATIO * max(rs, 1):
        if hk == best and hv >= HIST_MIN and hv >= HIST_RATIO * hr:
            log(f"weak SIFT ({bs} vs {rs}) accepted: colour histogram agrees ({hv:.2f} vs {hr:.2f}).")
            return best, scores
    if hv >= HIST_ONLY_MIN and hv >= HIST_ONLY_RATIO * hr:
        contradicted = any(k != hk and sc >= SIFT_CONTRADICT for k, sc in scores)
        if not contradicted:
            log(f"colour decisive ({hv:.2f} vs {hr:.2f}), SIFT weak ({bs}) but not contradicting -- accepted.")
            return hk, scores
    return None, scores


def count_blobs(img, y1, y2, x1, x2, merge_gap=24):
    """Finds the red/green count-text blobs ("0/1", "5/1") inside a box.
    The game draws these in PURE 255 red/green with a dark outline, which
    card art almost never contains, so strict channel thresholds separate
    them cleanly. Returns [(cx, 'red'|'green')] left-to-right; blobs of the
    same colour closer than merge_gap are one count."""
    box = img[y1:y2, x1:x2].astype(int)
    b, g, r = box[:, :, 0], box[:, :, 1], box[:, :, 2]
    masks = (("red", (r > 235) & (g < 45) & (b < 45)),
             ("green", (g > 235) & (r < 45) & (b < 45)))
    hits = []
    for color, m in masks:
        cols = np.where(m.sum(axis=0) >= 2)[0]
        for x in cols:
            hits.append((int(x1 + x), color))
    hits.sort()
    groups = []
    for x, color in hits:
        if groups and groups[-1]["color"] == color and x - groups[-1]["x2"] <= merge_gap:
            groups[-1]["x2"] = x
        else:
            groups.append({"color": color, "x1": x, "x2": x})
    return [((g["x1"] + g["x2"]) // 2, g["color"]) for g in groups if g["x2"] - g["x1"] >= 8]


# HUD corner holding the board's own blue "?" help button (matches the
# tooltip "?" template at 0.99 -- tapping it would be wrong). Masked out.
HELP_BUTTON_ZONE = (1250, 0, 1600, 220)   # x1, y1, x2, y2


def find_tooltip_question(img):
    """Like order_fulfill.find_question_button but ignores the board's own
    help button in the top-right corner. Returns (loc_or_None, confidence)."""
    res = cv2.matchTemplate(img, of.QUESTION_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    th, tw = of.QUESTION_TEMPLATE.shape[:2]
    x1, y1, x2, y2 = HELP_BUTTON_ZONE
    res[max(0, y1 - th):y2, max(0, x1 - tw):x2] = -1
    _, mv, _, ml = cv2.minMaxLoc(res)
    if mv < of.QUESTION_MATCH_THRESHOLD:
        return None, float(mv)
    return (ml[0] + tw // 2, ml[1] + th // 2), float(mv)


def tap_item_and_travel(tap_xy, label, stop_flag=None):
    """Taps an item, then (same script, within the ~4s tooltip window) taps
    the tooltip's "?" so the camera travels to its source. Declines any
    gem-buy dialog. Returns True if travel was triggered."""
    adb_helper.tap(*tap_xy)
    of.interruptible_sleep(0.3, stop_flag)
    img = adb_helper.screenshot()
    q, qc = find_tooltip_question(img)
    if q is None:
        no, nc = of.find_no_button(img)
        if no is not None:
            log(f"'{label}': tap opened a gem-buy dialog ({nc:.2f}) -- declining, never spending gems.")
            adb_helper.tap(*no)
        else:
            log(f"'{label}': no travel tooltip appeared (best '?' {qc:.2f}).")
        return False
    adb_helper.tap(*q)
    of.interruptible_sleep(2.0, stop_flag)
    return True


# --------------------------------------------------------------------------
# Board
# --------------------------------------------------------------------------

def read_board(img):
    """Returns a list of cards: {cx, btn:(x,y), slots:[{row,col,icon:(x,y),color}]}.
    Slot colour comes from the count text under each icon; empty slots are
    omitted."""
    cards = []
    for bx, by, _, _ in find_green_buttons(img, y1=780, y2=890):
        cx = bx + CARD_BTN_TO_CX
        slots = []
        for row in (0, 1):
            for col, dx in enumerate(SLOT_DX):
                tx = cx + dx
                # Strict pure-255 text blobs, NOT of._sample_color: a ready
                # card turns tan, and the tan background of its EMPTY slots
                # read as "red" there (seen live 10/2).
                blobs = count_blobs(img, ROW_TEXT_Y[row] - 12, ROW_TEXT_Y[row] + 12,
                                    tx - 32, tx + 32)
                if not blobs:
                    continue
                color = "red" if any(c == "red" for _, c in blobs) else "green"
                slots.append({"row": row, "col": col,
                              "icon": (tx, ROW_ICON_Y[row]), "color": color})
        cards.append({"cx": cx, "btn": (bx, by), "slots": slots})
    return cards


def card_is_ready(card):
    return bool(card["slots"]) and all(s["color"] == "green" for s in card["slots"])


def board_is_open(img):
    if len(find_green_buttons(img, y1=780, y2=890)) < 1:
        return False
    # The board's own orange-brown background (BGR ~26,62,128); a lime-green
    # hedge on the map was mistaken for a Complete button on 10/2.
    b, g, r = img[600:700, 60:200].reshape(-1, 3).mean(0)
    return b < 70 and 40 < g < 95 and 100 < r < 165


BOARD_ICON_TEMPLATE = os.path.join(BASE_DIR, "templates", "event_board_icon.png")
# The template is only the LEFT part of the shoes (a ready-badge covers the right
# part). A tap lands at the template's top-left + this offset = the icon's middle
# (template origin (1005,795), icon middle (1055,822)).
BOARD_ICON_TAP_OFFSET = (50, 27)
BOARD_ICON_REGION = (880, 720, 1320, 900)   # x1, y1, x2, y2 of the bottom event-icon bar


def hud_is_bright(img):
    """True when the screen is a PLAIN, undimmed map view (no popup / panel on top).
    Measured on the permanent bright-white Orders clipboard in the bottom-right nav:
    its 90th-percentile brightness reads 244-245 on every plain map (including dark
    or green crop-plot maps) and <= 234 under every popup/panel (most 50-62). The old
    whole-HUD-strip mean (>=155) wrongly rejected a green crop-plot map (153.7)."""
    v = cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2]
    return float(np.percentile(v, 90)) >= 240


def find_board_icon(img):
    """Finds the event's orders icon (the shoes) in the bottom nav bar by image,
    not by a fixed coordinate. Returns (x, y) or None. Per-event template:
    templates/event_board_icon.png (crop of the icon art only: no timer text,
    no badge). If the template file is missing, falls back to BOARD_ICON_LOC."""
    # Never tap the nav bar while a modal/panel dims the HUD (the template matcher
    # ignores brightness, so it would "find" the icon under a dimmed popup).
    if not hud_is_bright(img):
        return None
    tpl = cv2.imread(BOARD_ICON_TEMPLATE)
    if tpl is None:
        return BOARD_ICON_LOC
    x1, y1, x2, y2 = BOARD_ICON_REGION
    r = cv2.matchTemplate(img[y1:y2, x1:x2], tpl, cv2.TM_CCOEFF_NORMED)
    _, v, _, l = cv2.minMaxLoc(r)
    if v >= 0.6:
        return (x1 + l[0] + BOARD_ICON_TAP_OFFSET[0], y1 + l[1] + BOARD_ICON_TAP_OFFSET[1])
    # A green "ready" checkmark / number badge can cover the shoes so the template
    # misses (seen live 10/2: AFSD then could never open the board exactly when
    # cards were ready). If the screen is a PLAIN bright map view -- HUD not dimmed
    # by a popup/panel (modals measure <=140, plain maps >=166) -- the nav icon is
    # a fixed HUD button, so tapping its known spot is safe.
    if hud_is_bright(img):
        return BOARD_ICON_LOC
    return None


_last_unknown_save = 0.0


def save_unknown_screen(img):
    """An unrecognised screen is blocking the nav bar: keep a capture (at most
    one per 30s) in templates/unknown_screens/ so it can be trained as a
    popup. Never taps anything."""
    global _last_unknown_save
    if time.time() - _last_unknown_save < 30:
        return
    _last_unknown_save = time.time()
    d = os.path.join(BASE_DIR, "templates", "unknown_screens")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{int(time.time())}.png")
    cv2.imwrite(path, img)
    log(f"Saved the unrecognised screen to {path} -- send it to be trained as a popup.")


# When the event icon cannot be found, try these in order -- each rung is followed by
# a full re-check (dialogs, open panels, then the icon) before the next one (user, 10/2).
# Gestures are the project's proven ones (find_and_center's zoom pinch / hop drag).
RECOVERY_LADDER = ("zoom out", "swipe left")


def _recovery_gesture(name):
    if name == "zoom out":
        adb_helper.pinch(800, 450, 350, 80, steps=15)
    elif name == "swipe left":
        adb_helper.swipe(1000, 450, 600, 450, 600)        # drag left


def open_board(stop_flag=None):
    """Opens the event board and verifies it. SAFE ordering (a blind repeated
    tap at the icon spot once opened the Prize Tent, found live 10/2, and on an
    open board that same spot is card 3's TRASH button): look at the screen
    FIRST, never tap the icon while a board/panel is already up.
    If the icon cannot be found: zoom out and check again, then swipe left and check
    again (RECOVERY_LADDER) -- every rung starts with the dialog + open-panel checks.
    Any zoom-out is undone afterwards so later plot sweeps see the normal zoom."""
    rung = 0
    zoomed_out = False
    try:
        for _ in range(4 + len(RECOVERY_LADDER) * 2):
            of.check_stop(stop_flag)
            img = adb_helper.screenshot()
            if board_is_open(img):
                return img
            if fac.dismiss_error_dialog():          # Whoops / ANR / reward / Prize Tent...
                continue
            if station_panel_open(img) or of.panel_is_open(img):
                fac.close_any_open_panel(quiet=True, thorough=True)
                continue
            loc = find_board_icon(img)
            if loc is None:
                log("Board icon not found on screen -- not tapping blindly.")
                # A world-space info card (a crop's grow-timer card with its Skip [gem] button,
                # seen live 10/2) dims the HUD but its red X is nowhere near the corner:
                # search the whole screen for a red X and close it (never touching Skip).
                # Pass 2 (10/4): try this FIRST and only keep a picture of the screen when
                # nothing could be closed (it used to save every closable card as "unknown").
                if fac.close_any_open_panel(quiet=True, thorough=True):
                    log("Closed an open info card / panel (red X found) -- checking again.")
                    continue
                save_unknown_screen(img)
                if rung < len(RECOVERY_LADDER):
                    step = RECOVERY_LADDER[rung]
                    rung += 1
                    log(f"Recovery {rung}/{len(RECOVERY_LADDER)}: {step}, then checking panels and the icon again.")
                    _recovery_gesture(step)
                    zoomed_out = zoomed_out or step == "zoom out"
                    time.sleep(1.8)
                else:
                    time.sleep(1.5)
                    if rung >= len(RECOVERY_LADDER):
                        break
                continue
            adb_helper.tap(*loc)
            time.sleep(1.5)
            img = adb_helper.screenshot()
            if board_is_open(img):
                return img
        log("Board did not open (checked before every tap).")
        return None
    finally:
        if zoomed_out:
            adb_helper.pinch(800, 450, 80, 300, steps=15)     # undo the zoom-out
            time.sleep(1.2)


# --------------------------------------------------------------------------
# Station panels (stoves / merchants): find the card for an item, read its
# ingredients, recurse on a red one or press the action button
# --------------------------------------------------------------------------

STATION_BTN_Y = (540, 640)
EVENT_QUEUE_SLOTS = 2        # event stoves show 2 queue slots + a locked "Unlock"
MAX_DEPTH = 4
PENDING_DIR = os.path.join(BASE_DIR, "templates", "event_pending")


def station_buttons(img):
    return [b for b in find_green_buttons(img, 150, 800)
            if STATION_BTN_Y[0] <= b[1] <= STATION_BTN_Y[1]]


def station_panel_open(img):
    return len(station_buttons(img)) >= 1


def count_empty_slots(img):
    """Number of queue slots showing the white EMPTY label."""
    x1, y1, x2, y2 = of.QUEUE_SLOT_REGION
    res = cv2.matchTemplate(img[y1:y2, x1:x2], of.QUEUE_EMPTY_LABEL_TEMPLATE,
                            cv2.TM_CCOEFF_NORMED)
    xs = sorted(np.where(res >= 0.85)[1])
    clusters = []
    for x in xs:
        if not clusters or x - clusters[-1] > 40:
            clusters.append(int(x))
    return len(clusters)


def card_art(img, bx, by):
    return img[by - 298:by - 112, bx - 100:bx + 80]


def ingredient_icon(img, x, by):
    return img[by - 114:by - 60, x - 32:x + 32]


def board_icon(img, ix, iy):
    return img[iy - 62:iy + 28, ix - 55:ix + 55]


def _thumb(im):
    return cv2.resize(cv2.cvtColor(im, cv2.COLOR_BGR2GRAY), (24, 24)).astype(np.int16)


def _same(a, b, tol=14):
    return float(np.abs(_thumb(a) - _thumb(b)).mean()) < tol


def save_pending(icon, panel_img, why):
    os.makedirs(PENDING_DIR, exist_ok=True)
    stamp = int(time.time())
    cv2.imwrite(os.path.join(PENDING_DIR, f"{stamp}_icon.png"), icon)
    if panel_img is not None:
        cv2.imwrite(os.path.join(PENDING_DIR, f"{stamp}_panel.png"), panel_img)
    log(f"Saved unresolved capture to templates/event_pending/{stamp}_* ({why}).")


def _normal_library_card(icon, img, btns):
    """Fallback for ORDINARY items the image matcher cannot place (soft, low-detail
    icons such as an egg vs a drumstick, seen live 10/2 at the Chicken Coop): name the
    icon with the normal INGREDIENT library (sliding match, reliable), then find that
    dish's card on the panel by its trained PANEL art. Returns a button index or None."""
    try:
        r = of.identify_ingredient(icon)
        name = r.get("name") if isinstance(r, dict) else None
        if not name:
            return None
        cx, conf = of.find_dish_in_panel(img, name)
        if cx is None:
            return None
        i = min(range(len(btns)), key=lambda k: abs(btns[k][0] - cx))
        if abs(btns[i][0] - cx) > 60:
            return None
        log(f"normal-library fallback: icon is '{name}' (panel art match {conf:.2f}) -> card {i}")
        return i
    except Exception as e:                       # noqa: BLE001 -- a fallback must never break the run
        log(f"normal-library fallback failed: {e}")
        return None


def work_station(icon, label, depth, stop_flag, ctx, want=1):
    """On an open event station panel: pick the card matching `icon`, read
    its ingredients (colour AND have/need counts), then either chase the ingredient that
    is short or press the green button (only if every queue slot is EMPTY).
    `want` = how many of this item are still needed (express orders count what to make):
    a short ingredient is chased for its real deficit (need*want - have), and when
    everything is available up to min(want, batches the stock allows, EMPTY slots)
    batches are queued in one visit."""
    img = adb_helper.screenshot()
    btns = station_buttons(img)
    if not btns:
        return "no_panel"
    best, scores = pick_best(icon, [(i, card_art(img, b[0], b[1])) for i, b in enumerate(btns)])
    log(f"'{label}': card SIFT inliers per card {[s for _, s in scores]} -> "
        f"{'card ' + str(best) if best is not None else 'NO CONFIDENT MATCH'}")
    if best is None:
        best = _normal_library_card(icon, img, btns)
    if best is None:
        save_pending(icon, img, "card match not confident")
        return "unsure"
    bx, by = btns[best][0], btns[best][1]
    blobs = count_blobs(img, by - 70, by - 40, bx - 175, bx + 175)
    log(f"'{label}': ingredient counts {blobs}")
    if not blobs:
        return "unreadable"
    n = max(1, int(want or 1))
    ing = []       # [{x, color, have, need}]  (have/need None when the digits are unreadable)
    for x, color in blobs:
        rc = event_digits.read_count(img, x, by - 55)
        ing.append({"x": x, "color": color,
                    "have": rc["have"] if rc else None, "need": rc["need"] if rc else None})
    shown = ", ".join(f"{i['have']}/{i['need']}" if i["have"] is not None else "?" for i in ing)
    log(f"'{label}': have/need per ingredient [{shown}], wanting {n} of this item")

    def deficit(i, batches):
        if i["have"] is None:
            return 1 if i["color"] == "red" else 0
        return max(0, i["need"] * batches - i["have"])

    # 1) an ingredient that is red (cannot make even ONE batch): chase it, biggest deficit first
    reds = sorted((i for i in ing if i["color"] == "red"), key=lambda i: -deficit(i, n))
    if reds:
        if depth >= MAX_DEPTH:
            return "too_deep"
        i = reds[0]
        d = max(1, deficit(i, n))
        sub = ingredient_icon(img, i["x"], by)
        log(f"'{label}': short of an ingredient -- chasing {d} of it.")
        r = chase(sub, (i["x"], by - 56), f"{label}>ingredient", depth + 1, stop_flag, ctx, want=d)
        return f"recursed:{r}"
    # 2) one batch is possible; how many batches does the stock allow?
    k = n
    for i in ing:
        if i["have"] is not None and i["need"]:
            k = min(k, i["have"] // i["need"])
    k = max(1, k)
    art = card_art(img, bx, by)
    if any(_same(art, a) for a in ctx["made"]):
        return "already_made_this_run"
    n_empty = count_empty_slots(img)
    if n_empty < EVENT_QUEUE_SLOTS:
        log(f"'{label}': queue not empty ({n_empty}/{EVENT_QUEUE_SLOTS} EMPTY) -- already cooking, not queueing more.")
        return "waiting"
    batches = min(k, n_empty)
    queued = 0
    cur_empty = n_empty
    for _ in range(batches):
        adb_helper.tap(bx, by)
        of.interruptible_sleep(1.2, stop_flag)
        img2 = adb_helper.screenshot()
        no, nc = of.find_no_button(img2)
        if no is not None:
            log(f"'{label}': action opened a gem-buy dialog -- declining.")
            adb_helper.tap(*no)
            return "blocked_gem_dialog" if not queued else f"queued x{queued}"
        n2 = count_empty_slots(img2)
        if n2 < cur_empty:
            queued += 1
            cur_empty = n2
            if n2 == 0:
                break
        else:
            # Pass 2 (10/4): ~9 recent "tap the button" attempts ended "EMPTY slots stayed N". Look again after
            # a longer wait (the panel may redraw late) and keep both pictures so the real cause can be seen.
            of.interruptible_sleep(2.5, stop_flag)
            img3 = adb_helper.screenshot()
            n3 = count_empty_slots(img3)
            if n3 < cur_empty:
                queued += 1
                cur_empty = n3
                log(f"'{label}': the queue showed the new batch a moment later (EMPTY {n_empty} -> {n3}).")
                if n3 == 0:
                    break
                continue
            try:
                folder = os.path.join(BASE_DIR, "templates", "event_tapfail")
                os.makedirs(folder, exist_ok=True)
                stamp = int(time.time())
                cv2.imwrite(os.path.join(folder, f"{stamp}_before.png"), img)
                cv2.imwrite(os.path.join(folder, f"{stamp}_after.png"), img3)
            except Exception:
                pass
            log(f"'{label}': tapped the button but EMPTY slots stayed {n3} even after waiting -- NOT verified "
                "(before/after pictures saved to templates/event_tapfail/).")
            break
    ctx["made"].append(art)
    if queued:
        log(f"'{label}': queued {queued} batch(es) (wanted {n}, stock allowed {k}, EMPTY {n_empty} -> {cur_empty}).")
        return "queued" if queued == 1 else f"queued x{queued}"
    return "tap_unverified"


# --------------------------------------------------------------------------
# Plots (raw crops)
# --------------------------------------------------------------------------

BAR_CARD_X0, BAR_CARD_DX = 140, 281   # measured on the real 1600x900 emulator 10/2
BAR_CARD_Y = 260                       # tap point inside a card (art area)


def bar_is_open(img):
    """The 'Tap crops to plant them' bar: a perfectly FLAT dark strip across the top
    (pixel spread 0-0.7 on every real bar) with PALE-BLUE crop cards at its left.
    The old test (strip mean < 100 and a light card pixel) wrongly fired on a plain
    map with dark foliage, so arrival 'saw' a bar, tried to plant, and never tapped a
    single plot (10/2). Flatness + blue card separate it from maps (spread 26+) and
    station panels (spread ~6)."""
    strip = img[100:125, 1000:1250]
    if strip.std() > 2.5 or strip.mean() > 90:
        return False
    b, g, r = img[150:160, 228:238].reshape(-1, 3).mean(0)
    return b >= 235 and (b - r) >= 35


def bar_cards(img):
    out = []
    for k in range(6):
        cx = BAR_CARD_X0 + BAR_CARD_DX * k
        if cx > 1450:
            break
        if img[150:160, cx + 88:cx + 98].mean(axis=(0, 1)).min() > 150:
            out.append(cx)
    return out


def plant_item(icon, label, stop_flag, times=1):
    img = adb_helper.screenshot()
    if not bar_is_open(img):
        log(f"'{label}': plant bar is not open -- not planting.")
        return "bar_closed"
    cards = bar_cards(img)
    best, scores = pick_best(icon, [(cx, img[150:335, cx - 125:cx + 125]) for cx in cards])
    log(f"'{label}': plant-bar SIFT inliers {[s for _, s in scores]} -> {best}")
    if best is None:
        save_pending(icon, img, "plant-bar match not confident")
        return "unsure"
    adb_helper.tap(best, BAR_CARD_Y)
    of.interruptible_sleep(1.0, stop_flag)
    img2 = adb_helper.screenshot()
    no, nc = of.find_no_button(img2)
    if no is not None or fac.dismiss_error_dialog():
        # a 0-stock crop pops "You are out of X! Buy and plant one now? [No] [Yes N gems]"
        if no is not None:
            adb_helper.tap(*no)
        log(f"'{label}': out of that crop (stock 0) -- declined the gem purchase, nothing planted.")
        return "no_stock"
    planted = 1
    for _ in range(max(0, int(times) - 1)):
        img3 = adb_helper.screenshot()
        if not bar_is_open(img3):
            break                                   # no empty plot left (the bar closed itself)
        adb_helper.tap(best, BAR_CARD_Y)
        of.interruptible_sleep(1.0, stop_flag)
        img4 = adb_helper.screenshot()
        no, nc = of.find_no_button(img4)
        if no is not None or fac.dismiss_error_dialog():
            if no is not None:
                adb_helper.tap(*no)
            log(f"'{label}': ran out of that crop after {planted} -- declined the gem purchase.")
            break
        planted += 1
    log(f"'{label}': planted {planted} (tapped bar card at x={best}, wanted {times}).")
    return "planted" if planted == 1 else f"planted x{planted}"


def plot_points(img, max_points=8):
    """Tap points for the crop plots on screen, nearest the centre first.
    A plot = a brown soil blob (HSV) ringed by grey/white stone, wide rhombus shaped.
    Rejects the orange rug, a player's hair, grills, the tent doorway (rim colour,
    aspect ratio) and the HUD / nav / event-icon zones. Planted plots show less
    soil, so min area is small."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, (5, 90, 35), (22, 230, 130))
    m[:100, :] = 0
    m[780:, :] = 0
    m[:, 1380:] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    out = []
    for i in range(1, n):
        area, w, h = int(st[i][4]), int(st[i][2]), int(st[i][3])
        if area < 1800 or h == 0:
            continue
        ratio, fill = w / h, area / float(w * h)
        if not (1.3 <= ratio <= 3.2) or fill < 0.20 or int(cen[i][0]) < 110:
            continue
        blob = (lab == i).astype(np.uint8)
        ring = cv2.dilate(blob, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (45, 45))) - blob
        px = hsv[ring > 0]
        stone = float(((px[:, 1] < 55) & (px[:, 2] > 60)).mean())
        if stone < 0.35:
            continue
        out.append((int(cen[i][0]), int(cen[i][1])))
    out.sort(key=lambda p_: (p_[0] - 800) ** 2 + (p_[1] - 450) ** 2)
    return out[:max_points]


def sweep_plots(stop_flag=None, max_taps=6):
    """GO AROUND: tap each crop plot on screen in turn and read what the game does --
    nothing = a ready crop was harvested, a grow-timer card = still growing (closed
    without touching its Skip), the plant bar = an empty plot (stop, caller plants).
    Returns (kind, found_any): kind in {'plot' (bar open), 'growing', None}."""
    img = adb_helper.screenshot()
    pts = plot_points(img)
    log(f"plot sweep: {len(pts)} plot(s) found {pts[:max_taps]}")
    timer_seen = False
    for (x, y) in pts[:max_taps]:
        of.check_stop(stop_flag)
        adb_helper.tap(x, y)
        of.interruptible_sleep(1.1, stop_flag)
        im2 = adb_helper.screenshot()
        if bar_is_open(im2):
            log(f"plot at ({x},{y}): empty -> plant bar opened")
            return "plot", True
        if fac.dismiss_error_dialog():
            continue
        if of.close_any_open_panel(quiet=True, thorough=True):
            timer_seen = True
            log(f"plot at ({x},{y}): timer card = still growing (confirmed), closed it")
        else:
            log(f"plot at ({x},{y}): no panel -> ready crop harvested (or nothing to do)")
    return ("growing" if timer_seen else None), bool(pts)


def arrive(stop_flag):
    """After a quick-travel: wait for a station panel / plant bar. If neither is up,
    tap screen-centre at most twice (collects a finished batch / opens a station
    panel). The centre is only right when quick-travel could centre the camera; at a
    map edge it may hit a plot's rim or a nearby building (food truck, 10/2) -- so if
    that opens nothing useful, GO AROUND and tap each plot on screen (sweep_plots).
    Returns (kind, tapped_any)."""
    of.interruptible_sleep(1.0, stop_flag)
    taps = 0
    saw_timer = False
    for i in range(3):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if station_panel_open(img):
            return "station", taps > 0
        if bar_is_open(img):
            return "plot", taps > 0
        if i == 2:
            break
        if taps >= 1:
            # the previous centre-tap opened something that is not a station/bar
            # (a grow-timer card, the Food Truck panel...): close it (never the Skip)
            # and stop centre-tapping -- it would just reopen
            if of.close_any_open_panel(quiet=True, thorough=True):
                saw_timer = True
                break
        adb_helper.tap(*of.SCREEN_CENTER)
        taps += 1
        of.interruptible_sleep(1.2, stop_flag)
        if fac.dismiss_error_dialog():       # a stray popup (Prize Tent...) -- closed
            break
    kind, found = sweep_plots(stop_flag)
    if kind:
        return kind, True
    return ("growing", True) if saw_timer else ("unknown", taps > 0 or found)


def chase(icon, tap_xy, label, depth, stop_flag, ctx, want=1):
    """Follow one missing item to its source and act there. Returns a short
    status string."""
    if depth > MAX_DEPTH:
        return "too_deep"
    if not tap_item_and_travel(tap_xy, label, stop_flag):
        return "travel_failed"
    kind, tapped = arrive(stop_flag)
    log(f"'{label}': arrived -> {kind}{' (needed centre taps)' if tapped else ''}")
    if kind == "station":
        if tapped:
            # A centre-tap may have collected a finished batch that already
            # satisfies the need; stop and let the next pass re-read the board
            # rather than cook one more (same rule as order_fulfill's
            # collected_blocker).
            return "collected_blocker"
        return work_station(icon, label, depth, stop_flag, ctx, want=want)
    if kind == "plot":
        return plant_item(icon, label, stop_flag, times=min(max(1, int(want or 1)), 4))
    return kind


# --------------------------------------------------------------------------
# Board processing
# --------------------------------------------------------------------------

def serve_ready_cards(stop_flag=None, max_serves=6):
    """Taps Complete on every board card whose items are all green."""
    served = 0
    for _ in range(max_serves):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if not board_is_open(img):
            break
        ready = [c for c in read_board(img) if card_is_ready(c)]
        if not ready:
            break
        c = ready[0]
        log(f"Card at x={c['cx']} is fully green -- tapping Complete.")
        adb_helper.tap(*c["btn"])
        of.interruptible_sleep(1.5, stop_flag)
        img2 = adb_helper.screenshot()
        no, nc = of.find_no_button(img2)
        if no is not None:
            log("Complete opened a gem-buy dialog (stale read) -- declining.")
            adb_helper.tap(*no)
            break
        served += 1
        of.interruptible_sleep(1.0, stop_flag)
    return served


# --------------------------------------------------------------------------
# EXPRESS ORDER = state of emergency (built 10/3 from the user's design)
# --------------------------------------------------------------------------
# An express order is the GOLD card (30/45 min timer, a huge reward, lots of items). While one
# is on the board: (1) ONLY that card is worked on -- nothing is made for other cards;
# (2) the only Complete ever tapped is the express card's, and only when it is fully green;
# (3) afsd_core pauses every other feature (normal Orders, Pork, Dairy, Garden, ...) and the
# Merchant stocker; (4) it always tries, even if the clock says it is unlikely to finish;
# (5) every pass it reads the have/need counts (event_digits.py) and logs the shopping
# list, chases the biggest deficit first and queues several batches / plants several crops
# per visit. The state file lets afsd_core know an emergency is on between cycles.

EXPRESS_STATE = os.path.join(BASE_DIR, ".express_state.json")
EXPRESS_TTL_SEC = 600


def is_express_card(img, card):
    """The express card is gold (HSV h~24, s~224, v~217 in its header band); normal cards
    are grey (s~15) and a READY card is tan (s~130)."""
    x = card["cx"]
    band = img[400:470, max(0, x - 100):x + 100]
    if band.size == 0:
        return False
    hsv = cv2.cvtColor(band, cv2.COLOR_BGR2HSV)
    h, s_, v = (float(hsv[:, :, i].mean()) for i in range(3))
    return 15 <= h <= 32 and s_ >= 190 and v >= 190


def _express_write(active, note=""):
    try:
        if active:
            import json
            with open(EXPRESS_STATE, "w") as f:
                json.dump({"seen_at": time.time(), "note": note}, f)
        elif os.path.exists(EXPRESS_STATE):
            os.remove(EXPRESS_STATE)
    except OSError:
        pass


def express_active(max_age=EXPRESS_TTL_SEC):
    """True while an express card was seen on the board within the last max_age seconds."""
    try:
        import json
        with open(EXPRESS_STATE) as f:
            return time.time() - float(json.load(f)["seen_at"]) <= max_age
    except Exception:
        return False


def card_needs(img, card):
    """[{slot, color, have, need, missing}] for a card's occupied slots. have/need are None
    when the digits cannot be read (then 'missing' is 1 for a red slot, 0 for green)."""
    out = []
    for s_ in card["slots"]:
        tx, _ = s_["icon"]
        rc = event_digits.read_count(img, tx, ROW_TEXT_Y[s_["row"]])
        if rc:
            have, need, missing = rc["have"], rc["need"], max(0, rc["need"] - rc["have"])
        else:
            have = need = None
            missing = 1 if s_["color"] == "red" else 0
        out.append({"slot": s_, "color": s_["color"], "have": have, "need": need, "missing": missing})
    return out


def shopping_text(needs):
    parts = []
    for n in needs:
        s_ = n["slot"]
        c = f"{n['have']}/{n['need']}" if n["have"] is not None else "?"
        parts.append(f"r{s_['row']}c{s_['col']} {c}" + (f" (missing {n['missing']})" if n["missing"] else " ok"))
    return ", ".join(parts)


def run_express(stop_flag=None, max_chases=8):
    """One emergency pass over the board. Returns (served, results)."""
    ctx = {"made": []}
    results = []
    served = 0
    handled = []
    log("EXPRESS ORDER ACTIVE -- STATE OF EMERGENCY: working ONLY on the gold card, no other "
        "order will be made or completed.")
    first = True
    for n in range(max_chases):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if not board_is_open(img):
            img = open_board(stop_flag)
            if img is None:
                results.append({"item": "EXPRESS", "status": "board_not_opened"})
                break
        cards = read_board(img)
        ex = [c for c in cards if is_express_card(img, c)]
        if not ex:
            log("EXPRESS: the gold card is no longer on the board (completed or expired) -- "
                "emergency over.")
            _express_write(False)
            break
        card = ex[0]
        _express_write(True, "express card on board")
        needs = card_needs(img, card)
        text = shopping_text(needs)
        log(f"EXPRESS shopping list: {text}")
        if first:
            results.append({"item": "EXPRESS needs", "status": text})
            first = False
        if card_is_ready(card):
            log("EXPRESS card is fully green -- tapping ITS Complete (the only Complete allowed).")
            adb_helper.tap(*card["btn"])
            of.interruptible_sleep(1.5, stop_flag)
            no, nc = of.find_no_button(adb_helper.screenshot())
            if no is not None:
                log("EXPRESS: Complete opened a gem-buy dialog (stale read) -- declining.")
                adb_helper.tap(*no)
                break
            served += 1
            results.append({"item": "EXPRESS", "status": "COMPLETED"})
            _express_write(False)
            break
        target = None
        for nd in sorted(needs, key=lambda d_: -d_["missing"]):
            if nd["color"] != "red":
                continue
            icon = board_icon(img, *nd["slot"]["icon"])
            if any(_same(icon, h) for h in handled):
                continue
            target = (icon, nd)
            break
        if target is None:
            log("EXPRESS: every missing item was already worked this pass -- waiting for the batches.")
            break
        icon, nd = target
        handled.append(icon)
        label = f"EXPRESS item #{n + 1}"
        status = chase(icon, nd["slot"]["icon"], label, 0, stop_flag, ctx, want=max(1, nd["missing"]))
        log(f"{label}: {status}")
        results.append({"item": label, "status": status})
        of.close_any_open_panel(quiet=True, thorough=True)
        of.interruptible_sleep(0.8, stop_flag)
        if open_board(stop_flag) is None:
            break
    if board_is_open(adb_helper.screenshot()):
        of.close_any_open_panel(quiet=True)
    return served, results


def run_once(stop_flag=None, max_chases=4):
    """One pass: complete ready cards, then chase up to max_chases distinct
    missing items. Returns (served, [ {item, status} ])."""
    ctx = {"made": []}
    results = []
    of.close_any_open_panel(quiet=True, thorough=True)
    img = open_board(stop_flag)
    if img is None:
        return 0, [{"item": "-", "status": "board_not_opened"}]
    if any(is_express_card(img, c) for c in read_board(img)):
        return run_express(stop_flag)          # state of emergency: nothing else is touched
    if express_active():
        log("The express card is gone from the board -- emergency over.")
        _express_write(False)
    served = serve_ready_cards(stop_flag)
    handled = []
    for n in range(max_chases):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if not board_is_open(img):
            img = open_board(stop_flag)
            if img is None:
                break
        cards = sorted(read_board(img), key=lambda c: sum(s["color"] == "red" for s in c["slots"]))
        target = None
        for c in cards:
            for sl in c["slots"]:
                if sl["color"] != "red":
                    continue
                icon = board_icon(img, *sl["icon"])
                if any(_same(icon, h) for h in handled):
                    continue
                target = (icon, sl)
                break
            if target:
                break
        if target is None:
            break
        icon, sl = target
        handled.append(icon)
        label = f"board item #{n + 1}"
        status = chase(icon, sl["icon"], label, 0, stop_flag, ctx)
        log(f"{label}: {status}")
        results.append({"item": label, "status": status})
        of.close_any_open_panel(quiet=True, thorough=True)
        of.interruptible_sleep(0.8, stop_flag)
        if open_board(stop_flag) is None:
            break
    # leave the screen clean
    if board_is_open(adb_helper.screenshot()):
        of.close_any_open_panel(quiet=True)
    return served, results


# --------------------------------------------------------------------------
# Merchant stocker: keep every Dorothy Merchant item at >= MERCHANT_MIN_STOCK
# --------------------------------------------------------------------------
# The Merchant (3 cards: gold bottle 3m, rainbow vial 3m, mint shake 4m) makes
# the intermediate items most event cards need, so the user wants 2 of each in
# stock at all times and the 2 queue slots refilled whenever they are free.
# Stock is read from the white count box under each card (0/1 are read
# exactly, anything else = "2+" = enough, see order_fulfill.read_card_stock_low).
# Never touches the cyan Unlock button (only lime action buttons are tapped).

MERCHANT_DIR = os.path.join(BASE_DIR, "templates", "event_merchant")
MERCHANT_MIN_STOCK = 2
MERCHANT_STOCKING = True                 # set False to disable the stocker
MERCHANT_COOK_SEC = (180, 180, 240)      # cards 0,1,2 (3m, 3m, 4m)
MERCHANT_VISIT_GAP_SEC = 150             # don't re-travel more often than this
_merchant_arts_cache = []
_merchant_pending = {0: [], 1: [], 2: []}   # ready-at times of batches WE queued
_merchant_last_visit = 0.0


def _merchant_arts():
    if not _merchant_arts_cache:
        for i in range(3):
            a = cv2.imread(os.path.join(MERCHANT_DIR, f"{i}.png"))
            if a is not None:
                _merchant_arts_cache.append(a)
    return _merchant_arts_cache


def is_merchant_panel(img):
    """True if the open station panel is the Dorothy Merchant (its 3 card arts
    match the saved ones; other stoves score <= 6 inliers, the real panel
    116+)."""
    arts = _merchant_arts()
    btns = station_buttons(img)
    if len(arts) != 3 or len(btns) != 3:
        return False
    hits = sum(sift_match_score(arts[i], card_art(img, b[0], b[1])) >= 40
               for i, b in enumerate(btns))
    return hits >= 2


def route_to_merchant(stop_flag=None):
    """Opens the board and follows any slot whose icon is a Merchant item
    (gold bottle / vial / mint shake -- red OR green, the tooltip shows for
    both) to the Merchant. Returns True once its panel is open."""
    arts = _merchant_arts()
    if len(arts) != 3:
        log("Merchant stock: saved Merchant arts missing -- cannot route.")
        return False
    img = open_board(stop_flag)
    if img is None:
        return False
    for c in read_board(img):
        for sl in c["slots"]:
            icon = board_icon(img, *sl["icon"])
            best, scores = pick_best(icon, list(enumerate(arts)))
            if best is None:
                continue
            log(f"Merchant stock: board slot {sl['icon']} is a Merchant item "
                f"(card {best}) -- travelling to the Merchant.")
            if not tap_item_and_travel(sl["icon"], "merchant route", stop_flag):
                return False
            kind, tapped = arrive(stop_flag)
            if kind == "station" and is_merchant_panel(adb_helper.screenshot()):
                return True
            log(f"Merchant stock: arrived '{kind}' but it is not the Merchant panel.")
            return False
    log("Merchant stock: no Merchant item on the board to route through -- skipping this pass.")
    return False


def stock_merchant_here(stop_flag=None, ctx=None):
    """On an OPEN Merchant panel: queue batches (into EMPTY slots only) for any
    card whose stock is below MERCHANT_MIN_STOCK, counting batches we queued
    that are still cooking. If a needed card is blocked on a missing crop and
    no slot work is left, chase that crop (plants it) as the last step.
    Returns a short status string."""
    global _merchant_last_visit
    ctx = ctx if ctx is not None else {"made": []}
    _merchant_last_visit = time.time()
    img = adb_helper.screenshot()
    btns = station_buttons(img)
    if len(btns) != 3 or not is_merchant_panel(img):
        return "not_merchant"
    now = time.time()
    for i in _merchant_pending:
        _merchant_pending[i] = [t for t in _merchant_pending[i] if t > now]
    stock = [of.read_card_stock_low(img, b[0]) for b in btns]   # 0, 1 or None(2+)
    queued = []
    log(f"Merchant stock: counts {[('2+' if s is None else s) for s in stock]}, "
        f"cooking-by-us {[len(_merchant_pending[i]) for i in range(3)]}.")
    free = count_empty_slots(img)
    guard = 0
    while free > 0 and guard < 4:
        guard += 1
        of.check_stop(stop_flag)
        need = {}
        for i, b in enumerate(btns):
            have = 99 if stock[i] is None else stock[i]
            deficit = MERCHANT_MIN_STOCK - have - len(_merchant_pending[i])
            if deficit > 0:
                blobs = count_blobs(img, b[1] - 70, b[1] - 40, b[0] - 175, b[0] + 175)
                if blobs and all(c == "green" for _, c in blobs):
                    need[i] = deficit
        if not need:
            break
        i = max(need, key=lambda k: (need[k], -k))
        bx, by = btns[i][0], btns[i][1]
        adb_helper.tap(bx, by)
        of.interruptible_sleep(1.2, stop_flag)
        img2 = adb_helper.screenshot()
        no, nc = of.find_no_button(img2)
        if no is not None:
            log("Merchant stock: action opened a gem-buy dialog -- declining.")
            adb_helper.tap(*no)
            break
        free2 = count_empty_slots(img2)
        if free2 < free:
            _merchant_pending[i].append(time.time() + MERCHANT_COOK_SEC[i])
            queued.append(i)
            log(f"Merchant stock: queued card {i} (EMPTY slots {free} -> {free2}).")
            free = free2
            img = img2
        else:
            log(f"Merchant stock: tapped card {i} but EMPTY slots stayed {free2} -- NOT verified, stopping.")
            break
    # cards still short on a crop: plant/harvest it (leaves the panel)
    img = adb_helper.screenshot()
    if station_panel_open(img) and is_merchant_panel(img):
        btns = station_buttons(img)
        for i, b in enumerate(btns):
            have = 99 if stock[i] is None else stock[i]
            if MERCHANT_MIN_STOCK - have - len(_merchant_pending[i]) <= 0:
                continue
            blobs = count_blobs(img, b[1] - 70, b[1] - 40, b[0] - 175, b[0] + 175)
            reds = [x for x, c in blobs if c == "red"]
            if reds:
                sub = ingredient_icon(img, reds[0], b[1])
                r = chase(sub, (reds[0], b[1] - 56), f"merchant card {i} crop", 1, stop_flag, ctx)
                return f"queued {queued}, crop chase for card {i}: {r}"
    return f"queued {queued}" if queued else "nothing_needed_or_no_free_slot"


def stock_merchant(stop_flag=None, force=False):
    """Visit the Merchant (via a board Merchant item) and top it up, at most
    once per MERCHANT_VISIT_GAP_SEC. Returns a result dict for the report."""
    if not force and time.time() - _merchant_last_visit < MERCHANT_VISIT_GAP_SEC:
        return {"item": "merchant stock", "status": "skipped_recent_visit"}
    try:
        fac.close_any_open_panel(quiet=True, thorough=True)
        if not route_to_merchant(stop_flag):
            return {"item": "merchant stock", "status": "no_route"}
        status = stock_merchant_here(stop_flag)
    finally:
        pass
    fac.close_any_open_panel(quiet=True, thorough=True)
    log(f"Merchant stock: {status}")
    return {"item": "merchant stock", "status": status}


def format_report(served, results):
    lines = [f"Event orders: completed {served}"]
    for r in results:
        lines.append(f"  {r['item']}: {r['status']}")
    return "\n".join(lines)


def main(stop_flag=None):
    log("=== event orders run start ===")
    served, results = run_once(stop_flag)
    if MERCHANT_STOCKING and not express_active():
        results.append(stock_merchant(stop_flag))
    log(format_report(served, results).replace("\n", " | "))
    log("=== event orders run end ===")
    return served, results


if __name__ == "__main__":
    # Offline self-test: python event_orders.py <screenshot.png>
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        BASE_DIR, "event_pdf_extract", "storybook", "live_1_after_shoes.png")
    im = cv2.imread(path)
    print("buttons:", find_green_buttons(im, 780, 890))
    for c in read_board(im):
        print(c["cx"], c["btn"], [(s["row"], s["col"], s["color"]) for s in c["slots"]],
              "READY" if card_is_ready(c) else "")
