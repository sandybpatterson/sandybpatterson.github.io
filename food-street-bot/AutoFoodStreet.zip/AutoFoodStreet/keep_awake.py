"""PROPOSED (not applied): keep Windows from sleeping the display/system while AFSD runs.

Why: run_log.txt shows 933 "adb screencap timed out after 15 seconds" errors since 10/2, in long
clusters (10/3 05-06h, 11-14h; 10/4 00-02h, 07h) -- hours at a time with a cycle every ~47 s, never
recovering by itself. That pattern fits the emulator window stopping rendering when Windows turns the
display off / idles, so screencap never returns. Keeping the display awake while the bot runs should
remove most of them.

Use (when applied): afsd_core.run_loop -> keep_awake.start() right after "Start pressed", keep_awake.stop()
in its exit path. Windows keeps this state per THREAD, so a small background thread owns it.
"""
import ctypes
import datetime
import os
import threading
import time

ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002

_thread = None
_stop = threading.Event()


def _set_state(flags):
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(flags)
    except Exception:                      # not Windows / blocked: never break the bot
        pass


LOG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "run_log.txt")
GAP_SEC = 120                              # a 30-s tick that took longer than this = the program was paused


def _log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(f"[{datetime.datetime.now().isoformat(timespec='seconds')}] [sleep check] {msg}\n")
    except OSError:
        pass


def _awake_clock():
    """Seconds the PC has been AWAKE (QueryUnbiasedInterruptTime leaves out sleep / hibernate); None if unknown."""
    try:
        t = ctypes.c_ulonglong()
        if ctypes.windll.kernel32.QueryUnbiasedInterruptTime(ctypes.byref(t)):
            return t.value / 1e7
    except Exception:                      # noqa: BLE001
        pass
    return None


def _worker():
    _set_state(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED)
    wall, awake = time.time(), _awake_clock()
    while not _stop.wait(30):              # refresh every 30 s
        _set_state(ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED)
        # 10/25: night 10/24-25 the log stopped 22:09:55 -> 07:06:01 with no error and the auto restart came 9 h late:
        # the whole program was paused. Tell sleep apart from a freeze next time.
        w2, a2 = time.time(), _awake_clock()
        gap = w2 - wall
        if gap > GAP_SEC:
            start = datetime.datetime.fromtimestamp(wall).strftime("%H:%M")
            if awake is not None and a2 is not None and (a2 - awake) < gap / 2:
                _log(f"the PC was ASLEEP for about {int((gap - (a2 - awake)) // 60)} min (from about {start}) -- Windows "
                     f"slept despite the keep-awake request (lid / power button / sleep or hibernate timer?).")
            else:
                _log(f"AFSD was paused for {int(gap // 60)} min (from about {start}) while the PC stayed awake -- a freeze "
                     f"inside the program, not sleep.")
        wall, awake = w2, a2
    _set_state(ES_CONTINUOUS)              # release


def start():
    global _thread
    if _thread is not None and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(target=_worker, daemon=True, name="keep_awake")
    _thread.start()


def stop():
    _stop.set()
