"""S.P.R.O.U.T. (Storage-Paced Reading Of Unharvested Timers) -- step 1, LOG ONLY (owner 11/6: "we really need to work
on sprout"; approved #3 "plant-bar names from the growing-plot timer card").

Every time the bot taps a growing plot, the game opens a timer card: the crop's NAME on top ("Greens"), its picture,
and the time left ("4m 18s"). This module reads the name (Windows OCR once per crop, then by its picture from the
library templates/crop_cards/<slug>.png, made on the PC) and keeps a map of what grows where and when it is ready:
  [sprout] plot (797,408): Greens -- ready in 4m 18s
  [sprout] growing now: Greens x2 (next 4m), Pumpkin x1 (12m)       (every SUMMARY_SEC)
Taps nothing, changes nothing. Groundwork for the owner's event rule: keep 4 of each crop in storage plus 2 in the
ground, harvest only when storage drops below 4.
"""
import json
import os
import re
import time

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CARD_DIR = os.path.join(BASE_DIR, "templates", "crop_cards")
LOG = os.path.join(BASE_DIR, "run_log.txt")
# offsets from the timer card's red X centre (close_x.png match), checked on fail_pictures/1793906364 (Greens card)
TITLE_BOX = (-470, 48, -70, 108)      # x1, y1, x2, y2 relative to the X
ART_BOX = (-400, 103, -140, 363)
ART_SIZE = 64
ART_MIN = 0.85
SUMMARY_SEC = 600
FORGET_SEC = 4 * 3600                 # a plot entry is dropped this long after it was due

_plots = {}                           # (x, y) -> {"name", "ready", "seen"}
_last_summary = [0.0]
_lib = {}                             # slug -> small grey art


def log(msg):
    try:
        with open(LOG, "a", encoding="utf-8", errors="replace") as f:
            f.write(f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] [sprout] {msg}\n")
    except OSError:
        pass


def slug(name):
    return re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_")


def clean_name(raw):
    """Pure: OCR text of the card title -> "Greens" / "Twilight Root", or None for junk."""
    words = re.findall(r"[A-Za-z][A-Za-z']+", raw or "")
    if not words or len(" ".join(words)) > 30:
        return None
    return " ".join(w.capitalize() for w in words[:3])


def crop_names():
    """Every crop name S.P.R.O.U.T. may learn (11/8): recipe-book crops ("Cabbage / Greens" counts as both) plus the
    event plot crops Food Club has seen (event_orders._plot_crops, e.g. "bloodorange" -> matched without spaces)."""
    out = set()
    try:
        import recipe_book as rb
        for it in rb.load()["items"].values():
            if it.get("kind") == "crop" and it.get("name"):
                out |= {p.strip() for p in it["name"].split("/") if p.strip()}
    except Exception:                                  # noqa: BLE001
        pass
    try:
        import event_orders as eo
        out |= set(getattr(eo, "_plot_crops", set()))
    except Exception:                                  # noqa: BLE001
        pass
    return out


def known_crop(name, crops=None):
    """Pure: an OCR'd card title -> the recipe-book crop it is ("Nato" -> "Tomato"), or None for junk (11/8 logs:
    'Ting Food Street', "Eddie's Place" were learned as crops from cards that were not crop cards)."""
    import difflib
    crops = crop_names() if crops is None else crops
    if not name or not crops:
        return None
    squash = lambda t: re.sub(r"[^a-z]", "", t.lower())       # noqa: E731 -- "Blood Orange" == "bloodorange"
    low = {squash(c): c for c in crops}
    key = squash(name)
    if key in low:
        c = low[key]
        return c if " " in c or c[:1].isupper() else name.title()   # event slugs keep the card's own spelling
    near = difflib.get_close_matches(key, list(low), n=1, cutoff=0.75)
    if not near:
        return None
    c = low[near[0]]
    return c if " " in c or c[:1].isupper() else name.title()


def card_x(img):
    """(x, y) centre of the timer card's red X, or None."""
    import find_and_center as fac
    t = fac.CLOSE_X_TEMPLATE
    if img is None or t is None:
        return None
    r = cv2.matchTemplate(img, t, cv2.TM_CCOEFF_NORMED)
    _, v, _, loc = cv2.minMaxLoc(r)
    if v < 0.8:
        return None
    return loc[0] + t.shape[1] // 2, loc[1] + t.shape[0] // 2


def _crop(img, xy, box):
    x, y = xy
    x1, y1, x2, y2 = x + box[0], y + box[1], x + box[2], y + box[3]
    if x1 < 0 or y1 < 0 or x2 > img.shape[1] or y2 > img.shape[0]:
        return None
    return img[y1:y2, x1:x2]


def _small(art):
    return cv2.resize(cv2.cvtColor(art, cv2.COLOR_BGR2GRAY), (ART_SIZE, ART_SIZE), interpolation=cv2.INTER_AREA)


def _load_lib():
    if _lib or not os.path.isdir(CARD_DIR):
        return _lib
    for f in os.listdir(CARD_DIR):
        if f.endswith(".png"):
            a = cv2.imread(os.path.join(CARD_DIR, f))
            if a is not None:
                _lib[f[:-4]] = _small(a)
    return _lib


def match_art(art):
    """Pure-ish: (slug, score) of the best library picture, slug None below ART_MIN."""
    if art is None:
        return None, 0.0
    s = _small(art).astype(np.float32)
    best, bs = None, 0.0
    for k, ref in _load_lib().items():
        v = float(cv2.matchTemplate(s, ref.astype(np.float32), cv2.TM_CCOEFF_NORMED)[0][0])
        if v > bs:
            best, bs = k, v
    return (best if bs >= ART_MIN else None), bs


def _names():
    try:
        with open(os.path.join(CARD_DIR, "names.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def learn(name, art):
    """Store the crop's card picture under its name (never overwrites)."""
    k = slug(name)
    if not k or art is None:
        return
    try:
        os.makedirs(CARD_DIR, exist_ok=True)
        p = os.path.join(CARD_DIR, k + ".png")
        if not os.path.exists(p):
            cv2.imwrite(p, art)
            _lib[k] = _small(art)
            names = _names()
            names[k] = name
            with open(os.path.join(CARD_DIR, "names.json"), "w", encoding="utf-8") as f:
                json.dump(names, f, indent=1)
            log(f"learned the crop card '{name}' -- known by its picture from now on.")
    except OSError:
        pass


def _title_mask(t):
    g = cv2.cvtColor(t, cv2.COLOR_BGR2GRAY)
    bw = np.where(g < 110, 0, 255).astype(np.uint8)              # dark brown letters -> black on white
    bw = cv2.resize(bw, None, fx=2, fy=2, interpolation=cv2.INTER_NEAREST)
    return cv2.cvtColor(cv2.copyMakeBorder(bw, 16, 16, 16, 16, cv2.BORDER_CONSTANT, value=255), cv2.COLOR_GRAY2BGR)


def card_name(img, ocr=None):
    """The crop on an open plot timer card: by picture first, else OCR of the title (then learned). None if unsure."""
    xy = card_x(img)
    if xy is None:
        return None
    art = _crop(img, xy, ART_BOX)
    k, _s = match_art(art)
    if k:
        n = known_crop(_names().get(k) or k.replace("_", " ").title())
        if n:                                          # a junk picture learned before 11/8 is ignored
            return n
    title = _crop(img, xy, TITLE_BOX)
    if title is None:
        return None
    if ocr is None:
        import popup_ocr
        ocr = popup_ocr.read_text
    name = known_crop(clean_name(ocr(_title_mask(title))))
    if name:
        learn(name, art)
    return name


def note(x, y, name, secs, now=None):
    """Remember what grows at plot (x, y) and when it is ready; log it; a summary every SUMMARY_SEC."""
    now = now or time.time()
    if secs is None:
        return
    _plots[(x // 20, y // 20)] = {"name": name or "?", "ready": now + secs, "seen": now, "xy": (x, y)}
    log(f"plot ({x},{y}): {name or 'crop not read'} -- ready in {secs // 60}m {secs % 60:02d}s")
    if now - _last_summary[0] >= SUMMARY_SEC:
        _last_summary[0] = now
        log(summary(now))
        if any(_tally.values()):
            log(tally_line())


def summary(now=None, plots=None):
    """Pure: '[sprout] growing now: Greens x2 (next 4m), Pumpkin x1 (12m)'."""
    now = now or time.time()
    plots = _plots if plots is None else plots
    for k in [k for k, p in plots.items() if now - p["ready"] > FORGET_SEC]:
        del plots[k]
    by = {}
    for p in plots.values():
        if p["ready"] > now:
            by.setdefault(p["name"], []).append(p["ready"] - now)
    if not by:
        return "growing now: nothing known (no plot timer read in the last while)"
    parts = [f"{n} x{len(v)} (next {int(min(v) // 60)}m)" for n, v in sorted(by.items(), key=lambda t: min(t[1]))]
    return "growing now: " + ", ".join(parts)


def growing(name, now=None):
    """How many plots of this crop are known to be growing right now (for later steps)."""
    now = now or time.time()
    return sum(1 for p in _plots.values() if p["name"] == name and p["ready"] > now)


# --- step 2 (11/9, owner: "if you can work on 4 great"), LOG ONLY ---------------------------------------------------
# The owner's event rule: keep KEEP_STORE of each crop in Food Club storage plus KEEP_GROUND more growing in the plots.
# Ripe crops left in a plot do NOT take storage room, so a ripe plot is only worth harvesting when storage is below
# KEEP_STORE. Every real harvest / planting is graded against that rule:
#   [sprout test] harvested Pumpkin at (797,408) -- rule: WOULD LEAVE it in the ground (storage has 5, keep 4)
#   [sprout test] planted Greens x2 -- rule: AGREE (storage 1, growing 0 -> wants 4 more in storage)
# A tally goes into the summary line. Nothing here taps or changes what the bot does.
KEEP_STORE = 4
KEEP_GROUND = 2
STOCK_FRESH_SEC = 45 * 60             # a storage count older than this is "not known"
NEAR_PX = 40

_tally = {"harvest_ok": 0, "harvest_leave": 0, "plant_ok": 0, "plant_hold": 0, "unknown": 0}


def _key(name):
    return "".join(ch for ch in (name or "").lower() if ch.isalnum())


def stock_of(name, seen, now=None):
    """Pure: storage count of a crop from event_orders._stock_seen ({norm: (have, when, name)}), None when unknown/old."""
    now = now or time.time()
    v = (seen or {}).get(_key(name))
    if not v or v[0] is None or now - v[1] > STOCK_FRESH_SEC:
        return None
    return int(v[0])


def name_at(x, y, now=None, plots=None):
    """Which crop was last seen growing at this plot (within NEAR_PX), or None. A harvest tap lands on a plot whose
    timer the bot read earlier -- that tells us which crop it just pulled."""
    now = now or time.time()
    plots = _plots if plots is None else plots
    best, bd = None, NEAR_PX + 1
    for p in plots.values():
        px, py = p.get("xy", (None, None))
        if px is None:
            continue
        d = max(abs(px - x), abs(py - y))
        if d < bd and p.get("name") not in (None, "?") and p.get("ready", now) <= now + 30:   # was due = ripe
            best, bd = p, d
    return best["name"] if best else None


def harvest_verdict(stock):
    """Pure: 'harvest' when storage is below KEEP_STORE (or unknown), else 'leave'."""
    if stock is None:
        return "unknown"
    return "harvest" if stock < KEEP_STORE else "leave"


def plant_verdict(stock, growing_n):
    """Pure: 'plant' while storage + growing is short of KEEP_STORE + KEEP_GROUND, else 'hold'."""
    if stock is None:
        return "unknown"
    return "plant" if stock + growing_n < KEEP_STORE + KEEP_GROUND else "hold"


def note_harvest(x, y, seen, now=None):
    now = now or time.time()
    name = name_at(x, y, now)
    if not name:
        return
    stock = stock_of(name, seen, now)
    v = harvest_verdict(stock)
    if v == "unknown":
        _tally["unknown"] += 1
        log(f"test: harvested {name} at ({x},{y}) -- rule: storage count not known, no call")
        return
    _tally["harvest_ok" if v == "harvest" else "harvest_leave"] += 1
    if v == "harvest":
        log(f"test: harvested {name} at ({x},{y}) -- rule: AGREE (storage has {stock}, keep {KEEP_STORE})")
    else:
        log(f"test: harvested {name} at ({x},{y}) -- rule: WOULD LEAVE it in the ground (storage has {stock}, "
            f"keep {KEEP_STORE}; ripe crops in a plot take no storage room)")
    for k in [k for k, p in _plots.items() if p.get("xy") and max(abs(p["xy"][0] - x), abs(p["xy"][1] - y)) <= NEAR_PX]:
        del _plots[k]                                  # that plot is empty now


def note_planted(name, n, seen, now=None):
    now = now or time.time()
    if not known_crop(name):
        return
    stock = stock_of(name, seen, now)
    grow = growing(known_crop(name), now)
    v = plant_verdict(stock, grow)
    if v == "unknown":
        _tally["unknown"] += 1
        return
    _tally["plant_ok" if v == "plant" else "plant_hold"] += 1
    want = KEEP_STORE + KEEP_GROUND - stock - grow
    if v == "plant":
        log(f"test: planted {name} x{n} -- rule: AGREE (storage {stock}, growing {grow}; wants {want} more)")
    else:
        log(f"test: planted {name} x{n} -- rule: WOULD HOLD (storage {stock} + growing {grow} already cover "
            f"{KEEP_STORE} + {KEEP_GROUND})")


def tally_line():
    t = _tally
    return (f"rule check -- harvests: {t['harvest_ok']} agree, {t['harvest_leave']} would leave in the ground; "
            f"plantings: {t['plant_ok']} agree, {t['plant_hold']} would hold; {t['unknown']} with no storage count")
