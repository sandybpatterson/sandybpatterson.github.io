"""Dairy / Whipped Cream automation — same proven pattern as
pig_pen_check.py: find-and-center navigation, check for a ready-to-collect
icon first (it can occlude the station template, same issue found with
Ham), then check queue slots and tap Make if one's free.
"""
import os
import sys
import time
import datetime
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from adb_helper import screenshot, tap
from find_and_center import find_and_center, StopRequested, close_any_open_panel, dismiss_buy_missing_dialog

LOG = os.path.join(BASE_DIR, "run_log.txt")

DAIRY_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "dairy.png"))
CREAM_READY_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "whipped_cream_ready.png"))
CREAM_ICON_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "whipped_cream_icon.png"))
# Offset from the Whipped Cream card icon to its Make button, in fixed
# panel screen-space. Measured 9/24 across two different panel scroll
# states (dx 38 vs 46, dy 243 vs 245) — consistent enough to trust.
ICON_TO_MAKE_OFFSET = (42, 244)

MATCH_THRESHOLD = 0.6
SCALES = [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4]
FAST_SCALES = [0.4, 0.6, 0.8, 1.0, 1.2, 1.4]
READY_SCALES = [0.7, 0.85, 1.0, 1.15, 1.3]
READY_THRESHOLD = 0.6


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] {msg}\n")
    try:
        print(f"[{ts}] {msg}")
    except (AttributeError, OSError):
        pass


def _multiscale_match(img, template, scales, threshold):
    best_loc, best_val = None, 0.0
    th, tw = template.shape[:2]
    for scale in scales:
        w, h = int(tw * scale), int(th * scale)
        if w < 10 or h < 10 or w > img.shape[1] or h > img.shape[0]:
            continue
        resized = cv2.resize(template, (w, h))
        res = cv2.matchTemplate(img, resized, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val > best_val:
            best_val = max_val
            best_loc = (max_loc[0] + w // 2, max_loc[1] + h // 2)
    if best_val >= threshold:
        return best_loc, best_val
    return None, best_val


def find_dairy(img, fast=False):
    scales = FAST_SCALES if fast else SCALES
    search_img = img
    factor = 1.0
    if fast:
        factor = 0.5
        search_img = cv2.resize(img, (int(img.shape[1] * factor), int(img.shape[0] * factor)))
    loc, val = _multiscale_match(search_img, DAIRY_TEMPLATE, scales, MATCH_THRESHOLD)
    if loc is not None and fast:
        loc = (int(loc[0] / factor), int(loc[1] / factor))
    return loc, val


def find_ready_cream(img):
    return _multiscale_match(img, CREAM_READY_TEMPLATE, READY_SCALES, READY_THRESHOLD)


def is_slot_empty(img, x1, y1, x2, y2):
    region = img[y1:y2, x1:x2]
    return float(np.std(region)) < 70.0


def find_make_button(img):
    """Locate the Whipped Cream Make button dynamically via the card's
    icon (a stable anchor) plus a fixed offset, instead of trusting a
    fixed screen coordinate. Real bug found 9/24: the panel's card row
    can open at different horizontal scroll positions between sessions,
    silently breaking any fixed Make-button coordinate. The icon itself
    is unambiguous regardless of scroll state."""
    res = cv2.matchTemplate(img, CREAM_ICON_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)
    th, tw = CREAM_ICON_TEMPLATE.shape[:2]
    icon_center = (max_loc[0] + tw // 2, max_loc[1] + th // 2)
    make_loc = (icon_center[0] + ICON_TO_MAKE_OFFSET[0],
                icon_center[1] + ICON_TO_MAKE_OFFSET[1])
    return make_loc, max_val, icon_center


def main(stop_flag=None):
    log("=== dairy run start ===")
    try:
        close_any_open_panel()
        img = screenshot()
        ready_loc, ready_conf = find_ready_cream(img)
        if ready_loc is not None:
            log(f"Ready-to-collect Whipped Cream visible before searching "
                f"for Dairy (at {ready_loc}, confidence {ready_conf:.2f}) — "
                "collecting it first so it doesn't block Dairy detection.")
            tap(*ready_loc)
            time.sleep(1)
        else:
            log(f"No ready-to-collect Whipped Cream visible up front "
                f"(best match {ready_conf:.2f}). Proceeding to find Dairy.")

        loc, conf = find_and_center(find_dairy, label="Dairy", stop_flag=stop_flag)

        if loc is None:
            log("Dairy not found. Giving up this run — no changes made. "
                "Please check manually.")
            return

        log(f"Dairy located and centered at {loc} (confidence {conf:.2f}).")

        img = screenshot()
        ready_loc, ready_conf = find_ready_cream(img)
        if ready_loc is not None:
            log(f"Ready-to-collect Whipped Cream found at {ready_loc} "
                f"(confidence {ready_conf:.2f}) — collecting it.")
            tap(*ready_loc)
            time.sleep(1)
        else:
            log(f"No ready-to-collect Whipped Cream visible (best match {ready_conf:.2f}).")

        # The template marks the jug/lid ornament, which sits above the
        # actual counter body — tapping exactly on it can land a bit high
        # (confirmed by the user watching it happen). Offset down toward
        # the counter surface itself.
        counter_tap = (loc[0], loc[1] + 90)
        log(f"Opening panel (tapping counter body at {counter_tap}, "
            f"offset from jug landmark at {loc}).")
        tap(*counter_tap)
        time.sleep(1)
        img = screenshot()

        # Whipped Cream is the 15m recipe — the SECOND of 4 recipe cards.
        # Dairy has 3 usable queue slots (not 2, like Pig Pen). Slot boxes
        # are stable regardless of the card row's scroll state (confirmed
        # 9/24 — they read correctly across both observed scroll states),
        # but the Make button is NOT stable, so it's found dynamically.
        slot_boxes = [
            (412, 650, 597, 825),
            (607, 650, 792, 825),
            (797, 650, 990, 825),
        ]

        slots_empty = [is_slot_empty(img, *box) for box in slot_boxes]
        log(f"Slots empty: {slots_empty}")

        if any(slots_empty):
            make_button, icon_conf, icon_loc = find_make_button(img)
            log(f"Free queue slot detected — Whipped Cream icon found at "
                f"{icon_loc} (confidence {icon_conf:.2f}), tapping Make at "
                f"{make_button} (15m, 1 milk).")
            if icon_conf < 0.8:
                log(f"Icon confidence too low ({icon_conf:.2f}) to trust — "
                    "skipping the Make tap rather than guessing.")
            else:
                tap(*make_button)
                time.sleep(1)
                dismiss_buy_missing_dialog()
        else:
            log("All queue slots occupied — nothing to do this run.")

        close_button = (1541, 124)
        tap(*close_button)
        log("=== dairy run end ===")
    except StopRequested:
        log("=== dairy run stopped early by user ===")
        raise


if __name__ == "__main__":
    main()
