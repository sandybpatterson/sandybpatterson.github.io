﻿"""Reads the four ticket counters in the top bar (gold, grey, orange, blue) -- 10/10. READ-ONLY.
Digits are white with a dark brown outline; each is cut out as a white blob ringed by dark pixels, normalised to height 28,
and matched against templates/ticket_digits/<digit>_*.png (labelled by eye from saved screens). Anything that does not match
well returns None for that ticket -- it never guesses.
"""
import glob
import os

import cv2
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
TICKETS = ("gold", "grey", "orange", "blue")
# digit cells: x ranges (full-screen px) of each ticket's number, measured from saved screens
CELLS = ((707, 770), (770, 833), (833, 896), (896, 960))
MATCH_MIN = 0.80
_templates = None


def _load():
    global _templates
    if _templates is None:
        _templates = []
        for f in glob.glob(os.path.join(BASE, "templates", "ticket_digits", "*.png")):
            d = int(os.path.basename(f).split("_")[0])
            _templates.append((d, cv2.imread(f, 0).astype(np.float32)))
    return _templates


def _norm(c):
    h, w = c.shape
    nw = max(1, int(round(w * 28.0 / h)))
    r = cv2.resize(c * 255, (nw, 28), interpolation=cv2.INTER_AREA).astype(np.float32)
    can = np.zeros((28, 22), np.float32)
    x0 = (22 - nw) // 2
    can[:, x0:x0 + min(nw, 22)] = r[:, :22]
    return can


def glyphs(img):
    """[(x, normalised glyph)] for every digit blob in the ticket strip, left to right."""
    strip = img[8:72, 675:945]
    white = (strip.min(axis=2) > 200).astype(np.uint8)
    dark = strip.max(axis=2) < 135
    n, lab, st, _ = cv2.connectedComponentsWithStats(white, 8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if not (24 <= h <= 34 and 7 <= w <= 19 and a >= 70):
            continue
        comp = (lab == i).astype(np.uint8)
        ring = (cv2.dilate(comp, np.ones((7, 7), np.uint8)) > 0) & (comp == 0) & (white == 0)
        if ring.sum() < 40 or float((dark & ring).sum()) / ring.sum() < 0.55:
            continue
        out.append((int(x) + 675, _norm(comp[y:y + h, x:x + w])))
    return sorted(out, key=lambda g: g[0])


def classify(v):
    best, bs = None, 0.0
    for d, t in _load():
        s = float(cv2.matchTemplate(v, t, cv2.TM_CCOEFF_NORMED)[0][0])
        if s > bs:
            best, bs = d, s
    return (best, bs) if bs >= MATCH_MIN else (None, bs)


def read_tickets(img):
    """{'gold': n|None, 'grey': ..., 'orange': ..., 'blue': ...}; None when a number has no digits or one cannot be read."""
    out = {k: None for k in TICKETS}
    if img is None or img.shape[:2] != (900, 1600):
        return out
    cells = {k: [] for k in TICKETS}
    unknown = set()
    for x, v in glyphs(img):
        for k, (a, b) in zip(TICKETS, CELLS):
            if a <= x < b:
                d, _ = classify(v)
                if d is None:
                    unknown.add(k)
                else:
                    cells[k].append(str(d))
    for k in TICKETS:
        if cells[k] and k not in unknown:
            out[k] = int("".join(cells[k]))
    return out
