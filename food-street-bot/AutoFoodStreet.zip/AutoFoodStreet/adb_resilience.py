"""PROPOSED (not applied): a sturdier adb_helper._run for when the emulator stops answering.

Today a timeout triggers ONE `adb connect` and one retry, then raises; the loop logs an exception and
starts the next cycle 15 s later, which times out again -- 933 times since 10/2. This version
  1. escalates: attempt 1 = `adb connect`, attempt 2 = `adb kill-server` + `start-server` + `connect`;
  2. tells "LDPlayer is not running" apart from "running but not answering" (tasklist), and logs which;
  3. backs off after repeated failures (5 s, 10 s, 20 s ... capped at 60 s) instead of hammering a hung
     emulator, and resets the counter on the first success.
It never injects input and never touches the game. Drop-in replacement for adb_helper._run (same
signature/return), plus describe_hang() for log lines.
"""
import os
import subprocess
import time

def _ld_dir():
    """11/23: same search as adb_helper.find_ldplayer (kept here: adb_helper imports this module)."""
    for d in [os.environ.get("LDPLAYER_DIR", "")] + [dr + p for dr in ("C:", "D:", "E:") for p in
              (r"\LDPlayer\LDPlayer9", r"\Program Files\LDPlayer\LDPlayer9")]:
        if d and os.path.exists(os.path.join(d, "adb.exe")):
            return d
    return r"C:\LDPlayer\LDPlayer9"


ADB = os.path.join(_ld_dir(), "adb.exe")
PREFERRED_DEVICE = "127.0.0.1:5555"
ADB_TIMEOUT_SEC = 15
_consecutive_failures = 0
_sleep = time.sleep                         # patched in tests


def safe_run(cmd, timeout, text=False):
    """subprocess.run(cmd, capture_output=True, timeout=...) that can never hang (10/19).

    Live 10/19 09:28: one adb tap hung for 12 MINUTES although its timeout is 15 s. On Windows, run() kills adb on
    a timeout and then waits for its output pipes to close -- but an adb server that adb started in the
    background holds those pipes open, so Python waits as long as the server lives. Here the output goes to temp
    files instead (read after adb exits), so nothing can hold us: a timeout raises after `timeout` seconds."""
    import tempfile
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    outs = []
    try:
        for _ in range(2):
            fd, path = tempfile.mkstemp(prefix="afsd_adb_")
            os.close(fd)
            outs.append(path)
        with open(outs[0], "wb") as o, open(outs[1], "wb") as e:
            p = subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=o, stderr=e, creationflags=flags)
            try:
                rc = p.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                p.kill()
                raise subprocess.TimeoutExpired(cmd, timeout)
        data = []
        for path in outs:
            with open(path, "rb") as fh:
                b = fh.read()
            data.append(b.decode("utf-8", "replace") if text else b)
        return subprocess.CompletedProcess(cmd, rc, data[0], data[1])
    finally:
        for path in outs:
            try:
                os.remove(path)
            except OSError:
                pass                                  # a background adb server may still hold it -- harmless


def emulator_running():
    """True if an LDPlayer process is alive (dnplayer.exe is the window, Ld9BoxHeadless.exe the VM)."""
    try:
        out = subprocess.run(["tasklist"], capture_output=True, text=True, errors="replace", timeout=10).stdout.lower()
        return "dnplayer.exe" in out or "ld9boxheadless.exe" in out
    except Exception:
        return True                        # unknown: assume running


def describe_hang():
    return ("LDPlayer is running but not answering adb (display asleep? emulator frozen?)"
            if emulator_running() else "LDPlayer is not running at all")


def _reconnect(level):
    try:
        if level >= 2:
            safe_run([ADB, "kill-server"], 10)
            safe_run([ADB, "start-server"], 20)
        safe_run([ADB, "connect", PREFERRED_DEVICE], 10)
    except Exception:
        pass


# --- Watchdog test (10/19, owner: "log only first, prove it helps") ----------------------------------------
# Logs how long each run of adb failures lasts, and the moment a watchdog WOULD restart LDPlayer (failing for
# WATCHDOG_TEST_SEC). At that moment it also checks, read-only, that LDPlayer's control tool is there and which
# instance index it would restart (`ldconsole list2` lists instances; it changes nothing). Never restarts anything.
LDCONSOLE = os.path.join(os.path.dirname(ADB), "ldconsole.exe")
WATCHDOG_TEST_SEC = 120
_freeze_since = None
_watch_fired = False
_ldconsole_checked = False


def _watch_fail(log):
    global _freeze_since, _watch_fired, _ldconsole_checked
    now = time.time()
    if _freeze_since is None:
        _freeze_since, _watch_fired = now, False
        return
    if _watch_fired or now - _freeze_since < WATCHDOG_TEST_SEC:
        return
    _watch_fired = True
    log(f"[watchdog test] adb has failed for {int(now - _freeze_since)} s -- a watchdog WOULD restart LDPlayer now "
        f"({'emulator process alive' if emulator_running() else 'emulator process NOT running'}).")
    if not _ldconsole_checked:
        _ldconsole_checked = True
        try:
            r = subprocess.run([LDCONSOLE, "list2"], capture_output=True, text=True, errors="replace", timeout=10)
            log(f"[watchdog test] ldconsole list2 -> {(r.stdout or r.stderr or '').strip()[:200]!r}")
        except Exception as e:                      # noqa: BLE001
            log(f"[watchdog test] ldconsole not usable: {e!r}")


def _watch_ok(log):
    global _freeze_since
    if _freeze_since is not None:
        secs = int(time.time() - _freeze_since)
        if secs >= 20:
            log(f"[watchdog test] adb answered again after {secs} s of failures"
                + (" -- it came back BY ITSELF after the watchdog would have restarted LDPlayer." if _watch_fired
                   else " -- recovered without help."))
        _freeze_since = None


def run(args, resolve_device, log=lambda m: None):
    """Same job as adb_helper._run(args): run `adb -s <device> <args>`; returns CompletedProcess."""
    global _consecutive_failures
    if _consecutive_failures >= 3:
        wait = min(60, 5 * 2 ** (_consecutive_failures - 3))
        log(f"adb has failed {_consecutive_failures} times in a row -- waiting {wait}s before trying again")
        _sleep(wait)
    last = None
    for attempt in range(3):
        try:
            r = safe_run([ADB, "-s", resolve_device()] + args, ADB_TIMEOUT_SEC)
            _consecutive_failures = 0
            _watch_ok(log)
            return r
        except subprocess.TimeoutExpired as e:
            last = e
            _consecutive_failures += 1
            _watch_fail(log)
            log(f"adb timed out (attempt {attempt + 1}/3): {describe_hang()}")
            if attempt < 2:
                _reconnect(attempt + 1)
    raise last
