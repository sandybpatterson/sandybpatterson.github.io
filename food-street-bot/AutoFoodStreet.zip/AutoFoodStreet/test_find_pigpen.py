"""Test entry point: run this after manually scrolling the map away from
Pig Pen, to verify the zoom-out -> search -> center -> zoom-in navigation
actually finds and centers on it reliably. Heavily logged to run_log.txt.
"""
import sys
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from pig_pen_check import find_pig_pen
from find_and_center import find_and_center
from adb_helper import tap, screenshot
import cv2


def find_pig_pen_2tuple(img, fast=False):
    loc, conf, _scale = find_pig_pen(img, return_scale=True, fast=fast)
    return loc, conf


if __name__ == "__main__":
    loc, conf = find_and_center(find_pig_pen_2tuple, label="Pig Pen")
    if loc is not None:
        print(f"SUCCESS: Pig Pen centered at {loc}, confidence {conf:.2f}")
        cv2.imwrite(os.path.join(BASE_DIR, "test_find_result.png"), screenshot())
    else:
        print("FAILED to find Pig Pen.")
