"""11/15 loading window (owner: the main window "unfolds like a car into a mega monster" while it builds).

Runs as its OWN small program (python splash.py <flag dir>) so the GIF plays smoothly while AFSD builds its window
hidden. The owner's apple-picking GIF: templates/splash/splash.gif (gifs/picking-apple.gif at half size, full frames).
Rules (owner 11/15): show at least MIN_SEC; once AFSD says it is built (flag file "built") and MIN_SEC has passed,
play the GIF to the end of its loop, then write "closed" and exit -> AFSD shows its finished window.
Safety: gives up after MAX_SEC whatever happens. AFSD side: start(), built(), closed()."""
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
GIF = os.path.join(HERE, "templates", "splash", "splash.gif")
FLAGS = os.path.join(HERE, ".splash")
MIN_SEC = 2.0
MAX_SEC = 25.0
FRAME_MS = 100
BG = "#141414"


# ---- AFSD side ------------------------------------------------------------------------------------------------
def start():
    """Start the loading window (own process). Returns the Popen or None."""
    try:
        os.makedirs(FLAGS, exist_ok=True)
        for f in ("built", "closed"):
            try:
                os.remove(os.path.join(FLAGS, f))
            except OSError:
                pass
        if not os.path.exists(GIF):
            return None
        flags = 0x08000000 if os.name == "nt" else 0          # CREATE_NO_WINDOW
        return subprocess.Popen([sys.executable, os.path.abspath(__file__), FLAGS], creationflags=flags)
    except Exception:                                           # noqa: BLE001
        return None


def built():
    try:
        with open(os.path.join(FLAGS, "built"), "w") as fh:
            fh.write(str(time.time()))
    except OSError:
        pass


def closed(proc, since, now=None):
    """True when AFSD may show its window: the splash said so, it exited, or MAX_SEC passed."""
    now = now or time.time()
    if proc is None or os.path.exists(os.path.join(FLAGS, "closed")) or now - since > MAX_SEC:
        return True
    try:
        return proc.poll() is not None
    except Exception:                                           # noqa: BLE001
        return True


# ---- pure ------------------------------------------------------------------------------------------------------
def should_close(elapsed, built_flag, frame, finishing):
    """-> (close_now, finishing). Finishing starts once built and MIN_SEC passed; closes when the loop ends."""
    if elapsed > MAX_SEC:
        return True, finishing
    if not finishing and built_flag and elapsed >= MIN_SEC:
        finishing = True
        return False, finishing
    return bool(finishing and frame == 0), finishing


# ---- the splash program ----------------------------------------------------------------------------------------
def main(flag_dir):
    import tkinter as tk
    root = tk.Tk()
    root.withdraw()
    root.overrideredirect(True)
    root.configure(bg=BG)
    frames = [tk.PhotoImage(file=GIF, format="gif -index 0")]
    w, h = frames[0].width() + 16, frames[0].height() + 16
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")
    pic = tk.Label(root, image=frames[0], bg=BG, bd=0)
    pic.place(x=8, y=8)
    root.attributes("-topmost", True)
    root.deiconify()
    t0 = time.time()
    st = {"i": 0, "n": 0, "finishing": False}

    def tick():
        nxt = st["i"] + 1
        if not st["n"] and nxt >= len(frames):
            try:
                frames.append(tk.PhotoImage(file=GIF, format=f"gif -index {nxt}"))
            except tk.TclError:                                # past the last frame -> the loop length is known
                st["n"] = len(frames)
        if st["n"]:
            nxt %= st["n"]
        st["i"] = nxt
        pic.configure(image=frames[nxt])
        close, st["finishing"] = should_close(time.time() - t0, os.path.exists(os.path.join(flag_dir, "built")),
                                              nxt, st["finishing"])
        if close:
            try:
                with open(os.path.join(flag_dir, "closed"), "w") as fh:
                    fh.write("1")
            except OSError:
                pass
            root.destroy()
            return
        root.after(FRAME_MS, tick)

    root.after(FRAME_MS, tick)
    root.mainloop()


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else FLAGS)
