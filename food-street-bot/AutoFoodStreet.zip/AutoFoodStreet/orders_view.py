"""orders_view.py -- what the Orders window shows (10/16, owner's idea).

The bot fills this in while it works: event_orders.py for the Food Club Event board and afsd_core.py
for the normal clipboard orders. The Orders window (autofoodstreet.py) only reads it. Nothing here
taps or changes anything in the game -- it is a notebook the bot writes into and the window reads.

Each source holds its orders as they were last read:
    {"time": "19:42:05", "completed": 3, "note": "...",
     "orders": [{"no": 1, "items": [{"name": "Cherry Pie", "have": 0, "need": 1,
                                     "status": "cooking at Supermarket Merchant", "kind": "cooking",
                                     "active": False}]}]}
kind is one of: done, active, cooking, growing, waiting, stuck, todo -- the window colours by it.
"""
import copy
import json
import os
import threading
import time

HISTORY_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "order_history.json")
HISTORY_KEEP = 2000

FOOD_CLUB = "Food Club Event"
CLIPBOARD = "Clipboard orders"

_lock = threading.Lock()
_state = {}
_version = 0


def _bump():
    global _version
    _version += 1


def _source(name):
    return _state.setdefault(name, {"time": None, "updated": 0.0, "completed": 0, "note": "", "orders": []})


def friendly(status, where=None):
    """A bot result code -> (text for the window, kind)."""
    s = str(status or "")
    inner = s.replace("recursed:", "")
    at = f" at {where}" if where else ""
    if s.startswith("recursed:"):
        text, kind = friendly(inner, None)
        return f"working on an ingredient: {text}", kind
    table = [
        ("queued", (f"cooking{at}", "cooking")),
        ("already_cooking", (f"already cooking{at}", "cooking")),
        ("planted", ("planted, growing", "growing")),
        ("growing", ("growing", "growing")),
        ("waiting", ("waiting for a free slot", "waiting")),
        ("collected_blocker", ("collected a batch, checking it next pass", "waiting")),
        ("no_stock", ("out of seeds (no gems spent)", "stuck")),
        ("wrong_place", ("could not reach the station, retrying", "stuck")),
        ("station_not_opened", ("station menu did not open, retrying", "stuck")),
        ("travel_failed", ("travel failed, retrying", "stuck")),
        ("unsure", ("could not tell which card, picture saved", "stuck")),
        ("unknown", ("did not recognise where it arrived", "stuck")),
        ("board_not_opened", ("board did not open", "stuck")),
        ("served", ("served", "done")),
        ("complete", ("served", "done")),
    ]
    for key, val in table:
        if inner.startswith(key):
            return val
    return (inner.replace("_", " ") or "?", "waiting")


def set_orders(source, orders, note=""):
    """Replaces a source's orders with a fresh read. Keeps an item's last status when the same item
    is still on the same order (so the window does not blank out between reads)."""
    with _lock:
        src = _source(source)
        old = {(o["no"], i.get("name") or f"#{k}"): i for o in src["orders"] for k, i in enumerate(o["items"])}
        for o in orders:
            for k, it in enumerate(o["items"]):
                it.setdefault("active", False)
                prev = old.get((o["no"], it.get("name") or f"#{k}"))
                if it.get("kind") == "done":
                    continue
                if prev and prev.get("kind") not in (None, "todo", "active", "done") and not it.get("status"):
                    it["status"], it["kind"] = prev["status"], prev["kind"]
                it.setdefault("status", "needs making")
                it.setdefault("kind", "todo")
        src["orders"] = orders
        src["note"] = note
        src["time"] = time.strftime("%H:%M:%S")
        src["updated"] = time.time()
        _bump()


def mark_dismissed(source, same, state):
    """10/23: Dismiss on the Orders tab. state "queued" -> the card shows Dismissing...; "gone" -> the card is removed
    now; None -> back to normal. `same(sig)` tells whether an order's header signature is the dismissed one."""
    with _lock:
        src = _source(source)
        keep = []
        for o in src["orders"]:
            if o.get("sig") is not None and same(o["sig"]):
                if state == "gone":
                    continue
                o["dismissing"] = state == "queued"
            keep.append(o)
        src["orders"] = keep
        src["updated"] = time.time()
        _bump()


def set_item(source, order_no, index, status=None, kind=None, name=None, active=None, timer=None):
    """Updates one item (by its order number and position on the order)."""
    with _lock:
        src = _source(source)
        for o in src["orders"]:
            if o["no"] != order_no or index >= len(o["items"]):
                continue
            it = o["items"][index]
            if name:
                it["name"] = name
            if status is not None:
                it["status"] = status
            if kind is not None:
                it["kind"] = kind
            if timer:
                it["timer"] = timer                      # name of the timer that belongs to this row
            if active is not None:
                for o2 in src["orders"]:                     # only one item is "being worked on" at a time
                    for it2 in o2["items"]:
                        it2["active"] = False
                it["active"] = active
            src["updated"] = time.time()
            _bump()
            return True
    return False


def clear_active(source):
    with _lock:
        for o in _source(source)["orders"]:
            for it in o["items"]:
                it["active"] = False
        _bump()


def add_completed(source, n):
    if not n:
        return
    with _lock:
        _source(source)["completed"] += int(n)
        _bump()


def add_new_order_timer(source, until):
    """10/21 (owner): an order was dismissed -> the game sends a new one in ~30 min; the window shows a countdown."""
    with _lock:
        src = _source(source)
        src["new_orders"] = [u for u in src.get("new_orders", []) if u > time.time()] + [until]
        src["updated"] = time.time()
        _bump()


def set_read_new_orders(source, untils, key):
    """10/26 (backlog #27): countdowns READ from the board ("New Order In 21 Minutes") replace the 30-min guesses.
    key = which board page they came from: a page's own earlier readings are replaced, other pages' are kept."""
    now = time.time()
    with _lock:
        src = _source(source)
        read = {k: v for k, v in (src.get("new_orders_read") or {}).items() if any(u > now for u in v)}
        read[key] = [u for u in untils if u > now]
        src["new_orders_read"] = read
        src["new_orders"] = sorted(u for v in read.values() for u in v if u > now)   # guesses dropped: real times now
        src["updated"] = now
        _bump()


def set_note(source, note):
    with _lock:
        src = _source(source)
        src["note"] = note
        src["updated"] = time.time()
        _bump()


def _norm(name):
    return "".join(ch for ch in str(name or "").lower() if ch.isalnum())


def add_timer(source, name, where, ready_times, approx=False):
    """Step A of the cooking plan (10/16): remember when batches / crops of `name` will be ready."""
    if not name or not ready_times:
        return
    with _lock:
        src = _source(source)
        timers = src.setdefault("timers", {})
        now = time.time()
        t = timers.setdefault(_norm(name), {"name": name, "where": where, "ready": [], "approx": False})
        t["ready"] = sorted([r for r in t["ready"] if r > now - 600] + list(ready_times))
        t["where"] = where or t.get("where")
        t["approx"] = bool(approx)
        src["updated"] = now
        _bump()


def timer_for(state_source, name):
    """(ready_at, approx) of the next batch of `name` (or the latest one if all are due), else None."""
    t = (state_source.get("timers") or {}).get(_norm(name))
    if not t or not t["ready"]:
        return None
    now = time.time()
    upcoming = [r for r in t["ready"] if r >= now]
    return (upcoming[0] if upcoming else t["ready"][-1]), t.get("approx", False)


_run = {"cycle": 0, "started": None}


def note_cycle(n):
    """Called at the start of every cycle (afsd_core). Cycle 1 = a new run (Start pressed)."""
    with _lock:
        if n == 1 or _run["started"] is None:
            _run["started"] = time.time()
        _run["cycle"] = n


def progress():
    """What the status line under 'Status' shows: run time, cycle, orders completed this run (and coins),
    and the item being worked on right now. Never raises."""
    try:
        with _lock:
            run = dict(_run)
            hist = list(_load_history())
            active = None
            for src, d in _state.items():
                for o in d.get("orders", []):
                    for it in o["items"]:
                        if it.get("active"):
                            active = (it.get("name"), o["no"], src)
        if not run["started"]:
            return ""
        done = [e for e in hist if e["t"] >= run["started"]]
        coins = sum(e.get("reward") or 0 for e in done)
        mins = int((time.time() - run["started"]) // 60)
        parts = [f"cycle {run['cycle']}", f"running {mins // 60}h {mins % 60:02d}m" if mins >= 60 else f"running {mins}m",
                 f"{len(done)} order{'s' if len(done) != 1 else ''} done" + (f" (+{coins:,} coins)" if coins else "")]
        line = "  \u00b7  ".join(parts)
        if active:
            name, no, src = active
            line += f"\nworking on {name or 'an item'} for {'Food Club' if src == FOOD_CLUB else 'clipboard'} order {no}"
        return line
    except Exception:                                  # noqa: BLE001
        return ""


_history = None


def _load_history():
    global _history
    if _history is None:
        try:
            with open(HISTORY_FILE, encoding="utf-8") as fh:
                _history = json.load(fh)
        except (OSError, ValueError):
            _history = []
    return _history


def add_history(source, items, reward=None, express=False, missed=False, by_hand=False, points=None):
    """One completed order: when, which board, what was on it, and the coins it paid (when known).
    Kept in order_history.json so the History tab survives restarts. 10/18: express orders are flagged,
    and an express that left the board without the bot completing it is kept as missed=True."""
    with _lock:
        h = _load_history()
        e = {"t": time.time(), "source": source, "reward": reward,
             "items": [{"name": i.get("name"), "need": i.get("need")} for i in items]}
        if express:
            e["express"] = True
        if missed:
            e["missed"] = True
        if by_hand:
            e["by_hand"] = True
        if points:
            e["points"] = points
        h.append(e)
        del h[:-HISTORY_KEEP]
        try:
            tmp = HISTORY_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(h, fh)
            os.replace(tmp, HISTORY_FILE)
        except OSError:
            pass
        _bump()


def credit_points(source, points, since, until):
    """10/18: the scoreboard went up by `points` between two readings -- give them to the order(s) this board
    completed in that window (split evenly, marked shared, when more than one). Returns a short note or None."""
    with _lock:
        h = _load_history()
        hit = [e for e in h if e["source"] == source and not e.get("missed") and "points" not in e
               and since - 5 <= e["t"] <= until + 5]
        if not hit:
            return None
        each = int(round(points / len(hit)))
        for e in hit:
            e["points"] = each
            if len(hit) > 1:
                e["points_shared"] = len(hit)
        try:
            tmp = HISTORY_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(h, fh)
            os.replace(tmp, HISTORY_FILE)
        except OSError:
            pass
        _bump()
        return f"{len(hit)} order(s)" + (f", ~{each} each" if len(hit) > 1 else "")


def history():
    with _lock:
        return copy.deepcopy(_load_history())


def snapshot():
    """(version, deep copy of everything) -- for the window."""
    with _lock:
        return _version, copy.deepcopy(_state)
