@echo off
rem AutoFoodStreet installer. No admin needed. Puts its own Python in this folder's "python" subfolder,
rem installs the two libraries the bot needs (OpenCV, NumPy), makes a desktop shortcut and starts AFSD.
setlocal
cd /d "%~dp0"
set "HERE=%CD%"
set "PY=%HERE%\python\python.exe"
set "PYW=%HERE%\python\pythonw.exe"
set "PYVER=3.12.8"
echo.
echo  AutoFoodStreet installer
echo  Folder: %HERE%
echo.
if exist "%PY%" goto have_python
echo [1/3] Downloading Python %PYVER% (about 25 MB)...
curl -L --fail -o "%TEMP%\afsd_python.exe" "https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"
if errorlevel 1 goto fail
echo       Installing Python into %HERE%\python (takes a minute, no window)...
"%TEMP%\afsd_python.exe" /quiet InstallAllUsers=0 PrependPath=0 Shortcuts=0 AssociateFiles=0 Include_launcher=0 Include_test=0 Include_doc=0 Include_tcltk=1 Include_pip=1 TargetDir="%HERE%\python"
if not exist "%PY%" goto fail
del "%TEMP%\afsd_python.exe" >nul 2>&1
:have_python
echo [2/3] Installing OpenCV and NumPy...
"%PY%" -m pip install --disable-pip-version-check -q --upgrade opencv-python numpy
if errorlevel 1 goto fail
"%PY%" -c "import cv2, numpy, tkinter; print('      libraries OK')"
if errorlevel 1 goto fail
echo [3/3] Starting AutoFoodStreet (it makes a desktop shortcut on first start)...
if not exist "C:\LDPlayer\LDPlayer9\adb.exe" (
  echo.
  echo  NOTE: LDPlayer 9 was not found in C:\LDPlayer\LDPlayer9.
  echo  Install LDPlayer 9 from ldplayer.net, set its resolution to 1600x900, install Food Street in it.
  echo.
)
start "" "%PYW%" "%HERE%\autofoodstreet.py"
echo.
echo  Done. Next time use the "AutoFoodStreet" shortcut on your desktop.
pause
exit /b 0
:fail
echo.
echo  Something went wrong. Take a screenshot of this window and post it in the Discord.
pause
exit /b 1
