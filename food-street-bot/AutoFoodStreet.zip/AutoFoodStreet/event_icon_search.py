"""event_icon_search.py -- the bot finds a NEW Food Club event icon by itself (11/12, owner pick; Muse proposal
muse/auto-event-icon-retrain.md).

Each event draws a new icon in the bottom bar (Halloween cart -> burger on 11/12) and the board finder only knows the
old picture, so the board never opened and the bot ran clipboard fallback for 5 hours. Now, when opening the board
gives up, this tries every TIMED icon in the bottom event bar (each one has a "5d 19h" style timer under it) once:
tap -> did the Food Club board open? yes -> that icon becomes templates/event_board_icon.png (event_icon_trainer).
no -> back out (gem/buy question -> No, red X / panel closer, Back key) and remember it as not-the-board.

Never loops on a dead event: an icon that is not the board is not tapped again for TRIED_SEC (24 h); a search where
nothing opened the board rests the search for REST_SEC (24 h) unless a NEW timed icon shows up; failed searches on
MAX_FAIL_DAYS different days stop it until the owner trains an icon with the "New event icon" button.
"""
import json
import os
import time

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATE_FILE = os.path.join(BASE_DIR, ".event_icon_search.json")

TIMER_BAND = (845, 900)        # y band of the white timer text under the bottom-bar icons
ICON_ABOVE = 52                # icon middle = timer text top - this (burger: text top 864 -> icon 812)
GROUP_GAP = 25                 # timer glyphs closer than this belong to one timer
TRIED_SEC = 24 * 3600
REST_SEC = 24 * 3600
MAX_FAIL_DAYS = 3


def log(msg):
    try:
        import event_orders
        event_orders.log(f"[event icon] {msg}")
    except Exception:                                   # noqa: BLE001
        pass


def timer_icons(img, region):
    """Pure: [(x, y)] middles of the icons in `region` (x1, y1, x2, y2) that carry a white timer underneath, left
    to right. Timer digits are white (low saturation, bright) and ~24 px tall."""
    x1, _, x2, _ = region
    y1, y2 = TIMER_BAND
    roi = img[y1:y2, x1:x2]
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    m = ((hsv[:, :, 1] < 50) & (hsv[:, :, 2] > 215)).astype(np.uint8)
    n, _, st, _ = cv2.connectedComponentsWithStats(m)
    glyphs = sorted((st[i][0], st[i][1], st[i][2], st[i][3]) for i in range(1, n)
                    if 18 <= st[i][3] <= 32 and 5 <= st[i][2] <= 22)
    groups = []
    for gx, gy, gw, gh in glyphs:
        if groups and gx - groups[-1][1] <= GROUP_GAP:
            g = groups[-1]
            g[1] = max(g[1], gx + gw)
            g[2].append((gx, gx + gw, gy))
        else:
            groups.append([gx, gx + gw, [(gx, gx + gw, gy)]])
    out = []
    for _a, _b, parts in groups:
        tops = [p[2] for p in parts]
        mid = np.median(tops)
        line = [p for p in parts if abs(p[2] - mid) <= 4]        # glyphs on the timer's own line only
        a, b = min(p[0] for p in line), max(p[1] for p in line)
        # "5d 19h" = 5-6 glyphs, ~75-90 px wide; the MEDIAN glyph top (white bits of the map behind, e.g. a boat
        # cabin, can join a group but not shift its middle line)
        if len(tops) >= 3 and 40 <= b - a <= 140:
            top = int(np.median(tops))
            out.append((int(x1 + (a + b) // 2), int(y1 + top - ICON_ABOVE)))
    return out


def icon_key(img, x, y):
    """8x8 average-hash of the 70x68 icon picture at (x, y) -- remembers which icons were tried."""
    crop = img[max(0, y - 34):y + 34, max(0, x - 35):x + 35]
    g = cv2.resize(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY), (8, 8), interpolation=cv2.INTER_AREA)
    bits = (g > g.mean()).flatten()
    return "".join("1" if b else "0" for b in bits)


def _load():
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            s = json.load(f)
            if isinstance(s, dict):
                return s
    except Exception:                                   # noqa: BLE001
        pass
    return {}


def _save(s):
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(s, f)
    except Exception:                                   # noqa: BLE001
        pass


def reset():
    """The owner trained an icon by hand (or one was learned): start fresh."""
    _save({})


def untried(keys, state, now):
    """Pure: the keys not tried in the last TRIED_SEC."""
    tried = state.get("tried", {})
    return [k for k in keys if now - tried.get(k, 0) >= TRIED_SEC]


def may_search(keys, state, now):
    """Pure: (yes/no, why)."""
    if len(set(state.get("fail_days", []))) >= MAX_FAIL_DAYS:
        return False, (f"no icon opened the board on {MAX_FAIL_DAYS} different days -- stopped until an icon is "
                       "trained with the 'New event icon' button")
    fresh = untried(keys, state, now)
    if not fresh:
        return False, "every timed icon in the bar was already tried (none opened the board)"
    if now - state.get("last_fail", 0) < REST_SEC:
        new = [k for k in fresh if k not in state.get("tried", {})]
        if not new:
            return False, "resting after a search that found nothing (the event may be over)"
    return True, f"{len(fresh)} icon(s) to try"


def _back_out(of, adb_helper, fac, eo):
    """After a tap that did not open the board: decline any gem/buy question, close panels, Back key last."""
    for _ in range(3):
        time.sleep(0.8)
        img = adb_helper.screenshot()
        if img is None:
            continue
        no, _ = of.find_no_button(img)
        if no is not None:
            log("a buy / gem question came up -- tapping No.")
            adb_helper.tap(*no)
            continue
        if eo.hud_is_bright(img):
            return
        if fac.close_any_open_panel(quiet=True, thorough=True):
            continue
        adb_helper.back()


def search(stop_flag=None):
    """Tries the timed icons. Returns the open board picture when one of them is the Food Club board, else None."""
    import adb_helper
    import event_orders as eo
    import event_icon_trainer
    import find_and_center as fac
    import order_fulfill as of
    img = adb_helper.screenshot()
    if img is None or not eo.hud_is_bright(img):
        return None
    icons = timer_icons(img, eo.BOARD_ICON_REGION)
    keys = {icon_key(img, x, y): (x, y) for x, y in icons}
    state = _load()
    now = time.time()
    ok, why = may_search(list(keys), state, now)
    if not ok:
        if state.get("said") != why:
            log(f"not searching for a new board icon: {why}.")
            state["said"] = why
            _save(state)
        return None
    log(f"board not found -- searching for the new board icon ({why}: "
        f"{', '.join(str(keys[k]) for k in untried(list(keys), state, now))}).")
    for k in untried(list(keys), state, now):
        of.check_stop(stop_flag)
        x, y = keys[k]
        shot = adb_helper.screenshot()
        if shot is None or not eo.hud_is_bright(shot):
            _back_out(of, adb_helper, fac, eo)
            shot = adb_helper.screenshot()
            if shot is None or not eo.hud_is_bright(shot):
                log("the screen is covered -- stopping the search for now.")
                return None
        adb_helper.tap(x, y)
        board, opened = eo.wait_for(eo.board_is_open, 4.0, stop_flag)
        state.setdefault("tried", {})[k] = time.time()
        if opened:
            good, msg = event_icon_trainer.save_icon(shot, x, y)
            log(f"LEARNED the new board icon at ({x},{y}): {msg}")
            try:
                cv2.imwrite(os.path.join(BASE_DIR, "templates", "event_tapfail",
                                         f"{int(time.time())}_learned_icon.png"), shot)
            except Exception:                           # noqa: BLE001
                pass
            reset()
            return board if good else None
        log(f"the icon at ({x},{y}) is not the Food Club board -- backing out.")
        _save(state)
        _back_out(of, adb_helper, fac, eo)
    state = _load()
    state["last_fail"] = time.time()
    day = time.strftime("%Y-%m-%d")
    state.setdefault("fail_days", [])
    if day not in state["fail_days"]:
        state["fail_days"].append(day)
    state.pop("said", None)
    _save(state)
    log("no timed icon opened the Food Club board -- the event is probably over. Clipboard fallback as before; "
        "searching again in 24 h or when a new timed icon appears.")
    return None
