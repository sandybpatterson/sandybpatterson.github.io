"""Reads the white stock box under a recipe card on a station panel (10/20).

The game draws the count as dark digits in a white box at the card's lower right. Windows OCR returns nothing for a
lone digit (every Prep read failed live 10/19), so the digits are matched against shapes cut from 645 stock boxes
in saved screenshots (templates/stock_digits/<digit>_<variant>.png, 16x24 masks). Read-only, never taps.
"""
import glob
import os

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_TEMPLATES = []
for _p in sorted(glob.glob(os.path.join(BASE_DIR, "templates", "stock_digits", "*.png"))):
    _t = cv2.imread(_p, cv2.IMREAD_GRAYSCALE)
    if _t is not None:
        _v = _t.astype(np.float32).ravel()
        _TEMPLATES.append((int(os.path.basename(_p)[0]), (_v - _v.mean()) / (_v.std() + 1e-6)))
MATCH_MIN = 0.70
if not _TEMPLATES:                                      # 10/20: the pictures were missing on the PC (not in Update)
    try:
        from order_fulfill import log as _log
        _log("[stock] templates/stock_digits is missing -- stock boxes cannot be read until Update installs it.")
    except Exception:                                   # noqa: BLE001
        pass


def find_box(img, cx):
    """(x, y, w, h) of the white stock box right of a card centred at cx, or None."""
    x1, x2 = max(0, cx + 30), min(img.shape[1], cx + 190)
    band = img[390:480, x1:x2].astype(np.int16)
    # pure white only: the pale-blue card behind the box is also bright, and merged into it on some panels
    white = (band.min(axis=2) > 225) & ((band.max(axis=2) - band.min(axis=2)) < 14)
    n, _lab, st, _c = cv2.connectedComponentsWithStats(white.astype(np.uint8))
    best = None
    for x, y, w, h, a in st[1:]:
        if 50 <= w <= 80 and 40 <= h <= 66 and a > 0.5 * w * h:
            if best is None or a > best[4]:
                best = (x, y, w, h, a)
    if best is None:
        # a white plate touching the box merges with it -- the box always sits at the same spot from the card's
        # button (cx + 76..78, y 405..407, 65 x 50 in 645 saved boxes), so read that spot instead
        return cx + 77, 406, 65, 50
    x, y, w, h, _a = best
    return x + x1, y + 390, w, h


def read_box(crop):
    """The number in a stock-box crop, or None."""
    g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    m = (g < 120).astype(np.uint8)
    m[:3] = 0
    m[-3:] = 0
    m[:, :3] = 0
    m[:, -3:] = 0
    n, _lab, st, _c = cv2.connectedComponentsWithStats(m)
    comps = sorted((x, y, w, h) for x, y, w, h, a in st[1:] if h >= 14 and a >= 25)
    if not comps or len(comps) > 3:
        return None
    digits = []
    for x, y, w, h in comps:
        gl = cv2.resize(m[y:y + h, x:x + w] * 255, (16, 24), interpolation=cv2.INTER_AREA).astype(np.float32).ravel()
        v = (gl - gl.mean()) / (gl.std() + 1e-6)
        score, d = max((float(np.dot(v, t) / len(v)), d) for d, t in _TEMPLATES)
        if score < MATCH_MIN:
            return None
        digits.append(str(d))
    return int("".join(digits))


def read_stock(img, cx):
    """Stock count of the card centred at cx on an open station panel, or None."""
    try:
        b = find_box(img, cx)
        if b is None:
            return None
        x, y, w, h = b
        return read_box(img[y:y + h, x:x + w])
    except Exception:                                  # noqa: BLE001
        return None
