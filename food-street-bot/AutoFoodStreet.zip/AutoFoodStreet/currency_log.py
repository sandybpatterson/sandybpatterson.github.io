"""Gems / coins / ticket log (10/10). READ-ONLY: takes a screenshot and reads the top bar, never taps anything.

- start_run()  -> baseline at Start; end_run() -> "earned +N" summary when the run ends (or Stop is pressed).
- snapshot()   -> one line in run_log.txt at most every SNAPSHOT_GAP_SEC, and a loud GEM DROP line if gems go down.
- Gems and coins are read with Windows OCR (clean on the HUD). The four ticket counters (gold, grey, orange, blue)
  use a font OCR cannot read: ticket_reader.py reads them with digit templates (confirmed by a second look); a picture of
  the strip is saved to templates/currency_strips/ only when they cannot be read.
"""
import json
import os
import time

import adb_helper

BASE = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE, "run_log.txt")
STRIP_DIR = os.path.join(BASE, "templates", "currency_strips")
GEM_REGIONS = ((1400, 5, 1520, 75), (1415, 10, 1510, 70), (1405, 8, 1515, 72))
COIN_REGIONS = ((1100, 10, 1215, 70), (1110, 15, 1200, 65), (1090, 12, 1215, 68), (1105, 12, 1205, 68))   # the coin icon's edge leaks into some boxes and a 5-digit number overflows others
TICKET_STRIP = (5, 75, 675, 945)           # y1, y2, x1, x2 -- the four ticket icons + their numbers
SNAPSHOT_GAP_SEC = 600

_baseline = None
_last = None
_next_snapshot = 0.0


# what each ticket colour is, as far as we know (the owner said gold = the street Food Truck event, the better rewards; the rest is a guess)
TICKET_LEGEND = {"gold": "gold", "grey": "grey", "orange": "orange", "blue": "blue"}   # 10/31 (owner): vouchers from random rewards, no colour belongs to one event


def _tk_name(k):
    return TICKET_LEGEND.get(k, k)


def log(msg):
    line = f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] [currency] {msg}"
    print(line)
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def _number(img, regions):
    """Read a HUD number with Windows OCR from a few slightly different boxes and trust the value two of them agree on
    (a box that clips a digit or catches the icon gives nothing or a wrong digit); the first reading if none agree."""
    import collections
    import popup_ocr
    try:                                               # 10/24: the game's own digit shapes first (OCR dropped digits: 8464 -> 464)
        import coin_digits
        v = coin_digits.read_hud(img)["coins" if regions[0] in COIN_REGIONS else "gems"]
        if v is not None:
            return v
    except Exception:                                  # noqa: BLE001
        pass
    vals = []
    for region in regions:
        txt = popup_ocr.read_text(img, region)
        digits = "".join(ch for ch in txt if ch.isdigit())
        if 1 <= len(digits) <= 7:
            vals.append(int(digits))
    if not vals:
        return None
    v, n = collections.Counter(vals).most_common(1)[0]
    if n >= 2:
        return v
    return max(vals, key=lambda x: len(str(x)))        # no two boxes agree: a clipped box drops digits, so the longest reading is the safest


def read_hud(img):
    """{'gems': n|None, 'coins': n|None} from the top bar."""
    out = {"gems": None, "coins": None}
    try:
        out["gems"] = _number(img, GEM_REGIONS)
        out["coins"] = _number(img, COIN_REGIONS)
    except Exception:                                  # noqa: BLE001
        pass
    return out


def read_tickets(img):
    """The four ticket counters, trusted only when a second screenshot ~1 s later reads exactly the same
    (a flying reward particle over a digit can drop a digit, e.g. 14 -> 1). Returns a dict or None."""
    try:
        import ticket_reader
        first = ticket_reader.read_tickets(img)
        if any(v is None for v in first.values()):
            return None
        time.sleep(1.0)
        second = ticket_reader.read_tickets(adb_helper.screenshot())
        return first if second == first else None
    except Exception:                                  # noqa: BLE001
        return None


def save_ticket_strip(img, tag):
    try:
        import cv2
        os.makedirs(STRIP_DIR, exist_ok=True)
        y1, y2, x1, x2 = TICKET_STRIP
        path = os.path.join(STRIP_DIR, f"{time.strftime('%Y%m%d_%H%M%S')}_{tag}.png")
        cv2.imwrite(path, img[y1:y2, x1:x2])
        return os.path.relpath(path, BASE)
    except Exception:                                  # noqa: BLE001
        return None


def snapshot(tag="cycle", force=False, img=None):
    """Read gems + coins, log them, shout on a gem drop. Returns the reading (or None)."""
    global _last, _next_snapshot
    if not force and time.time() < _next_snapshot:
        return _last
    _next_snapshot = time.time() + SNAPSHOT_GAP_SEC
    try:
        if img is None:
            img = adb_helper.screenshot()
        cur = read_hud(img)
    except Exception as e:                             # noqa: BLE001
        log(f"snapshot failed (ignored): {e}")
        return _last
    if cur["gems"] is None and cur["coins"] is None:
        return _last
    tickets = read_tickets(img) if (force or tag != "cycle") else None
    strip = save_ticket_strip(img, tag) if (force and tickets is None) else None     # a picture only when the numbers could not be read
    if _last and cur["gems"] is not None and _last.get("gems") is not None and cur["gems"] < _last["gems"]:
        log(f"GEM DROP: {_last['gems']} -> {cur['gems']} ({tag}) -- nothing in the bot should spend gems; check the log lines just before this one.")
    tk = ("  tickets " + " ".join(f"{_tk_name(k)} {v}" for k, v in tickets.items())) if tickets else ""
    log(f"[{tag}] gems {cur['gems']}  coins {cur['coins']}" + tk + (f"  (tickets unreadable -- picture: {strip})" if strip else ""))
    cur["strip"] = strip
    cur["tickets"] = tickets
    cur["time"] = time.time()
    if _last:                                          # keep the last good value if one number was unreadable
        for k in ("gems", "coins"):
            if cur[k] is None:
                cur[k] = _last.get(k)
    _last = cur
    return cur


def start_run():
    """Baseline at the start of a run."""
    global _baseline
    cur = snapshot("start", force=True)
    _baseline = dict(cur) if cur else None
    try:
        with open(os.path.join(BASE, ".currency_baseline.json"), "w", encoding="utf-8") as fh:
            json.dump(_baseline or {}, fh)
    except OSError:
        pass
    return _baseline


def _delta(a, b):
    if a is None or b is None:
        return "?"
    return f"{b - a:+d} ({a} -> {b})"


def end_run():
    """Final reading + 'earned' summary against the baseline."""
    base = _baseline
    cur = snapshot("end", force=True)
    if not cur:
        log("run summary: could not read the top bar at the end of the run.")
        return None
    if not base:
        log(f"run summary: no baseline (start reading failed); end gems {cur['gems']} coins {cur['coins']}.")
        return cur
    mins = int((cur["time"] - base["time"]) / 60)
    bt, ct = base.get("tickets"), cur.get("tickets")
    if bt and ct:
        tk = ", ".join(f"{_tk_name(k)} {_delta(bt[k], ct[k])}" for k in ct)
    else:
        tk = f"not read -- compare {base.get('strip')} with {cur.get('strip')}"
    log(f"RUN SUMMARY ({mins} min): gems {_delta(base.get('gems'), cur.get('gems'))}, coins {_delta(base.get('coins'), cur.get('coins'))}; tickets: {tk}")
    return cur


# ---------------------------------------------------------------------------------------------------------------
# per-cycle change line (10/10): one quick reading at the end of every AFSD cycle (gems + coins; tickets about every 10 min)
# ---------------------------------------------------------------------------------------------------------------
_cd_gems = None
_cd_coins = None
_cd_tickets = None
_cd_tickets_next = 0.0
TICKET_GAP_SEC = 600


def cycle_delta():
    """'currency: gems 61 (+0), coins 9485 (+320), tickets gold 8 ... (gold +1)' -- or None when the top bar cannot be read.
    One screenshot and one OCR read per number (a wider fallback only when the quick read fails)."""
    global _cd_gems, _cd_coins, _cd_tickets, _cd_tickets_next, _last
    try:
        img = adb_helper.screenshot()
        gems = _number(img, GEM_REGIONS[:1])
        if gems is None:
            gems = _number(img, GEM_REGIONS)
        coins = _number(img, COIN_REGIONS[:1])
        if coins is None or (_cd_coins and abs(coins - _cd_coins) > 0.4 * _cd_coins):       # missing or a big jump -> ask all the boxes
            coins = _number(img, COIN_REGIONS)
    except Exception:                                  # noqa: BLE001
        return None
    if gems is None and coins is None:
        return None
    parts = []
    if gems is not None:
        if _cd_gems is not None and gems < _cd_gems:
            log(f"GEM DROP: {_cd_gems} -> {gems} (cycle end) -- nothing in the bot should spend gems; check the log lines of this cycle.")
        parts.append(f"gems {gems}" + (f" ({gems - _cd_gems:+d})" if _cd_gems is not None else ""))
        _cd_gems = gems
    if coins is not None:
        parts.append(f"coins {coins}" + (f" ({coins - _cd_coins:+d})" if _cd_coins is not None else ""))
        _cd_coins = coins
    if time.time() >= _cd_tickets_next:
        _cd_tickets_next = time.time() + TICKET_GAP_SEC
        tk = read_tickets(img)
        if tk:
            diff = ""
            if _cd_tickets:
                ch = [f"{_tk_name(k)} {tk[k] - _cd_tickets[k]:+d}" for k in tk if tk[k] != _cd_tickets[k]]
                diff = f" ({', '.join(ch) if ch else 'no change'} since the last ticket look)"
            parts.append("tickets " + " ".join(f"{_tk_name(k)} {v}" for k, v in tk.items()) + diff)
            _cd_tickets = tk
    if _last is not None:                              # keep the snapshot()'s gem-drop memory in step
        _last = dict(_last)
        if gems is not None:
            _last["gems"] = gems
        if coins is not None:
            _last["coins"] = coins
    return "currency: " + ", ".join(parts)
