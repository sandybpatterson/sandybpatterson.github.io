"""Delivery Event automation. Confirmed live 9/26 via real ADB screenshots
(not just the reference PDF) -- see CLAUDE.md for the full writeup.

Mechanic: the event's Tasks tab fills on its own from normal gameplay
(completing orders, collecting dishes, harvesting crops, etc) -- there is
nothing to actively do for those. The only real player action is tapping
"Send Order" once enough accumulated delivery-box items are banked, which
consumes them for event/club points. Every task also has a green
"Complete [ruby cost]" skip button -- these are gem-spend skips and must
NEVER be tapped, same rule as every other gem-cost button in this project.

v1 scope, explicitly basic/untested end-to-end per the user (2026-09-26):
find the nav icon, open the panel, confirm it's really the Delivery Event
banner, check whether Send Order looks tappable, tap it if so, close the
panel. Chef Challenge and the (still unlocated) Food Truck event are out
of scope for this module -- no templates exist for either yet.
"""
import os
import sys
import time
import datetime
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from adb_helper import screenshot, tap
from find_and_center import (
    StopRequested, close_any_open_panel, check_stop, interruptible_sleep,
    dismiss_second_device_dialog, CLOSE_X_LOC,
)

LOG = os.path.join(BASE_DIR, "run_log.txt")

NAV_ICON_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "delivery_nav_icon.png"))
BANNER_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "delivery_event_banner.png"))
SEND_ORDER_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "delivery_send_order_button.png"))

# Fixed bottom-nav position, confirmed live 9/26 -- unlike a station or map
# landmark, this icon sits in the fixed HUD (same idea as the Orders
# clipboard icon), so no map search/centering is needed, just a direct tap.
NAV_ICON_LOC = (1015, 790)
NAV_MATCH_THRESHOLD = 0.6
BANNER_MATCH_THRESHOLD = 0.7
SEND_ORDER_MATCH_THRESHOLD = 0.7

# The panel's own close-X is NOT at the standard fixed CLOSE_X_LOC this
# time -- confirmed live at (1541,133), close enough to the standard
# (1541,124) that CLOSE_X_LOC still works fine in practice, but recorded
# here in case that ever needs distinguishing.


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] [delivery_event] {msg}\n")
    try:
        print(f"[{ts}] [delivery_event] {msg}")
    except (AttributeError, OSError):
        pass


def _match(img, template, threshold):
    if template is None:
        return None, 0.0
    res = cv2.matchTemplate(img, template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)
    if max_val < threshold:
        return None, max_val
    th, tw = template.shape[:2]
    return (max_loc[0] + tw // 2, max_loc[1] + th // 2), max_val


def find_nav_icon(img):
    return _match(img, NAV_ICON_TEMPLATE, NAV_MATCH_THRESHOLD)


def panel_is_open(img):
    loc, conf = _match(img, BANNER_TEMPLATE, BANNER_MATCH_THRESHOLD)
    return loc is not None, conf


def find_send_order_button(img):
    return _match(img, SEND_ORDER_TEMPLATE, SEND_ORDER_MATCH_THRESHOLD)


def send_order_is_affordable(img, loc):
    """Cheap grey-vs-colored check, same idea as garden_check's red/green
    carrot check -- a disabled Send Order button reads as flat grey, an
    enabled one should show real color (green, per the reference PDF).
    Only the disabled/grey state has actually been observed live so far
    (9/26) -- this heuristic is UNVERIFIED against a real enabled button
    and should be double-checked the first time this runs against a
    genuinely affordable order before trusting it unattended."""
    x, y = loc
    region = img[max(0, y - 15):y + 15, max(0, x - 60):x + 60]
    b, g, r = region[:, :, 0].mean(), region[:, :, 1].mean(), region[:, :, 2].mean()
    # Grey: r/g/b all close together. Green: g clearly dominant.
    is_grey = abs(int(r) - int(g)) < 12 and abs(int(g) - int(b)) < 12
    affordable = (not is_grey) and (g > r + 15)
    log(f"send_order_is_affordable check: r={r:.0f} g={g:.0f} b={b:.0f} -> "
        f"{'affordable/green' if affordable else 'not affordable/grey'}")
    return affordable


def main(stop_flag=None):
    log("=== delivery event run start ===")
    try:
        close_any_open_panel()

        img = screenshot()
        loc, conf = find_nav_icon(img)
        if loc is None:
            log(f"Delivery nav icon not found on current screen (best {conf:.2f}) -- "
                "it's a fixed HUD icon so it should always be visible; giving up this run.")
            log("=== delivery event run end (icon not found) ===")
            return

        check_stop(stop_flag)
        log(f"Delivery nav icon found at {loc} (confidence {conf:.2f}) -- tapping it.")
        tap(*NAV_ICON_LOC)
        interruptible_sleep(1, stop_flag)
        dismiss_second_device_dialog()

        img = screenshot()
        open_ok, banner_conf = panel_is_open(img)
        if not open_ok:
            log(f"Delivery Event banner not confirmed after tapping the icon "
                f"(best {banner_conf:.2f}) -- something else may have opened instead "
                "(a promo/gem dialog, a map marker under the icon, etc). Closing "
                "whatever's open and giving up this run rather than acting blind.")
            close_any_open_panel()
            log("=== delivery event run end (banner not confirmed) ===")
            return
        log(f"Delivery Event panel confirmed open (confidence {banner_conf:.2f}).")

        check_stop(stop_flag)
        btn_loc, btn_conf = find_send_order_button(img)
        if btn_loc is None:
            log(f"Send Order button not found (best {btn_conf:.2f}) -- panel layout "
                "may differ from what was templated. Closing without acting.")
            tap(*CLOSE_X_LOC)
            log("=== delivery event run end (send order button not found) ===")
            return

        if send_order_is_affordable(img, btn_loc):
            log(f"Send Order looks affordable at {btn_loc} (confidence {btn_conf:.2f}) -- tapping it.")
            tap(*btn_loc)
            interruptible_sleep(1, stop_flag)
        else:
            log(f"Send Order found at {btn_loc} (confidence {btn_conf:.2f}) but doesn't "
                "look affordable yet -- nothing to do this run.")

        check_stop(stop_flag)
        tap(*CLOSE_X_LOC)
        log("=== delivery event run end ===")
    except StopRequested:
        log("=== delivery event run stopped early by user ===")
        raise


if __name__ == "__main__":
    main()
