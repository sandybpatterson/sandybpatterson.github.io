"""S.O.U.P.S. -- Simulator Offers Useful Planning Suggestions (owner 11/9: "Soups? ... rename the last one and work
on it"). Step 4 of the kitchen simulator plan (kitchen_model.py), LOG ONLY.

Every simulator snapshot (kitchen_model.tick, every 10 min) the advisor lists the moves it WOULD make, best first:
  - a finished batch nobody collected (it blocks the station slot)
  - a ripe crop nobody harvested (only when storage has room -- ripe crops wait in the plot for free)
  - a stove the bot has used in the last 3 h that has had NOTHING of ours cooking for 10+ min
  - storage about to fill -> cook something that uses several ingredients first
and at the next snapshot it grades the last advice against what really happened ("acted on" / "still open"):
  [soups] advice: 1) collect Bread at Bread Oven (ready 6 min ago) 2) Dairy idle 14 min 3) harvest Wheat
  [soups] last advice: 2 of 3 acted on; still open: Dairy idle 24 min | so far 11 of 17 acted on
Nothing here taps or changes what the bot does. The open items are the bot's missed chances to keep busy -- the raw
material for Busy Mode (B.U.S.Y.) later.
"""
import time

IDLE_MIN_SEC = 10 * 60          # a stove counts as idle after this long with nothing of ours cooking
SEEN_SEC = 3 * 3600             # only stoves the bot used within this long
WAITING_MIN_SEC = 2 * 60        # a batch / crop counts as waiting this long after it was due
MAX_ADVICE = 5

_seen = {}                      # station -> last time something of ours was cooking there
_idle_since = {}                # station -> first snapshot it was seen idle
_last = []                      # [(key, text)] from the previous snapshot
_score = {"advised": 0, "acted": 0}


def _fmt(secs):
    m = int(secs // 60)
    return f"{m} min" if m < 60 else f"{m // 60}h{m % 60:02d}m"


def advise(snap, seen=None, idle_since=None, now=None):
    """Pure: [(key, text)] best first. snap = kitchen_model.snapshot(); seen / idle_since are updated in place."""
    now = snap.get("t", now or time.time())
    seen = _seen if seen is None else seen
    idle_since = _idle_since if idle_since is None else idle_since
    out = []
    stations = snap.get("stations") or {}
    # 1) finished batches waiting to be collected
    for st, items in stations.items():
        for dish, ready in items:
            if ready <= now - WAITING_MIN_SEC:
                out.append((f"collect:{st}:{dish}",
                            f"collect {dish.replace('_', ' ').title()} at {st} (ready {_fmt(now - ready)} ago)"))
    # 2) stoves that have gone idle
    for st, items in stations.items():
        if any(r > now for _d, r in items):
            seen[st] = now
    for st, last in list(seen.items()):
        if now - last > SEEN_SEC:
            del seen[st]
            idle_since.pop(st, None)
            continue
        busy = any(r > now for _d, r in stations.get(st, []))
        if busy:
            idle_since.pop(st, None)
            continue
        since = idle_since.setdefault(st, last)
        if now - since >= IDLE_MIN_SEC:
            out.append((f"idle:{st}", f"{st} idle {_fmt(now - since)} -- start something there"))
    # 3) ripe crops, only when storage has room (ripe crops wait in the plot without using storage)
    st_used = snap.get("storage")
    room = not st_used or st_used[0] < st_used[1] - 2
    for crop, ready in (snap.get("crops") or {}).items():
        if ready <= now - WAITING_MIN_SEC and room:
            out.append((f"harvest:{crop}", f"harvest {crop.replace('_', ' ').title()} (ripe {_fmt(now - ready)})"))
    # 4) storage close to full
    if st_used and st_used[0] >= st_used[1] - 2:
        out.append(("storage", f"storage {st_used[0]}/{st_used[1]} -- cook something that uses several ingredients "
                               "before harvesting more"))
    # order: collect (frees a slot) > idle stove > storage > harvest
    rank = {"collect": 0, "idle": 1, "storage": 2, "harvest": 3}
    out.sort(key=lambda kv: rank.get(kv[0].split(":")[0], 9))
    return out[:MAX_ADVICE]


def grade(last, now_advice):
    """Pure: last advice that no longer shows up = acted on. Returns (acted, still_open_texts)."""
    keys_now = {k for k, _t in now_advice}
    acted = [t for k, t in last if k not in keys_now]
    still = [t for k, t in now_advice if k in {k2 for k2, _ in last}]
    return acted, still


def tick(snap, log):
    """Called by kitchen_model with each snapshot. Never raises."""
    global _last
    try:
        adv = advise(snap)
        if _last:
            acted, still = grade(_last, adv)
            _score["advised"] += len(_last)
            _score["acted"] += len(acted)
            log(f"[soups] last advice: {len(acted)} of {len(_last)} acted on"
                + (f"; still open: {'; '.join(still)}" if still else "")
                + f" | so far {_score['acted']} of {_score['advised']} acted on")
        if adv:
            log("[soups] advice: " + " ".join(f"{i}) {t}" for i, (_k, t) in enumerate(adv, 1)))
        else:
            log("[soups] advice: nothing to suggest -- every known stove is busy, nothing waiting")
        _last = adv
    except Exception as e:                             # noqa: BLE001 -- a test must never break the run
        log(f"[soups] skipped: {e!r}")
