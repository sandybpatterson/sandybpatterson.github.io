"""Reads a number from a screen region showing one of this game's white-
box stock-count fonts (dark bold digit on a light box). NOT a general OCR
engine — built specifically for these fixed fonts, since Tesseract needs
a separate binary we don't have and easyocr needs heavy dependencies
(PyTorch) for a problem this constrained.

Validated 9/24 against all 10 digits of the original "stock_box" font
(Ham/Egg-style counts) gathered from real screenshots: every digit self-
matches at 1.000, the worst cross-digit confusion is 0.638 (between 3 and
2) — a threshold of 0.75 cleanly separates every real match from every
possible confusion.

**Multiple fonts, not one** — confirmed live 9/26: the crop-planting
bar's stock-count font is visually similar (same dark-digit-on-light-box
style) but does NOT reliably match the "stock_box" templates -- a real
"3" scored top match "8" at 0.85, with "3" not even in the top 4. This is
exactly the risk this file's own notes flagged months earlier ("there are
at least 2 visually distinct digit fonts... don't mix without validating
cross-font match first") turning out to need a THIRD font, not just two.
Rather than force one template set to cover both, `read_number()` now
takes a `font` name selecting which template set to match against.
"""
import os
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DIGIT_MATCH_THRESHOLD = 0.88  # aspect-preserving normalization (below) fixed a
                               # real distortion bug but made 8-vs-9 confusable
                               # up to 0.832 — set well above that
MIN_MARGIN = 0.06  # best match must also beat the runner-up by this much

# Each font is a directory under templates/ holding per-digit glyph crops,
# named either "{d}_glyph.png" (the original stock_box set) or plain
# "{d}.png" (newer sets, e.g. plant_bar, built directly from
# _isolate_glyphs output without the extra suffix). Not every font has
# all 10 digits gathered yet -- a digit missing from a set just never
# matches, which is the correct "degrade safely" behavior rather than an
# error, since _match_digit already requires both a high score AND a
# margin over the runner-up.
_FONT_DIRS = {
    "stock_box": "digits",
    "plant_bar": "plant_bar_digits",
}


def _load_font_templates(dirname):
    templates = {}
    folder = os.path.join(BASE_DIR, "templates", dirname)
    for d in "0123456789":
        for fname in (f"{d}_glyph.png", f"{d}.png"):
            path = os.path.join(folder, fname)
            if os.path.exists(path):
                templates[d] = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
                break
    return templates


_DIGIT_TEMPLATES = _load_font_templates(_FONT_DIRS["stock_box"])


def _isolate_glyphs(region_bgr, dark_threshold=120):
    """Threshold to binary (dark digit on light box -> white glyph on
    black), then segment by finding gaps of all-empty columns — NOT
    cv2.findContours, which fragments a single character into multiple
    disconnected pieces when a stroke has a thin joint (confirmed 9/24:
    it split a '7' into just its diagonal, losing the top bar). Column-
    gap segmentation treats each contiguous run of non-empty columns as
    one glyph, matching how the single-digit templates were built."""
    gray = cv2.cvtColor(region_bgr, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, dark_threshold, 255, cv2.THRESH_BINARY_INV)
    col_has_ink = np.any(binary > 0, axis=0)
    glyphs = []
    start = None
    for x, has_ink in enumerate(col_has_ink):
        if has_ink and start is None:
            start = x
        elif not has_ink and start is not None:
            glyphs.append((start, x))
            start = None
    if start is not None:
        glyphs.append((start, len(col_has_ink)))

    result = []
    for x1, x2 in glyphs:
        if x2 - x1 < 3:
            continue  # noise — too thin to be a real stroke
        col_slice = binary[:, x1:x2]
        # Drop only genuinely tiny speck components (shadows, box-corner
        # highlights — confirmed 9/24 one such speck was inflating a '4's
        # bounding box), then MERGE the bounding boxes of everything that
        # survives, rather than keeping just the single largest component.
        # A real digit like '7' can itself split into two components
        # after thresholding (its top bar and diagonal stroke connect
        # only through a thin anti-aliased joint) — picking "largest"
        # alone silently threw away the other real half.
        n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(col_slice)
        if n_labels <= 1:
            continue
        keep = [i for i in range(1, n_labels) if stats[i, cv2.CC_STAT_AREA] >= 12]
        if not keep:
            continue
        mask = np.isin(labels, keep).astype(np.uint8) * 255
        rows_with_ink = np.where(np.any(mask > 0, axis=1))[0]
        cols_with_ink = np.where(np.any(mask > 0, axis=0))[0]
        if len(rows_with_ink) == 0:
            continue
        y1, y2 = rows_with_ink[0], rows_with_ink[-1] + 1
        cx1, cx2 = cols_with_ink[0], cols_with_ink[-1] + 1
        if y2 - y1 < 8:
            continue  # noise — too short to be a real digit
        result.append(mask[y1:y2, cx1:cx2])
    return result


_CANVAS = 64  # fixed square canvas both templates and query glyphs get
              # normalized into, preserving aspect ratio (pad, don't
              # stretch) — needed because digit examples were gathered
              # from several different screenshots/zoom levels, so raw
              # pixel sizes aren't consistent even for the same digit.
              # Stretching to match sizes directly distorted narrow/tall
              # glyphs badly (confirmed 9/24 on a "4" read at 50x21 vs a
              # template built from a 48x37 source — very different
              # aspect ratio, matched at only 0.39 before this fix).


def _normalize(glyph):
    h, w = glyph.shape[:2]
    scale = (_CANVAS - 8) / max(h, w)
    new_w, new_h = max(1, int(w * scale)), max(1, int(h * scale))
    resized = cv2.resize(glyph, (new_w, new_h))
    canvas = np.zeros((_CANVAS, _CANVAS), dtype=np.uint8)
    y_off = (_CANVAS - new_h) // 2
    x_off = (_CANVAS - new_w) // 2
    canvas[y_off:y_off + new_h, x_off:x_off + new_w] = resized
    return canvas


_NORMALIZED_TEMPLATES_BY_FONT = {}


def _normalized_templates(font):
    if font not in _NORMALIZED_TEMPLATES_BY_FONT:
        raw = _DIGIT_TEMPLATES if font == "stock_box" else _load_font_templates(_FONT_DIRS[font])
        _NORMALIZED_TEMPLATES_BY_FONT[font] = {d: _normalize(t) for d, t in raw.items()}
    return _NORMALIZED_TEMPLATES_BY_FONT[font]


def _match_digit(glyph, font="stock_box"):
    """Returns (best_digit_char_or_None, confidence). Requires both a
    high absolute score AND a clear margin over the runner-up — some
    digit pairs (8/9) can both score high after aspect-preserving
    normalization, so a high score alone isn't enough to be confident.
    `font` selects which template set to match against -- see _FONT_DIRS;
    different UI elements in this game use visually similar but NOT
    interchangeable digit fonts, confirmed live 9/26."""
    norm_glyph = _normalize(glyph)
    scores = {}
    for digit, template in _normalized_templates(font).items():
        res = cv2.matchTemplate(template, norm_glyph, cv2.TM_CCOEFF_NORMED)
        scores[digit] = res[0][0]
    if not scores:
        return None, 0.0
    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    best_digit, best_score = ranked[0]
    runner_up_score = ranked[1][1] if len(ranked) > 1 else 0.0
    if best_score >= DIGIT_MATCH_THRESHOLD and (best_score - runner_up_score) >= MIN_MARGIN:
        return best_digit, best_score
    return None, best_score


def read_number(img, region, font="stock_box"):
    """region = (x1, y1, x2, y2) in the given full-screen image. `font`
    selects the digit template set (see _FONT_DIRS) -- default is the
    original Ham/Egg-style "stock_box" font; pass font="plant_bar" for
    the crop-planting bar's stock counts, which use a different font.
    Returns (int_or_None, per_digit_confidences). Returns None for the
    number if any single glyph couldn't be confidently read — never
    guesses."""
    x1, y1, x2, y2 = region
    crop = img[y1:y2, x1:x2]
    glyphs = _isolate_glyphs(crop)
    if not glyphs:
        return None, []
    digits = []
    confidences = []
    for glyph in glyphs:
        digit, conf = _match_digit(glyph, font=font)
        digits.append(digit)
        confidences.append(conf)
    if any(d is None for d in digits):
        return None, confidences
    return int("".join(digits)), confidences
