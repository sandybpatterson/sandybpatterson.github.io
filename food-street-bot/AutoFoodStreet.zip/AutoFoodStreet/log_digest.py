"""11/15 log digest (owner: "save tokens, cut spam, a log for a loop catcher"). Pure, used by afsd_tools.send_logs.

Turns the raw run_log lines of one send into a short file for Claude / Muse:
  * a header: time span, counts that matter (serves, queued, errors, storage full, restarts, test results),
    LOOPS (the same line LOOP_MIN+ times inside LOOP_WINDOW_SEC) and the top repeats;
  * the body with spam cut: a line whose SHAPE (text with the time stamp dropped and every number -> #) already
    showed KEEP times in the last WINDOW_SEC is hidden; the next shown line of that shape says "(+N hidden)".
    Lines that must never be hidden (IMPORTANT) always stay; traceback lines follow their parent line.
The raw run_log.txt on the PC is unchanged."""
import collections
import re

WINDOW_SEC = 600
KEEP = 3                       # lines of one shape shown per window
LOOP_WINDOW_SEC = 600
LOOP_MIN = 12
TOP_N = 8
IMPORTANT = re.compile(r"SERVED|HANDED IN|TRADED|LEARNED|REPLANTED|\bCUT\b|PASS|FAIL|Traceback|Error|error|EXPRESS.{0,30}(COMPLETE|MISSED|pays)"
                       r"|Start pressed|run_loop exited|\[hard restart\]|\[watchdog\]|\[no progress\]|\[auto restart\]"
                       r"|\[score\] \+\d+ credited|\[eta check\]|App closing|app launched|app exited|Relaunch|\[whoops\]|\[offline\]|\[update\]|alarm|gem dialog|buy with gems", re.I)
BORING = re.compile(r"--- cycle # (start|end)|=== event orders run (start|end)|CYCLE # SUMMARY")
_TS = re.compile(r"^\[(\d{4})-(\d\d)-(\d\d)T(\d\d):(\d\d):(\d\d)\] ")
COUNTS = (("served", re.compile(r"SERVED order|SERVE: served \d+ ready|\[score\] \+\d+ credited")),
          ("queued", re.compile(r"queued successfully|: queued \d|queued \d+ batch|queued x\d")),
          ("harvested", re.compile(r"[Hh]arvested [1-9]")),
          ("errors", re.compile(r"Traceback|failed \(ignored\)|[Ee]rror[: ]")),
          ("storage full", re.compile(r"storage is full|Storage is full")),
          ("pantry full", re.compile(r"Pantry is full|\[pantry full\]")),
          ("gem No", re.compile(r"gem.{0,40}\bNo\b|tapped No")),
          ("game restarts", re.compile(r"restart(ing)? the game|force_restart")),
          ("LDPlayer restarts", re.compile(r"\[hard restart\]|\[watchdog\].*restart")),
          ("tests PASS", re.compile(r"\[tests\] .*: PASS")),
          ("tests FAIL", re.compile(r"\[tests\] .*: FAIL")))


def stamp(line):
    """Seconds since 2000 (enough for ordering and gaps) or None for a line without a time stamp."""
    m = _TS.match(line)
    if not m:
        return None
    y, mo, d, h, mi, s = (int(v) for v in m.groups())
    return ((((y - 2000) * 372 + mo * 31 + d) * 24 + h) * 60 + mi) * 60 + s


def shape(line):
    return re.sub(r"\d+", "#", _TS.sub("", line, count=1)).strip()[:140]


def _hhmm(line):
    m = _TS.match(line)
    return f"{m.group(4)}:{m.group(5)}" if m else "?"


def loops(lines):
    """[(count, shape, first hh:mm, last hh:mm)] -- shapes that showed LOOP_MIN+ times inside one LOOP_WINDOW_SEC."""
    seen = collections.defaultdict(collections.deque)
    best = {}
    for ln in lines:
        t = stamp(ln)
        if t is None:
            continue
        s = shape(ln)
        if BORING.search(s):
            continue
        q = seen[s]
        q.append((t, ln))
        while q and t - q[0][0] > LOOP_WINDOW_SEC:
            q.popleft()
        if len(q) >= LOOP_MIN and len(q) > best.get(s, (0,))[0]:
            best[s] = (len(q), _hhmm(q[0][1]), _hhmm(ln))
    return sorted(((n, s, a, b) for s, (n, a, b) in best.items()), reverse=True)


def header(lines):
    timed = [ln for ln in lines if stamp(ln) is not None]
    out = [f"=== DIGEST {_hhmm(timed[0]) if timed else '?'}-{_hhmm(timed[-1]) if timed else '?'}, "
           f"{len(lines)} raw lines (spam hidden below: max {KEEP} of the same line per {WINDOW_SEC // 60} min) ==="]
    counts = [f"{name} {sum(1 for ln in lines if rx.search(ln))}" for name, rx in COUNTS]
    out.append("COUNTS: " + ", ".join(counts))
    lp = loops(lines)
    if lp:
        out.append(f"LOOPS (same line {LOOP_MIN}+ times in {LOOP_WINDOW_SEC // 60} min):")
        out += [f"  {n}x {a}-{b}  {s}" for n, s, a, b in lp[:TOP_N]]
    top = collections.Counter(shape(ln) for ln in timed if not BORING.search(shape(ln))).most_common(TOP_N)
    if top:
        out.append("TOP REPEATS: " + " | ".join(f"{n}x {s[:80]}" for s, n in top))
    out.append("=" * 60)
    return out


def body(lines):
    recent = collections.defaultdict(collections.deque)
    hidden = collections.Counter()
    out = []
    keep_tail = True                       # traceback / continuation lines follow their parent
    for ln in lines:
        t = stamp(ln)
        if t is None:
            if keep_tail:
                out.append(ln)
            continue
        s = shape(ln)
        q = recent[s]
        while q and t - q[0] > WINDOW_SEC:
            q.popleft()
        if len(q) >= KEEP and not IMPORTANT.search(ln):
            hidden[s] += 1
            keep_tail = False
            continue
        q.append(t)
        keep_tail = True
        if hidden[s]:
            ln = f"{ln}  (+{hidden[s]} like this hidden)"
            hidden[s] = 0
        out.append(ln)
    rest = [(n, s) for s, n in hidden.items() if n]
    if rest:
        out.append("[digest] hidden after their last shown line: " +
                   " | ".join(f"{n}x {s[:80]}" for n, s in sorted(rest, reverse=True)[:20]))
    return out


def digest(lines):
    """Raw lines (with or without newlines) -> digest lines (no newlines)."""
    raw = [ln.rstrip("\r\n") for ln in lines]
    raw = [ln for ln in raw if ln.strip()]
    return header(raw) + body(raw)
