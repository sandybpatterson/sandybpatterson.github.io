"""Reads the three Chef Challenge task rows (10/24, owner: "how are you going to do that" -- read first, cook later).

Each row (fixed spots, card left edge x 820, tops y 292 / 496 / 700) shows a title with progress "Produce and collect
this dish (0/5)", a timer pill "2h 13m 17s", chef-hat points and blue bags (white outlined digits -- the coin reader's
shapes), and the task's picture. Title -> Windows OCR on the title line only; timer, points and bags -> glyph shapes
(digits from templates/coin_digits, the d/h/m/s letters from templates/chef_letters, cut from the 10/23 test picture);
picture -> compared with the dish library (templates/dishes), unknown ones saved to templates/chef_icons/. READ-ONLY:
never taps anything (the rows also hold a trash button and a gem "Complete" button).
"""
import glob
import os
import re

import cv2
import numpy as np

import coin_digits as cd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
X0 = 820
ROW_TOPS = (292, 496, 700)
TIMER_DX = (195, 335)
POINTS_DX = (385, 445)
BAGS_DX = (490, 525)
ICON_BOX = (25, 60, 140, 178)                    # x1, y1, x2, y2 inside the row
ICON_DIR = os.path.join(BASE_DIR, "templates", "chef_icons")
UNIT_SEC = {"d": 86400, "h": 3600, "m": 60, "s": 1}

_LETTERS = {}
for _p in glob.glob(os.path.join(BASE_DIR, "templates", "chef_letters", "*.png")):
    _m = cv2.imread(_p, cv2.IMREAD_GRAYSCALE)
    if _m is not None:
        _LETTERS[os.path.basename(_p)[0]] = cd._feat(_m > 127)


def _glyph_text(crop):
    out = []
    for m in cd._glyphs(crop, 0, crop.shape[1]):
        h, w = m.shape
        if h < 10 or w < 4:
            continue                                 # the pill's rounded edge
        f = cd._feat(m)
        d, s = max(((d, float(f @ t)) for d, t in cd._TEMPLATES), key=lambda ds: ds[1]) if cd._TEMPLATES else (None, 0)
        if h < 18:
            out.append("m" if w >= 12 else "s")
            continue
        cands = {k: float(f @ v) for k, v in _LETTERS.items() if k in "dh"}
        k = max(cands, key=cands.get) if cands else None
        out.append(str(d) if (k is None or s >= cands[k]) and s >= 0.7 else (k or "?"))   # tall: digit vs d / h
    return "".join(out)


_ORDER = "dhms"


def _slash_as_one(text):
    """11/8: OCR read the takeout task's "(0/2)" as "(012)" -- the slash came out as a 1, so the count was never
    read and the takeout task never started. A 3-4 digit group in brackets whose middle digit is 1 is split there,
    only when the result makes sense (done <= total, total 1-50). Returns a match-like object or None."""
    m = re.search(r"\((\d{3,4})\)", text or "")
    if not m:
        return None
    d = m.group(1)
    for i in range(1, len(d) - 1):
        if d[i] == "1":
            a, b = int(d[:i]), int(d[i + 1:])
            if 0 < b <= 50 and a <= b:
                return _Pair(a, b)
    return None


class _Pair:
    def __init__(self, a, b):
        self._g = (str(a), str(b))

    def group(self, i):
        return self._g[i - 1]


def parse_time(text):
    """'4h53m18s' -> seconds. 10/24 (Muse): a lost letter -- '11h4634' (= 11h46m34s), '4h14h44m' (first h is a d):
    after a unit, letterless digits are 2-digit pairs for the next smaller units; a repeated unit bumps the earlier
    one up one step. No digits at all -> None."""
    toks = re.findall(r"(\d+)([dhms]?)", text or "")
    if not toks:
        return None
    units = [u for _, u in toks]
    for i in range(len(units) - 1):              # '4h14h44m': same unit twice -> the first is one bigger
        if units[i] and units[i] == units[i + 1] and _ORDER.index(units[i]) > 0:
            units[i] = _ORDER[_ORDER.index(units[i]) - 1]
    secs, last, ok = 0, None, False
    for (n, _), u in zip(toks, units):
        if u:
            secs += int(n) * UNIT_SEC[u]
            last, ok = u, True
            continue
        if last is None:
            continue
        i = _ORDER.index(last)
        for j in range(0, len(n), 2):            # '4634' after h -> 46 m, 34 s
            i += 1
            if i >= len(_ORDER):
                break
            secs += int(n[j:j + 2]) * UNIT_SEC[_ORDER[i]]
            last, ok = _ORDER[i], True
    return secs if ok else None


BAG_ICON_DX = (450, 492)                         # the bag picture left of its count


def _bag_color(crop):
    """10/24 (owner, via Muse: keep track of the bag COLOR): name of the bag picture's main colour."""
    try:
        hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
        m = (hsv[..., 1] > 110) & (hsv[..., 2] > 90)
        if m.sum() < 30:
            return "?"
        h = float(np.median(hsv[..., 0][m]))     # OpenCV hue 0-180
        for lim, name in ((8, "red"), (20, "orange"), (34, "gold"), (85, "green"), (128, "blue"), (160, "purple")):
            if h < lim:
                return name
        return "red"
    except Exception:                            # noqa: BLE001
        return "?"


def _number(crop):
    t = _glyph_text(crop)
    return int(t) if t.isdigit() else None


NAMED_DIR = os.path.join(BASE_DIR, "templates", "chef_icons_named")   # 10/24: task pictures named by hand
NAMED_MIN = 0.8
NOT_A_DISH = ("any", "orders", "takeout", "food_truck")   # 10/27: food truck = "Complete Food Truck orders"                 # cloche = any dish, clipboard = complete menu orders


def _dish(icon):
    """(name, score) of the best task picture: first the hand-named chef task pictures (the task art is drawn
    differently from the clipboard icons -- live 10/23 the dish library scored only 0.21-0.47), then the dish library.
    "any" / "orders" are kinds of task, not dishes -> (None, score)."""
    def norm(a):
        g = cv2.resize(a, (48, 48), interpolation=cv2.INTER_AREA).astype(np.float32)
        g = (g - g.mean()) / (g.std() + 1e-6)
        return g.ravel() / (np.linalg.norm(g) + 1e-6)
    v = norm(icon)
    best, bs = None, 0.0
    for p in glob.glob(os.path.join(NAMED_DIR, "*.png")):
        t = cv2.imread(p)
        if t is not None:
            s = float(v @ norm(t))
            if s > bs:
                best, bs = os.path.basename(p)[:-4].split("__")[0], s
    if bs >= NAMED_MIN:
        return (None if best in NOT_A_DISH else best), bs
    named_best = bs
    best, bs = None, 0.0
    for p in glob.glob(os.path.join(BASE_DIR, "templates", "dishes", "*.png")):
        t = cv2.imread(p)
        if t is None:
            continue
        s = float(v @ norm(t))
        if s > bs:
            best, bs = os.path.basename(p)[:-4].split("__")[0], s
    # 10/24: the clipboard dish pictures are a weak fallback (live: the takeout task read as "pastry 0.62") -- only a
    # strong match counts; otherwise the picture is saved for naming
    return (best, bs) if bs >= 0.8 else (None, max(bs, named_best))


def is_empty_slot(img, top):
    """10/31: a used-up task slot is a plain BROWN panel ("New task in 26 Minutes" + a green 'Get it now' gem button);
    a real task row is a grey card (BGR ~167,178,189 vs brown ~103,125,154 on the 10/27 picture). Pure."""
    b, g, r = img[top + 20:top + 60, 830:900].reshape(-1, 3).mean(0)
    return b < 135 and r - b > 30


def read_tasks(img, ocr=None):
    """[{n, title, done, total, secs, timer, points, bags, dish, dish_score, icon}] for the three rows."""
    if ocr is None:
        import popup_ocr
        ocr = popup_ocr.read_text
    rows = []
    for n, top in enumerate(ROW_TOPS, 1):
        if is_empty_slot(img, top):                  # 10/31: "New task in N Minutes [Get it now 3 gems]" -- not a task
            rows.append({"n": n, "kind": "empty", "title": "", "done": None, "total": None, "timer": "", "secs": None,
                         "points": None, "bags": None, "bag_color": "", "dish": None, "dish_score": 0.0,
                         "icon": np.zeros((0, 0, 3), np.uint8)})
            continue
        try:                                         # 10/24: dark letters only, black on white, x2 (live: "disb.@/4)")
            t = img[top + 8:top + 52, X0:X0 + 545]
            dark = (t.max(axis=2) < 110).astype(np.uint8)
            clean = cv2.copyMakeBorder(cv2.resize(np.where(dark, 0, 255).astype(np.uint8), None, fx=2, fy=2,
                                                  interpolation=cv2.INTER_CUBIC), 16, 16, 16, 16,
                                       cv2.BORDER_CONSTANT, value=255)
            title = (ocr(cv2.cvtColor(clean, cv2.COLOR_GRAY2BGR)) or "").strip(" -—|")
        except Exception:                            # noqa: BLE001
            title = ""
        fixed = re.sub(r"(?<=[(/])[@Oo]|[@Oo](?=\s*/)", "0", title)
        m = re.search(r"\(?\s*(\d+)\s*/\s*(\d+)\s*\)", fixed) or _slash_as_one(fixed)
        band = img[top + 55:top + 97]
        timer = _glyph_text(band[:, X0 + TIMER_DX[0]:X0 + TIMER_DX[1]])
        x1, y1, x2, y2 = ICON_BOX
        icon = img[top + y1:top + y2, X0 + x1:X0 + x2]
        dish, ds = _dish(icon)
        low = title.lower()
        kind = ("food_truck" if "truck" in low else "takeout" if "takeout" in low or "take" in low else "orders" if "menu" in low or "complete" in low
                else "dish" if "dish" in low or "dis" in low else "any")
        rows.append({"n": n, "kind": kind, "title": re.sub(r"\s*\(?\s*\S+\s*/\s*\d+\s*\).*", "", title).strip(),
                     "done": int(m.group(1)) if m else None, "total": int(m.group(2)) if m else None,
                     "timer": timer, "secs": parse_time(timer),
                     "points": _number(band[:, X0 + POINTS_DX[0]:X0 + POINTS_DX[1]]),
                     "bags": _number(band[:, X0 + BAGS_DX[0]:X0 + BAGS_DX[1]]),
                     "bag_color": _bag_color(band[:, X0 + BAG_ICON_DX[0]:X0 + BAG_ICON_DX[1]]),
                     "dish": dish, "dish_score": round(ds, 2), "icon": icon})
    return rows


CHALLENGE_TIMER = (700, 195, 950, 240)          # "4d 23h 47m" under the progress bar


CLAIM_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".chef_claim.json")
CLAIM_MAX_SEC = 3 * 3600


def claim_of(rows):
    """Pure (11/9 O.R.D.E.R.): {dish: still to make} from the unfinished "produce this dish" rows."""
    out = {}
    for r in rows:
        if r.get("kind") == "dish" and r.get("dish") and r.get("total") is not None and r.get("done") is not None:
            left = r["total"] - r["done"]
            if left > 0:
                out[r["dish"]] = out.get(r["dish"], 0) + left
    return out


def save_claim(rows):
    try:
        import json
        import time as _t
        with open(CLAIM_FILE, "w", encoding="utf-8") as fh:
            json.dump({"t": _t.time(), "claim": claim_of(rows)}, fh)
    except Exception:                                # noqa: BLE001
        pass


def load_claim(now=None):
    try:
        import json
        import time as _t
        with open(CLAIM_FILE, encoding="utf-8") as fh:
            d = json.load(fh)
        if (now or _t.time()) - d.get("t", 0) > CLAIM_MAX_SEC:
            return {}
        return dict(d.get("claim") or {})
    except Exception:                                # noqa: BLE001
        return {}


def _fmt_secs(secs):
    d, r = divmod(int(secs), 86400)
    h, r = divmod(r, 3600)
    m = r // 60
    return (f"{d}d" if d else "") + (f"{h}h" if d or h else "") + f"{m}m"


def log_tasks(img, log, ocr=None):
    """Logs one `[chef test] task N: ...` line per row; saves pictures it could not name. Never raises."""
    try:
        x1, y1, x2, y2 = CHALLENGE_TIMER
        t = _glyph_text(img[y1:y2, x1:x2])
        secs = parse_time(t) if t else None              # 11/10: show the PARSED time ('1h19h41m' is 1d19h41m)
        log(f"[chef test] challenge: {_fmt_secs(secs) if secs else (t or '?')} left"
            + (f" (read '{t}')" if secs and _fmt_secs(secs) != t else ""))
        rows = read_tasks(img, ocr)
    except Exception as e:                           # noqa: BLE001
        log(f"[chef test] task read failed: {e!r}")
        return []
    save_claim(rows)                                 # 11/9 O.R.D.E.R.: what Chef still has to make
    for r in rows:
        if r["kind"] == "empty":
            log(f"[chef test] task {r['n']}: empty slot -- a new task is on its way (never taps 'Get it now', it costs gems).")
            continue
        if r["dish"] is None and r["dish_score"] < NAMED_MIN and r["icon"].size:
            try:
                os.makedirs(ICON_DIR, exist_ok=True)
                import hashlib, time as _t                # 10/27: hash() changes every run -> md5; and the cap counted
                h = hashlib.md5(r["icon"][::8, ::8].tobytes()).hexdigest()[:8]   # old 10/24 files, so the folder
                path = os.path.join(ICON_DIR, f"{h}.png")                       # was full and new tasks were lost
                recent = [f for f in os.listdir(ICON_DIR)
                          if _t.time() - os.path.getmtime(os.path.join(ICON_DIR, f)) < 3 * 86400]
                if not os.path.exists(path) and len(recent) < 20:
                    cv2.imwrite(path, r["icon"])
            except Exception:                        # noqa: BLE001
                pass
        prog = f" ({r['done']}/{r['total']})" if r["done"] is not None else ""
        log(f"[chef test] task {r['n']}: {r['title'] or '?'}{prog} | "
            f"{r['dish'] or {'any': 'any dish', 'orders': 'menu orders', 'takeout': 'takeout orders', 'food_truck': 'food truck orders'}.get(r['kind']) if r['dish_score'] >= NAMED_MIN else r['dish'] or 'picture not known'}"
            f" ({r['dish_score']}) | {r['timer'] or '?'} left"
            + (f" ({r['secs']} s)" if r["secs"] else "") + f" | {r['points'] if r['points'] is not None else '?'} pts"
            f", {r['bags'] if r['bags'] is not None else '?'} {r['bag_color']} bag(s)")
        if r["timer"] and r["secs"] and not re.search(r"[ms]", r["timer"]) and len(r["timer"]) > 4:
            try:                                         # 10/24: "11h4634" -- m/s letters missed; keep the row to look at
                os.makedirs(ICON_DIR, exist_ok=True)
                top = ROW_TOPS[r["n"] - 1]
                p = os.path.join(ICON_DIR, f"timer_row{r['n']}.png")
                if not os.path.exists(p):
                    cv2.imwrite(p, img[top:top + 110, X0:X0 + 560])
            except Exception:                            # noqa: BLE001
                pass
    return rows
