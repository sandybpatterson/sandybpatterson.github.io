"""Schedule tab (11/14, owner: "visually perfect ... build that mock up into the bot ... see dates into the future").

Hidden until Settings > Experimental > "Schedule" is on. Two day columns (today + tomorrow by default; the ◀ ▶ arrows
move 1 day, "Today" jumps back, the date picker row shows the next 7 days). Job chips on the left are dragged onto a
day: a 1-hour block at the nearest half hour. Click a block: move it ±30 min, make it ±30 min longer / shorter, delete.

Engine (`tick`, every 20 s, only while "Run the schedule" is on -- off by default): at a block's START its job is
ticked (the bot presses Start itself when it is stopped -- owner 11/14); at its END the job is unticked (owner 11/14).
Specials: "Hold serving" turns hold serving on / off, "Stop bot" presses Stop. Expresses come first anyway (the run loop
never leaves an express). Blocks live in .schedule.json (gitignored), times in the PC's own clock.
"""
import json
import os
import time
import datetime as dt
import tkinter as tk

BASE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(BASE, ".schedule.json")
HOUR_PX = 44
DAY_W = 200
HEAD_H = 34
SNAP_SEC = 30 * 60
BLOCK_SEC = 60 * 60

# list row name -> (chip label, colour, app attribute of its tick variable)
JOBS = (("Food Club Event", "Food Club Event", "#c9a84c", "event_orders_var"),
        ("Hold serving", "⏸ Hold serving", "#9a9a9a", "hold_serve_var"),
        ("Auto Fulfill Orders", "Clipboard Orders", "#5b9bd5", "orders_var"),
        ("Prep work", "Prep work", "#4fc3a1", "prep_var"),
        ("Food Truck (street)", "Food Truck (street)", "#f0a040", "street_truck_var"),
        ("Chef Challenge", "Chef Challenge", "#b38ad9", "chef_challenge_var"),
        ("Tests", "Tests", "#7fa7c9", "tests_var"),
        ("Stop bot", "Stop bot", "#e06060", None))
COLOR = {j[0]: j[2] for j in JOBS}
LABEL = {j[0]: j[1] for j in JOBS}


def load():
    try:
        with open(FILE, encoding="utf-8") as fh:
            d = json.load(fh)
            if isinstance(d, dict):
                d.setdefault("blocks", [])
                return d
    except (OSError, ValueError):
        pass
    return {"blocks": [], "on": False}


def save(d):
    try:
        with open(FILE + ".tmp", "w", encoding="utf-8") as fh:
            json.dump(d, fh, indent=1)
        os.replace(FILE + ".tmp", FILE)
    except OSError:
        pass


def snap(t):
    return int(round(t / SNAP_SEC) * SNAP_SEC)


def events_between(blocks, last, now):
    """Pure: [(when, "start"|"end", block)] of block starts / ends in (last, now], oldest first."""
    out = []
    for b in blocks:
        if last < b["start"] <= now:
            out.append((b["start"], "start", b))
        if b.get("end") and last < b["end"] <= now:
            out.append((b["end"], "end", b))
    return sorted(out, key=lambda e: (e[0], e[1] == "start"))


def prune(blocks, now, keep_days=2):
    """Pure: drop blocks that ended more than keep_days ago."""
    return [b for b in blocks if (b.get("end") or b["start"]) > now - keep_days * 86400]


def fmt(t):
    return time.strftime("%I:%M %p", time.localtime(t)).lstrip("0")


# ---------------------------------------------------------------- engine
_last = [time.time()]


def tick(app, log):
    """Every 20 s from the window: carry out block starts / ends since the last tick."""
    now = time.time()
    last, _last[0] = _last[0], now
    d = load()
    if not d.get("on"):
        return
    for when, kind, b in events_between(d["blocks"], last, now):
        job = b["job"]
        if job == "Stop bot":
            if kind == "start" and app.running:
                log(f"[schedule] {fmt(when)}: 'Stop bot' block -- pressing Stop.")
                app.toggle_running()
            continue
        attr = next((j[3] for j in JOBS if j[0] == job), None)
        var = getattr(app, attr, None) if attr else None
        if var is None:
            continue
        on = kind == "start"
        var.set(on)
        log(f"[schedule] {fmt(when)}: {LABEL.get(job, job)} {'ticked' if on else 'unticked'} (block "
            f"{fmt(b['start'])}{' - ' + fmt(b['end']) if b.get('end') else ''}).")
        if on and job != "Hold serving" and not app.running:
            log("[schedule] the bot was stopped -- pressing Start.")
            app.toggle_running()
    d["blocks"] = prune(d["blocks"], now)
    save(d)


# ---------------------------------------------------------------- tab
class ScheduleTab:
    def __init__(self, app, parent, ui, log):
        self.app, self.ui, self.log = app, ui, log
        self.offset = 0                       # days from today shown in the first column
        self.drag = None
        top = tk.Frame(parent, bg=ui.BG)
        top.pack(fill="x", padx=14, pady=(4, 6))
        ui.button(top, "◀", lambda: self.move(-1), bg=ui.CARD).pack(side="left")
        ui.button(top, "Today", lambda: self.move(None), bg=ui.CARD).pack(side="left", padx=6)
        ui.button(top, "▶", lambda: self.move(1), bg=ui.CARD).pack(side="left")
        d = load()
        self.on_var = tk.BooleanVar(value=bool(d.get("on")))
        ui.Switch(top, self.on_var, command=self.set_on, bg=ui.BG).pack(side="right")
        tk.Label(top, text="Run the schedule", bg=ui.BG, fg=ui.TEXT, font=ui.font(10)).pack(side="right", padx=6)
        self.days_row = tk.Frame(top, bg=ui.BG)
        self.days_row.pack(side="left", padx=(14, 0))
        self.next_lab = tk.Label(parent, text="", bg=ui.BG, fg=ui.DIM, font=ui.font(9), anchor="w")
        self.next_lab.pack(fill="x", padx=16, pady=(0, 4))
        body = tk.Frame(parent, bg=ui.BG)
        body.pack(fill="both", expand=True, padx=14, pady=(0, 10))
        left = ui.card(body)
        left.pack(side="left", fill="y", padx=(0, 10))
        tk.Label(left, text="Drag a job onto the calendar", bg=ui.CARD, fg=ui.GOLD, font=ui.font(10, True)).pack(
            anchor="w", padx=10, pady=(10, 6))
        for name, label, col, _a in JOBS:
            chip = tk.Label(left, text="●  " + label, bg=ui.mix(ui.CARD, "#ffffff", 0.06), fg=ui.TEXT,
                            font=ui.font(10), anchor="w", padx=10, pady=6, cursor="fleur")
            chip.pack(fill="x", padx=10, pady=3)
            chip.bind("<ButtonPress-1>", lambda e, n=name: self.drag_start(n))
            chip.bind("<ButtonRelease-1>", self.drag_drop)
            tk.Frame(chip, bg=col, width=4).place(x=0, y=0, relheight=1)
        tk.Label(left, text="A block ticks its job when it starts and unticks it when it ends. If the bot is stopped "
                 "when a block starts, it presses Start. Click a block to change or delete it.", bg=ui.CARD,
                 fg=ui.DIM, font=ui.font(8), wraplength=200, justify="left").pack(anchor="w", padx=10, pady=10)
        wrap = tk.Frame(body, bg=ui.BG)
        wrap.pack(side="left", fill="both", expand=True)
        self.cv = tk.Canvas(wrap, bg="#262626", highlightthickness=0)
        sb = getattr(ui, "ThinScrollbar", tk.Scrollbar)(wrap, command=self.cv.yview)
        self.cv.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.cv.pack(side="left", fill="both", expand=True)
        self.cv.bind("<Configure>", lambda e: self.draw())
        self.cv.bind("<Enter>", lambda e: self.cv.bind_all("<MouseWheel>", self._wheel))
        self.cv.bind("<Leave>", lambda e: self.cv.unbind_all("<MouseWheel>"))
        self.draw()
        self.cv.after(300, lambda: self.cv.yview_moveto(max(0.0, (time.localtime().tm_hour - 2) / 24.0)))
        self._poll()

    def _wheel(self, e):
        self.cv.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1), "units")

    def set_on(self):
        d = load()
        d["on"] = bool(self.on_var.get())
        save(d)
        _last[0] = time.time()                 # never replay blocks that started while it was off
        self.log(f"[schedule] owner turned the schedule {'ON' if d['on'] else 'OFF'}.")
        self.draw()

    def move(self, n):
        self.offset = 0 if n is None else self.offset + n
        self.draw()

    def day0(self, i):
        d = dt.date.today() + dt.timedelta(days=self.offset + i)
        return d, time.mktime(d.timetuple())

    def ncols(self):
        return max(2, min(3, (self.cv.winfo_width() - 60) // DAY_W))

    def draw(self):
        ui, cv = self.ui, self.cv
        cv.delete("all")
        for w in self.days_row.winfo_children():
            w.destroy()
        for i in range(7):                          # quick date picker: the next 7 days
            d = dt.date.today() + dt.timedelta(days=i)
            sel = i == self.offset
            b = tk.Label(self.days_row, text=d.strftime("%a %d"), bg=ui.GOLD if sel else ui.CARD,
                         fg="#1e1e1e" if sel else ui.TEXT, font=ui.font(9), padx=8, pady=3, cursor="hand2")
            b.pack(side="left", padx=2)
            b.bind("<Button-1>", lambda e, k=i: self.move_to(k))
        cols = self.ncols()
        colw = max(150, (cv.winfo_width() - 60) // cols)
        h = HEAD_H + 24 * HOUR_PX
        cv.configure(scrollregion=(0, 0, 60 + cols * colw, h))
        for hr in range(24):
            y = HEAD_H + hr * HOUR_PX
            cv.create_text(52, y + 2, text=time.strftime("%I %p", time.strptime(str(hr), "%H")).lstrip("0"),
                           anchor="ne", fill="#8a8a8a", font=("Segoe UI", 8))
            cv.create_line(60, y, 60 + cols * colw, y, fill="#2f2f2f")
        blocks = load()["blocks"]
        now = time.time()
        for i in range(cols):
            d, t0 = self.day0(i)
            x0 = 60 + i * colw
            cv.create_line(x0, 0, x0, h, fill="#3a3a3a")
            label = ("Today · " if d == dt.date.today() else
                     "Tomorrow · " if d == dt.date.today() + dt.timedelta(days=1) else "") + d.strftime("%a %b %d")
            cv.create_text(x0 + colw / 2, HEAD_H / 2, text=label, fill=ui.GOLD, font=("Segoe UI", 10, "bold"))
            for b in blocks:
                s, e = b["start"], b.get("end") or b["start"] + BLOCK_SEC
                if e <= t0 or s >= t0 + 86400:
                    continue
                y1 = HEAD_H + max(0, s - t0) / 3600 * HOUR_PX
                y2 = HEAD_H + min(86400, e - t0) / 3600 * HOUR_PX
                tag = f"b{b['id']}"
                cv.create_rectangle(x0 + 6, y1 + 1, x0 + colw - 6, max(y1 + 18, y2 - 1),
                                    fill=COLOR.get(b["job"], "#888"), outline="", tags=(tag,))
                cv.create_text(x0 + 14, y1 + 5, anchor="nw", fill="#141414", font=("Segoe UI", 9, "bold"),
                               text=f"{LABEL.get(b['job'], b['job'])}\n{fmt(s)} – {fmt(e)}", width=colw - 24, tags=(tag,))
                cv.tag_bind(tag, "<Button-1>", lambda ev, bid=b["id"]: self.block_menu(ev, bid))
            if t0 <= now < t0 + 86400:
                y = HEAD_H + (now - t0) / 3600 * HOUR_PX
                cv.create_line(x0, y, x0 + colw, y, fill="#e05050", width=2)
        self.colw = colw
        self.next_text()

    def move_to(self, k):
        self.offset = k
        self.draw()

    def next_text(self):
        d = load()
        up = sorted((b for b in d["blocks"] if b["start"] > time.time()), key=lambda b: b["start"])
        txt = (f"Next: {LABEL.get(up[0]['job'], up[0]['job'])} at {fmt(up[0]['start'])} "
               f"{time.strftime('%a', time.localtime(up[0]['start']))}") if up else "Nothing scheduled"
        self.next_lab.config(text=txt + ("" if d.get("on") else "  ·  schedule is OFF"))

    def drag_start(self, job):
        self.drag = job
        self.cv.config(cursor="plus")

    def drag_drop(self, e):
        job, self.drag = self.drag, None
        self.cv.config(cursor="")
        if not job:
            return
        x = e.x_root - self.cv.winfo_rootx()
        y = e.y_root - self.cv.winfo_rooty()
        if not (0 <= x <= self.cv.winfo_width() and 0 <= y <= self.cv.winfo_height()):
            return
        y = self.cv.canvasy(y)
        col = int((self.cv.canvasx(x) - 60) // self.colw)
        if col < 0 or col >= self.ncols() or y < HEAD_H:
            return
        _d, t0 = self.day0(col)
        start = snap(t0 + (y - HEAD_H) / HOUR_PX * 3600)
        d = load()
        b = {"id": int(time.time() * 1000) % 10 ** 9, "job": job, "start": start,
             "end": None if job == "Stop bot" else start + BLOCK_SEC}
        d["blocks"].append(b)
        save(d)
        self.log(f"[schedule] added {LABEL.get(job, job)} at {fmt(start)} {time.strftime('%a %b %d', time.localtime(start))}.")
        self.draw()

    def block_menu(self, ev, bid):
        m = tk.Menu(self.cv, tearoff=0, bg="#2a2a2a", fg="#e8e8e8", activebackground="#8a6f1e")
        for text, fn in (("Start 30 min earlier", lambda: self.edit(bid, -SNAP_SEC, -SNAP_SEC)),
                         ("Start 30 min later", lambda: self.edit(bid, SNAP_SEC, SNAP_SEC)),
                         ("30 min longer", lambda: self.edit(bid, 0, SNAP_SEC)),
                         ("30 min shorter", lambda: self.edit(bid, 0, -SNAP_SEC)),
                         ("1 hour longer", lambda: self.edit(bid, 0, 3600))):
            m.add_command(label=text, command=fn)
        m.add_separator()
        m.add_command(label="Delete", command=lambda: self.delete(bid))
        m.tk_popup(ev.x_root, ev.y_root)

    def edit(self, bid, ds, de):
        d = load()
        for b in d["blocks"]:
            if b["id"] == bid:
                b["start"] += ds
                if b.get("end"):
                    b["end"] = max(b["start"] + SNAP_SEC, b["end"] + de)
        save(d)
        self.draw()

    def delete(self, bid):
        d = load()
        d["blocks"] = [b for b in d["blocks"] if b["id"] != bid]
        save(d)
        self.draw()

    def _poll(self):
        try:
            tick(self.app, self.log)
            self.draw()
        except Exception as ex:                       # noqa: BLE001
            self.log(f"[schedule] tick failed: {ex!r}")
        self.cv.after(20000, self._poll)
