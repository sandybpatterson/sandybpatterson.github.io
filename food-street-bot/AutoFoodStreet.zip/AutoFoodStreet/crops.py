"""11/15 C.R.O.P.S. (Crop-farmer Route Over the Plots, Scouted). Owner's picture of the whole event area
(templates/crops/owner_event_area.jpg): crop plots in the middle, the Food Club STORAGE BOX (red barn, grey roof) left
of the clubs kiosk, the CROP FARMER on the far left under the fountain. The box looks the same every season; the
farmer does not -- so the bot finds the BOX by picture and taps the farmer at a fixed offset from it.
Offsets are in the owner picture's pixels (box centre (367,217), farmer (140,330)) and scale with the match size."""
import os
import time
import cv2

HERE = os.path.dirname(os.path.abspath(__file__))
BOX = os.path.join(HERE, "templates", "crops", "storage_box.png")
BOX_MIN = 0.75                       # colour match; grey matching gave 0.62-0.67 on unrelated screens
SCALES = (0.6, 0.7, 0.8, 0.9, 1.0, 1.15, 1.3, 1.5, 1.7, 1.9, 2.1, 2.4, 2.7, 3.0)   # 11/15: the game sat zoomed in at 2.7
EDGE = 220                           # farmer spot closer than this to an edge -> centre it first
FARMER_OFFSET = (-227, 113)          # farmer tap point minus box centre, owner-picture pixels at scale 1.0
_tpl = []


def _box():
    if not _tpl:
        t = cv2.imread(BOX)
        if t is not None:
            _tpl.append(t)
    return _tpl[0] if _tpl else None


def find_box(img):
    """(score, (cx, cy), scale) of the storage box, best over SCALES; score 0 when none."""
    t = _box()
    if t is None or img is None:
        return 0.0, None, None
    g = img if img.ndim == 3 else cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    g = cv2.resize(g, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)       # half size: fast enough to run often
    best = (0.0, None, None)
    for s in SCALES:
        tt = cv2.resize(t, None, fx=s * 0.5, fy=s * 0.5, interpolation=cv2.INTER_AREA)
        if tt.shape[0] >= g.shape[0] or tt.shape[1] >= g.shape[1]:
            continue
        r = cv2.matchTemplate(g, tt, cv2.TM_CCOEFF_NORMED)
        _mn, mx, _l, loc = cv2.minMaxLoc(r)
        if mx > best[0]:
            best = (float(mx), ((loc[0] + tt.shape[1] / 2) * 2, (loc[1] + tt.shape[0] / 2) * 2), s)
    if best[1] is not None:
        best = (best[0], (int(round(best[1][0])), int(round(best[1][1]))), best[2])
    return best


# 11/17: the farmer's own stall -- this season's sacks + girl (templates/crops/farmer_sacks.png, cut from
# tests/20261116_185723_crops_nobox.jpg). On 11/16 the farmer was IN VIEW in 17 of 27 failed walks (0.80-0.98; the
# storage box was cut off at the screen top), every other crops picture <= 0.47. Changes every season: recut then.
SACKS = os.path.join(HERE, "templates", "crops", "farmer_sacks.png")
SACKS_MIN = 0.7
SACK_SCALES = (0.7, 0.85, 1.0, 1.2, 1.4)
SACK_TAPS = ((0, -20), (45, -165))      # middle sack, then the farmer herself (offsets at scale 1.0)
_sacks = []


def find_sacks(img):
    """(score, (cx, cy), scale) of the farmer's sacks; score 0 when none."""
    if not _sacks:
        t = cv2.imread(SACKS)
        if t is None:
            return 0.0, None, None
        _sacks.append(t)
    t = _sacks[0]
    if img is None:
        return 0.0, None, None
    g = cv2.resize(img, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
    best = (0.0, None, None)
    for s in SACK_SCALES:
        tt = cv2.resize(t, None, fx=s * 0.5, fy=s * 0.5, interpolation=cv2.INTER_AREA)
        if tt.shape[0] >= g.shape[0] or tt.shape[1] >= g.shape[1]:
            continue
        _mn, mx, _l, loc = cv2.minMaxLoc(cv2.matchTemplate(g, tt, cv2.TM_CCOEFF_NORMED))
        if mx > best[0]:
            best = (float(mx), (int((loc[0] + tt.shape[1] / 2) * 2), int((loc[1] + tt.shape[0] / 2) * 2)), s)
    return best


def sack_taps(xy, scale, size=(1600, 900)):
    """Pure: tap points for the farmer at a sacks match, only those safely on the screen (off the HUD / icon bars)."""
    out = []
    for dx, dy in SACK_TAPS:
        x, y = int(xy[0] + dx * scale), int(xy[1] + dy * scale)
        if 60 <= x <= size[0] - 180 and 120 <= y <= size[1] - 130:
            out.append((x, y))
    return out


def farmer_spot(box_xy, scale, size=(1600, 900)):
    """Pure: where to tap the farmer for a box at box_xy matched at `scale`; None when off the screen."""
    if box_xy is None or not scale:
        return None
    x = int(box_xy[0] + FARMER_OFFSET[0] * scale)
    y = int(box_xy[1] + FARMER_OFFSET[1] * scale)
    if not (20 <= x <= size[0] - 20 and 100 <= y <= size[1] - 80):
        return None
    return x, y


def farmer_point(box_xy, scale):
    """Pure (11/16): the farmer's spot for a box match, on or OFF the screen (for centring)."""
    return int(box_xy[0] + FARMER_OFFSET[0] * scale), int(box_xy[1] + FARMER_OFFSET[1] * scale)


SEARCH_DRAGS = (((800, 330), (800, 530)), ((500, 450), (800, 450))) * 3   # 11/16 (Muse): up, then left, alternating
FAIL_RETRY_SEC = 5 * 60          # a failed walk to the farmer is tried again after 5 min (not the full 30)


def _save_pic(img, tag):
    try:
        import cv2
        d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "tests")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, time.strftime("%Y%m%d_%H%M%S") + f"_{tag}.jpg")
        cv2.imwrite(p, img, [cv2.IMWRITE_JPEG_QUALITY, 70])
        return p
    except Exception:                                   # noqa: BLE001
        return "none"


def is_farmer_title(title):
    t = (title or "").lower()
    return "farmer" in t or "crop" in t


# ---- step 3 (owner 11/15: "yes"): trade crops at the farmer when Food Club storage is nearly full ----------------
LIVE = True                 # trade when storage is nearly full (Food Club job); False = the Tests route only
NEAR_FULL_FREE = 4          # trade when storage has this many free spaces or fewer
KEEP_AFTER = 4              # owner's event rule: keep 4 of each crop in storage
GAP_SEC = 30 * 60           # one farmer visit per 30 min (his trades are slow -- ~1 per hour per card)
_state = {"last": 0.0}


def swap_pick(cards):
    """Pure: which card to trade. cards = [(bx, by, [ingredient dicts {have, need, color}])]. A card qualifies when
    it takes ONE ingredient, has a readable count, and trading still leaves KEEP_AFTER of it; the card whose
    ingredient we hold the most of wins (that pile frees the most room). Returns (bx, by, have, need) or None."""
    best = None
    for bx, by, ing in cards:
        if len(ing) != 1:
            continue
        i = ing[0]
        h, n = i.get("have"), i.get("need")
        if h is None or not n or i.get("color") == "red" or h - n < KEEP_AFTER:
            continue
        if best is None or h > best[2]:
            best = (bx, by, h, n)
    return best


def due(used_cap, now, express):
    """Pure: time for a farmer trade?"""
    if not LIVE or express or not used_cap:
        return False
    used, cap = used_cap
    return cap - used <= NEAR_FULL_FREE and now - _state["last"] >= GAP_SEC


def _clear_view(stop):
    """11/15 (owner): travelling to a crop plot leaves the plot's plant bar open, and a drag with it open does
    nothing useful -- close the bar (and any panel) before looking or dragging."""
    import adb_helper
    import event_orders as eo
    import garden_check
    import order_fulfill as of
    for _ in range(2):
        shot = adb_helper.screenshot()
        if shot is not None and eo.bar_is_open(shot):
            garden_check.close_plant_bar(stop)
            of.interruptible_sleep(0.6, stop)
            continue
        break
    of.close_any_open_panel(quiet=True, thorough=True)


def go_to_farmer(stop, log, pic=None):
    """Event plots -> drags up until the storage box shows -> tap the farmer. Returns (panel_img, title, why)."""
    import adb_helper
    import order_fulfill as of
    import prep_engine as pe
    import event_orders as eo
    import tests_job
    from tests_job import CROPS_SMALL_UP
    if not tests_job._reach_event_plots(stop):
        of.close_any_open_panel(quiet=True, thorough=True)
        return None, "", "no board item led to the event crop plots"
    _clear_view(stop)
    of.interruptible_sleep(0.8, stop)
    shot = adb_helper.screenshot()
    score, xy, sc = find_box(shot)
    drags = 0
    sack_tried = False
    while True:                                        # 11/17: the farmer himself in view -> tap him, no box needed
        ss, sxy, ssc = (0.0, None, None) if sack_tried else find_sacks(shot)
        taps = sack_taps(sxy, ssc, (shot.shape[1], shot.shape[0])) if ss >= SACKS_MIN else []
        sack_tried = sack_tried or bool(taps)
        for spot in taps:
            adb_helper.tap(*spot)
            of.interruptible_sleep(1.6, stop)
            panel = adb_helper.screenshot()
            title = pe._panel_title(panel) or ""
            if is_farmer_title(title):
                log(f"[crops] Crop Farmer open: his sacks seen ({ss:.2f}, scale {ssc}) at {sxy} after {drags} drag(s), "
                    f"tapped {spot}, title '{title}'")
                return panel, title, ""
            no, _c = of.find_no_button(panel)
            if no is not None:
                adb_helper.tap(*no)
            of.close_any_open_panel(quiet=True, thorough=True)
            log(f"[crops] tapped the farmer at {spot} (sacks {ss:.2f}) but it opened '{title or 'nothing'}'" + (
                f" -- picture {pic(panel, 'crops_sack_tap')}" if pic else ""))
            of.interruptible_sleep(0.6, stop)
            shot = adb_helper.screenshot()
        if score >= BOX_MIN or drags >= len(SEARCH_DRAGS):
            break
        if eo.bar_is_open(shot):
            _clear_view(stop)
        a, b = SEARCH_DRAGS[drags]
        adb_helper.swipe(a[0], a[1], b[0], b[1], 700)
        drags += 1
        of.interruptible_sleep(1.3, stop)
        shot = adb_helper.screenshot()
        score, xy, sc = find_box(shot)
    if score < BOX_MIN:
        return None, "", f"storage box not found after {drags} drags (best {score:.2f})" + (
            f" -- picture {pic(shot, 'crops_nobox')}" if pic else "")
    log(f"[crops] storage box found ({score:.2f}, scale {sc}) at {xy} after {drags} drag(s)")
    spot = farmer_spot(xy, sc, (shot.shape[1], shot.shape[0]))
    raw = farmer_point(xy, sc)
    if spot is None or not (EDGE <= spot[0] <= 1600 - EDGE and 150 <= spot[1] <= 900 - EDGE):
        # 11/15: zoomed in, the farmer sits at (or past) the screen edge -- drag him toward the middle, then find the
        # box again (11/16, Muse: also when he is OFF the screen)
        dx = max(-600, min(600, 800 - raw[0]))
        dy = max(-350, min(350, 450 - raw[1]))
        adb_helper.swipe(800 - dx // 2, 450 - dy // 2, 800 + dx // 2, 450 + dy // 2, 900)
        of.interruptible_sleep(1.3, stop)
        shot = adb_helper.screenshot()
        score, xy, sc = find_box(shot)
        if score < BOX_MIN:
            return None, "", f"lost the storage box after centring the farmer (best {score:.2f})" + (
                f" -- picture {pic(shot, 'crops_nobox')}" if pic else "")
        spot = farmer_spot(xy, sc, (shot.shape[1], shot.shape[0]))
    if spot is None:
        return None, "", f"storage box at {xy} (scale {sc}) but the farmer spot is still off the screen" + (
            f" -- picture {pic(shot, 'crops_offscreen')}" if pic else "")
    adb_helper.tap(*spot)
    of.interruptible_sleep(1.6, stop)
    panel = adb_helper.screenshot()
    title = pe._panel_title(panel) or ""
    if not is_farmer_title(title):
        no, _c = of.find_no_button(panel)
        if no is not None:
            adb_helper.tap(*no)
        of.close_any_open_panel(quiet=True, thorough=True)
        return None, title, f"tapped {spot} next to the box ({score:.2f}) but it opened '{title or 'nothing'}'" + (
            f" -- picture {pic(panel, 'crops_farmer_tap')}" if pic else "")
    log(f"[crops] Crop Farmer open: box {score:.2f} at {xy} (scale {sc}), tapped {spot}, title '{title}'")
    return panel, title, ""


def swap(stop, log):
    """Food Club storage nearly full -> walk to the Crop Farmer and trade ONE card (3 of a crop we hold plenty of ->
    1 of another), never a red card, never gems. Returns a short result."""
    import adb_helper
    import event_orders as eo
    import order_fulfill as of
    _state["last"] = time.time()
    panel, _title, why = go_to_farmer(stop, log, pic=_save_pic)
    if panel is None:
        _state["last"] = time.time() - GAP_SEC + FAIL_RETRY_SEC     # 11/16 (Muse): retry sooner after a failed walk
        log(f"[crops] no farmer trade: {why}")
        return "no_farmer"
    try:
        cards = [(bx, by, eo._panel_ingredients(panel, bx, by)) for bx, by, *_ in (eo.station_buttons(panel) or [])]
        pick = swap_pick(cards)
        if pick is None:
            log("[crops] storage nearly full, but no farmer card has a crop we hold enough of: "
                + "; ".join(f"x={bx} " + ",".join(f"{i['have']}/{i['need']}" for i in ing) for bx, by, ing in cards))
            return "nothing"
        bx, by, h, n = pick
        empty0 = eo.count_empty_slots(panel)
        adb_helper.tap(bx, by)
        of.interruptible_sleep(1.2, stop)
        img = adb_helper.screenshot()
        no, _c = of.find_no_button(img)
        if no is not None:
            adb_helper.tap(*no)
            log("[crops] the farmer card asked for gems -- declined, no trade.")
            return "gems"
        ok = eo.count_empty_slots(img) < empty0
        log(f"[crops] {'TRADED' if ok else 'tapped (no change seen)'} at the Crop Farmer: card x={bx} takes "
            f"{n} of a crop we had {h} of -- frees {n - 1} storage space(s) when collected.")
        return "traded" if ok else "unsure"
    finally:
        of.close_any_open_panel(quiet=True, thorough=True)
