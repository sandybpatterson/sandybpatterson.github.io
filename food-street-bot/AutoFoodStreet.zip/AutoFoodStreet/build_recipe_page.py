"""Builds recipe_reference/index.html -- a local reference page of the normal (clipboard-menu)
dishes with big panel art, the small Orders-board icon, cook time and ingredients (with icons).
Run again any time (python build_recipe_page.py) after the dish/ingredient libraries change.
Data below is compiled from the project notes; '?' / "not recorded" = not captured yet."""
import os
import shutil
import html

BASE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(BASE, "recipe_reference")
IMG = os.path.join(OUT, "img")

# ---------------------------------------------------------------------------
# The data now lives in recipes.json (the recipe book, read by recipe_book.py). This page is just a
# view of it. Edit recipes.json, then re-run this script.
# ---------------------------------------------------------------------------
import recipe_book

_BOOK = recipe_book.load(force=True)
_ALIAS_NAMES = {"fish": ("Fish", "sea"), "seaweed": ("Seaweed", "sea"),
                "chicken": ("Chicken", "animal"), "sugar": ("Sugar", "made")}
ING = {}
for _k, _it in _BOOK["items"].items():
    ING[_k] = (_it["name"], "made" if _it["kind"] == "dish" else _it["kind"])
ING.update(_ALIAS_NAMES)
ING["cabbage"] = ("Cabbage / Greens", "crop")
ING["ham"] = ("Ham / Pork", "animal")

STATION_ORDER = ["Dairy", "Smoothie Bar", "Soup Station", "Breakfast Stove", "Barista Coffee", "Cake Oven",
                 "Bread Oven", "Pasta Counter", "Pizza Oven", "Grill", "Wok Station", "Salad Station",
                 "Sushi Bar", "Pie Oven", "Chicken Coop", "Cow Shed", "Pig Pen", "Fisherman's Boat",
                 "Fisherman's Lighthouse"]


def fmt_secs(sec):
    sec = int(round(sec))
    if sec <= 0:
        return "0"
    h, r = divmod(sec, 3600)
    m, sc = divmod(r, 60)
    parts = []
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    if sc and not h:
        parts.append(f"{sc}s")
    return " ".join(parts)


def scratch(key):
    return recipe_book.scratch(key)


def _build_stations():
    groups = {}
    for key, it in _BOOK["items"].items():
        if not it.get("show_on_page", True):
            continue
        ct = "?" if it["cook_sec"] is None else fmt_secs(it["cook_sec"])
        ings = [(ik, cnt if it.get("counts_confirmed") else None) for ik, cnt in it["ingredients"]]
        groups.setdefault(it["station"], []).append((key, it["name"], ct, ings, it.get("note", "")))
    ordered = [st for st in STATION_ORDER if st in groups] + [st for st in groups if st not in STATION_ORDER]
    return [(st, groups[st]) for st in ordered]


STATIONS = _build_stations()


def copy_img(src, dst_name):
    """Returns the picture as a base64 data URI so the page is ONE self-contained file.
    Big pictures are re-encoded as JPEG and small ones as optimised PNG to keep the file small
    (a small file also opens in viewers that refuse very large pages)."""
    import base64
    import cv2
    if not os.path.exists(src):
        return None
    img = cv2.imread(src, cv2.IMREAD_UNCHANGED)
    if img is None:
        return None
    if dst_name.startswith("big_"):
        ok, buf = cv2.imencode(".jpg", img[:, :, :3] if img.ndim == 3 else img, [cv2.IMWRITE_JPEG_QUALITY, 82])
        mime = "image/jpeg"
    else:
        ok, buf = cv2.imencode(".png", img, [cv2.IMWRITE_PNG_COMPRESSION, 9])
        mime = "image/png"
    return f"data:{mime};base64," + base64.b64encode(buf.tobytes()).decode("ascii")


def main():
    if os.path.isdir(IMG):
        shutil.rmtree(IMG)          # old versions kept pictures in a folder
    os.makedirs(OUT, exist_ok=True)
    ing_img = {}
    for k in ING:
        ing_img[k] = (copy_img(os.path.join(BASE, "templates", "ingredients", k + ".png"), f"ing_{k}.png")
                      or copy_img(os.path.join(BASE, "templates", "recipe_page_extra", k + ".png"), f"ing_{k}.png"))
    sections = []
    for station, dishes in STATIONS:
        cards = []
        for key, name, t, ings, note in dishes:
            big = copy_img(os.path.join(BASE, "templates", "dish_panels", key + ".png"), f"big_{key}.png")
            small = copy_img(os.path.join(BASE, "templates", "dishes", key + ".png"), f"small_{key}.png")
            li = []
            sc_p, sc_s, sc_u = scratch(key)
            for ik, cnt in ings:
                nm, kind = ING.get(ik, (ik, "made"))
                img = ing_img.get(ik)
                pic = f'<img src="{img}" alt="">' if img else '<span class="noimg">?</span>'
                ip, _is, iu = scratch(ik)
                itime = f'<em class="it">{"&ge;" if iu else ""}{fmt_secs(ip)}</em>' if ip or iu else ''
                li.append(f'<li class="k-{kind}">{pic}<span>{html.escape(nm)}' +
                          (f' <b>x{cnt}</b>' if cnt else '') + f'</span>{itime}</li>')
            ing_html = "<ul>" + "".join(li) + "</ul>" if li else '<p class="muted">Ingredients not recorded yet.</p>'
            big_html = f'<img class="big" src="{big}" alt="">' if big else '<div class="big nobig">no big picture yet</div>'
            small_html = f'<img class="small" src="{small}" alt="small board icon" title="small icon on the Orders board">' if small else ""
            cards.append(f'''<article class="dish" data-name="{html.escape(name.lower())}">
  {big_html}
  <div class="info"><h3>{small_html}<span>{html.escape(name)}</span></h3>
  <p class="time">Cook time: <b>{html.escape(t)}</b></p>
  <p class="time scratch" title="How long it takes if you have none of the ingredients. All at once = everything that can be made at the same time is; one at a time = every batch back to back.">From scratch: <b>{"&ge;" if sc_u else ""}{fmt_secs(sc_p)}</b> all at once &middot; <b>{"&ge;" if sc_u else ""}{fmt_secs(sc_s)}</b> one at a time</p>{ing_html}
  {f'<p class="muted note">{html.escape(note)}</p>' if note else ''}</div></article>''')
        sections.append(f'<section data-station="{html.escape(station.lower())}"><h2>{html.escape(station)}</h2><div class="grid">{"".join(cards)}</div></section>')
    page = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Food Street Recipes</title>
<style>
:root {{ --bg:#faf6ee; --card:#fff; --text:#2a2118; --muted:#7a6b58; --line:#e6dccb; --accent:#c8791a;
  --crop:#2f8f3e; --fruit:#c0392b; --animal:#8a5a2b; --made:#6b4fb3; --sea:#1f7fa3; }}
@media (prefers-color-scheme: dark) {{ :root {{ --bg:#1d1913; --card:#2a241b; --text:#f1e9da; --muted:#b3a58f; --line:#41392b; --accent:#f0a23b; }} }}
* {{ box-sizing:border-box; }}
body {{ margin:0; background:var(--bg); color:var(--text); font:15px/1.4 system-ui,Segoe UI,sans-serif; }}
header {{ position:sticky; top:0; z-index:5; background:var(--bg); border-bottom:1px solid var(--line); padding:12px 16px; }}
h1 {{ margin:0 0 6px; font-size:20px; }}
#q {{ width:100%; max-width:420px; padding:8px 10px; border-radius:8px; border:1px solid var(--line); background:var(--card); color:var(--text); font-size:15px; }}
.legend {{ margin-top:8px; font-size:12px; color:var(--muted); display:flex; gap:12px; flex-wrap:wrap; }}
.dot {{ display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:4px; vertical-align:middle; }}
main {{ padding:8px 16px 40px; max-width:1300px; margin:0 auto; }}
h2 {{ margin:26px 0 10px; font-size:17px; color:var(--accent); border-bottom:1px solid var(--line); padding-bottom:4px; }}
.grid {{ display:grid; grid-template-columns:repeat(auto-fill,minmax(300px,1fr)); gap:12px; }}
.dish {{ background:var(--card); border:1px solid var(--line); border-radius:12px; overflow:hidden; display:flex; flex-direction:column; }}
.big {{ width:100%; height:170px; object-fit:contain; background:#ece3d2; }}
@media (prefers-color-scheme: dark) {{ .big {{ background:#3a3225; }} }}
.nobig {{ display:flex; align-items:center; justify-content:center; color:var(--muted); font-size:13px; }}
.info {{ padding:10px 12px 12px; }}
h3 {{ margin:0 0 4px; font-size:16px; display:flex; align-items:center; gap:8px; }}
.small {{ width:34px; height:34px; object-fit:contain; border-radius:6px; background:#ece3d2; }}
.time {{ margin:0 0 6px; color:var(--muted); font-size:13px; }}
ul {{ list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:4px; }}
li {{ display:flex; align-items:center; gap:8px; padding:3px 6px; border-radius:8px; border-left:4px solid var(--line); background:rgba(127,127,127,.08); }}
li img {{ width:30px; height:30px; object-fit:contain; }}
.noimg {{ width:30px; height:30px; display:inline-flex; align-items:center; justify-content:center; color:var(--muted); }}
.k-crop {{ border-left-color:var(--crop); }} .k-fruit {{ border-left-color:var(--fruit); }}
.k-animal {{ border-left-color:var(--animal); }} .k-made {{ border-left-color:var(--made); }} .k-sea {{ border-left-color:var(--sea); }}
.muted {{ color:var(--muted); font-size:13px; margin:4px 0 0; }}
.scratch {{ color:var(--text); background:rgba(200,121,26,.12); border-radius:8px; padding:4px 8px; }}
.it {{ margin-left:auto; font-style:normal; font-size:12px; color:var(--muted); }}
.hidden {{ display:none !important; }}
</style></head><body>
<header><h1>Food Street &ndash; normal recipes</h1>
<input id="q" type="search" placeholder="Search a dish, station or ingredient..." autocomplete="off">
<div class="legend"><span><i class="dot" style="background:var(--crop)"></i>crop (Garden Plot)</span>
<span><i class="dot" style="background:var(--fruit)"></i>fruit / bush</span>
<span><i class="dot" style="background:var(--animal)"></i>animal product</span>
<span><i class="dot" style="background:var(--made)"></i>made at a station</span>
<span><i class="dot" style="background:var(--sea)"></i>sea</span>
<span>From scratch = time if you have none of the ingredients (&ge; = some times unknown, counted as 0). Right of each ingredient = how long that ingredient takes from scratch.</span>
<span>Small icon next to the name = how it looks on the Orders board. x2 = amount per batch. The number badge on the big picture is just the stock when it was captured.</span></div></header>
<main>{"".join(sections)}
<p class="muted">Compiled from the bot's project notes and its trained picture libraries. "?" or "not recorded" means that detail has not been captured yet. Rebuild with <code>python build_recipe_page.py</code>.</p></main>
<script>
const q=document.getElementById('q');
q.addEventListener('input',()=>{{const t=q.value.trim().toLowerCase();
document.querySelectorAll('.dish').forEach(d=>{{d.classList.toggle('hidden',t&&!(d.textContent.toLowerCase().includes(t)||d.closest('section').dataset.station.includes(t)));}});
document.querySelectorAll('section').forEach(s=>s.classList.toggle('hidden',!s.querySelector('.dish:not(.hidden)')));}});
</script></body></html>'''
    with open(os.path.join(OUT, "index.html"), "w", encoding="utf-8") as f:
        f.write(page)
    print("wrote", os.path.join(OUT, "index.html"))


if __name__ == "__main__":
    main()
