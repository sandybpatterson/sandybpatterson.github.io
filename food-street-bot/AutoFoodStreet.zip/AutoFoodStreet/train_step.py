"""Interactive training helper. Finds the next not-yet-trained missing
item on the Orders board, travels to its station, and saves a screenshot
of the OPENED PANEL (not just the small Orders-board icon) so a human (or
Claude, viewing it) can see which recipe card actually matches and call
train_dish() with the right card_index -- matching this project's
established "identify by looking at the real station panel" training
workflow (used earlier for margherita_pizza, cupcakes, calzone,
beef_burger).

Persists an accumulating skip_slots list across separate invocations (via
pickle) so each run advances to a NEW item instead of rediscovering
whatever was already looked at. Run again after training (or explicitly
skipping) the current item to move to the next one.
"""
import os
import sys
import pickle

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

SKIP_PICKLE = os.path.join(BASE_DIR, "train_step_skip.pkl")
PANEL_SHOT = os.path.join(BASE_DIR, "event_pdf_extract", "train_step_panel.png")
ICON_SHOT = os.path.join(BASE_DIR, "event_pdf_extract", "train_step_icon.png")


def load_skip():
    if os.path.exists(SKIP_PICKLE):
        with open(SKIP_PICKLE, "rb") as f:
            return pickle.load(f)
    return []


def save_skip(skip):
    with open(SKIP_PICKLE, "wb") as f:
        pickle.dump(skip, f)


if __name__ == "__main__":
    # Real live-emulator actions below -- guarded so an `import train_step`
    # (e.g. for inspection, or accidentally via a syntax-check script) can
    # never trigger them. Confirmed the hard way 9/26: an unguarded import
    # ran this whole body for real against the live game.
    import session_lock
    if not session_lock.check_and_warn("train_step.py"):
        sys.exit(1)
    session_lock.acquire(owner="train_step")

    import cv2
    from adb_helper import screenshot, tap
    from find_and_center import close_any_open_panel, interruptible_sleep, CLOSE_X_LOC
    import order_fulfill as of

    try:
        skip = load_skip()
        print(f"Resuming with {len(skip)} slot(s) already skipped this training session.")

        close_any_open_panel()
        tap(*of.ORDERS_ICON_LOC)
        interruptible_sleep(1, None)
        of.reset_orders_scroll(None)
        img = screenshot()

        # The whole board fits in two looks -- see order_fulfill.LONG_SWIPE_ENDPOINTS.
        item = of.find_missing_item(img, skip_slots=skip)
        if item is None:
            of.swipe_to_far_end(None)
            img = screenshot()
            item = of.find_missing_item(img, skip_slots=skip)

        if item is None:
            print("NO MORE missing items to train -- board is fully covered (or everything left is blocked/skipped).")
            tap(*CLOSE_X_LOC)
            session_lock.release()
            sys.exit(0)

        print(f"Found item at {item['tap_loc']}, slot_key dx={item['slot_key']['dx']} row={item['slot_key']['row']}")
        cv2.imwrite(ICON_SHOT, item["icon"])
        print(f"Saved small icon to {ICON_SHOT}")

        # Check if it's already trained (in case the library grew since last board load)
        dish = of.identify_dish(item["icon"])
        if dish:
            print(f"Already trained as '{dish['name']}' (confidence {dish['confidence']:.2f}) -- "
                  "nothing to do, skipping to keep this session moving.")
            skip.append(item["slot_key"])
            save_skip(skip)
            tap(*CLOSE_X_LOC)
            session_lock.release()
            sys.exit(0)

        if not of.travel_to_missing_item(item, None):
            print("Quick-travel tooltip failed (timing miss) -- this item's slot_key will NOT be "
                  "added to skip, so it'll be retried on the next invocation. Closing.")
            tap(*CLOSE_X_LOC)
            session_lock.release()
            sys.exit(1)

        img = screenshot()
        opened = of.panel_is_open(img)
        if not opened:
            for _ in range(3):
                interruptible_sleep(0.7, None)
                img = screenshot()
                if of.panel_is_open(img):
                    opened = True
                    break
        if not opened:
            for attempt in range(2):
                tap(*of.SCREEN_CENTER)
                interruptible_sleep(1, None)
                img = screenshot()
                if of.panel_is_open(img):
                    opened = True
                    break
        if not opened:
            print("Panel never opened -- landed on the map instead. This item's slot_key will NOT be "
                  "added to skip (retry next time). Closing without guessing.")
            tap(*CLOSE_X_LOC)
            session_lock.release()
            sys.exit(1)

        with open(os.path.join(BASE_DIR, "train_step_current.pkl"), "wb") as f:
            pickle.dump({"icon": item["icon"], "slot_key": item["slot_key"]}, f)

        cv2.imwrite(PANEL_SHOT, img)
        print(f"Panel opened -- saved to {PANEL_SHOT}. View it, determine the dish name and which "
              "recipe card (0-indexed, left to right) matches the small icon, then run:")
        print(f"  python train_confirm.py <name> <card_index>")
        print("or, if this is a raw ingredient / can't be safely identified, run:")
        print(f"  python train_confirm.py --skip")
        # Leave the panel OPEN and the lock HELD -- train_confirm.py will close
        # the panel and release the lock once a decision is made, so nothing
        # else can collide with the emulator in between.
    finally:
        pass  # deliberately not releasing the lock here -- train_confirm.py does, see above
