"""Thin wrapper around adb for the Food Street automation bot.
No AI/vision-model calls anywhere in here — just subprocess + OpenCV.
"""
import os
import struct
import subprocess
import time
import numpy as np
import cv2

def find_ldplayer(env=None, exists=os.path.exists):
    """11/23: the folder LDPlayer 9 is installed in (adb.exe + dnconsole.exe). Default C:\\LDPlayer\\LDPlayer9;
    LDPLAYER_DIR overrides; other drives / Program Files are tried for shared copies of the bot."""
    env = os.environ if env is None else env
    tries = [env.get("LDPLAYER_DIR", "")]
    for drive in "CDEFG":
        tries += [drive + r":\LDPlayer\LDPlayer9", drive + r":\Program Files\LDPlayer\LDPlayer9",
                  drive + r":\Program Files (x86)\LDPlayer\LDPlayer9"]
    for d in tries:
        if d and exists(os.path.join(d, "adb.exe")):
            return d
    return r"C:\LDPlayer\LDPlayer9"


LDPLAYER_DIR = find_ldplayer()
ADB = os.path.join(LDPLAYER_DIR, "adb.exe")
PREFERRED_DEVICE = "127.0.0.1:5555"
DEVICE = None  # resolved lazily by _resolve_device() -- LDPlayer has been seen
               # to hand out a different adb identity (e.g. "emulator-5554")
               # after a restart, silently breaking a hardcoded address

# Real bug found 9/30: AFSD silently froze for 13+ hours overnight (cycle 132
# started, then NOTHING logged until the user closed the app the next
# morning) -- every subprocess.run() call in this file had NO timeout, so a
# hung adb connection (LDPlayer paused/asleep, the host machine itself
# sleeping, etc.) could block forever with zero error and zero log output.
# ADB_TIMEOUT_SEC applies to every call below; a timeout raises
# subprocess.TimeoutExpired, which propagates up to afsd_core.run_loop()'s
# existing `except Exception` handler -- already logs the full traceback and
# moves on to the next cycle, so a hang now surfaces as a loud, recoverable
# error instead of an invisible, unrecoverable freeze. 15s is generous
# against the slowest known-normal call (screenshot(), measured ~2.2-2.4s).
ADB_TIMEOUT_SEC = 15


def _connected_devices():
    result = _safe_run([ADB, "devices"], ADB_TIMEOUT_SEC, text=True)
    devices = []
    for line in result.stdout.splitlines()[1:]:
        line = line.strip()
        if line.endswith("\tdevice"):
            devices.append(line.split("\t")[0])
    return devices


def _safe_run(cmd, timeout, text=False):
    """adb without the 12-minute pipe hang (see adb_resilience.safe_run)."""
    import adb_resilience
    return adb_resilience.safe_run(cmd, timeout, text=text)


def _resolve_device():
    """Picks an adb device to talk to, preferring PREFERRED_DEVICE if it's
    connected, otherwise falling back to whatever else is available (and
    trying `adb connect` on the preferred address first, in case it just
    needs re-establishing) -- confirmed live 9/25: after an overnight
    restart, LDPlayer came back as "emulator-5554" while the old
    "127.0.0.1:5555" identity was simply gone from `adb devices`, which
    crashed every screenshot() call with an empty-buffer cv2 error."""
    global DEVICE
    if DEVICE is not None:
        return DEVICE
    devices = _connected_devices()
    if PREFERRED_DEVICE not in devices:
        _safe_run([ADB, "connect", PREFERRED_DEVICE], ADB_TIMEOUT_SEC)
        devices = _connected_devices()
    if PREFERRED_DEVICE in devices:
        DEVICE = PREFERRED_DEVICE
    elif devices:
        DEVICE = devices[0]
    else:
        raise RuntimeError("No adb devices connected -- is LDPlayer running?")
    return DEVICE


def _reconnect():
    """Drop the cached device and re-establish the adb link (self-heal after a hang, an
    'offline' device, or an emulator restart). Never raises."""
    global DEVICE
    DEVICE = None
    try:
        _safe_run([ADB, "connect", PREFERRED_DEVICE], 10)
    except Exception:
        try:
            _safe_run([ADB, "kill-server"], 10)
            _safe_run([ADB, "start-server"], 20)
            _safe_run([ADB, "connect", PREFERRED_DEVICE], 10)
        except Exception:
            pass


_BAD_ADB_TEXT = (b"device offline", b"device not found", b"no devices", b"cannot connect",
                 b"closed", b"device unauthorized")


def _run_basic(args):
    """Runs one adb command. On a timeout, or an offline/missing-device error, reconnects
    and retries ONCE (a second failure propagates so the caller still sees a loud error)."""
    r = None
    for attempt in (0, 1):
        try:
            r = _safe_run([ADB, "-s", _resolve_device()] + args, ADB_TIMEOUT_SEC)
        except subprocess.TimeoutExpired:
            if attempt:
                raise
            _reconnect()
            continue
        err = (r.stderr or b"").lower()
        if attempt == 0 and r.returncode != 0 and any(t in err for t in _BAD_ADB_TEXT):
            _reconnect()
            continue
        return r
    return r


def _adb_log(msg):
    try:
        import time as _t
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "run_log.txt"), "a", encoding="utf-8") as f:
            f.write(f"[{_t.strftime('%Y-%m-%dT%H:%M:%S')}] [adb] {msg}\n")
    except Exception:
        pass


def _run(args):
    """adb call with escalating recovery (see adb_resilience.py); falls back to the plain version."""
    try:
        import adb_resilience as _ar
    except Exception:
        return _run_basic(args)
    r = _ar.run(args, _resolve_device, log=_adb_log)
    err = (r.stderr or b"").lower()
    if r.returncode != 0 and any(t in err for t in _BAD_ADB_TEXT):       # old 'device offline' self-heal
        _reconnect()
        return _ar.run(args, _resolve_device, log=_adb_log)
    return r


# Faster screenshots (10/17). "screencap -p" makes the emulator squeeze every picture into a PNG
# first; plain "screencap" sends the raw pixels instead (same picture, no squeezing). The first few
# screenshots try both ways and keep whichever is faster on this PC; any raw-picture problem falls
# back to PNG for good. Pixels are identical either way (PNG is lossless), so no template changes.
_SHOT = {"mode": None, "times": {"raw": [], "png": []}, "n": 0, "total": 0.0}
_SHOT_TRIALS = 4                                    # per mode, before choosing


def _decode_raw(data):
    """Raw screencap bytes -> BGR image, or None. Header is 12 bytes (w, h, format) on old Android,
    16 (plus colour space) on newer; format 1 = RGBA_8888."""
    if len(data) < 16:
        return None
    w, h, fmt = struct.unpack_from("<III", data, 0)
    if fmt != 1 or not (100 <= w <= 8000 and 100 <= h <= 8000):
        return None
    hdr = len(data) - w * h * 4
    if hdr not in (12, 16):
        return None
    px = np.frombuffer(data, dtype=np.uint8, offset=hdr).reshape(h, w, 4)
    return cv2.cvtColor(px, cv2.COLOR_RGBA2BGR)


def _shot_once(mode):
    if mode == "raw":
        result = _run(["exec-out", "screencap"])
        return _decode_raw(result.stdout or b"")
    result = _run(["exec-out", "screencap", "-p"])
    arr = np.frombuffer(result.stdout or b"", dtype=np.uint8)
    # OpenCV 5 raises on an empty buffer instead of returning None (seen live
    # 10/2: one empty read crashed here and the retry path below never ran),
    # so guard it explicitly.
    return cv2.imdecode(arr, cv2.IMREAD_COLOR) if arr.size else None


def _pick_mode():
    m = _SHOT["mode"]
    if m:
        return m
    t = _SHOT["times"]
    return "raw" if len(t["raw"]) <= len(t["png"]) else "png"


def _note_time(mode, secs):
    _SHOT["n"] += 1
    _SHOT["total"] += secs
    if _SHOT["mode"] is None:
        t = _SHOT["times"]
        t[mode].append(secs)
        if len(t["raw"]) >= _SHOT_TRIALS and len(t["png"]) >= _SHOT_TRIALS:
            raw, png = sorted(t["raw"])[_SHOT_TRIALS // 2], sorted(t["png"])[_SHOT_TRIALS // 2]
            _SHOT["mode"] = "raw" if raw < png else "png"
            _adb_log(f"Screenshot speed test: raw {raw:.2f} s, PNG {png:.2f} s -> using {_SHOT['mode'].upper()}.")
    if _SHOT["n"] % 200 == 0:
        _adb_log(f"Screenshots: {_SHOT['n']} taken, average {_SHOT['total'] / _SHOT['n']:.2f} s "
                 f"({(_SHOT['mode'] or 'testing').upper()}).")


SCREENSHOT_OBSERVERS = []      # 10/17: watch-only hooks, called with every screenshot (must be fast, never raise)


def _observe(img):
    for fn in list(SCREENSHOT_OBSERVERS):
        try:
            fn(img)
        except Exception:                              # noqa: BLE001 -- an observer must never break a screenshot
            pass


_LAST_WH = [(1600, 900)]        # 11/1 FLASH: size of the last adb picture, for resizing the window copy

# 11/8 ANY 16:9 RESOLUTION (owner 11/2: "put that on the freetime list"): every template, spot and tap was made at
# 1600x900. After an LDPlayer restart came back at 1920x1080 (11/2) the bot saw nothing. Now an adb picture of ANY
# 16:9 size (1280x720, 1920x1080, 2560x1440 ... and the portrait ads, 1080x1920) is shrunk/grown to 1600x900 (900x1600)
# and every tap / swipe / pinch is scaled back by the same factor. Other shapes are left alone (the [screen] alarm).
SCALE = [1.0]


def screen_scale(w, h):
    """Pure: factor from the 1600-wide working picture to the real screen (1920x1080 -> 1.2), 1.0 at 1600x900,
    None for a shape that is not 16:9 (landscape or portrait)."""
    if not w or not h:
        return None
    long_, short = max(w, h), min(w, h)
    if abs(long_ * 9 - short * 16) > long_ * 9 * 0.01:
        return None
    return long_ / 1600.0


def normalize(img):
    """A 16:9 picture of any size -> 1600x900 / 900x1600 (and remember the factor for taps)."""
    if img is None:
        return img
    h, w = img.shape[:2]
    sc = screen_scale(w, h)
    if sc is None:
        return img                                     # unknown shape: leave it, the [screen] check warns
    SCALE[0] = sc
    if abs(sc - 1.0) < 1e-6:
        return img
    size = (1600, 900) if w >= h else (900, 1600)
    return cv2.resize(img, size, interpolation=cv2.INTER_AREA if sc > 1 else cv2.INTER_CUBIC)


def _real(v):
    """A 1600-space coordinate -> the real screen's (str for adb)."""
    return str(int(round(float(v) * SCALE[0])))


def screenshot():
    """The current screen, BGR. 11/1 FLASH (Settings "FLASH fast capture"): a copy of LDPlayer's window
    first (~0.05-0.2 s); anything wrong with it -> the normal adb screenshot below."""
    try:
        import flash
        if flash.ON:
            wait = FLASH_AFTER_TAP_SEC - (time.time() - ACTIONS["t"])
            if wait > 0:
                time.sleep(wait)
            img = flash.grab(_LAST_WH[0])
            if img is not None:
                _observe(img)
                return img
    except Exception:                                  # noqa: BLE001 -- FLASH must never break a screenshot
        pass
    img = adb_screenshot()
    try:
        import flash
        if flash.ON:
            flash.note_adb(img)                         # 11/3: checks a window copy that looked frozen
    except Exception:                                  # noqa: BLE001
        pass
    return img


def exact_screenshot():
    """11/1: a pixel-exact adb picture even when FLASH is on -- for the few readers with tight colour/shape gates
    (crop plot detection: 10 of 56 plain-map screens gave a different plot list on a FLASH-style copy)."""
    try:
        import flash
        if flash.ON:
            return adb_screenshot()
    except Exception:                                  # noqa: BLE001
        pass
    return screenshot()


def adb_screenshot():
    """Returns the current screen as a BGR numpy array (OpenCV format), always through adb.
    Self-healing: if the currently-cached device stops responding (e.g. its
    adb identity changed underneath us), drop the cache and re-resolve once
    before giving up, rather than staying stuck on a dead address for the
    rest of the process's life."""
    global DEVICE
    mode = _pick_mode()
    t0 = time.time()
    img = _shot_once(mode)
    if img is None and mode == "raw":
        _SHOT["mode"] = "png"                       # raw did not work here -- PNG from now on
        _adb_log("Raw screenshot could not be read -- using PNG screenshots from now on.")
        mode, t0 = "png", time.time()
        img = _shot_once("png")
    if img is not None:
        _note_time(mode, time.time() - t0)
        img = normalize(img)                           # 11/8: any 16:9 size -> 1600x900
        _LAST_WH[0] = (img.shape[1], img.shape[0])
        _observe(img)
        return img
    stale_device = DEVICE
    DEVICE = None
    img = _shot_once("png")
    if img is None:
        raise RuntimeError(
            f"adb screenshot returned no data (tried '{stale_device}' and "
            f"re-resolved to '{DEVICE}') -- is LDPlayer actually running?"
        )
    return normalize(img)


ACTIONS = {"n": 0, "total": 0.0, "t": 0.0}     # 11/1 FLASH: taps/swipes/keys, count + seconds + last end time
FLASH_AFTER_TAP_SEC = 0.4       # a fast look waits this long after the last tap (adb's own delay used to cover it)


def _act(args):
    t0 = time.time()
    try:
        try:
            import fast_input                           # 11/1 FLASH step 3: one open adb shell for taps
            if fast_input.ON and fast_input.send(args, ADB, _resolve_device()):
                return None
        except Exception:                               # noqa: BLE001
            pass
        return _run(args)
    finally:
        ACTIONS["n"] += 1
        ACTIONS["total"] += time.time() - t0
        ACTIONS["t"] = time.time()


def tap(x, y):
    _act(["shell", "input", "tap", _real(x), _real(y)])


def back():
    """Android BACK key — reliably dismisses most unexpected dialogs/panels
    a stray tap might open, without needing to guess that dialog's own
    close-button position."""
    _act(["shell", "input", "keyevent", "4"])


def swipe(x1, y1, x2, y2, duration_ms=500):
    _act(["shell", "input", "swipe", _real(x1), _real(y1), _real(x2), _real(y2), str(duration_ms)])


TOUCH_DEVICE = "/dev/input/event2"


def pinch(cx, cy, start_radius, end_radius, steps=12):
    """Two-finger pinch/zoom gesture via raw Protocol-B multitouch sendevent
    calls, since `input swipe` only supports a single pointer. Positive
    (end_radius > start_radius) = fingers spreading apart = zoom in.
    Negative = zoom out. All events are batched into one adb shell call."""
    ev = []

    def slot(n):
        ev.append(f"sendevent {TOUCH_DEVICE} 3 47 {n}")

    def pos(x, y):
        ev.append(f"sendevent {TOUCH_DEVICE} 3 53 {_real(x)}")
        ev.append(f"sendevent {TOUCH_DEVICE} 3 54 {_real(y)}")

    def syn():
        ev.append(f"sendevent {TOUCH_DEVICE} 0 0 0")

    # Touch down: two fingers on either side of (cx, cy) along the x-axis.
    slot(0)
    ev.append(f"sendevent {TOUCH_DEVICE} 3 57 100")
    pos(cx - start_radius, cy)
    ev.append(f"sendevent {TOUCH_DEVICE} 1 330 1")
    syn()
    slot(1)
    ev.append(f"sendevent {TOUCH_DEVICE} 3 57 101")
    pos(cx + start_radius, cy)
    syn()

    # Interpolate the pinch.
    for i in range(1, steps + 1):
        r = start_radius + (end_radius - start_radius) * i / steps
        slot(0)
        pos(cx - r, cy)
        slot(1)
        pos(cx + r, cy)
        syn()

    # Lift both fingers.
    slot(0)
    ev.append(f"sendevent {TOUCH_DEVICE} 3 57 -1")
    slot(1)
    ev.append(f"sendevent {TOUCH_DEVICE} 3 57 -1")
    ev.append(f"sendevent {TOUCH_DEVICE} 1 330 0")
    syn()

    _run(["shell", " ; ".join(ev)])
