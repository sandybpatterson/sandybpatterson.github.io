"""Cross-process lock so the AFSD GUI's background loop and any manual/
ad-hoc ADB exploration (by the user or by Claude driving adb.exe directly)
don't touch the same emulator at the same time. Built 9/26 after a real
collision: the GUI's loop was running unattended while a manual debugging
session was also tapping/swiping the same emulator, and the two interfered
with each other (a manual tap landed on an Orders card instead of the
intended nav icon; the GUI's own scroll-stability log looked suspicious in
a way that's most likely explained by the same collision, not a real bug
in the scroll logic -- see CLAUDE.md).

This is intentionally a simple advisory file lock, not an OS-level mutex
-- nothing forcibly prevents a second process from touching the emulator
anyway (adb has no concept of exclusive access), so the value here is
purely "check before you act, and don't proceed if someone else is
already driving." Any script that does one-off manual ADB commands
against 127.0.0.1:5555 should call check_and_warn() first.
"""
import os
import time
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOCK_PATH = os.path.join(BASE_DIR, ".session.lock")
STALE_AFTER_SEC = 20 * 60  # if the GUI crashed without releasing, don't
                             # block forever -- 20 min is far longer than
                             # any single automation cycle should ever take


def acquire(owner="afsd_gui"):
    data = {"owner": owner, "pid": os.getpid(), "acquired_at": time.time()}
    with open(LOCK_PATH, "w") as f:
        json.dump(data, f)


def release():
    try:
        os.remove(LOCK_PATH)
    except FileNotFoundError:
        pass


def status():
    """Returns None if unlocked (or the lock is stale), else the lock's
    info dict with an added 'age_sec' field."""
    if not os.path.exists(LOCK_PATH):
        return None
    try:
        with open(LOCK_PATH) as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
    age = time.time() - data.get("acquired_at", 0)
    if age > STALE_AFTER_SEC:
        return None
    data["age_sec"] = age
    return data


def check_and_warn(label="this script"):
    """Call at the top of any manual/ad-hoc ADB script (or before Claude
    runs a batch of manual adb commands) before touching the emulator.
    Prints a clear warning and returns False if the GUI's loop looks
    active, so the caller can decide to stop rather than proceed and
    risk exactly the kind of collision this module exists to prevent."""
    info = status()
    if info is None:
        return True
    mins = info["age_sec"] / 60
    print(f"WARNING: {label} wants to touch the emulator, but a lock file says "
          f"'{info.get('owner', 'unknown')}' (pid {info.get('pid', '?')}) has been "
          f"running for {mins:.1f} min. Stop it first (AFSD's Stop button, or close "
          "the app) before running manual/ad-hoc ADB commands -- concurrent access "
          "has caused real collisions before (see CLAUDE.md, 2026-09-26).")
    return False


if __name__ == "__main__":
    info = status()
    print("Locked:" if info else "Not locked.", info or "")
