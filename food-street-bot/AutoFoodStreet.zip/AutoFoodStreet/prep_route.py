"""Prep work route finder (10/19, owner's idea). READ-ONLY: plans, never taps.

To make an item for a Prep order the bot has to reach the station that makes it. The fast way is a "?" tooltip:
an item on the clipboard has one that fast-travels to the station making it, and every station card shows its
ingredients, each with a "?" that travels on to THAT ingredient's station. So any clipboard item whose recipe
chain leads to the wanted station is a way there:

    wheat   -- Bread on the clipboard:      Bread "?" -> Bread Oven, Bread's wheat "?" -> Garden Plot
    ice cream -- a coffee on the clipboard:  Affogato "?" -> Barista Coffee, its ice cream "?" -> Dairy
    milk    -- anything at the Dairy:       ... -> Dairy, Cheese's milk "?" -> Cow Shed
    carrots -- Bread again: carrots grow on the same Garden Plot as wheat

find_route() is a breadth-first search over "station -> station" hops built from recipes.json (recipe_book).
"""
import os
from collections import deque

import recipe_book as rb


def _items():
    return rb.load()["items"]


def station_of(item_key):
    it = _items().get(item_key)
    return it["station"] if it else None


def hops():
    """station -> [(next station, dish on that station's card, ingredient whose '?' to tap)]"""
    items = _items()
    out = {}
    for dish_key, it in items.items():
        here = it["station"]
        for ing, _n in it["ingredients"]:
            ing_key = rb.resolve(ing) if ing not in items else ing
            nxt = items.get(ing_key, {}).get("station")
            if not nxt or nxt == here:
                continue
            out.setdefault(here, []).append((nxt, dish_key, ing_key))
    for k in out:                                    # stable, readable order: shortest names first
        out[k].sort(key=lambda t: (t[0], len(t[1]), t[1]))
    return out


def _key(name):
    items = _items()
    if name in items:
        return name
    try:
        k = rb.resolve(name)
        return k if k in items else None
    except Exception:                                # noqa: BLE001
        return None


def find_route(target, board_items):
    """Fastest way to the station that makes `target`, starting from an item on the clipboard.

    Returns None when no clipboard item leads there, else a list of steps:
      ("board", item, station)              tap the item on the clipboard, then its "?"  -> station
      ("hop", dish, ingredient, station)    on that station's panel: dish card, ingredient "?" -> station
    The target's own station is reached when the last step's station == station_of(target)."""
    tkey = _key(target)
    goal = station_of(tkey) if tkey else None
    if goal is None:
        return None
    starts = []
    for b in board_items:
        bk = _key(b)
        st = station_of(bk) if bk else None
        if st:
            starts.append((bk, st))
    if not starts:
        return None
    graph = hops()
    seen = {}
    q = deque()
    for bk, st in starts:
        if st not in seen:
            seen[st] = [("board", bk, st)]
            q.append(st)
    while q:
        st = q.popleft()
        if st == goal:
            return seen[st]
        # 10/20 (owner): hop through the target ITSELF when a dish here uses it -- carrots via Carrot Cake's carrot "?"
        # lands on a carrot plot (ready to collect) or an empty plot; via Cupcakes' wheat "?" it lands on wheat.
        for nxt, dish, ing in sorted(graph.get(st, []), key=lambda t: t[2] != tkey):
            if nxt not in seen:
                seen[nxt] = seen[st] + [("hop", dish, ing, nxt)]
                q.append(nxt)
    return None


def describe(target, route):
    """One readable line for the log / the Prep work tab."""
    items = _items()
    name = lambda k: items.get(k, {}).get("name", k)          # noqa: E731
    if route is None:
        return f"{name(_key(target) or target)}: no clipboard item leads to {station_of(_key(target) or '') or 'its station'}"
    parts = []
    for s in route:
        if s[0] == "board":
            parts.append(f"clipboard {name(s[1])} '?' -> {s[2]}")
        else:
            parts.append(f"{name(s[1])}'s {name(s[2])} '?' -> {s[3]}")
    return f"{name(_key(target))} ({len(route) - 1} hop{'s' if len(route) != 2 else ''}): " + ", then ".join(parts)


# --- Watch-only live test (10/19 freetime): every time the clipboard is read, log the route the Prep work engine
# WOULD take to each item on the Prep list (or to wheat / ice cream / milk / carrot while the list is empty).
# At most once per board change, so the log stays short. Never taps anything.
PREP_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".prep.json")
SAMPLE_TARGETS = ("wheat", "ice_cream", "milk", "carrot")
_last_board = None


def watch(board_names, log):
    global _last_board
    try:
        import json
        board = sorted({_key(n) for n in board_names if n and _key(n)})
        if not board or board == _last_board:
            return
        _last_board = board
        try:
            with open(PREP_FILE, encoding="utf-8") as fh:
                targets = list((json.load(fh).get("items") or {}).keys())
        except (OSError, ValueError):
            targets = []
        src = "Prep list" if targets else "sample"
        for t in (targets or list(SAMPLE_TARGETS)):
            log(f"[prep route] ({src}) {describe(t, find_route(t, board))}")
    except Exception as e:                           # noqa: BLE001 -- a test must never break the run
        log(f"[prep route] skipped: {e}")
