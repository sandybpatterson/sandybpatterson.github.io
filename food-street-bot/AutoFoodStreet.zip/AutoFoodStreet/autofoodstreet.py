"""AutoFoodStreet — simple desktop GUI wrapping the Food Street automation
scripts. v1: Pork (Ham) only. Dark grey / gold theme.
"""
import os
import re
import sys
import importlib
import datetime
import traceback
import threading
import time
import tkinter as tk
from tkinter import font as tkfont

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import session_lock
import ui_kit
import ad_skip
import recipe_book as rb
import afsd_core  # the actual per-cycle automation logic -- split out 9/29
                   # specifically so the in-app Reload button can refresh it;
                   # see afsd_core.py's own module docstring for why

LOG = os.path.join(BASE_DIR, "run_log.txt")


def log(msg):
    """Same shared run_log.txt every other module writes to -- the GUI's
    own lifecycle (start/stop, which checkboxes were on, any exception a
    cycle hit) was previously only ever shown in a Tkinter label and lost
    the moment it scrolled past or the app closed. Without this, an
    overnight crash left literally no trace to review later."""
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] [afsd] {msg}\n")
    try:
        print(f"[{ts}] [afsd] {msg}")
    except (AttributeError, OSError):
        pass


BG = "#1e1e1e"
PANEL = "#2a2a2a"
GOLD = "#c9a227"
GOLD_DIM = "#8a6f1e"
TEXT = "#e8e8e8"
DIM_TEXT = "#9a9a9a"

def open_recipe_window(parent, colors, embed=False, prep=None):
    """Recipe book + order calculator window (button "Recipes"): browse every dish, build an order, say what you
    already have and the coin reward, read the time, steps and coins-per-minute score. Never touches the game."""
    BG, PANEL, GOLD, TEXT, DIM = (colors[k] for k in ("BG", "PANEL", "GOLD", "TEXT", "DIM"))
    book = rb.load(force=True)
    items = book["items"]
    if embed:                                        # 10/18: the Recipe Book tab of the main window
        win = parent
    else:
        win = tk.Toplevel(parent)
        win.title("AFSD — Recipes")
        win.geometry("900x720+80+30")
        win.configure(bg=BG)

    def lbl(master, text, **kw):
        return tk.Label(master, text=text, bg=kw.pop("bg", BG), fg=kw.pop("fg", TEXT), **kw)

    # ---------------- top: search + list + details ----------------
    top = tk.Frame(win, bg=BG)
    top.pack(fill="both", expand=True, padx=10, pady=(10, 4))
    left = tk.Frame(top, bg=BG)
    left.pack(side="left", fill="y")
    lbl(left, "Find an item:", fg=DIM).pack(anchor="w")
    q = tk.StringVar()
    ent = tk.Entry(left, textvariable=q, width=30)
    ent.pack(anchor="w", pady=(0, 4))
    dishes_only = tk.BooleanVar(value=prep is None)      # 10/18: the Prep work tab lists crops too (carrots, wheat...)
    tk.Checkbutton(left, text="dishes only (hide raw crops)", variable=dishes_only, bg=BG, fg=TEXT,
                   selectcolor=PANEL, activebackground=BG, highlightthickness=0).pack(anchor="w")
    lb_frame = tk.Frame(left, bg=BG)
    lb_frame.pack(fill="y", expand=True)
    lb = tk.Listbox(lb_frame, width=34, height=9 if prep is not None else 14, bg=PANEL, fg=TEXT, selectbackground=GOLD,
                    selectforeground="#1e1e1e", activestyle="none", exportselection=False)
    sb = tk.Scrollbar(lb_frame, command=lb.yview)
    lb.config(yscrollcommand=sb.set)
    lb.pack(side="left", fill="y")
    sb.pack(side="left", fill="y")
    keys = []

    def refresh_list(*_):
        t = q.get().strip().lower()
        lb.delete(0, "end")
        keys.clear()
        rows = []
        for k, it in items.items():
            if dishes_only.get() and not it.get("show_on_page", True):
                continue
            hay = f"{it['name']} {it['station']} {k} " + " ".join(i for i, _ in it["ingredients"])
            if t and t not in hay.lower():
                continue
            rows.append((it["station"], it["name"], k))
        for st, nm, k in sorted(rows):
            ct = items[k]["cook_sec"]
            lb.insert("end", f"{nm}   · {st} · {'?' if ct is None else rb.fmt(ct)}")
            keys.append(k)

    q.trace_add("write", refresh_list)
    dishes_only.trace_add("write", refresh_list)

    right = tk.Frame(top, bg=BG)
    right.pack(side="left", fill="both", expand=True, padx=(12, 0))
    lbl(right, "Recipe:", fg=DIM).pack(anchor="w")
    details = tk.Text(right, height=9 if prep is not None else 14, bg=PANEL, fg=TEXT, relief="flat", wrap="word", state="disabled")
    details.pack(fill="both", expand=True)

    def set_text(widget, text):
        widget.config(state="normal")
        widget.delete("1.0", "end")
        widget.insert("end", text)
        widget.config(state="disabled")

    def selected_key():
        sel = lb.curselection()
        return keys[sel[0]] if sel else None

    def show_details(*_):
        k = selected_key()
        if not k:
            return
        it = items[k]
        ct = "not recorded" if it["cook_sec"] is None else rb.fmt(it["cook_sec"])
        lines = [f"{it['name']}", f"Made at: {it['station']}   ·   one batch: {ct}   ·   makes {it.get('yield', 1)}"]
        if it["ingredients"]:
            lines.append("")
            lines.append("Needs:")
            for ik, cnt in it["ingredients"]:
                nm = items[rb.resolve(ik)]["name"]
                par, ser, unk = rb.scratch(ik)
                shown = f"{cnt} x " if it.get("counts_confirmed") else ""
                lines.append(f"   {shown}{nm}   (from scratch: {'>= ' if unk else ''}{rb.fmt(par)})")
        par, ser, unk = rb.scratch(k)
        lines += ["", f"From scratch: {'>= ' if unk else ''}{rb.fmt(par)} if everything is made at once, "
                      f"{'>= ' if unk else ''}{rb.fmt(ser)} of total machine time."]
        if it.get("note"):
            lines += ["", "Note: " + it["note"]]
        set_text(details, "\n".join(lines))

    lb.bind("<<ListboxSelect>>", show_details)

    # ---------------- bottom: order + calculator ----------------
    bot = tk.Frame(win, bg=BG)
    bot.pack(fill="both", expand=True, padx=10, pady=(4, 10))
    ctrl = tk.Frame(bot, bg=BG)
    ctrl.pack(fill="x")
    lbl(ctrl, "Quantity:").pack(side="left")
    qty = tk.StringVar(value="1")
    tk.Spinbox(ctrl, from_=1, to=99, width=4, textvariable=qty).pack(side="left", padx=(4, 8))
    order = {}                               # key -> qty
    ol = tk.Listbox(bot, height=3, bg=PANEL, fg=TEXT, selectbackground=GOLD, selectforeground="#1e1e1e",
                    exportselection=False)

    prep_hooks = []

    def refresh_order():
        ol.delete(0, "end")
        for k, n in order.items():
            try:
                t = rb.fmt(rb.cost({k: n})["wall"])
            except Exception:                            # noqa: BLE001
                t = "?"
            ol.insert("end", f"{items[k]['name']}  x{n}    ({t})")
        calc()
        for fn in prep_hooks:
            fn()

    def add(*_):
        k = selected_key()
        if not k:
            return
        try:
            n = max(1, int(qty.get()))
        except ValueError:
            n = 1
        order[k] = order.get(k, 0) + n
        refresh_order()

    def remove():
        sel = ol.curselection()
        if sel:
            order.pop(list(order)[sel[0]], None)
            refresh_order()

    def clear():
        order.clear()
        refresh_order()

    for text, cmd in (("Add to order", add), ("Remove selected", remove), ("Clear", clear)):
        tk.Button(ctrl, text=text, command=cmd, bg=PANEL, fg=TEXT, relief="flat",
                  activebackground=GOLD).pack(side="left", padx=3)
    lb.bind("<Double-Button-1>", add)
    ol.pack(fill="x", pady=(6, 4))
    if prep is not None:                             # 10/18: "Ready by" + start time + Place order (Prep work tab)
        pf = tk.Frame(bot, bg=BG)
        pf.pack(fill="x", pady=(0, 4))
        prep_hooks.append(prep(pf, order, refresh_order))

    row = tk.Frame(bot, bg=BG)
    row.pack(fill="x")
    lbl(row, "Already have:").pack(side="left")
    stock = tk.StringVar()
    se = tk.Entry(row, textvariable=stock, width=30)
    se.pack(side="left", padx=(4, 4))
    lbl(row, "(like  wheat=3, egg=1)", fg=DIM).pack(side="left", padx=(0, 12))
    lbl(row, "Reward (coins):").pack(side="left")
    coins = tk.StringVar()
    tk.Entry(row, textvariable=coins, width=8).pack(side="left", padx=4)

    res_frame = tk.Frame(bot, bg=BG)
    res_frame.pack(fill="both", expand=True, pady=(6, 0))
    result = tk.Text(res_frame, height=6 if prep is not None else 14, bg=PANEL, fg=TEXT, relief="flat", wrap="none", state="disabled",
                     font=("Consolas", 9))
    rsb = tk.Scrollbar(res_frame, command=result.yview)
    result.config(yscrollcommand=rsb.set)
    rsb.pack(side="right", fill="y")
    result.pack(side="left", fill="both", expand=True)

    def calc(*_):
        if not order:
            set_text(result, "Pick an item on the left, press \"Add to order\" (or double-click it), and the time, "
                             "steps and score show up here.")
            return
        try:
            st = rb.parse_pairs(stock.get(), "=") if stock.get().strip() else {}
        except (KeyError, ValueError) as e:
            set_text(result, f"I could not read the \"Already have\" box: {e}")
            return
        try:
            c = float(coins.get()) if coins.get().strip() else None
        except ValueError:
            c = None
        set_text(result, rb.report(dict(order), st, c))

    stock.trace_add("write", calc)
    coins.trace_add("write", calc)
    refresh_list()
    refresh_order()
    win.afsd_refresh_order = refresh_order               # lets tests (and the app) redraw the order list
    if not embed:
        ent.focus_set()
    return win


def _eta_color(o):
    """11/16: the card's time / points line -- amber for long clipboard orders, gold for the best pts/min card."""
    if o.get("eta_long"):
        return "#f0a040"
    return GOLD if str(o.get("eta", "")).endswith("· best") else DIM_TEXT


def completed_today(hist, now, source=None):
    """Pure (11/15): history entries completed since local midnight (not missed), of one board when given."""
    lt = time.localtime(now)
    midnight = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))
    return [e for e in hist if e.get("t", 0) >= midnight and not e.get("missed")
            and (source is None or e.get("source") == source)]


class AutoFoodStreetApp:
    def __init__(self, root):
        self.root = root
        self.running = False
        self.stop_flag = threading.Event()
        self.thread = None

        # Small collapsible stats overlay (user's idea, 9/29) -- a separate,
        # always-on-top window the user can drag over/near the LDPlayer
        # window, distinct from the earlier "live transparent desktop
        # overlay" idea that was discussed and dropped on 9/26 in favor of
        # static annotated screenshots. This one shows live text stats
        # (e.g. dishes detected needing to be cooked), not a synced visual
        # overlay on top of the game's own pixels -- much simpler and
        # doesn't need to track the emulator window's position/zoom at all.
        # Reuses order_fulfill.format_run_report()'s text directly rather
        # than building a second stats renderer.
        self.stats_window = None
        self.stats_expanded = True
        self.stats_detail_frame = None
        self.stats_toggle_button = None
        self.stats_text_var = None

        root.title("AFSD — AutoFoodStreet")
        root.geometry("360x560")
        root.configure(bg=BG)
        root.resizable(True, True)   # 10/15: can be dragged bigger; it is also auto-fitted below

        title_font = tkfont.Font(family="Segoe UI", size=16, weight="bold")
        label_font = tkfont.Font(family="Segoe UI", size=11)
        status_font = tkfont.Font(family="Segoe UI", size=9)

        # 10/18 (owner): ONE window -- today's controls in a left column, Orders / Recipe Book / Catering / Log
        # as tabs on the right (they used to be separate windows), Send logs / Update without black windows.
        win_root = root
        main = tk.Frame(win_root, bg=BG)
        main.pack(fill="both", expand=True)
        root = tk.Frame(main, bg=BG)                       # the left column (every widget below used to sit on root)
        root.pack(side="left", fill="y")
        self._left_col = root                              # 11/9: the caret strip next to it hides it (any tab)
        # 11/9 (owner): a "‹" caret on the gold line between the columns hides the Jobs column; it flips to "›"
        # while hidden, and pressing it brings the column back. Remembered in the settings file.
        self._left_sep = tk.Frame(main, bg=BG, width=18)
        self._left_sep.pack(side="left", fill="y")
        self._left_sep.pack_propagate(False)
        tk.Frame(self._left_sep, bg=GOLD_DIM, width=1).place(relx=0.5, rely=0.0, relheight=1.0, anchor="n")
        self._jobs_caret = tk.Label(self._left_sep, text="‹", font=("Segoe UI", 16, "bold"), bg=PANEL, fg=GOLD,
                                    cursor="hand2", padx=2, pady=6)
        self._jobs_caret.place(relx=0.5, rely=0.5, anchor="center")
        self._jobs_caret.bind("<Button-1>", lambda e: self._toggle_jobs_column())
        self._jobs_caret.bind("<Enter>", lambda e: self._jobs_caret.config(bg=GOLD, fg="#1e1e1e"))
        self._jobs_caret.bind("<Leave>", lambda e: self._jobs_caret.config(bg=PANEL, fg=GOLD))
        self.right = tk.Frame(main, bg=BG)
        self.right.pack(side="left", fill="both", expand=True)

        title_row = tk.Frame(root, bg=BG)
        title_row.pack(fill="x", padx=20, pady=(18, 4))
        tk.Label(title_row, text="AutoFoodStreet", font=title_font, bg=BG, fg=GOLD).pack(side="left")
        # 10/19 (owner): the gear panel became a Settings tab on the right (room for more settings).
        self._fonts = (label_font, status_font)
        self.auto_update_var = tk.BooleanVar(value=bool(self._load_setting("auto_update", 0)))
        # Shared copies (built by tools/build_share_zip.py) send logs to Discord on
        # every Stop unless the tester turns it off; the owner's copy has no .shared
        # file, so its default is unchanged.
        _shared = os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".shared"))
        self.send_at_stop_var = tk.BooleanVar(value=bool(self._load_setting(
            "send_at_stop", 1 if _shared else self._load_setting("send_at_start", 0))))
        self.send_after_play_var = tk.BooleanVar(value=bool(self._load_setting("send_after_play", 1)))  # 10/26
        # 10/22 (owner): every N min while running: Stop (sends logs), then Start again (update check / auto-update)
        self.auto_cycle_min_var = tk.IntVar(value=int(self._load_setting("auto_cycle_min", 0)))
        self.seed_reserve_var = tk.IntVar(value=int(self._load_setting("seed_reserve", 2)))
        self.storage_guard_var = tk.IntVar(value=int(self._load_setting("storage_guard", 27)))
        self.prestock_var = tk.IntVar(value=int(self._load_setting("prestock_each", 2)))
        self.clip_turn_var = tk.IntVar(value=int(self._load_setting("clip_turn_min", 5)))
        self.plant_wait_var = tk.BooleanVar(value=bool(self._load_setting("plant_while_waiting", 1)))  # 10/22
        self.quick_first_var = tk.IntVar(value=int(self._load_setting("quick_first", 1)))   # 10/22; 10/27: 2 = coins/h
        if not self._load_setting("coins_rank_switched", 0):            # 10/27 (owner: yes) -> switch to it once;
            self.quick_first_var.set(2)                                  # Settings can still change it back
            self._save_setting("quick_first", 2)
            self._save_setting("coins_rank_switched", 1)
        # 10/23 settings rework: "Then" = 1 dismiss / 0 skip for 1 h; long cooks = one number (0 = off)
        self.giveup_dismiss_var = tk.IntVar(value=int(self._load_setting("giveup_dismiss", 1)))
        self.long_cook_limit_var = tk.IntVar(value=int(self._load_setting(
            "long_cook_limit", self._load_setting("long_cook_min", 30) if self._load_setting("long_cook_guard", 1) else 0)))
        self.dismiss_min_var = tk.IntVar(value=int(self._load_setting("dismiss_min", 30)))             # 10/22
        self.long_order_min_var = tk.IntVar(value=int(self._load_setting("long_order_min", 90)))     # 10/26
        self.crop_reserve_var = tk.IntVar(value=int(self._load_setting("crop_reserve", 2)))            # 10/23
        self.truck_first_var = tk.BooleanVar(value=bool(self._load_setting("truck_first", 1)))               # 11/9 O.R.D.E.R.
        self.alarm_var = tk.BooleanVar(value=bool(self._load_setting("express_alarm", 1)))
        self.wheel_var = tk.BooleanVar(value=bool(self._load_setting("daily_wheel", 1)))        # 10/31 (owner)
        self.wheel_hours_var = tk.IntVar(value=int(self._load_setting("wheel_hours", 24)))
        self.prestock_hold_var = tk.BooleanVar(value=bool(self._load_setting("prestock_hold", 1)))   # 10/31 (owner)
        self.storage_purge_var = tk.BooleanVar(value=bool(self._load_setting("storage_purge", 1)))   # 11/17 (owner)
        self.event_clip_fallback_var = tk.BooleanVar(value=bool(self._load_setting("event_clip_fallback", 0)))  # 11/13
        self.admin_var = tk.BooleanVar(value=bool(self._load_setting("run_as_admin", 0)))
        self.flash_var = tk.BooleanVar(value=bool(self._load_setting("flash_capture", 0)))       # 11/1 FLASH
        self.fast_taps_var = tk.BooleanVar(value=bool(self._load_setting("flash_fast_taps", 1)))  # 11/1 FLASH step 3
        self.watch_ads_var = tk.BooleanVar(value=bool(self._load_setting("watch_ads", 0)))       # 11/1 ADS
        self.ads_min_var = tk.IntVar(value=int(self._load_setting("ads_min_left", 3)))           # 11/2 ADS
        self.orchard_cut_var = tk.BooleanVar(value=bool(self._load_setting("orchard_cut", 1)))   # 11/8 O.R.C.H.A.R.D.
        self.orchard_replant_var = tk.BooleanVar(value=bool(self._load_setting("orchard_replant", 1)))   # 11/9 step 4
        self.ads_event_var = tk.BooleanVar(value=bool(self._load_setting("ads_event_only", 1)))  # 11/6 ADS
        self.schedule_on_var = tk.BooleanVar(value=bool(self._load_setting("schedule_on", 0)))   # 11/14 Schedule tab
        self.chat_on_var = tk.BooleanVar(value=bool(self._load_setting("chat_on", 0)))           # 11/14 Chat relay
        self.auto_clean_var = tk.BooleanVar(value=bool(self._load_setting("auto_clean", 1)))     # 11/14 cleanup
        self.stall_wait_var = tk.BooleanVar(value=bool(self._load_setting("stall_fill_waiting", 1)))    # 11/1 owner
        self.pantry_relief_var = tk.BooleanVar(value=bool(self._load_setting("pantry_relief", 1)))      # 11/1 owner
        for _k in ("stock", "back", "apples"):             # 11/15: farmer has no switch (owner 10/21: no switch per test)   # 10/20 Tests job: which tests run today
            setattr(self, f"test_{_k}_var", tk.BooleanVar(value=bool(self._load_setting(f"test_{_k}", 1))))
        self.test_sell_apple_juice_var = tk.BooleanVar(value=bool(self._load_setting("test_sell_apple_juice", 0)))  # 10/25
        self.tool_buttons = {}
        self.version_var = tk.StringVar(value="")
        jobs_head = tk.Frame(root, bg=BG)                  # 10/19 (owner): name the checklist
        jobs_head.pack(fill="x", padx=20, pady=(8, 0))
        tk.Label(jobs_head, text="Jobs", font=label_font, bg=BG, fg=GOLD).pack(side="left")
        self.info_icon(jobs_head, "Tick the jobs the bot should do.\n"
                                  "The top of the list goes first each round -- drag \u2261 to change the order.\n"
                                  "An express order on the Food Club board always comes first.", bg=BG
                       ).pack(side="left", padx=(6, 0))
        list_frame = ui_kit.card(root, edge=GOLD_DIM, bg=PANEL)          # 10/20: rounded like the tabs
        list_frame.pack(padx=20, pady=(4, 0), fill="x")

        # Pork (Ham) and Whipped Cream were taken off the list 10/15 (owner's request). Their
        # switches stay as always-off values because afsd_core.FEATURES still names them.
        self.pork_var = tk.BooleanVar(value=False)
        self.cream_var = tk.BooleanVar(value=False)

        # Garden Plot was taken off the list 10/15 (owner's request). Its switch stays as an
        # always-off value and the "keep N each" number keeps its saved value, because
        # afsd_core.FEATURES / _run_garden still name them.
        self.carrot_var = tk.BooleanVar(value=False)
        self.restock_var = tk.StringVar(value=str(self._load_setting("restock_min", 5)))

        self.orders_var = tk.BooleanVar(value=False)
        orders_row = tk.Frame(list_frame, bg=PANEL)
        orders_row.pack(fill="x", padx=12, pady=4)
        tk.Checkbutton(orders_row, text="Clipboard Orders", variable=self.orders_var,
                        font=label_font, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                        activebackground=PANEL, activeforeground=GOLD,
                        highlightthickness=0).pack(side="left")

        # 10/19 (owner): "Keep fishing (sell extras)" was replaced by "Prep work" -- fishing becomes something you put
        # on the Prep list. Its switch stays as an always-off value (afsd_core.FEATURES still names it), and the
        # "keep N each" number keeps its saved value for when it comes back inside Prep work.
        self.fishing_var = tk.BooleanVar(value=False)
        self.fish_keep_var = tk.StringVar(value=str(self._load_setting("fish_keep", 5)))
        self.prep_var = tk.BooleanVar(value=False)
        fishing_row = tk.Frame(list_frame, bg=PANEL)            # (the Prep work row, kept under its old name)
        fishing_row.pack(fill="x", padx=12, pady=4)
        tk.Checkbutton(fishing_row, text="Prep work", variable=self.prep_var,
                        font=label_font, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                        activebackground=PANEL, activeforeground=GOLD,
                        highlightthickness=0).pack(side="left")
        tk.Label(fishing_row, text="(your list on the Prep work tab)", font=label_font, bg=PANEL,
                 fg=DIM_TEXT).pack(side="left", padx=(8, 0))

        self.delivery_var = tk.BooleanVar(value=False)
        delivery_row = tk.Frame(list_frame, bg=PANEL)
        delivery_row.pack(fill="x", padx=12, pady=4)
        tk.Checkbutton(delivery_row, text="Delivery Event", variable=self.delivery_var,
                        font=label_font, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                        activebackground=PANEL, activeforeground=GOLD,
                        highlightthickness=0).pack(side="left")

        # "Food Truck Event (not yet functional)" was taken off the list 10/17 -- it never did anything.
        # The switch stays as an always-off value because afsd_core.FEATURES still names it.
        self.food_truck_var = tk.BooleanVar(value=False)

        self.chef_challenge_var = tk.BooleanVar(value=False)
        chef_challenge_row = tk.Frame(list_frame, bg=PANEL)
        chef_challenge_row.pack(fill="x", padx=12, pady=4)
        tk.Checkbutton(chef_challenge_row, text="Chef Challenge", variable=self.chef_challenge_var,
                        font=label_font, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                        activebackground=PANEL, activeforeground=GOLD,
                        highlightthickness=0).pack(side="left")

        self.event_orders_var = tk.BooleanVar(value=False)
        event_orders_row = tk.Frame(list_frame, bg=PANEL)
        event_orders_row.pack(fill="x", padx=12, pady=4)
        tk.Checkbutton(event_orders_row, text="Food Club Event",
                        variable=self.event_orders_var,
                        font=label_font, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                        activebackground=PANEL, activeforeground=GOLD,
                        highlightthickness=0).pack(side="left")
        # 11/13 (owner, via Muse: club rule "don't play the first day, stock up, then rocket past"): hold serving --
        # the job keeps cooking/prestocking/reading the score, ready regular cards are NOT handed in; expresses are.
        self.hold_serve_var = tk.BooleanVar(value=bool(self._load_setting("hold_serve", 0)))
        hold_cb = tk.Checkbutton(event_orders_row, text="\u23f8 hold serving", variable=self.hold_serve_var,
                                 font=label_font, bg=PANEL, fg=DIM_TEXT, selectcolor=PANEL,
                                 activebackground=PANEL, activeforeground=GOLD, highlightthickness=0)
        hold_cb.pack(side="left", padx=(10, 0))

        def _hold_changed(*_):
            on = bool(self.hold_serve_var.get())
            self._save_setting("hold_serve", int(on))
            hold_cb.config(fg=GOLD if on else DIM_TEXT)
            log(f"[hold] owner turned 'Hold serving' {'ON' if on else 'OFF'}.")
        self.hold_serve_var.trace_add("write", _hold_changed)
        hold_cb.config(fg=GOLD if self.hold_serve_var.get() else DIM_TEXT)

        self.street_truck_var = tk.BooleanVar(value=False)
        street_truck_row = tk.Frame(list_frame, bg=PANEL)
        street_truck_row.pack(fill="x", padx=12, pady=4)
        tk.Checkbutton(street_truck_row, text="Food Truck (street)", variable=self.street_truck_var,
                        font=label_font, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                        activebackground=PANEL, activeforeground=GOLD,
                        highlightthickness=0).pack(side="left")

        # 10/20 (owner): a Tests job -- runs the planned tests (tests_job.py) one per turn, never during an express
        self.tests_var = tk.BooleanVar(value=False)
        tests_row = tk.Frame(list_frame, bg=PANEL)
        tests_row.pack(fill="x", padx=12, pady=4)
        tk.Checkbutton(tests_row, text="Tests", variable=self.tests_var,
                        font=label_font, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                        activebackground=PANEL, activeforeground=GOLD,
                        highlightthickness=0).pack(side="left")
        tk.Label(tests_row, text="(today's checks, see Settings)", font=label_font, bg=PANEL,
                 fg=DIM_TEXT).pack(side="left", padx=(8, 0))

        # 11/10 (owner: "add busy mode as a job") B.U.S.Y. job -- LOG ONLY for now: says what it WOULD do, taps nothing
        self.busy_var = tk.BooleanVar(value=False)
        busy_row = tk.Frame(list_frame, bg=PANEL)
        busy_row.pack(fill="x", padx=12, pady=4)
        tk.Checkbutton(busy_row, text="Busy Mode", variable=self.busy_var,
                        font=label_font, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                        activebackground=PANEL, activeforeground=GOLD,
                        highlightthickness=0).pack(side="left")
        tk.Label(busy_row, text="(makes + sells quick items)", font=label_font, bg=PANEL,
                 fg=DIM_TEXT).pack(side="left", padx=(8, 0))

        self._hidden_rows = set()

        # 11/14 (owner): Chat relay -- shown only with Settings > Experimental > Chat relay on
        self.chat_var = tk.BooleanVar(value=False)
        chat_row = tk.Frame(list_frame, bg=PANEL)
        chat_row.pack(fill="x", padx=12, pady=4)
        tk.Checkbutton(chat_row, text="Chat update", variable=self.chat_var,
                        font=label_font, bg=PANEL, fg=TEXT, selectcolor=PANEL,
                        activebackground=PANEL, activeforeground=GOLD,
                        highlightthickness=0).pack(side="left")
        tk.Label(chat_row, text="(club chat to your phone)", font=label_font, bg=PANEL,
                 fg=DIM_TEXT).pack(side="left", padx=(8, 0))
        if not self.chat_on_var.get():
            self._hidden_rows.add("Chat update")

        # Drag-to-reorder: grab the "≡" handle on a row and drag it up/down. The order is
        # remembered in ui_order.json. (Display order only -- the run order inside a cycle is
        # still fixed in afsd_core.run_loop.)
        self.list_parent = list_frame
        self.list_rows = [
            ("Auto Fulfill Orders", orders_row),
            ("Prep work", fishing_row),
            ("Delivery Event", delivery_row),
            ("Chef Challenge", chef_challenge_row),
            ("Food Club Event", event_orders_row),
            ("Food Truck (street)", street_truck_row),
            ("Tests", tests_row),
            ("Busy Mode", busy_row),
            ("Chat update", chat_row),
        ]
        for key, row in self.list_rows:
            first = row.winfo_children()[0]
            handle = tk.Label(row, text="\u2261", font=label_font, bg=PANEL, fg=DIM_TEXT,
                              cursor="fleur", padx=4)
            handle.pack(side="left", padx=(0, 6), before=first)
            handle.bind("<ButtonPress-1>", lambda e, f=row: self._drag_start(f))
            handle.bind("<B1-Motion>", self._drag_move)
            handle.bind("<ButtonRelease-1>", self._drag_end)
        self._restore_list_order()
        # 10/19 (owner): the ticks were not saved -- every reopen (incl. the automatic relaunch after an update)
        # came back with nothing ticked, so Start ran 10 min doing nothing. Remember them.
        for key, var in (("orders", self.orders_var), ("prep", self.prep_var), ("delivery", self.delivery_var),
                         ("chef", self.chef_challenge_var), ("food_club", self.event_orders_var),
                         ("street_truck", self.street_truck_var), ("tests", self.tests_var),
                         ("busy", self.busy_var), ("chat", self.chat_var)):
            var.set(bool(self._load_setting(f"job_{key}", 0)))
            var.trace_add("write", lambda *_, k=key, v=var: (self._save_setting(f"job_{k}", int(v.get())),
                                                             setattr(self, "_ow_version", -1)))   # redraw the Orders tab
        if not self.chat_on_var.get():
            self.chat_var.set(False)
        else:
            self._chat_start()

        button_row = tk.Frame(root, bg=BG)
        button_row.pack(pady=(24, 10))

        self.start_button = ui_kit.RoundButton(
            button_row, text="Start", font=label_font, bg=GOLD, fg="#1e1e1e",
            activebackground=GOLD_DIM, activeforeground="#1e1e1e",
            relief="flat", command=self._start_stop_clicked, chars=12,
        )
        self.start_button.pack(side="left")

        # 10/16: the Stats button was removed (owner) -- the Orders window replaces it. set_stats() stays
        # as a harmless no-op target because afsd_core still calls it.

        # 10/16: the Reload button was removed (owner) -- Start already reloads the automation modules
        # ("Auto-reloaded N modules at Start"), and an update is followed by reopening the app anyway.

        record_row = tk.Frame(root, bg=BG)
        record_row.pack(pady=(0, 6))
        # "Record ad": greyed out while AFSD runs (Stop first). Observe-only recorder, see ad_skip.py.
        self.recording_ad = False
        self.record_ad_button = ui_kit.RoundButton(
            record_row, text="Record ad", font=label_font, bg=PANEL, fg=TEXT,
            activebackground=GOLD_DIM, activeforeground="#1e1e1e",
            disabledforeground="#6a6a6a", relief="flat", command=self.record_ad,
            chars=9,
        )
        self.record_ad_button.pack(side="left", padx=(0, 6))

        # 10/25 (owner): "Let Me Play" -- pauses the bot, records every tap/drag YOU make (screen before + after,
        # templates/let_me_play/play_*/), "Done playing" starts the bot again if it was running. Observe only.
        self.playing = False
        self.play_button = ui_kit.RoundButton(
            record_row, text="Let Me Play", font=label_font, bg=PANEL, fg=TEXT,
            activebackground=GOLD_DIM, activeforeground="#1e1e1e",
            relief="flat", command=self.let_me_play, chars=11,
        )
        self.play_button.pack(side="left", padx=(0, 6))

        # One-off screenshot of the current screen for training data (read-only, always usable).
        self.shot_button = ui_kit.RoundButton(
            record_row, text="Screenshot", font=label_font, bg=PANEL, fg=TEXT,
            activebackground=GOLD_DIM, activeforeground="#1e1e1e",
            relief="flat", command=self.take_training_shot, chars=9,
        )
        self.shot_button.pack(side="left", padx=(0, 6))

        # 10/18: the Log and Recipes buttons became tabs on the right.
        self.log_window = None

        # Third row: "Debug pictures" switch (10/10). ON = the file .debug_pictures exists in the bot folder, and the
        # run trace (run_trace.py) saves before/after pictures around queue / harvest / plant taps into templates/debug_pictures/.
        debug_row = tk.Frame(root, bg=BG)
        debug_row.pack(pady=(0, 6))
        self.debug_pictures_button = ui_kit.RoundButton(
            debug_row, text="Debug pictures: OFF", font=label_font, bg=PANEL, fg=TEXT,
            activebackground=GOLD_DIM, activeforeground="#1e1e1e",
            relief="flat", command=self.toggle_debug_pictures, chars=20,
        )
        self.debug_pictures_button.pack(side="left")
        self._refresh_debug_pictures_button()
        # 10/15: new event / season -> new bottom-bar icon. Click it once to retrain (event_icon_trainer.py).
        ui_kit.RoundButton(
            debug_row, text="New event icon", font=label_font, bg=PANEL, fg=TEXT,
            activebackground=GOLD_DIM, activeforeground="#1e1e1e",
            relief="flat", command=self.train_event_icon, chars=14,
        ).pack(side="left", padx=(6, 0))

        # Fourth row: Send logs / Update (10/18: run inside AFSD, progress under Status -- no black windows;
        # the Orders button became a tab on the right).
        tools_row = tk.Frame(root, bg=BG)
        tools_row.pack(pady=(0, 6))
        for key, text in (("update", "Update"),):
            b = ui_kit.RoundButton(
                tools_row, text=text, font=label_font, bg=PANEL, fg=TEXT,
                activebackground=GOLD_DIM, activeforeground="#1e1e1e", relief="flat", chars=10,
                disabledforeground="#6a6a6a", command=lambda k=key: self.run_tool_inline(k),
            )
            b.pack(side="left", padx=(0, 6))
            self.tool_buttons[key] = b

        tk.Frame(root, bg=GOLD_DIM, height=1).pack(fill="x", padx=20, pady=(4, 8))

        self.status_var = tk.StringVar(value="Idle")
        tk.Label(root, text="Status:", font=status_font, bg=BG, fg=DIM_TEXT).pack()
        self.status_label = tk.Label(root, textvariable=self.status_var, font=label_font,
                                      bg=BG, fg=TEXT, wraplength=320, justify="center")
        self.status_label.pack(pady=(2, 10))

        # 10/17: live progress under the status -- cycle, run time, orders done this run, current item
        self.progress_var = tk.StringVar(value="")
        tk.Label(root, textvariable=self.progress_var, font=status_font, bg=BG, fg=GOLD,
                 wraplength=320, justify="center").pack(pady=(0, 6))
        self.root.after(1000, self._refresh_progress)

        self.log_var = tk.StringVar(value="")
        tk.Label(root, textvariable=self.log_var, font=status_font, bg=BG,
                 fg=DIM_TEXT, wraplength=320, justify="center").pack()

        # 10/16: the "Missing ingredients / dishes needed" panel was removed (owner) -- the Orders window
        # shows what every order still needs. missing_var stays (not shown) so set_missing() still works.
        self.missing_var = tk.StringVar(value="")

        # 10/18: Send logs / Update / the update check at Start report here (they used to open black windows)
        # 10/18 (owner): it is a TOAST -- hidden until something runs, green when done, then it slides away
        # after a few seconds. A warning / failure stays until clicked.
        # 10/18 (owner): on the RIGHT, above the tabs -- at the bottom of the left column it got hidden whenever
        # the column ran out of room (the Relaunch button vanished). Packed only while showing.
        self.toast = tk.Frame(self.right, bg=BG, height=1)
        self.toast.pack_propagate(False)
        strip = tk.Frame(self.toast, bg="#252525", highlightbackground="#333333", highlightthickness=1)
        strip.pack(fill="x")
        self._toast_strip = strip
        self._toast_job = None
        self.tool_var = tk.StringVar(value="")
        self.tool_label = tk.Label(strip, textvariable=self.tool_var, font=status_font, bg="#252525", fg=DIM_TEXT,
                                   wraplength=640, justify="left", anchor="w")
        self.tool_label.pack(fill="x", padx=8, pady=(6, 3))
        self.tool_bar = tk.Canvas(strip, height=6, bg="#333333", highlightthickness=0)
        self.tool_bar.pack(fill="x", padx=8, pady=(0, 7))
        self.tool_bar.bind("<Configure>", self._draw_tool_bar)
        # 10/18 (owner): when an update needs AFSD reopened, one click does it (and presses Start again)
        self.relaunch_button = ui_kit.RoundButton(strip, text="Relaunch AFSD now", font=status_font, bg=GOLD, fg="#1e1e1e",
                                         relief="flat", activebackground=GOLD_DIM, command=self.relaunch)
        # 10/18 (owner): a failure can be copied in one click and pasted to Claude
        self.copy_button = ui_kit.RoundButton(strip, text="Copy error for Claude", font=status_font, bg=PANEL, fg=TEXT,
                                     relief="flat", activebackground=GOLD_DIM, command=self._copy_tool_error)
        self._tool_error = ""
        for w in (strip, self.tool_label, self.tool_bar):         # 10/18: a click only dismisses a FINISHED message --
            w.bind("<Button-1>", lambda e: None if self._tool_lock.locked() else self._toast_hide())  # never one at work
        self._tool_lock = threading.Lock()      # 10/18 review: Send logs / Update / Start check never run at once
        self.root.after(60000, self._auto_cycle_tick)       # 10/22: auto restart every N min (Settings)
        self.root.after(20000, self._fc_start_tick)         # 11/13: "Start Food Club at" timer (Settings > Food Club)

        self._build_tabs(self.right)

        # 10/15: grow the window to fit everything packed, never past the screen (10/18: plus the tab area)
        win_root.update_idletasks()
        fit_w = max(1060, root.winfo_reqwidth() + 720)
        fit_h = max(700, root.winfo_reqheight() + 10)
        win_root.geometry(f"{min(fit_w, win_root.winfo_screenwidth() - 80)}x"
                          f"{min(fit_h, win_root.winfo_screenheight() - 80)}")
        win_root.after(500, lambda: self.version_var.set("Code version: " + self._code_version()))

        win_root.protocol("WM_DELETE_WINDOW", self.on_close)

    def set_status(self, text):
        self.status_var.set(text)

    def set_log(self, text):
        self.log_var.set(text)

    def set_missing(self, summary):
        """Renders order_fulfill.summarize_missing()'s output as a compact
        multi-line shopping list. Shows a positive "nothing missing"
        message rather than leaving the panel blank when a cycle finds
        nothing blocked -- an empty widget looks identical to "hasn't
        updated," which isn't the same thing."""
        ing = summary.get("ingredient_counts", {})
        dishes = summary.get("dish_counts", {})
        if not ing and not dishes:
            self.missing_var.set("Nothing missing -- last check found no blocked items.")
            return
        lines = []
        if ing:
            ing_line = ", ".join(f"{name} x{count}" for name, count in
                                  sorted(ing.items(), key=lambda kv: -kv[1]))
            lines.append(f"Ingredients needed: {ing_line}")
        if dishes:
            dish_line = ", ".join(f"{name} x{count}" for name, count in
                                   sorted(dishes.items(), key=lambda kv: -kv[1]))
            lines.append(f"Dishes still blocked: {dish_line}")
        self.missing_var.set("\n".join(lines))

    def _active_checkboxes(self):
        active = []
        if self.pork_var.get():
            active.append("Pork")
        if self.cream_var.get():
            active.append("Whipped Cream")
        if self.carrot_var.get():
            active.append("Carrots")
        if self.orders_var.get():
            active.append("Clipboard Orders")
        if self.prep_var.get():
            active.append("Prep work")
        if self.delivery_var.get():
            active.append("Delivery Event")
        if self.food_truck_var.get():
            active.append("Food Truck Event")
        if self.chef_challenge_var.get():
            active.append("Chef Challenge")
        if self.event_orders_var.get():
            active.append("Food Club Event")
        if self.street_truck_var.get():
            active.append("Food Truck (street)")
        if getattr(self, "tests_var", None) is not None and self.tests_var.get():
            active.append("Tests")
        if getattr(self, "busy_var", None) is not None and self.busy_var.get():
            active.append("Busy Mode")
        return active or ["none"]

    def reload_modules(self):
        """Re-imports the automation modules from disk so an edited .py
        file takes effect without closing and relaunching this whole app
        -- Python only reads a module's source once, at the first import,
        so a live-edited file otherwise keeps running the old code until
        the process restarts. Refuses while a cycle is running, since
        reloading a module out from under an in-progress call is a good
        way to get a confusing half-old-half-new state."""
        if self.running:
            self.set_status("Stop first, then Reload.")
            log("Reload pressed while running -- ignored.")
            return
        try:
            import pig_pen_check as m_pig, dairy_check as m_dairy, order_fulfill as m_of, \
                garden_check as m_garden, delivery_event as m_deliv, \
                food_truck_event as m_truck, chef_challenge as m_chef, event_orders as m_event
            import find_and_center as m_fac
            importlib.reload(m_fac)  # FIRST: other modules do `from find_and_center import ...`
            importlib.reload(m_pig)
            importlib.reload(m_dairy)
            importlib.reload(m_of)
            importlib.reload(m_garden)  # after order_fulfill -- imports find_question_button from it
            importlib.reload(m_deliv)
            importlib.reload(m_truck)
            importlib.reload(m_chef)
            importlib.reload(m_event)  # after order_fulfill (uses `import order_fulfill as of`)
            # afsd_core -- the actual per-cycle orchestration logic (see its
            # own module docstring, 9/29) -- reloaded LAST so its own
            # `import X` statements bind against whatever's freshest, though
            # since reload mutates a module's existing object in place
            # rather than replacing it, order here isn't strictly load-
            # bearing the way it is for garden_check above (afsd_core never
            # uses `from X import Y`, specifically to avoid that trap).
            importlib.reload(afsd_core)
            log("Reload pressed -- all automation modules AND afsd_core re-imported from disk.")
            self.set_status("Modules reloaded.")
        except Exception as e:
            log(f"Reload failed: {e}\n{traceback.format_exc()}")
            self.set_status(f"Reload failed: {e}")

    ORDER_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui_order.json")
    SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui_settings.json")

    def _load_setting(self, key, default):
        try:
            import json
            with open(self.SETTINGS_FILE, encoding="utf-8") as fh:
                return int(json.load(fh).get(key, default))
        except Exception:                                  # noqa: BLE001
            return default

    def _save_setting(self, key, value):
        try:
            import json
            try:
                with open(self.SETTINGS_FILE, encoding="utf-8") as fh:
                    data = json.load(fh)
            except Exception:                              # noqa: BLE001
                data = {}
            data[key] = int(str(value).strip()) if str(value).strip().isdigit() else data.get(key, 5)
            with open(self.SETTINGS_FILE, "w", encoding="utf-8") as fh:
                json.dump(data, fh)
        except Exception:                                  # noqa: BLE001
            pass

    def _repack_list(self, rows):
        self.list_rows = rows
        hidden = getattr(self, "_hidden_rows", set())
        for _, f in rows:
            f.pack_forget()
        for k, f in rows:
            if k not in hidden:                          # rows hidden by their Settings switch (Chat)
                f.pack(fill="x", padx=12, pady=4)

    def _restore_list_order(self):
        try:
            import json
            with open(self.ORDER_FILE, encoding="utf-8") as fh:
                saved = json.load(fh)
        except Exception:                                  # noqa: BLE001
            saved = []
        saved = ["Garden Plot" if str(k).startswith("Garden Plot") else k for k in saved]  # renamed 10/3
        saved = ["Food Club Event" if str(k).startswith(("Event Orders", "Food Club Event")) else k for k in saved]  # renamed 10/10
        saved = ["Prep work" if str(k).startswith("Keep fishing") else k for k in saved]  # replaced 10/19
        by_key = dict(self.list_rows)
        rows = [(k, by_key[k]) for k in saved if k in by_key]
        rows += [(k, f) for k, f in self.list_rows if k not in saved]
        self._repack_list(rows)

    def _drag_start(self, frame):
        self._drag_frame = frame
        frame.config(bg=GOLD_DIM)

    def _drag_move(self, event):
        frame = getattr(self, "_drag_frame", None)
        if frame is None:
            return
        y = event.y_root - self.list_parent.winfo_rooty()
        others = [(k, f) for k, f in self.list_rows if f is not frame]
        idx = sum(1 for _, f in others if f.winfo_y() + f.winfo_height() / 2 < y)
        key = next(k for k, f in self.list_rows if f is frame)
        new = others[:idx] + [(key, frame)] + others[idx:]
        if [f for _, f in new] != [f for _, f in self.list_rows]:
            self._repack_list(new)

    def _drag_end(self, event):
        frame = getattr(self, "_drag_frame", None)
        self._drag_frame = None
        if frame is not None:
            frame.config(bg=PANEL)
        try:
            import json
            with open(self.ORDER_FILE, "w", encoding="utf-8") as fh:
                json.dump([k for k, _ in self.list_rows], fh)
        except Exception:                                  # noqa: BLE001
            pass

    def _update_ad_button(self):
        """Record ad is only usable while AFSD is stopped; Start is locked while recording."""
        if self.recording_ad:
            self.record_ad_button.config(text="Cancel recording", state="normal")
            self.start_button.config(state="disabled")
        else:
            self.record_ad_button.config(text="Record ad",
                                         state="disabled" if self.running else "normal")
            self.start_button.config(state="normal")
        if getattr(self, "tool_buttons", None):                 # 10/18: Update only while stopped
            self.tool_buttons["update"].config(state="disabled" if self.running else "normal")

    LOG_TAIL_BYTES = 80000
    LOG_MAX_LINES = 600

    def open_recipes(self):
        """Recipe book + order cost calculator window (built into this file)."""
        try:
            if self.recipe_win is not None and self.recipe_win.winfo_exists():
                self.recipe_win.lift()
                return
        except tk.TclError:
            pass
        try:
            self.recipe_win = open_recipe_window(
                self.root, {"BG": BG, "PANEL": PANEL, "GOLD": GOLD, "TEXT": TEXT, "DIM": DIM_TEXT})
        except Exception as e:                       # noqa: BLE001
            log(f"Recipes window failed: {e}\n{traceback.format_exc()}")
            self.set_status(f"Recipes window failed: {e}")

    DEBUG_FLAG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".debug_pictures")

    def _refresh_debug_pictures_button(self):
        on = os.path.exists(self.DEBUG_FLAG_FILE)
        self.debug_pictures_button.config(
            text="Debug pictures: ON" if on else "Debug pictures: OFF",
            bg=GOLD if on else PANEL, fg="#1e1e1e" if on else TEXT)

    def toggle_debug_pictures(self):
        """Switch the debug pictures on/off by creating / deleting the file .debug_pictures (the run trace checks for it every time)."""
        try:
            if os.path.exists(self.DEBUG_FLAG_FILE):
                os.remove(self.DEBUG_FLAG_FILE)
                self.set_status("Debug pictures OFF.")
            else:
                open(self.DEBUG_FLAG_FILE, "w").close()
                self.set_status("Debug pictures ON -- before/after pictures go to templates/debug_pictures/ (newest 200).")
        except OSError as e:
            self.set_status(f"Could not switch debug pictures: {e}")
        self._refresh_debug_pictures_button()

    def open_log_window(self, prefilter=""):
        """10/18: the log is the Log tab now -- show it (Record ad opens it filtered to [ads])."""
        self._show_tab("log")
        if prefilter:
            self.log_filter_var.set(prefilter)

    # 10/20 redesign (owner picked the "Raw" view): the full log, coloured by area, tracebacks folded into one line,
    # chips with counts instead of typing filters. The file itself (what Send logs sends) is unchanged.
    LOG_CHIPS = (("all", "All"), ("club", "Food Club"), ("clip", "Clipboard"), ("prep", "Prep"),
                 ("problem", "Problems"), ("test", "Tests"))
    LOG_PROBLEM = re.compile(r"EXCEPTION|Traceback|\bfailed\b|timed out|\berror\b|crash|not answering|stuck", re.I)
    LOG_TEST = re.compile(r"tests?\]|\[worth\]|\[sim|\[forecast|\[express plan\]|\[score\]")

    def _log_kind(self, line):
        if self.LOG_PROBLEM.search(line) and "(ignored)" not in line:
            return "problem"
        if "[prep" in line:
            return "prep"
        if self.LOG_TEST.search(line):
            return "test"
        if "[event]" in line:
            return "club"
        if "[order_fulfill]" in line:
            return "clip"
        return "other"

    def _build_log(self, win, prefilter=""):
        """Live tail of run_log.txt: search box + chips, colour per area, folded tracebacks."""
        import ui_kit as ui
        self.log_window = win
        top = tk.Frame(win, bg=BG)
        top.pack(fill="x", padx=14, pady=(4, 4))
        tk.Label(top, text="\u2315", font=ui.font(12), bg=BG, fg=DIM_TEXT).pack(side="left")
        self.log_filter_var = tk.StringVar(value=prefilter)
        ui.entry(top, self.log_filter_var, width=30, bg=BG).pack(side="left", fill="x", expand=True, padx=(4, 14),
                                                                 ipady=2)
        self.log_follow_var = tk.BooleanVar(value=True)
        tk.Label(top, text="follow", font=ui.font(9), bg=BG, fg=DIM_TEXT).pack(side="left", padx=(0, 4))
        ui.Switch(top, self.log_follow_var, bg=BG).pack(side="left")
        self.log_chip_frame = tk.Frame(win, bg=BG)
        self.log_chip_frame.pack(fill="x", padx=14, pady=(0, 6))
        self.log_chip = "all"
        self._log_counts = {}
        frame = ui.card(win, bg=ui.mix(BG, "#000000", 0.25), stretch=True)
        frame.pack(fill="both", expand=True, padx=14, pady=(0, 10))
        t = tk.Text(frame, bg=ui.mix(BG, "#000000", 0.25), fg=TEXT, font=("Consolas", 9), wrap="word",
                    state="disabled", relief="flat", padx=8, pady=6, spacing1=1, cursor="arrow", highlightthickness=0, bd=0,
                    selectbackground=GOLD_DIM)
        self.log_text = t
        sb = getattr(ui, "ThinScrollbar", tk.Scrollbar)(frame, command=t.yview)   # 11/9: dark, thin
        t.config(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        t.pack(side="left", fill="both", expand=True)
        t.tag_configure("ts", foreground="#6a6a6a")
        t.tag_configure("ln", lmargin2=tkfont.Font(family="Consolas", size=9).measure("00:00:00  "))
        for k, col in (("club", GOLD), ("clip", ui.BLUE), ("prep", ui.TEAL), ("test", ui.PURPLE),
                       ("problem", ui.RED), ("other", DIM_TEXT)):
            t.tag_configure("tag_" + k, foreground=col)
            t.tag_configure("msg_" + k, foreground=TEXT if k != "problem" else "#f0a0a0")
        t.tag_configure("msg_other", foreground="#c8c8c8")
        t.tag_configure("fold", foreground="#8a8a8a")
        t.tag_configure("foldbtn", foreground=GOLD, underline=True)
        t.tag_bind("foldbtn", "<Enter>", lambda e: t.config(cursor="hand2"))
        t.tag_bind("foldbtn", "<Leave>", lambda e: t.config(cursor="arrow"))
        t.tag_bind("foldbtn", "<Button-1>", self._log_toggle_fold)
        self._log_pos = None
        self._log_lines = []
        self._log_last_filter = None
        self._log_draw_chips()
        self._log_poll()

    def _log_draw_chips(self):
        import ui_kit as ui
        for w in self.log_chip_frame.winfo_children():
            w.destroy()
        cols = {"club": GOLD, "clip": ui.BLUE, "prep": ui.TEAL, "problem": ui.RED, "test": ui.PURPLE}
        for key, text in self.LOG_CHIPS:
            n = None if key == "all" else self._log_counts.get(key, 0)
            ui.chip(self.log_chip_frame, text, key == self.log_chip, lambda k=key: self._log_set_chip(k), n, bg=BG,
                    color=cols.get(key, GOLD)).pack(side="left", padx=(0, 4))

    def _log_set_chip(self, key):
        self.log_chip = key
        self._log_pos = None                      # redraw everything with the new filter
        self._log_draw_chips()

    def _log_toggle_fold(self, event):
        t = self.log_text
        idx = t.index(f"@{event.x},{event.y}")
        for name in t.tag_names(idx):
            if name.startswith("fb_"):
                body = "fl_" + name[3:]
                hidden = bool(int(t.tag_cget(body, "elide") or 0))
                t.tag_configure(body, elide=not hidden)
                rng = t.tag_ranges(name)
                if rng:
                    old = t.get(rng[0], rng[1])
                    t.config(state="normal")
                    t.delete(rng[0], rng[1])
                    t.insert(rng[0], old.replace("\u25b8", "\u25be") if hidden else old.replace("\u25be", "\u25b8"),
                             ("foldbtn", name))
                    t.config(state="disabled")
                return

    def _log_group(self, lines):
        """[(head line, [continuation lines])] -- a line not starting with '[20..' belongs to the line above."""
        groups = []
        for ln in lines:
            if groups and not ln.startswith("[20"):
                groups[-1][1].append(ln)
            else:
                groups.append((ln, []))
        return groups

    def _log_render(self, groups, append):
        t = self.log_text
        t.config(state="normal")
        if not append:
            t.delete("1.0", "end")
            self._log_nfold = 0
        for head, rest in groups:
            if t.index("end-1c") != "1.0":
                t.insert("end", "\n")
            kind = self._log_kind(head + (" " + rest[-1] if rest else ""))
            m = re.match(r"\[(\d{4}-\d\d-\d\d)T(\d\d:\d\d:\d\d)\] ((?:\[[^\]]+\] ?)*)(.*)", head)
            if m:
                t.insert("end", m.group(2) + "  ", ("ts", "ln"))
                if m.group(3):
                    t.insert("end", m.group(3), ("tag_" + kind, "ln"))
                t.insert("end", m.group(4), ("msg_" + kind, "ln"))
            else:
                t.insert("end", head, ("msg_" + kind, "ln"))
            if rest:
                self._log_nfold += 1
                n = self._log_nfold
                what = "traceback" if any("Traceback" in r for r in rest) else "more"
                t.insert("end", "   ", "ln")
                t.insert("end", f"\u25b8 {len(rest)} lines ({what})", ("foldbtn", f"fb_{n}", "ln"))
                t.tag_configure(f"fl_{n}", elide=True)
                t.insert("end", "\n" + "\n".join("        " + r for r in rest), ("fold", f"fl_{n}"))
        t.config(state="disabled")

    def close_log_window(self):
        self.log_window = None

    def _log_poll(self):
        win = self.log_window
        if win is None:
            return
        if self._tab != "log":                     # hidden tab: read nothing; reload when it is shown again
            self._log_pos = None
            win.after(800, self._log_poll)
            return
        try:
            flt = self.log_filter_var.get().strip().lower()
            size = os.path.getsize(LOG)
            reload_all = (self._log_pos is None) or (flt != self._log_last_filter) or size < self._log_pos
            if reload_all:
                start = max(0, size - self.LOG_TAIL_BYTES)
                self._log_lines = []
            else:
                start = self._log_pos
            with open(LOG, "rb") as fh:
                fh.seek(start)
                data = fh.read()
            self._log_pos = size
            self._log_last_filter = flt
            new = data.decode("utf-8", "replace").splitlines()
            if reload_all and start > 0 and new:
                new = new[1:]                      # first line may be cut in half
            if not new and not reload_all:
                win.after(800, self._log_poll)
                return
            kind = lambda g: self._log_kind(g[0] + (" " + g[1][-1] if g[1] else ""))      # noqa: E731
            # a traceback can arrive in pieces: a read that starts mid-traceback is regrouped with what came before
            full = reload_all or (new and not new[0].startswith("[20")) or \
                int(self.log_text.index("end-1c").split(".")[0]) > self.LOG_MAX_LINES * 3
            self._log_raw = (([] if reload_all else getattr(self, "_log_raw", [])) + new)[-self.LOG_MAX_LINES * 4:]
            groups = self._log_group(self._log_raw if full else new)
            if full:
                self._log_counts = {}
            for g in groups:
                self._log_counts[kind(g)] = self._log_counts.get(kind(g), 0) + 1
            if self.log_chip != "all":
                groups = [g for g in groups if kind(g) == self.log_chip]
            if flt:
                groups = [g for g in groups if flt in (g[0] + " ".join(g[1])).lower()]
            if full:
                groups = groups[-self.LOG_MAX_LINES:]
            y = self.log_text.yview()
            if groups or full:
                self._log_render(groups, append=not full)
                if self.log_follow_var.get():
                    self.log_text.see("end")
                elif full:
                    self.log_text.yview_moveto(y[0])
            self._log_draw_chips()
        except Exception:                          # noqa: BLE001 -- a viewer must never crash the app
            pass
        win.after(800, self._log_poll)

    # ------------------------------------------------------------------
    # Orders window (10/16): live view of what every order needs and what the bot is doing about it
    # ------------------------------------------------------------------
    ORDER_KIND_STYLE = {          # kind -> (symbol, colour)
        "done": ("\u2713", "#6fcf6f"),
        "active": ("\u25d0", GOLD),
        "cooking": ("\u25cf", "#f0a040"),
        "growing": ("\u2618", "#4fc3a1"),
        "waiting": ("\u2026", "#9a9a9a"),
        "stuck": ("\u2715", "#e06060"),
        "todo": ("\u25cb", "#7a7a7a"),
    }
    SPINNER = "\u25d0\u25d3\u25d1\u25d2"

    def open_orders_window(self):
        self._show_tab("orders")

    def _build_orders(self, win):
        """10/18: the Orders tab (was its own window)."""
        self.orders_win = win
        f_title = tkfont.Font(family="Segoe UI", size=15, weight="bold")
        f_sec = tkfont.Font(family="Segoe UI", size=11, weight="bold")
        f_row = tkfont.Font(family="Segoe UI", size=10)
        f_small = tkfont.Font(family="Segoe UI", size=9)
        f_sym = tkfont.Font(family="Segoe UI Symbol", size=12)
        self._ow_fonts = (f_sec, f_row, f_small, f_sym)

        head = tk.Frame(win, bg=BG)
        head.pack(fill="x", padx=14, pady=(4, 4))
        self._ow_dot = tk.Label(head, text="\u25cf", font=f_sym, bg=BG, fg="#555555")
        self._ow_dot.pack(side="left", padx=(0, 4))
        self._ow_age = tk.Label(head, text="waiting for the bot...", font=f_small, bg=BG, fg=DIM_TEXT)
        self._ow_age.pack(side="left")
        # tabs (10/16): Now = live orders, History = every completed order
        # 11/2 (#30, owner approved): one tab per board -- Food Club / Clipboard / History
        self._ow_tab = "fc" if self.event_orders_var.get() or not self.orders_var.get() else "clip"
        self._ow_tabs = {}
        for key, text in (("history", "History"), ("clip", "Clipboard"), ("fc", "Food Club")):
            b = ui_kit.RoundButton(head, text=text, font=f_small, chars=9, pady=4, command=lambda k=key: self._ow_switch(k))
            b.pack(side="right", padx=(4, 0), before=self._ow_dot)   # 11/3: packed first = never squeezed out
            self._ow_tabs[key] = b
        self._ow_style_tabs()
        # 10/20 redesign: stats strip (numbers the bot already measures) + "Now:" bar
        import ui_kit as ui
        self._ow_stats = tk.Frame(win, bg=BG)
        self._ow_stats.pack(fill="x", padx=14, pady=(4, 6))
        self._ow_tiles = {}
        for i, (key, label) in enumerate((("pph", "Points / hour"), ("score", "Score"), ("storage", "Storage"),
                                          ("done", "Completed"))):
            self._ow_stats.columnconfigure(i, weight=1, uniform="tile")
            t = ui.card(self._ow_stats)
            t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 4, 0))
            tk.Label(t, text=label.upper(), font=ui.font(7, True), bg=ui.CARD, fg=ui.DIM).pack(anchor="w", padx=10,
                                                                                              pady=(7, 0))
            big = tk.Label(t, text="\u2014", font=ui.font(16, True), bg=ui.CARD, fg=TEXT, anchor="w")
            big.pack(anchor="w", padx=10)
            bar_holder = tk.Frame(t, bg=ui.CARD, height=5)
            bar_holder.pack(fill="x", padx=10)
            sub = tk.Label(t, text="", font=ui.font(8), bg=ui.CARD, fg=ui.DIM, anchor="w")
            sub.pack(anchor="w", padx=10, pady=(1, 7))
            self._ow_tiles[key] = (big, bar_holder, sub)
        nowbar = ui.card(win, edge=GOLD_DIM)
        nowbar.pack(fill="x", padx=14, pady=(0, 6))
        tk.Label(nowbar, text="Now:", font=ui.font(10, True), bg=ui.CARD, fg=GOLD).pack(side="left", padx=(10, 6),
                                                                                       pady=5)
        self._ow_now = tk.Label(nowbar, text="", font=ui.font(10), bg=ui.CARD, fg=TEXT, anchor="w", justify="left",
                                wraplength=600)
        self._ow_now.pack(side="left", fill="x", expand=True)
        ads_slot = tk.Frame(win, bg=BG)                     # 11/2: ads line (shown only while ads are on)
        ads_slot.pack(fill="x")
        self._ow_ads = tk.Label(ads_slot, text="", font=ui.font(9), bg=BG, fg=DIM_TEXT, anchor="w")
        self._ow_ads_shown = False
        self._ow_ads_before = None
        self._ow_stats_t = 0

        outer = tk.Frame(win, bg=BG)
        outer.pack(fill="both", expand=True, padx=(14, 4), pady=(0, 10))
        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0)
        sb = getattr(ui, "ThinScrollbar", tk.Scrollbar)(outer, command=canvas.yview)          # 11/9: dark, thin
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y", padx=(4, 0))
        canvas.pack(side="left", fill="both", expand=True)
        body = tk.Frame(canvas, bg=BG)
        body_id = canvas.create_window((0, 0), window=body, anchor="nw")
        body.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        def resized(e):
            canvas.itemconfigure(body_id, width=e.width)
            if abs(e.width - getattr(self, "_ow_render_w", e.width)) > 20:     # cards wrap to the new width
                self._ow_render_w = e.width
                self._ow_version = -1
        canvas.bind("<Configure>", resized)
        # mouse wheel scrolls the orders only while the pointer is over them (the Log tab scrolls itself)
        wheel = lambda e: canvas.yview_scroll(int(-e.delta / 120), "units")       # noqa: E731
        canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", wheel))
        canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
        self._ow_body = body
        self._ow_canvas = canvas
        self._ow_version = -1
        self._ow_sig = None
        self._ow_spin = []          # (label, ) of rows being worked on right now
        self._ow_tick = 0
        self._ow_poll()

    def _ow_style_tabs(self):
        for k, b in self._ow_tabs.items():
            on = k == self._ow_tab
            b.config(bg=GOLD if on else PANEL, fg="#1e1e1e" if on else TEXT,
                     activebackground=GOLD_DIM, activeforeground="#1e1e1e")

    def _ow_switch(self, tab):
        if tab == self._ow_tab:
            return
        self._ow_tab = tab
        self._ow_stats_t = 0                   # 11/15: the Completed tile follows the sub tab at once
        self._ow_style_tabs()
        try:
            self._ow_canvas.yview_moveto(0)    # 11/2: a new tab starts at its top
        except Exception:                      # noqa: BLE001
            pass
        self._ow_version = -1                  # force a redraw of the chosen tab
        self._ow_sig = None

    def _ow_render_history(self):
        f_sec, f_row, f_small, f_sym = self._ow_fonts
        body = self._ow_body
        self._ow_gen = getattr(self, "_ow_gen", 0) + 1
        for w in body.winfo_children():
            w.destroy()
        self._ow_spin, self._ow_count = [], []
        try:
            import orders_view
            hist = orders_view.history()
        except Exception:                                # noqa: BLE001
            hist = []
        if not hist:
            tk.Label(body, text="No completed orders recorded yet.\nEvery order the bot completes from now on is listed here.",
                     font=f_row, bg=BG, fg=DIM_TEXT, justify="center").pack(pady=40)
            return
        import datetime as _dt
        today = _dt.date.today()
        by_day = {}
        for e in reversed(hist):                       # newest first
            by_day.setdefault(_dt.date.fromtimestamp(e["t"]), []).append(e)
        for day, entries in by_day.items():
            label = "TODAY" if day == today else "YESTERDAY" if (today - day).days == 1 else day.strftime("%A %b %d").upper()
            fc = sum(1 for e in entries if e["source"] == "Food Club Event")
            cb = len(entries) - fc
            coins = sum(e.get("reward") or 0 for e in entries)
            sec = tk.Frame(body, bg=BG)
            sec.pack(fill="x", pady=(10, 3))
            tk.Label(sec, text=label, font=f_sec, bg=BG, fg=GOLD).pack(side="left")
            missed = sum(1 for e in entries if e.get("missed"))
            summary = f"   {len(entries) - missed} completed  \u00b7  {fc - missed} Food Club  \u00b7  {cb} clipboard"
            if missed:
                summary += f"  \u00b7  {missed} express missed"
            pts = sum(e.get("points") or 0 for e in entries if not e.get("missed"))   # 10/30: missed pts shown, not counted
            if pts:
                summary += f"  \u00b7  +{pts:,} points"
            if coins:
                summary += f"  \u00b7  +{coins:,} coins"
            tk.Label(sec, text=summary, font=f_small, bg=BG, fg=DIM_TEXT).pack(side="left")
            for e in entries:
                miss, exp = bool(e.get("missed")), bool(e.get("express"))     # 10/18: express label, missed in red
                edge = "#e06060" if miss else (GOLD if exp else GOLD_DIM)
                row = tk.Frame(body, bg=PANEL, highlightbackground=edge, highlightthickness=2 if (miss or exp) else 1)
                row.pack(fill="x", pady=2)
                club = e["source"] == "Food Club Event"
                tk.Frame(row, bg="#e06060" if miss else (GOLD if club else "#4fa3e0"), width=4).pack(side="left", fill="y")
                tk.Label(row, text=_dt.datetime.fromtimestamp(e["t"]).strftime("%I:%M %p").lstrip("0"),
                         font=f_row, bg=PANEL, fg=TEXT, width=9, anchor="w").pack(side="left", padx=(8, 0))
                if miss:
                    tag, col = "\u2715 MISSED", "#e06060"
                elif e.get("by_hand"):
                    tag, col = "\u2605 BY HAND", GOLD
                elif exp:
                    tag, col = "\u2605 EXPRESS", GOLD
                else:
                    tag, col = ("Food Club", GOLD) if club else ("Clipboard", "#4fa3e0")
                tk.Label(row, text=tag, font=f_small, bg=PANEL, fg=col, width=10, anchor="w").pack(side="left")
                names = [f"{i['name'] or 'item'}" + (f" \u00d7{i['need']}" if i.get("need") and i["need"] > 1 else "")
                         for i in e.get("items", [])]
                text = ", ".join(names) or "(items not read)"
                if miss:
                    text += "\nnot completed by the bot: it expired, or was finished by hand"
                tk.Label(row, text=text, font=f_small, bg=PANEL,
                         fg="#e08080" if miss else TEXT,
                         anchor="w", justify="left", wraplength=360).pack(side="left", fill="x", expand=True, pady=5)
                if e.get("reward"):
                    tk.Label(row, text=f"+{e['reward']:,}", font=f_row, bg=PANEL, fg="#f0c040").pack(side="right", padx=8)
                elif e.get("points"):                   # 10/18: Food Club points from the scoreboard
                    shared = e.get("points_shared")
                    tk.Label(row, text=(f"~+{e['points']} pts" if shared else f"+{e['points']} pts"), font=f_row,
                             bg=PANEL, fg="#e06060" if miss else "#f0c040").pack(side="right", padx=8)

    @staticmethod
    def _ow_hist_key():
        """10/27: what the History tab / Recent feed show -- they redraw only when this changes."""
        try:
            import orders_view
            h = orders_view.history()
            return (len(h), repr(h[-5:]), time.strftime("%Y-%m-%d"))
        except Exception:                                # noqa: BLE001
            return None

    def _ow_poll(self):
        """Refresh loop of the Orders window. Always re-schedules itself, even if one refresh fails
        (10/16: a failing refresh used to stop the loop and freeze the window empty)."""
        try:
            alive = self._ow_poll_once()
        except Exception as e:                           # noqa: BLE001
            alive = True
            log(f"Orders window: refresh failed ({e!r}) -- trying again.")
        if alive:
            self.root.after(180, self._ow_poll)

    def _ow_poll_once(self):
        win = getattr(self, "orders_win", None)
        try:
            if win is None or not win.winfo_exists():
                self.orders_win = None
                return False
        except tk.TclError:
            self.orders_win = None
            return False
        if self._tab != "orders":                       # hidden tab: nothing to draw; redraw when shown
            self._ow_version = -1
            self._ow_sig = None
            return True
        try:
            import orders_view
            version, state = orders_view.snapshot()
        except Exception:                                # noqa: BLE001
            version, state = self._ow_version, {}
        if version != self._ow_version:
            forced = self._ow_version == -1             # tab switch / resize / shown again: always redraw
            self._ow_version = version
            if self._ow_tab == "history":
                hk = self._ow_hist_key()
                if forced or hk != getattr(self, "_ow_hist_k", None):
                    self._ow_hist_k = hk
                    self._ow_render_history()
                    ui_kit.fix_scroll(self._ow_canvas, self._ow_body)     # 11/2: no blank list after a shrink
            else:
                # 10/24 (#16a, flicker): a new version often changes nothing you can see (a re-read of the same
                # board) -- redraw only when the visible content changed; the age/countdowns/spinner tick anyway
                try:
                    look = repr(sorted((k, {a: b for a, b in v.items() if a not in ("time", "updated")})
                                       for k, v in state.items())) + repr(self.root.winfo_width())
                except Exception:                        # noqa: BLE001
                    look = None
                if forced or look is None or look != getattr(self, "_ow_look", None):
                    self._ow_look = look
                    self._ow_render(state, forced)
                    ui_kit.fix_scroll(self._ow_canvas, self._ow_body)     # 11/2: no blank list after a shrink
                else:                                    # 10/27: "read 14:02" froze while the board was re-read
                    self._ow_headers(state)
                    self._ow_recent_refresh()
        if time.time() - getattr(self, "_ow_stats_t", 0) > 2:
            self._ow_stats_t = time.time()
            try:
                self._ow_update_stats(state)
            except Exception:                            # noqa: BLE001 -- display only
                pass
        # header: live dot + "updated N s ago"
        newest = max([v.get("updated", 0) for v in state.values()] or [0])
        if newest:
            age = time.time() - newest
            self._ow_age.config(text=f"updated {int(age)} s ago" if age < 120 else f"updated {int(age // 60)} min ago")
            live = age < 15
            self._ow_dot.config(fg=("#6fcf6f" if self._ow_tick % 2 else "#3f8f3f") if live else "#555555")
        # countdowns ("ready in 2m 10s") on cooking / growing rows -- Step A of the cooking plan
        for lab, base, ready, approx in list(getattr(self, "_ow_count", [])):
            left = int(ready - time.time())
            if left > 0:
                tail = f"ready in {left // 60}m {left % 60:02d}s" + (" or later" if approx else "")
            else:
                tail = "should be ready now"
            try:
                lab.config(text=f"{base}  \u00b7  {tail}")
            except tk.TclError:
                self._ow_count.remove((lab, base, ready, approx))
        # 10/27: "New order coming" cards -- the minutes froze and the card stayed up after its time
        for lab, until, read in list(getattr(self, "_ow_new", [])):
            if until <= time.time():
                self._ow_new = []
                self._ow_version = -1                    # redraw on the next tick, without that card
                break
            try:
                lab.config(text=self._ow_new_text(until, read))
            except tk.TclError:
                self._ow_new.remove((lab, until, read))
        # spinner on the item being worked on
        self._ow_tick += 1
        for lab in list(self._ow_spin):
            try:
                lab.config(text=self.SPINNER[self._ow_tick % len(self.SPINNER)])
            except tk.TclError:
                self._ow_spin.remove(lab)
        return True

    def _ow_update_stats(self, state):
        """The four tiles + the Now: bar. Only numbers the bot already measures (scoreboard, storage banner,
        history); nothing here is a forecast."""
        import ui_kit as ui
        eo = sys.modules.get("event_orders")
        ov = sys.modules.get("orders_view")

        def tile(key, big, sub="", frac=None, col=GOLD):
            b, holder, s_ = self._ow_tiles[key]
            b.config(text=big)
            s_.config(text=sub)
            kids = holder.winfo_children()
            want = max(40, holder.winfo_width())
            if frac is None:
                for w in kids:
                    w.destroy()
            elif kids and abs(int(kids[0].cget("width")) - want) < 4:   # 10/27: redraw in place (the stats bars
                ui.set_bar(kids[0], frac, col)                            # blinked every 2 s)
            else:
                for w in kids:
                    w.destroy()
                holder.update_idletasks()
                ui.bar(holder, frac, col, width=max(40, holder.winfo_width()), height=4).pack(anchor="w")
        sc = getattr(eo, "_score", None) or {}
        started = (getattr(ov, "_run", None) or {}).get("started") if self.running else None
        try:                                             # 11/15 (owner): last 24 h -- points / hours running, and
            import points_day                            # points / 24 h in small grey
            p24, hrs, pph, flat = points_day.current()
        except Exception:                                # noqa: BLE001
            p24, hrs, pph, flat = 0, 0.0, None, 0.0
        if pph is not None:
            tile("pph", f"{pph:.0f}", f"{flat:.0f}/h over 24 h · {p24:,} pts in {hrs:.1f} h running")
        else:
            tile("pph", "—", f"shows after 10 min of running ({hrs * 60:.0f} min so far)")
        last = sc.get("last")
        if last:
            tile("score", f"{last[0]:,}", f"of {last[1]:,} this level", last[0] / max(1, last[1]))
        else:
            tile("score", "—", "read from the board")
        stg = (getattr(eo, "_storage", None) or {}).get("last")
        if stg:
            age = int((time.time() - (eo._storage.get("last_t") or time.time())) // 60)
            frac = stg[0] / max(1, stg[1])
            tile("storage", f"{stg[0]}/{stg[1]}", "nearly full" if stg[1] - stg[0] <= 3 else
                 (f"read {age} min ago" if age else "just read"), frac,
                 "#e06060" if frac >= 0.9 else "#f0a040" if frac >= 0.75 else "#6fcf6f")
        else:
            tile("storage", "—", "Food Club storage")
        hist = ov.history() if ov else []
        # 11/15 (owner): completed TODAY (since midnight), only the board of the selected sub tab
        src = {"fc": ov.FOOD_CLUB, "clip": ov.CLIPBOARD}.get(getattr(self, "_ow_tab", ""), None) if ov else None
        done = completed_today(hist, time.time(), src)
        exp = sum(1 for e in done if e.get("express"))
        tile("done", f"{len(done)}", (f"{exp} express ★ · " if exp else "") +
             {ov.FOOD_CLUB: "Food Club today", ov.CLIPBOARD: "clipboard today"}.get(src, "today") if ov else "today")
        active = None
        for src, d in state.items():
            for o in d.get("orders", []):
                for it in o["items"]:
                    if it.get("active"):
                        active = (it.get("name") or "an item", it.get("status", ""), o["no"], src)
        try:                                             # 11/2: "Ads: N watched this hour" while ads are on
            ap = sys.modules.get("ad_player")
            if ap is not None and getattr(ap, "ON", False):
                self._ow_ads.config(text="\u25b6 " + ap.status_line())
                if not self._ow_ads_shown:
                    self._ow_ads.pack(fill="x", padx=16, pady=(0, 4))
                    self._ow_ads_shown = True
            elif self._ow_ads_shown:
                self._ow_ads.pack_forget()
                self._ow_ads_shown = False
        except Exception:                                # noqa: BLE001 -- display only
            pass
        if active:
            name, st, no, src = active
            self._ow_now.config(text=f"{name} for {'Food Club' if src == 'Food Club Event' else 'clipboard'} "
                                     f"order {no}" + (f"  ·  {st}" if st else ""), fg=TEXT)
        else:
            self._ow_now.config(text=self.status_var.get() if self.running else "not running -- press Start",
                                fg=TEXT if self.running else DIM_TEXT)

    _HINTS = {}

    def _ow_item_look(self, it):
        """(kind, symbol, colour, have, need, bar fraction, count colour, status text) of one order item."""
        kind = "active" if it.get("active") else it.get("kind", "todo")
        sym, col = self.ORDER_KIND_STYLE.get(kind, self.ORDER_KIND_STYLE["todo"])
        have, need = it.get("have"), it.get("need")
        if have is not None and need is not None:
            frac = have / max(1, need)
            ccol = "#6fcf6f" if frac >= 1 or kind == "done" else ("#f0a040" if frac >= 0.5 or kind in (
                "cooking", "growing", "active") else "#e06060")
        else:
            frac, ccol = (1.0, "#6fcf6f") if kind == "done" else (None, None)
        st = it.get("status", "")
        if kind == "active" and not st:
            st = "working on it now"
        if st == "needs making" and it.get("name"):          # 10/24 (#16b): say WHAT it needs
            st = self._recipe_hint(it["name"]) or st
        return kind, sym, col, have, need, frac, ccol, st

    def _ow_countdown(self, d, it, kind, st_lab, st):
        if kind in ("cooking", "growing") or it.get("timer"):           # live countdown
            try:
                import orders_view
                tm = orders_view.timer_for(d, it.get("timer") or it.get("name"))
            except Exception:                            # noqa: BLE001
                tm = None
            if tm:
                self._ow_count.append((st_lab, st, tm[0], tm[1]))

    def _ow_closest(self, src, d):
        def missing(o):
            return sum(max(0, (i.get("need") or 1) - (i.get("have") or 0)) for i in o["items"]
                       if i.get("kind") != "done")
        open_cards = [o for o in d["orders"] if o["items"] and not all(i.get("kind") == "done" for i in o["items"])]
        return min(open_cards, key=missing)["no"] if len(open_cards) > 1 and src == "Food Club Event" else None

    def _ow_layout_key(self, state):
        """10/24 (#16a): everything that decides WHICH widgets the Orders tab has. Same key -> only texts, colours,
        bars and rings change, and _ow_patch updates them in place instead of rebuilding the page (flicker)."""
        key = [self.root.winfo_width(), getattr(self, "_ow_tab", "")]   # 11/2: tab too (Food Club / Clipboard)
        for src in ("Food Club Event", "Clipboard orders"):
            d = state.get(src) or {}
            if not (d.get("orders") or d.get("note")):
                key.append((src, None))
                continue
            orders = []
            for o in d["orders"]:
                tot, n_ok = len(o["items"]), sum(1 for i in o["items"] if i.get("kind") == "done")
                orders.append((o["no"], bool(o.get("express")), bool(o.get("dismissing")), o.get("sig") is not None,
                               bool(o.get("next_up")), bool(o.get("eta")), bool(tot and n_ok == tot),
                               tuple((i.get("name"), i.get("have") is None or i.get("need") is None,
                                      (i.get("have") is None or i.get("need") is None) and i.get("kind") == "done")
                                     for i in o["items"])))
            key.append((src, d.get("note"), self._ow_closest(src, d), tuple(orders),
                        len([u for u in d.get("new_orders", []) if u > time.time()])))
        if not any(k[1] is not None for k in key[2:]):
            key.append(tuple(self._active_checkboxes()) + (self.running,))
        return key

    def _ow_headers(self, state):
        """The "read 14:02:11 · completed this run: N" line of each board."""
        for src, d in state.items():
            hdr = (getattr(self, "_ow_refs", None) or {}).get("hdr", {}).get(src)
            if hdr is None or not d:
                continue
            done = sum(1 for o in d.get("orders", []) if o["items"] and all(i.get("kind") == "done" for i in o["items"]))
            extra = (f"   read {d['time']}" if d.get("time") else "   not read yet") + \
                f"  ·  completed this run: {d.get('completed', 0)}" + (f"  ·  {done} ready to serve" if done else "")
            try:
                hdr.config(text=extra)
            except tk.TclError:
                pass

    def _ow_patch(self, state):
        """Update the existing Orders cards in place (numbers, statuses, colours, bars, rings, header line)."""
        import ui_kit as ui
        self._ow_spin, self._ow_count = [], []
        self._ow_headers(state)
        for src, d in state.items():
            if not d or not d.get("orders"):
                continue
            for o in d["orders"]:
                refs = self._ow_refs["cards"].get((src, o["no"]))
                if refs is None:
                    raise KeyError(f"no card for {src} order {o['no']}")
                n_ok = sum(1 for i in o["items"] if i.get("kind") == "done")
                tot = len(o["items"])
                working = any(i.get("active") for i in o["items"])
                exp = bool(o.get("express"))
                getattr(refs["card"], "_card", refs["card"]).set_edge(GOLD if (exp or working) else ui.LINE, 2 if (exp or working) else 1)
                if refs.get("eta") is not None and o.get("eta"):            # 10/27: re-priced orders, in place
                    refs["eta"].config(text="⏱ " + o["eta"], font=ui.font(8, bool(o.get("eta_long"))),
                                       fg=_eta_color(o))
                ui.set_ring(refs["ring"], n_ok / tot if tot else 0, "#6fcf6f" if tot and n_ok == tot else GOLD,
                            f"{n_ok}/{tot}")
                for k, it in enumerate(o["items"]):
                    w = self._ow_refs["items"][(src, o["no"], k)]
                    kind, sym, col, have, need, frac, ccol, st = self._ow_item_look(it)
                    w["sym"].config(text=sym, fg=col)
                    if kind == "active":
                        self._ow_spin.append(w["sym"])
                    if w["count"] is not None:
                        w["count"].config(text=f"{have}/{need}", fg=ccol)
                    if w["bar"] is not None and frac is not None:
                        ui.set_bar(w["bar"], frac, ccol)
                    w["status"].config(text=st, fg=col)
                    self._ow_countdown(d, it, kind, w["status"], st)
        self._ow_recent_refresh()

    def _ow_recent_refresh(self):
        """10/27: redraw only the Recent feed when the history changed (it used to rebuild every order card)."""
        if getattr(self, "_ow_recent", None) is None:
            return
        hk = self._ow_hist_key()
        if hk != getattr(self, "_ow_recent_k", None):
            self._ow_recent_k = hk
            for w in self._ow_recent.winfo_children():
                w.destroy()
            self._ow_render_recent(self._ow_recent)

    def _recipe_hint(self, name):
        """10/24 (freetime #16b): 'needs Wheat 3, Egg 1, Butter 2 · Bread Oven 1h' from the recipe book (display only)."""
        if name in self._HINTS:
            return self._HINTS[name]
        hint = None
        try:
            import recipe_book as rb
            it = rb.load()["items"][rb.resolve(name)]
            where = it.get("station") or "?"
            if it.get("ingredients"):
                items = rb.load()["items"]
                parts = ", ".join(f"{items.get(k, {}).get('name', k.replace('_', ' ').title())} {n}"
                                  for k, n in it["ingredients"])
                hint = f"needs {parts} · {where}" + (f" {rb.fmt(it['cook_sec'])}" if it.get("cook_sec") else "")
            elif it["kind"] == "crop":
                hint = f"needs growing · {where}"
            elif it["kind"] in ("fruit", "animal"):
                hint = f"needs collecting · {where}"
        except Exception:                                # noqa: BLE001 -- unknown item: keep "needs making"
            hint = None
        self._HINTS[name] = hint
        return hint

    def _ow_render(self, state, forced=True):
        """10/20 redesign (report lab-x3m8d): each board as a row of cards like the game shows it (3 side by side),
        a progress ring per card, count + bar per item (red far / amber on the way / green done), the real status
        with a live countdown, and a short Recent feed. No coin badges yet (the ranking test isn't proven)."""
        import ui_kit as ui
        f_sec, f_row, f_small, f_sym = self._ow_fonts
        body = self._ow_body
        layout = self._ow_layout_key(state)               # 10/24 (#16a): same cards -> update them in place
        if not forced and layout == getattr(self, "_ow_layout", None) and getattr(self, "_ow_refs", None):
            try:
                self._ow_patch(state)
                return
            except Exception as e:                       # noqa: BLE001 -- fall back to a full redraw
                log(f"Orders window: in-place update failed ({e!r}) -- redrawing.")
        self._ow_layout = layout
        self._ow_refs = {"hdr": {}, "cards": {}, "items": {}}
        sig = tuple((src, tuple((o["no"], len(o["items"])) for o in d.get("orders", [])))
                    for src, d in sorted(state.items()))
        animate = forced and sig != self._ow_sig        # 10/27: load-in only when the tab is opened (Muse: flicker)
        self._ow_sig = sig
        self._ow_gen = getattr(self, "_ow_gen", 0) + 1
        gen = self._ow_gen
        for w in body.winfo_children():
            w.destroy()
        self._ow_spin = []
        self._ow_count = []
        self._ow_new = []
        self._ow_recent = None
        want_src = {"fc": "Food Club Event", "clip": "Clipboard orders"}.get(self._ow_tab)
        shown = {k: v for k, v in state.items() if want_src is None or k == want_src}
        if not any(d.get("orders") or d.get("note") for d in shown.values()):
            jobs = self._active_checkboxes()
            other = [k for k, v in state.items() if k != want_src and (v.get("orders") or v.get("note"))]
            if other and jobs != ["none"]:
                tk.Label(body, text="Nothing on this board right now", font=ui.font(14, True), bg=BG,
                         fg=GOLD).pack(pady=(40, 6))
                tk.Label(body, text=("The Clipboard tab" if want_src == "Food Club Event" else "The Food Club tab")
                         + " has orders.", font=f_row, bg=BG, fg=DIM_TEXT).pack()
                self._ow_recent = tk.Frame(body, bg=BG)
                self._ow_recent.pack(fill="x")
                self._ow_recent_k = self._ow_hist_key()
                self._ow_render_recent(self._ow_recent)
                return
            big = ui.font(16, True)
            if jobs == ["none"]:
                tk.Label(body, text="⚠  Nothing is ticked", font=big, bg=BG, fg="#f0c040").pack(pady=(40, 6))
                tk.Label(body, text="Tick Food Club Event (or another job) on the left, then press Start.",
                         font=f_row, bg=BG, fg=TEXT).pack()
            else:
                tk.Label(body, text="Press Start" if not self.running else "Reading the board...", font=big,
                         bg=BG, fg=GOLD).pack(pady=(40, 6))
                tk.Label(body, text=f"Ticked: {', '.join(jobs)}. The orders appear here as the bot reads the board.",
                         font=f_row, bg=BG, fg=DIM_TEXT, wraplength=560).pack()
            self._ow_recent = tk.Frame(body, bg=BG)
            self._ow_recent.pack(fill="x")
            self._ow_recent_k = self._ow_hist_key()
            self._ow_render_recent(self._ow_recent)
            return
        delay = 0
        for src in ("Food Club Event", "Clipboard orders"):
            d = state.get(src)
            if not d or not (d.get("orders") or d.get("note")) or (want_src and src != want_src):
                continue
            sec = tk.Frame(body, bg=BG)
            sec.pack(fill="x", pady=(6, 4))
            tk.Label(sec, text="FOOD CLUB" if src == "Food Club Event" else "CLIPBOARD", font=ui.font(11, True),
                     bg=BG, fg=GOLD).pack(side="left")
            done = sum(1 for o in d["orders"] if o["items"] and all(i.get("kind") == "done" for i in o["items"]))
            extra = (f"   read {d['time']}" if d.get("time") else "   not read yet") + \
                f"  ·  completed this run: {d.get('completed', 0)}"
            if done:
                extra += f"  ·  {done} ready to serve"
            hdr = tk.Label(sec, text=extra, font=f_small, bg=BG, fg=DIM_TEXT)
            hdr.pack(side="left")
            self._ow_refs["hdr"][src] = hdr
            if d.get("note"):
                tk.Label(body, text=d["note"], font=f_small, bg=BG, fg="#e0b050", anchor="w",
                         justify="left", wraplength=640).pack(fill="x", padx=2, pady=(0, 4))
            row = tk.Frame(body, bg=BG)
            row.pack(fill="x")
            per_row = 3
            bw_ = body.master.winfo_width()                  # the canvas: the body itself may not be sized yet
            self._ow_render_w = bw_
            cw = max(150, ((bw_ if bw_ > 50 else 680) - 8) // per_row)        # one card's width, for wrapping
            for c in range(per_row):
                row.columnconfigure(c, weight=1, uniform="ocard")
            closest = self._ow_closest(src, d)          # closest to done = fewest missing units (2+ cards open)
            for n, o in enumerate(d["orders"]):
                exp = bool(o.get("express"))
                working = any(i.get("active") for i in o["items"])
                edge = GOLD if (exp or working) else ui.LINE
                card = ui.card(row, edge=edge, thick=2 if (exp or working) else 1)
                rr, cc = divmod(n, per_row)
                inner = tk.Frame(card, bg=ui.CARD)
                inner.pack(fill="both", expand=True, padx=10, pady=8)
                n_ok = sum(1 for i in o["items"] if i.get("kind") == "done")
                tot = len(o["items"])
                top = tk.Frame(inner, bg=ui.CARD)
                top.pack(fill="x")
                tl = tk.Frame(top, bg=ui.CARD)
                tl.pack(side="left", fill="x", expand=True)
                head = tk.Frame(tl, bg=ui.CARD)                    # 10/21: "Order N" + Dismiss on one line
                head.pack(anchor="w", fill="x")
                tk.Label(head, text=f"Order {o['no']}", font=ui.font(11, True), bg=ui.CARD, fg=TEXT,
                         anchor="w").pack(side="left")
                tag = "★ EXPRESS" if exp else ("closest to done" if o["no"] == closest else
                                                    ("ready to serve" if tot and n_ok == tot else ""))
                if tag:
                    tk.Label(tl, text=tag, font=ui.font(8, True), bg=ui.CARD,
                             fg=GOLD if exp else ("#6fcf6f" if n_ok == tot else DIM_TEXT), anchor="w").pack(anchor="w")
                if src == "Clipboard orders" and o.get("dismissing"):                # 10/23
                    tk.Label(head, text="⏳ Dismissing…", font=ui.font(8, True), bg=ui.CARD,
                             fg="#f0a040").pack(side="left", padx=(10, 0))
                elif src == "Clipboard orders" and o.get("sig") is not None and not (tot and n_ok == tot):
                    lk = tk.Label(head, text="✕ Dismiss", font=ui.font(8, True), bg=ui.CARD, fg="#e06060",
                                  cursor="hand2")
                    lk.pack(side="left", padx=(10, 0))
                    lk.bind("<Button-1>", lambda _e, no=o["no"], sg=o["sig"]: self._dismiss_order(no, sg))
                if o.get("next_up") and not (tot and n_ok == tot):  # 10/22: quickest-first marker
                    tk.Label(tl, text="⚡ next up", font=ui.font(8, True), bg=ui.CARD, fg=GOLD,
                             anchor="w").pack(anchor="w")
                eta_lab = None
                if o.get("eta") and (o.get("eta_always") or not (tot and n_ok == tot)):  # 10/21 clipboard, 11/16 Food Club
                    eta_lab = tk.Label(tl, text="⏱ " + o["eta"], font=ui.font(8, bool(o.get("eta_long"))), bg=ui.CARD,
                                       fg=_eta_color(o), anchor="w")
                    eta_lab.pack(anchor="w")
                rg = ui.ring(top, n_ok / tot if tot else 0, "#6fcf6f" if tot and n_ok == tot else GOLD, size=36,
                             text=f"{n_ok}/{tot}", bg=ui.CARD)
                rg.pack(side="right")
                self._ow_refs["cards"][(src, o["no"])] = {"card": card, "ring": rg, "eta": eta_lab}
                for k, it in enumerate(o["items"]):
                    kind, sym, col, have, need, frac, ccol, st = self._ow_item_look(it)
                    tk.Frame(inner, bg=ui.mix(ui.CARD, "#ffffff", 0.06), height=1).pack(fill="x", pady=(6, 4))
                    r1 = tk.Frame(inner, bg=ui.CARD)
                    r1.pack(fill="x")
                    s_lab = tk.Label(r1, text=sym, font=f_sym, bg=ui.CARD, fg=col, width=2)
                    s_lab.pack(side="left")
                    if kind == "active":
                        self._ow_spin.append(s_lab)
                    c_lab = None
                    if have is not None and need is not None:
                        c_lab = tk.Label(r1, text=f"{have}/{need}", font=ui.font(10, True), bg=ui.CARD, fg=ccol)
                        c_lab.pack(side="right")
                    name = it.get("name") or f"item {k + 1} (name not learned yet)"
                    tk.Label(r1, text=name, font=ui.font(10, it.get("name") is not None), bg=ui.CARD,
                             fg=TEXT if it.get("name") else DIM_TEXT, anchor="w", justify="left",
                             wraplength=max(70, cw - 100)).pack(side="left", fill="x", expand=True)
                    b_cv = None
                    if frac is not None:
                        bh = tk.Frame(inner, bg=ui.CARD)
                        bh.pack(fill="x", padx=(26, 0), pady=(2, 0))
                        b_cv = ui.bar(bh, frac, ccol, width=max(60, cw - 60), height=3)
                        b_cv.pack(anchor="w")
                    st_lab = tk.Label(inner, text=st, font=ui.font(8), bg=ui.CARD, fg=col, anchor="w",
                                      justify="left", wraplength=max(80, cw - 56))
                    st_lab.pack(fill="x", padx=(26, 0), pady=(1, 0))
                    self._ow_refs["items"][(src, o["no"], k)] = {"sym": s_lab, "count": c_lab, "bar": b_cv,
                                                                 "status": st_lab}
                    self._ow_countdown(d, it, kind, st_lab, st)
                place = dict(row=rr, column=cc, sticky="nsew", padx=(0 if cc == 0 else 4, 0), pady=(0, 6))
                if animate:
                    self.root.after(delay, lambda c=card, g=gen, p=place: self._ow_grid(c, g, p))
                    delay += 90
                else:
                    card.grid(**place)
            if src == "Clipboard orders":                  # 10/21: dismissed orders -> "new order in N min" cards
                k = len(d["orders"])
                for until in sorted(u for u in d.get("new_orders", []) if u > time.time()):
                    rr, cc = divmod(k, per_row)
                    k += 1
                    card = ui.card(row, edge=ui.LINE, thick=1)
                    inner = tk.Frame(card, bg=ui.CARD)
                    inner.pack(fill="both", expand=True, padx=10, pady=8)
                    tk.Label(inner, text="New order coming", font=ui.font(11, True), bg=ui.CARD, fg=DIM_TEXT,
                             anchor="w").pack(anchor="w")
                    read = any(until in v for v in (d.get("new_orders_read") or {}).values())   # 10/26: the game's own time
                    nl = tk.Label(inner, text=self._ow_new_text(until, read), font=ui.font(9), bg=ui.CARD,
                                  fg="#f0a040", anchor="w")
                    nl.pack(anchor="w", pady=(4, 0))
                    self._ow_new.append((nl, until, read))
                    card.grid(row=rr, column=cc, sticky="nsew", padx=(0 if cc == 0 else 4, 0), pady=(0, 6))
        self._ow_recent = tk.Frame(body, bg=BG)          # 10/27: redrawn on its own when the history changes
        self._ow_recent.pack(fill="x")
        self._ow_recent_k = self._ow_hist_key()
        self._ow_render_recent(self._ow_recent)

    @staticmethod
    def _ow_new_text(until, read):
        return (f"⏱ in {'' if read else 'about '}{max(1, int((until - time.time()) // 60))} min "
                f"(at {time.strftime('%H:%M', time.localtime(until))})")

    def _ow_grid(self, widget, gen, place):
        if gen != getattr(self, "_ow_gen", 0):
            return
        try:
            if widget.winfo_exists():
                widget.grid(**place)
        except tk.TclError:
            pass

    def _ow_render_recent(self, body):
        """The last few completed orders (the full list is under History)."""
        import ui_kit as ui
        import datetime as _dt
        try:
            import orders_view
            hist = orders_view.history()[-5:]
        except Exception:                                # noqa: BLE001
            hist = []
        if not hist:
            return
        sec = tk.Frame(body, bg=BG)
        sec.pack(fill="x", pady=(10, 4))
        tk.Label(sec, text="RECENT", font=ui.font(11, True), bg=BG, fg=GOLD).pack(side="left")
        tk.Label(sec, text="   full list under History", font=ui.font(9), bg=BG, fg=DIM_TEXT).pack(side="left")
        box = ui.card(body)
        box.pack(fill="x")
        for e in reversed(hist):
            r = tk.Frame(box, bg=ui.CARD)
            r.pack(fill="x", padx=10, pady=3)
            club = e["source"] == "Food Club Event"
            if e.get("missed"):
                tag, col = "✕ MISSED", "#e06060"
            elif e.get("express"):
                tag, col = "★ EXPRESS", GOLD
            else:
                tag, col = ("Food Club", GOLD) if club else ("Clipboard", "#4fa3e0")
            ui.pill(r, tag, col, bg=ui.CARD, size=8).pack(side="left")
            names = ", ".join(f"{i['name'] or 'item'}" + (f" ×{i['need']}" if i.get("need") and i["need"] > 1
                                                          else "") for i in e.get("items", [])) or "(items not read)"
            tk.Label(r, text=names, font=ui.font(9), bg=ui.CARD, fg=TEXT, anchor="w").pack(side="left", padx=8)
            when = _dt.datetime.fromtimestamp(e["t"]).strftime("%I:%M %p").lstrip("0")
            gain = f"+{e['reward']:,} coins" if e.get("reward") else (
                (f"~+{e['points']} pts" if e.get("points_shared") else f"+{e['points']} pts") if e.get("points") else "")
            tk.Label(r, text=f"{gain}  ·  {when}" if gain else when, font=ui.font(9), bg=ui.CARD,
                     fg=("#e06060" if e.get("missed") else "#f0c040") if gain else DIM_TEXT).pack(side="right")

    def _refresh_progress(self):
        try:
            import orders_view
            self.progress_var.set(orders_view.progress() if self.running else "")
        except Exception:                                # noqa: BLE001
            pass
        self.root.after(1000, self._refresh_progress)

    # ------------------------------------------------------------------
    # 10/18: one window -- tabs, settings gear, Send logs / Update inside AFSD, Catering
    # ------------------------------------------------------------------
    TABS = (("orders", "Orders"), ("recipes", "Prep work"), ("truck", "\U0001f69a Food Truck"),
            ("busy", "\U0001f4b0 Busy Mode"), ("schedule", "\U0001f5d3 Schedule"),
            ("log", "Log"), ("settings", "\u2699 Settings"))

    def _tab_strip_fit(self):
        try:
            c = self._tab_canvas
            c.configure(scrollregion=(0, 0, self._tab_strip.winfo_reqwidth(), self._tab_strip.winfo_reqheight()),
                        height=self._tab_strip.winfo_reqheight())
        except tk.TclError:
            pass

    def _tab_scroll_bind(self, w):
        """11/15: wheel / drag on the tab strip scrolls it sideways (only when the tabs do not all fit)."""
        def fits():
            return self._tab_strip.winfo_reqwidth() <= self._tab_canvas.winfo_width()

        def wheel(e):
            if fits():
                return
            step = -1 if (getattr(e, "delta", 0) > 0 or getattr(e, "num", 0) == 4) else 1
            self._tab_canvas.xview_scroll(step * 3, "units")

        def press(e):
            self._tab_drag = (e.x_root, self._tab_canvas.canvasx(0))

        def motion(e):
            d = getattr(self, "_tab_drag", None)
            if not d or fits():
                return
            dx = e.x_root - d[0]
            if abs(dx) > 6:
                total = max(1, self._tab_strip.winfo_reqwidth())
                self._tab_canvas.xview_moveto(max(0.0, (d[1] - dx) / total))
                w.suppress_click = True
        for ev, fn in (("<MouseWheel>", wheel), ("<Button-4>", wheel), ("<Button-5>", wheel),
                       ("<ButtonPress-1>", press), ("<B1-Motion>", motion)):
            w.bind(ev, fn, add="+")

    def _build_tabs(self, parent):
        # 11/2 (owner approved): gold EXPRESS banner above the tabs, shown only while an express is on the board
        self._xbanner = tk.Label(parent, text="", font=tkfont.Font(family="Segoe UI", size=11, weight="bold"),
                                 bg=GOLD, fg="#1e1e1e", anchor="w", padx=12, pady=6, justify="left", wraplength=900)
        self._xbanner_on = False
        bar = tk.Frame(parent, bg=BG)
        self._tab_bar = bar
        bar.pack(fill="x", padx=14, pady=(16, 0))
        tk.Frame(parent, bg=GOLD_DIM, height=1).pack(fill="x", padx=14, pady=(8, 6))
        body = tk.Frame(parent, bg=BG)
        body.pack(fill="both", expand=True)
        self._tab = None
        self._tab_buttons, self._tab_frames = {}, {}
        f = tkfont.Font(family="Segoe UI", size=10)
        # 11/15 (owner: a small window hid tabs): the left tabs sit in a strip that scrolls sideways -- mouse wheel or
        # click-and-drag; Settings + the speed light stay fixed on the right.
        self._tab_canvas = tk.Canvas(bar, bg=BG, highlightthickness=0, bd=0, height=34)
        strip = tk.Frame(self._tab_canvas, bg=BG)
        self._tab_strip = strip
        self._tab_canvas.create_window(0, 0, window=strip, anchor="nw")
        for key, text in self.TABS:
            b = ui_kit.RoundButton(bar if key == "settings" else strip, text=text, font=f, padx=14, pady=5,
                                   command=lambda k=key: self._show_tab(k))
            b.pack(side="right" if key == "settings" else "left", padx=(0, 6))      # 10/19: Settings sits right
            self._tab_buttons[key] = b
            self._tab_frames[key] = tk.Frame(body, bg=BG)
            if key != "settings":
                self._tab_scroll_bind(b)
        self._tab_scroll_bind(self._tab_canvas)
        strip.bind("<Configure>", lambda e: self._tab_strip_fit())
        # 11/9 (owner: "only the jobs part loads ... jammed into a small window"): one tab that fails to build must
        # never take the whole window down -- each tab is built on its own; a failure shows a note on that tab and
        # the full traceback goes to run_log.txt (Send logs still works from the left column).
        self.recipe_win = None
        for key, build in (("orders", self._build_orders), ("recipes", self._build_prep),
                           ("truck", self._build_truck), ("busy", self._build_busy), ("schedule", self._build_schedule), ("log", self._build_log),
                           ("settings", self._build_settings)):
            try:
                build(self._tab_frames[key])
            except Exception as e:                       # noqa: BLE001
                log(f"[window] the {key} tab failed to build: {e!r}\n{traceback.format_exc()}")
                try:
                    tk.Label(self._tab_frames[key], text=f"This tab could not load: {e}\n\nPress Send logs and tell "
                             "Claude -- the details are in the log.", bg=BG, fg=DIM_TEXT, justify="center",
                             wraplength=500).pack(pady=40)
                except tk.TclError:
                    pass
        # 11/2 speed light: is FLASH (window looks) / fast taps working right now?
        self._speed_light = tk.Label(bar, text="\u25cf", font=tkfont.Font(family="Segoe UI Symbol", size=11),
                                     bg=BG, fg="#555555")
        # 11/3: Settings + the light are packed BEFORE the left tabs, so a narrow window squeezes the left tabs,
        # never the Settings button (it used to vanish below ~1000 px wide)
        self._speed_light.pack(side="right", padx=(0, 8))
        self._tab_canvas.pack(side="left", fill="x", expand=True)
        ui_kit.hover_card(self._speed_light, lambda: getattr(self, "_speed_light_text", "FLASH"))
        if not self.schedule_on_var.get():
            self._tab_buttons["schedule"].pack_forget()   # 11/14: only with Settings > Experimental > Schedule
        self._show_tab("orders")
        self.root.after(2000, self._ui_poll)

    def _ui_poll(self):
        """Every 2 s, on any tab: the EXPRESS banner and the speed light. Display only."""
        try:
            eo = sys.modules.get("event_orders")
            txt = eo.banner_text() if (eo is not None and self.running) else ""
            if txt:
                self._xbanner.config(text=txt, wraplength=max(400, self.right.winfo_width() - 60))
                if not self._xbanner_on:
                    self._xbanner.pack(fill="x", padx=14, pady=(12, 0), before=self._tab_bar)
                    self._xbanner_on = True
            elif self._xbanner_on:
                self._xbanner.pack_forget()
                self._xbanner_on = False
        except Exception:                                # noqa: BLE001
            pass
        try:
            import flash
            col, text = flash.light_now()
            self._speed_light.config(fg={"green": "#6fcf6f", "amber": "#f0a040"}.get(col, "#555555"))
            self._speed_light_text = text
        except Exception:                                # noqa: BLE001
            pass
        if self.running:                                 # 11/15: hours running in the last 24 h (Points / hour tile)
            try:
                import points_day
                points_day.note_running()
            except Exception:                            # noqa: BLE001
                pass
        try:
            self.root.after(2000, self._ui_poll)
        except tk.TclError:
            pass

    @staticmethod
    def _widget_words(w):
        """Every label / button text under a widget (Settings search)."""
        out = []
        for c in w.winfo_children():
            try:
                t = c.cget("text")
                if t:
                    out.append(str(t))
            except tk.TclError:
                pass
            out += AutoFoodStreetApp._widget_words(c)
        return out

    def _show_tab(self, key):
        if key == self._tab:
            return
        for k, fr in self._tab_frames.items():
            fr.pack_forget()
            on = k == key
            self._tab_buttons[k].config(bg=GOLD if on else PANEL, fg="#1e1e1e" if on else TEXT,
                                        activebackground=GOLD_DIM, activeforeground="#1e1e1e")
        self._tab_frames[key].pack(fill="both", expand=True)
        self._tab = key
        self._apply_jobs_column()
        if key == "settings":
            self.version_var.set("Code version: " + self._code_version())

    def _build_schedule(self, win):
        """11/14 (owner): the Schedule tab -- calendar of job blocks (schedule_tab.py)."""
        import ui_kit as ui
        import schedule_tab
        self._schedule = schedule_tab.ScheduleTab(self, win, ui, log)

    def _apply_schedule(self):
        on = bool(self.schedule_on_var.get())
        self._save_setting("schedule_on", int(on))
        b = self._tab_buttons["schedule"]
        if on:
            b.pack(side="left", padx=(0, 6), before=self._tab_buttons["log"])
        else:
            b.pack_forget()
            if self._tab == "schedule":
                self._show_tab("orders")
        log(f"[schedule] Schedule tab switched {'ON' if on else 'OFF'} in Settings.")

    def _chat_start(self):
        try:
            import chat_relay
            chat_relay.STATUS["job_on"] = lambda: bool(self.chat_var.get())
            chat_relay.STATUS["running"] = lambda: bool(self.running)
            chat_relay.start(log)
        except Exception as e:                       # noqa: BLE001
            log(f"[chat] could not start the chat page: {e!r}")

    def _apply_chat(self):
        """11/14: Settings > Experimental > Chat relay -- show / hide the Chat update job, start / stop the page."""
        on = bool(self.chat_on_var.get())
        self._save_setting("chat_on", int(on))
        if on:
            self._hidden_rows.discard("Chat update")
            self._chat_start()
        else:
            self._hidden_rows.add("Chat update")
            self.chat_var.set(False)
            try:
                import chat_relay
                chat_relay.stop_server()
            except Exception:                        # noqa: BLE001
                pass
        self._repack_list(self.list_rows)
        log(f"[chat] Chat relay switched {'ON' if on else 'OFF'} in Settings.")

    def _chat_code_tick(self):
        lab = getattr(self, "_chat_code_label", None)
        try:
            if lab is None or not lab.winfo_exists():
                return
            if self.chat_on_var.get():
                import chat_relay
                code, left = chat_relay.current_code()
                err = chat_relay.SERVER_ERR[0]
                lab.config(text=(f"\u26a0 {err}\n" if err else "") + f"Code: {code[:3]} {code[3:]}   ({left} s left)")
                self._chat_show_links(chat_relay.links())
            else:
                lab.config(text="")
                self._chat_show_links([])
        except Exception as e:                       # noqa: BLE001
            lab.config(text=f"chat relay: {e!r}")
        self.root.after(1000, self._chat_code_tick)

    def _chat_show_links(self, links):
        """One row per link: the address as a clickable link + a Copy button; a hint when there is no away link."""
        fr = getattr(self, "_chat_link_frame", None)
        if fr is None or not fr.winfo_exists() or links == self._chat_links_shown:
            return
        self._chat_links_shown = links
        for w in fr.winfo_children():
            w.destroy()
        import webbrowser
        ui = ui_kit
        for label, u in links:
            tk.Label(fr, text=f"{label}:", bg=ui.CARD, fg=ui.DIM, font=("Segoe UI", 9), anchor="w").pack(fill="x")
            r = tk.Frame(fr, bg=ui.CARD)
            r.pack(fill="x", pady=(0, 4))

            def _copy(u=u):
                self.root.clipboard_clear()
                self.root.clipboard_append(u)
                self.set_status(f"Copied {u} -- paste it into your phone's browser.")
            ui.RoundButton(r, text="Copy", command=_copy, bg=ui.LINE, fg=ui.TEXT, chars=5).pack(side="left")
            a = tk.Label(r, text=u, bg=ui.CARD, fg=ui.BLUE, cursor="hand2", font=("Courier New", 10, "underline"),
                         anchor="w")
            a.pack(side="left", padx=(8, 0), fill="x", expand=True)
            a.bind("<Button-1>", lambda _e, u=u: webbrowser.open(u))
        if links and not any(lbl == "Away from home" for lbl, _ in links):
            h = tk.Label(fr, text="Away from home: install Tailscale (free) on this PC and your phone, same account "
                                  "-- an 'Away from home' link then shows here.", bg=ui.CARD, fg=ui.DIM,
                         font=("Segoe UI", 9), wraplength=260, justify="left", anchor="w")
            h.pack(fill="x", pady=(2, 0))
            fr.bind("<Configure>", lambda e, h=h: h.config(wraplength=max(160, e.width - 4)))

    # ---- Food Truck tab (11/8, owner: "look kinda like the actual food truck screen") -----------------------------
    TRUCK_TILE = 128                                     # one grid tile, px (the game shows 3 x 3)
    TRUCK_TILE_MIN = 92                                  # 11/9: smallest tile on a narrow window
    TRUCK_LOG_WORDS = ("HANDED IN", "fast travel to", "trip result", "resting", "skipping", "quickest first",
                       "handing them in", "cooking for")

    def _truck_state(self):
        try:
            import truck_panel
            return truck_panel, truck_panel.load()
        except Exception:                                # noqa: BLE001
            return None, {}

    TRUCK_NARROW_PX = 860            # 11/9: below this width the detail pane sits under the grid
    TRUCK_RESIZE = True              # 11/9: False in SAFE MODE (fixed layout, as before 11/9)

    def _truck_img(self, path, zoom=1):
        """PhotoImage of a learned dish picture (kept alive in self._truck_imgs)."""
        if not path:
            return None
        try:
            im = tk.PhotoImage(file=path)
            if zoom > 1:
                im = im.zoom(zoom)
            self._truck_imgs.append(im)
            return im
        except tk.TclError:
            return None

    @staticmethod
    def _truck_dish_info(name):
        """(station, cook seconds) from the recipe book, or (None, None)."""
        try:
            import recipe_book as rb
            it = rb.load()["items"][rb.resolve(name)]
            return it.get("station"), it.get("cook_sec")
        except Exception:                                # noqa: BLE001
            return None, None

    @staticmethod
    def _truck_fmt(secs):
        secs = max(0, int(secs))
        h, m = secs // 3600, secs % 3600 // 60
        if h:
            return f"{h}h {m:02d}m"
        return f"{m}m" if secs % 60 == 0 else f"{m}m {secs % 60:02d}s"

    def _truck_left(self, st):
        if not st.get("leaving_sec"):
            return None
        return st["leaving_sec"] - (time.time() - st.get("t", time.time()))

    def _truck_tick(self):
        """Every second: the big 'Leaving in' countdown."""
        try:
            _tp, st = self._truck_state()
            left = self._truck_left(st)
            if left is None:
                txt = "Leaving in —"
            elif left <= 0:
                txt = "Truck has left"
            else:
                txt = "Leaving in " + self._truck_fmt(left)
            self._truck_w["leaving"].config(text=txt)
        except (tk.TclError, AttributeError, KeyError):
            return
        self.root.after(1000, self._truck_tick)

    def _truck_poll(self):
        """Every 3 s. 11/8 (owner: "the page is really glitchy"): the grid + detail are rebuilt ONLY when what the bot
        read changed (state / selection) -- the old signature held the log size, which grows every second, so the
        whole page was torn down and redrawn every 3 s. The recent steps redraw on their own, only when they change."""
        try:
            tp, st = self._truck_state()
            sig = self._truck_sig_of(st)
            if sig != self._truck_sig:
                self._truck_sig = sig
                self._truck_draw(tp, st)
            items = self._truck_activity()
            if items != self._truck_act_items:
                self._truck_act_items = items
                self._truck_draw_activity(items)
            try:
                age = int((time.time() - st.get("t", 0)) // 60) if st else None
                if age is not None and self._truck_w.get("done_txt"):
                    self._truck_w["done"].config(text=self._truck_w["done_txt"] + f"   ·   read {age} min ago")
            except tk.TclError:
                pass
        except (tk.TclError, AttributeError):
            return
        except Exception as e:                           # noqa: BLE001 -- display only
            try:
                self._truck_w["done"].config(text=f"(could not show the truck: {e!r})")
            except (tk.TclError, KeyError):
                return
        self.root.after(3000, self._truck_poll)

    def _truck_activity(self):
        """The last few truck steps from run_log.txt, in plain words: [(HH:MM, text)]."""
        try:
            size = os.path.getsize(LOG)
            with open(LOG, "rb") as fh:
                fh.seek(max(0, size - 200_000))
                lines = fh.read().decode("utf-8", "replace").splitlines()
        except OSError:
            return []
        out = []
        for ln in lines:
            if "[truck]" not in ln or not any(w in ln for w in self.TRUCK_LOG_WORDS):
                continue
            m = re.match(r"\[\d{4}-\d\d-\d\dT(\d\d:\d\d)", ln)
            txt = ln.split("[truck]", 1)[1].replace("[food truck]", "").strip()
            txt = re.sub(r"^Slot \d+: ", "", txt)
            out.append((m.group(1) if m else "", txt))
        return out[-6:]

    def _truck_select(self, i):
        self._truck_sel = i
        self._truck_poll_once()

    def _truck_sig_of(self, st):
        return repr((st.get("t"), st.get("slots"), st.get("working"), st.get("cooking"), st.get("skipped"),
                     st.get("leaving_sec"), self._truck_sel))

    def _truck_poll_once(self):
        tp, st = self._truck_state()
        self._truck_sig = self._truck_sig_of(st)
        self._truck_draw(tp, st)

    def _truck_draw(self, tp, st):
        import ui_kit as ui
        w = self._truck_w
        tsz = getattr(self, "_truck_tile", self.TRUCK_TILE)   # 11/9: tiles shrink on a narrow window
        self._truck_imgs = []
        slots = [sl for sl in st.get("slots", []) if sl.get("state") != "none"]
        rows = tp.dish_rows(st.get("slots", [])) if (tp and st) else []
        by_name = {(r.get("name") or "").lower(): r for r in rows}
        done = sum(1 for sl in slots if sl.get("state") == "done")
        working = (st.get("working") or "").lower()
        cooking = st.get("cooking") or {}
        skipped = {(n or "").lower() for n in st.get("skipped") or []}
        if not st:
            w["done"].config(text="Nothing read yet. Tick 'Food Truck (street)' and press Start -- the bot opens "
                                  "the truck from its gold icon in the bottom bar.")
        else:
            age = int((time.time() - st.get("t", 0)) // 60)
            w["done_txt"] = f"{done} of {len(slots)} done"
            w["done"].config(text=w["done_txt"] + f"   ·   read {age} min ago")
        ui.set_bar(w["bar"], (done / len(slots)) if slots else 0, ui.GREEN)
        # --- the 3 x 3 grid, game order --------------------------------------------------------------------------
        for c in w["grid"].winfo_children():
            c.destroy()
        all_slots = {sl["i"]: sl for sl in st.get("slots", [])}
        shares = tp.slot_shares(st.get("slots", [])) if (tp and st) else {}
        default = None
        for i in range(1, 10):
            sl = all_slots.get(i, {"i": i, "state": "none"})
            name = sl.get("name")
            is_work = sl.get("state") == "order" and name and name.lower() == working
            if default is None and sl.get("state") == "order" and (is_work or not working):
                default = i
            sel = False
            edge = ui.GOLD if (is_work or sel) else ui.LINE
            tile = ui.card(w["grid"], edge=edge, thick=2 if (is_work or sel) else 1)
            tile.grid(row=(i - 1) // 3, column=(i - 1) % 3, padx=5, pady=5)
            box = tk.Frame(tile, width=tsz, height=tsz, bg=ui.CARD)
            box.pack()
            box.pack_propagate(False)
            st_ = sl.get("state")
            if st_ == "none":
                tk.Label(box, text="", bg=ui.CARD).pack(expand=True)
                continue
            img = self._truck_img(tp.picture_path(name) if tp else None)
            if st_ == "done":
                if img:
                    tk.Label(box, image=img, bg=ui.CARD).pack(pady=(10, 0))
                tk.Label(box, text="\u2713", font=ui.font(30, True), bg=ui.CARD, fg=ui.GREEN).place(
                    relx=0.5, rely=0.42, anchor="center")
                tk.Label(box, text="handed in", font=ui.font(9), bg=ui.CARD, fg=ui.DIM).pack(side="bottom", pady=6)
            else:
                if img:
                    tk.Label(box, image=img, bg=ui.CARD).pack(pady=(8, 0))
                else:
                    tk.Label(box, text=name or "?", font=ui.font(10, True), bg=ui.CARD, fg=ui.TEXT,
                             wraplength=tsz - 16, justify="center").pack(expand=True, pady=(14, 0))
                want = sl.get("need") or sl.get("want")
                badge = tk.Label(box, text=f"\u00d7{want or '?'}", font=ui.font(10, True), bg=ui.GOLD,
                                 fg="#1e1e1e", padx=5)
                badge.place(relx=1.0, x=-6, y=6, anchor="ne")
                r = by_name.get((name or "").lower())
                have, need = shares.get(i, (None, None))     # 11/8: the stock shared out order by order
                frac = (have / need) if (have is not None and need) else 0
                col = ui.DIM if (name or "").lower() in skipped else ui.GOLD
                ui.bar(box, min(1.0, frac), col, width=tsz - 24, bg=ui.CARD).pack(side="bottom", pady=8)
            # 11/9 (owner: "we dont need all that"): tiles are not clickable any more -- the gold edge only marks the
            # dish the bot is working on, and the detail pane always shows that dish.
        # --- detail pane -------------------------------------------------------------------------------------------
        d = w["detail"]
        for c in d.winfo_children():
            c.destroy()
        pick = all_slots.get(self._truck_sel or default or 0)
        if not pick or pick.get("state") == "none":
            tk.Label(d, text="No order picked." if st else "", font=ui.font(10), bg=ui.CARD, fg=ui.DIM).pack(
                padx=16, pady=20)
            return
        name = pick.get("name")
        img = self._truck_img(tp.picture_path(name) if tp else None,
                              zoom=1 if getattr(self, "_truck_narrow", False) else 2)
        tk.Label(d, text=name or "(name read on its next visit)", font=ui.font(13, True), bg=ui.CARD,
                 fg=ui.TEXT).pack(anchor="w", padx=16, pady=(14, 4))
        if img:
            tk.Label(d, image=img, bg=ui.CARD).pack(pady=4)
        r = by_name.get((name or "").lower()) or {}
        if pick.get("state") == "done":
            ui.pill(d, "handed in \u2713", ui.GREEN, bg=ui.CARD).pack(anchor="w", padx=16, pady=8)
        else:
            have, need = r.get("have"), r.get("need")
            n = len(r.get("slots") or [])
            line = (f"have {have} of {need}" if have is not None and need else "count not read yet")
            if n > 1 and r.get("ready") is not None:
                line += f"   ·   enough for {r['ready']} of {n} orders"
            tk.Label(d, text=line, font=ui.font(11), bg=ui.CARD, fg=ui.TEXT).pack(anchor="w", padx=16, pady=(6, 2))
            ui.bar(d, (have / need) if (have is not None and need) else 0, ui.GOLD, width=240, height=8,
                   bg=ui.CARD).pack(anchor="w", padx=16, pady=(0, 8))
            station, cook = self._truck_dish_info(name) if name else (None, None)
            if station or cook:
                tk.Label(d, text=" · ".join(x for x in (station, (self._truck_fmt(cook) + " to cook") if cook else None)
                                            if x), font=ui.font(9), bg=ui.CARD, fg=ui.DIM).pack(anchor="w", padx=16)
            key = (name or "").lower()
            until = cooking.get(key)
            if key in skipped:
                txt, col = "skipped — can't finish before the truck leaves", ui.RED
            elif until and until > time.time():
                txt, col = "cooking — ready " + time.strftime("%H:%M", time.localtime(until)), ui.TEAL
            elif key and key == working:
                txt, col = "the bot is working on this one", ui.GOLD
            else:
                txt, col = "waiting its turn", ui.DIM
            ui.pill(d, txt, col, bg=ui.CARD).pack(anchor="w", padx=16, pady=(10, 14))

    def _truck_draw_activity(self, items):
        import ui_kit as ui
        a = self._truck_w["activity"]
        for c in a.winfo_children():
            c.destroy()
        if not items:
            tk.Label(a, text="Nothing yet.", font=ui.font(9), bg=ui.CARD, fg=ui.DIM).pack(anchor="w", padx=14, pady=4)
        for hhmm, txt in reversed(items):
            r = tk.Frame(a, bg=ui.CARD)
            r.pack(fill="x", padx=14, pady=1)
            tk.Label(r, text=hhmm, font=ui.font(9), bg=ui.CARD, fg=ui.DIM, width=6, anchor="w").pack(side="left")
            col = ui.GREEN if "HANDED IN" in txt else ui.TEXT
            lab = tk.Label(r, text=txt, font=ui.font(9), bg=ui.CARD, fg=col, anchor="w", justify="left")
            lab.pack(side="left", fill="x", expand=True)
            lab.bind("<Configure>", lambda e, l=lab: l.config(wraplength=max(100, e.width - 4)))

    def _build_truck(self, parent):
        """11/8: the Food Truck tab looks like the game's truck screen -- leaving countdown, a 3 x 3 grid of the slots
        (dish picture, x3 badge, have bar, green check when handed in), a detail pane for the picked slot, and the
        last truck steps. Reads .food_truck.json (truck_panel) and run_log.txt; display only."""
        import ui_kit as ui
        self._truck_w, self._truck_imgs, self._truck_sel, self._truck_sig = {}, [], None, None
        self._truck_act_items = None
        area = ui.scroll_area(parent)
        area.pack(fill="both", expand=True, padx=(14, 4), pady=(4, 10))
        top = area.body
        head = tk.Frame(top, bg=BG)
        head.pack(fill="x", pady=(0, 8))
        ui.title(head, "\U0001f69a Food Truck", size=13).pack(side="left")
        self._truck_w["leaving"] = tk.Label(head, text="Leaving in —", font=ui.font(16, True), bg=BG, fg=ui.GOLD)
        self._truck_w["leaving"].pack(side="right")
        prog = tk.Frame(top, bg=BG)
        prog.pack(fill="x", pady=(0, 10))
        self._truck_w["done"] = tk.Label(prog, text="", font=ui.font(10), bg=BG, fg=ui.DIM, anchor="w")
        self._truck_w["done"].pack(side="left")
        self._truck_w["bar"] = ui.bar(prog, 0, ui.GREEN, width=220, height=8, bg=BG)
        self._truck_w["bar"].pack(side="right")
        body = tk.Frame(top, bg=BG)
        body.pack(fill="x")
        gcard = ui.card(body)
        gcard.pack(side="left", anchor="n", padx=(0, 10))
        self._truck_w["grid"] = tk.Frame(gcard, bg=ui.CARD)
        self._truck_w["grid"].pack(padx=8, pady=8)
        dcard = ui.card(body)
        dcard.pack(side="left", anchor="n", fill="x", expand=True)
        self._truck_w["detail"] = tk.Frame(dcard, bg=ui.CARD)
        self._truck_w["detail"].pack(fill="both", expand=True)
        self._truck_narrow = False

        self._truck_fit_job = None

        def _fit(e):
            # 11/9: never redraw INSIDE the resize event (a window that froze half-drawn on the owner's PC) -- skip the
            # tiny widths of a window still opening, and redraw once, 200 ms after the resizing stopped.
            if e.width < 300 or not self.TRUCK_RESIZE:
                return
            if self._truck_fit_job is not None:
                try:
                    body.after_cancel(self._truck_fit_job)
                except tk.TclError:
                    pass
            self._truck_fit_job = body.after(200, lambda w=e.width: _fit_now(w))

        def _fit_now(width):                             # 11/9 (owner: "different window sizes"): narrow window ->
            self._truck_fit_job = None
            e = type("E", (), {"width": width})
            narrow = e.width < self.TRUCK_NARROW_PX       # the detail pane goes UNDER the grid, smaller picture
            tile = max(self.TRUCK_TILE_MIN, min(self.TRUCK_TILE, (e.width - 40) // 3 - 14))
            tile -= tile % 4
            if narrow == self._truck_narrow and tile == getattr(self, "_truck_tile", self.TRUCK_TILE):
                return
            self._truck_tile = tile
            try:
                self._truck_w["bar"].configure(width=120 if e.width < 600 else 220)
            except (tk.TclError, KeyError):
                pass
            self._truck_narrow = narrow
            try:
                if narrow:
                    dcard.pack_configure(side="top", anchor="w", fill="x", expand=False, pady=(10, 0))
                    gcard.pack_configure(side="top", anchor="w", padx=0)
                else:
                    gcard.pack_configure(side="left", anchor="n", padx=(0, 10))
                    dcard.pack_configure(side="left", anchor="n", fill="x", expand=True, pady=0)
                self._truck_sig = None                    # redraw the detail at the new picture size
                self._truck_poll_once()
            except tk.TclError:
                pass
        body.bind("<Configure>", _fit)
        tk.Label(top, text="RECENT", font=ui.font(9, True), bg=BG, fg=ui.DIM, anchor="w").pack(fill="x", pady=(14, 4))
        acard = ui.card(top)
        acard.pack(fill="x")
        self._truck_w["activity"] = tk.Frame(acard, bg=ui.CARD)
        self._truck_w["activity"].pack(fill="x", pady=8)
        tk.Label(top, text="The bot hands in a slot only when it has all of that dish, cooks the quickest dish first "
                           "and skips dishes that can't finish before the truck leaves. It never taps the blue hand, "
                           "Dismiss Truck or anything with a gem price.",
                 font=ui.font(9), bg=BG, fg=ui.DIM, anchor="w", justify="left", wraplength=640).pack(fill="x",
                                                                                                    pady=(10, 0))
        self._truck_poll()
        self._truck_tick()

    def _build_busy(self, parent):
        """B.U.S.Y. = Best Use of Stoves & Yards (11/9). 11/15 (owner: "get the busy mode tab to work"): LIVE, display
        only -- real max prices (busy price test), what each stove / plot is doing (kitchen_model.snapshot), the moves
        it would make (soups.advise on copies of its state) and the latest [busy] log lines. Redraws every 5 s, only
        when something changed."""
        import ui_kit as ui
        area = ui.scroll_area(parent)
        area.pack(fill="both", expand=True, padx=(14, 4), pady=(4, 10))
        self._busy_top = area.body
        self._busy_sig = None
        self._busy_poll()

    def _busy_data(self):
        now = time.time()
        d = {"prices": _busy_price_rows(12), "stations": [], "crops": [], "advice": [], "log": [], "storage": None}
        try:
            import kitchen_model
            snap = kitchen_model.snapshot(now)
            for st, items in sorted(snap["stations"].items()):
                cnt = {}
                for dish, ready in items:
                    cnt.setdefault(dish, []).append(ready)
                for dish, rs in cnt.items():
                    left = min(rs) - now
                    d["stations"].append((st, f"{dish.replace('_', ' ').title()} x{len(rs)}",
                                          "ready" if left <= 0 else f"in {int(left // 60) + 1}m"))
            for crop, ready in sorted(snap["crops"].items(), key=lambda kv: kv[1]):
                left = ready - now
                d["crops"].append((str(crop).replace("_", " ").title(),
                                   "ripe" if left <= 0 else f"in {int(left // 60) + 1}m"))
            d["storage"] = snap.get("storage")
            import soups
            d["advice"] = [t for _k, t in soups.advise(snap, seen=dict(soups._seen),
                                                         idle_since=dict(soups._idle_since), now=now)]
        except Exception:                                # noqa: BLE001
            pass
        try:
            with open(LOG, "rb") as fh:
                fh.seek(0, 2)
                fh.seek(max(0, fh.tell() - 200000))
                tail = fh.read().decode("utf-8", errors="replace").splitlines()
            d["log"] = [ln[12:19] + "  " + ln.split("[busy]", 1)[1].strip() for ln in tail if "[busy]" in ln][-6:]
        except Exception:                                # noqa: BLE001
            pass
        return d

    def _busy_poll(self):
        try:
            d = self._busy_data()
            on = bool(getattr(self, "busy_var", None) and self.busy_var.get())
            sig = repr((d, on, self.running))
            if sig != self._busy_sig and self._busy_top.winfo_exists():
                self._busy_sig = sig
                self._busy_draw(d, on)
        except Exception as e:                           # noqa: BLE001
            log(f"[window] busy tab refresh failed: {e!r}")
        try:
            self.root.after(5000, self._busy_poll)
        except tk.TclError:
            pass

    def _busy_draw(self, d, on):
        import ui_kit as ui
        top = self._busy_top
        for w in top.winfo_children():
            w.destroy()
        head = tk.Frame(top, bg=BG)
        head.pack(fill="x", pady=(0, 2))
        ui.title(head, "\U0001f4b0 Busy Mode", size=13).pack(side="left")
        if on and self.running:
            ui.pill(head, "RUNNING -- making + selling", "#6fcf6f", bg=BG).pack(side="left", padx=10)
        elif on:
            ui.pill(head, "TICKED -- press Start", ui.GOLD, bg=BG).pack(side="left", padx=10)
        else:
            ui.pill(head, "OFF -- tick Busy Mode on the left", ui.DIM, bg=BG).pack(side="left", padx=10)
        tk.Label(top, text="B.U.S.Y. -- Best Use of Stoves & Yards. Makes anything that takes under 15 min and "
                           "sells it at the max price (checks the stall every 3 min, collects what sold, lists again); "
                           "makes ONE of each slower item until it knows its price. Keeps your Prep list, the crop "
                           "reserve and what jobs above it need. Never gems, never saws.",
                 font=ui.font(10), bg=BG, fg=ui.DIM, anchor="w", justify="left", wraplength=760).pack(fill="x",
                                                                                                   pady=(0, 10))
        best = d["prices"][0] if d["prices"] else None
        stg = d["storage"]
        stats = tk.Frame(top, bg=BG)
        stats.pack(fill="x", pady=(0, 10))
        for i, (big, small) in enumerate(((best[4] if best else "\u2014", f"best coins/min ({best[0]})" if best
                                           else "best coins/min"),
                                          (str(len(d["prices"])), "items priced"),
                                          (str(len({r[0] for r in d["stations"]})), "stoves cooking"),
                                          (str(len(d["crops"])), "crops growing"),
                                          (f"{stg[0]}/{stg[1]}" if stg else "\u2014", "Food Club storage"))):
            stats.columnconfigure(i, weight=1, uniform="s")
            c = ui.card(stats, bg=ui.CARD)
            c.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 6, 0))
            tk.Label(c, text=big, font=ui.font(15, True), bg=ui.CARD, fg=TEXT).pack(anchor="w", padx=12, pady=(8, 0))
            tk.Label(c, text=small, font=ui.font(9), bg=ui.CARD, fg=ui.DIM).pack(anchor="w", padx=12, pady=(0, 8))

        def table(title_text, cols, rows, weights, empty):
            tk.Label(top, text=title_text, font=ui.font(9, True), bg=BG, fg=ui.DIM, anchor="w").pack(fill="x",
                                                                                                   pady=(8, 4))
            c = ui.card(top, bg=ui.CARD)
            c.pack(fill="x")
            g = tk.Frame(c, bg=ui.CARD)
            g.pack(fill="x", padx=12, pady=8)
            if not rows:
                tk.Label(g, text=empty, font=ui.font(10), bg=ui.CARD, fg=ui.DIM, anchor="w", justify="left",
                         wraplength=720).pack(fill="x")
                return
            for j, w in enumerate(weights):
                g.columnconfigure(j, weight=w)
            for j, h in enumerate(cols):
                tk.Label(g, text=h, font=ui.font(9, True), bg=ui.CARD, fg=ui.DIM, anchor="w").grid(
                    row=0, column=j, sticky="w", padx=(0, 10), pady=(0, 4))
            for r_i, row in enumerate(rows, 1):
                for j, v in enumerate(row):
                    tk.Label(g, text=v, font=ui.font(10), bg=ui.CARD, fg=TEXT, anchor="w").grid(
                        row=r_i, column=j, sticky="w", padx=(0, 10), pady=1)

        table("BEST COINS PER MINUTE  (max price for 1 / its own cook or grow time)",
              ("Item", "Made at", "Time", "Max price", "Coins / min", "Have"), d["prices"], (3, 3, 1, 1, 1, 1),
              "No prices yet. Tick Busy Mode and press Start: it prices one item every 10 min.")
        table("STOVES RIGHT NOW  (batches the bot queued)", ("Where", "Cooking", "Ready"), d["stations"], (3, 4, 2),
              "Nothing the bot queued is cooking right now.")
        table("CROPS RIGHT NOW", ("Crop", "Ready"), d["crops"], (4, 2), "No crops tracked right now.")
        table("NEXT MOVES IT WOULD MAKE", ("#", "Move"), [(str(i + 1), t) for i, t in enumerate(d["advice"])],
              (1, 12), "Nothing to suggest -- every known stove is busy and nothing is waiting.")
        table("BUSY MODE LOG  (newest last)", ("Time", "Line"), [tuple(x.split("  ", 1)) for x in d["log"]],
              (1, 12), "No Busy Mode lines yet.")

    def _build_settings(self, parent):
        """10/20 redesign: section cards side by side, switches, −/+ steppers, explanations behind ⓘ hovers."""
        import ui_kit as ui
        area = ui.scroll_area(parent)
        area.pack(fill="both", expand=True, padx=(14, 4), pady=(4, 10))
        grid = area.body
        for c in (0, 1):
            grid.columnconfigure(c, weight=1, uniform="col")
        # 11/2 (owner approved): search box -- shows only the sections whose words match
        sr = tk.Frame(grid, bg=BG)
        sr.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        tk.Label(sr, text="\u2315", font=ui.font(12), bg=BG, fg=ui.DIM).pack(side="left")
        self.set_q = tk.StringVar()
        ui.entry(sr, self.set_q, width=30, bg=BG).pack(side="left", padx=(4, 0), ipady=2)
        self._set_none = tk.Label(sr, text="", font=ui.font(9), bg=BG, fg=ui.DIM)
        self._set_none.pack(side="left", padx=10)
        cols = [tk.Frame(grid, bg=BG), tk.Frame(grid, bg=BG)]
        cols[0].grid(row=1, column=0, sticky="new", padx=(0, 6))
        cols[1].grid(row=1, column=1, sticky="new", padx=(6, 0))
        self._set_sections = []                          # (box, words) for the search

        def section(col, text):
            box = ui.card(cols[col], bg=ui.CARD)
            box.pack(fill="x", pady=(0, 12))
            ui.title(box, text, bg=ui.CARD).pack(anchor="w", padx=12, pady=(10, 6))
            self._set_sections.append((box, text))
            return box

        def search(*_):
            q = self.set_q.get().strip().lower()
            hits = 0
            for box, _t in self._set_sections:           # forget all, re-pack the matches in their own order
                try:
                    box.pack_forget()
                except tk.TclError:
                    pass
            for box, title in self._set_sections:
                words = (title + " " + " ".join(self._widget_words(box))).lower()
                if q and q not in words:
                    continue
                hits += 1
                try:
                    box.pack(fill="x", pady=(0, 12))
                except tk.TclError:
                    pass
            self._set_none.config(text="" if hits or not q else "nothing matches")
            area.reset(top=True)
        self.set_q.trace_add("write", search)

        def row(box, text, note):
            r = tk.Frame(box, bg=ui.CARD)
            r.pack(fill="x", padx=12, pady=(0, 9))
            lab = tk.Label(r, text=text, font=ui.font(10), bg=ui.CARD, fg=ui.TEXT, anchor="w", justify="left",
                           wraplength=190)
            lab.pack(side="left")
            if note:
                ui.info(r, note, bg=ui.CARD).pack(side="left", padx=(4, 0))
            fit_label(r, lab)
            return r

        def fit_label(r, lab):
            """11/3: wrap the label to the room the row really has (a fixed 190 px got cut off in a narrow window)."""
            def fit(e):
                others = sum(w.winfo_reqwidth() + 8 for w in r.winfo_children() if w is not lab)
                want = max(90, min(260, e.width - others - 6))
                if abs(int(lab.cget("wraplength")) - want) > 4:
                    lab.config(wraplength=want)
            r.bind("<Configure>", fit, add="+")

        def coming_soon(box, text, note=None):
            """10/31 (owner): a feature still being built gets its switch now -- greyed out, off, "(coming soon)"."""
            r = tk.Frame(box, bg=ui.CARD)
            r.pack(fill="x", padx=12, pady=(0, 9))
            lab = tk.Label(r, text=f"{text} (coming soon)", font=ui.font(10), bg=ui.CARD, fg=ui.DIM, anchor="w",
                           justify="left", wraplength=190)
            lab.pack(side="left")
            fit_label(r, lab)
            if note:
                ui.info(r, note, bg=ui.CARD).pack(side="left", padx=(4, 0))
            ui.Switch(r, tk.BooleanVar(value=False), bg=ui.CARD, disabled=True).pack(side="right", before=r.winfo_children()[0])
            return r

        def switch(box, text, var, key, note=None, sub=None):
            r = row(box, text, note)
            ui.Switch(r, var, command=lambda: self._save_setting(key, int(var.get())), bg=ui.CARD).pack(side="right", before=r.winfo_children()[0])
            if sub:
                tk.Label(box, text=sub, font=ui.font(9), bg=ui.CARD, fg=ui.DIM).pack(anchor="w", padx=12,
                                                                                    pady=(0, 8))
                r.pack_configure(pady=(0, 0))

        def number(box, text, var, key, lo, hi, step, unit="", note=None):
            r = row(box, text, note)
            ui.Stepper(r, var, lo, hi, step, unit, command=lambda v: self._save_setting(key, v),
                       bg=ui.CARD).pack(side="right", before=r.winfo_children()[0])
            return r

        box = section(0, "Food Club")
        number(box, "Crops kept for replanting", self.seed_reserve_var, "seed_reserve", 0, 10, 1,
               note="Below this the bot plants the crop instead of cooking with it.")
        number(box, "Storage guard (Food Club storage)", self.storage_guard_var, "storage_guard", 0, 60, 1,
               note="At this many items in Food Club storage the bot stops planting extra crops (seed reserve and "
                    "express buffer) and cooks with what is there, so storage does not fill up. 0 = off.")
        number(box, "Prestock Food Club event storage", self.prestock_var, "prestock_each", 0, 10, 1,
               note="Keep this many of EVERY Food Club event item in storage: at each event station the bot "
                    "opens, any card below this number is cooked (ingredients above the crop reserve only). "
                    "Quick regular ingredients the bot fetches for event dishes (Milk, Egg) are kept at this number "
                    "too. Not during an express or above the storage guard. 0 = off.")
        # 11/13 (owner): start Food Club at a set time (one-shot) -- ticks the job, hold serving off, presses Start
        r = row(box, "Start Food Club at", "At this time the bot ticks Food Club Event, turns 'hold serving' off "
                "and presses Start if it is stopped. Runs once (the PC's own clock), then switches itself off.")
        self.fc_h, self.fc_m, self.fc_ap = tk.StringVar(value="3"), tk.StringVar(value="00"), tk.StringVar(value="AM")
        tr = tk.Frame(box, bg=ui.CARD)
        tr.pack(fill="x", padx=12, pady=(0, 9))
        sp = dict(width=3, justify="center", bg=ui.mix(ui.CARD, "#000000", 0.25), fg=TEXT, relief="flat",
                  buttonbackground=ui.mix(ui.CARD, "#ffffff", 0.08), insertbackground=TEXT, font=ui.font(9))
        tk.Spinbox(tr, from_=1, to=12, textvariable=self.fc_h, **sp).pack(side="left")
        tk.Label(tr, text=":", bg=ui.CARD, fg=TEXT, font=ui.font(10)).pack(side="left")
        tk.Spinbox(tr, values=tuple(f"{m:02d}" for m in range(0, 60, 5)), textvariable=self.fc_m, **sp).pack(side="left")
        apm = tk.OptionMenu(tr, self.fc_ap, "AM", "PM")
        apm.config(bg=ui.mix(ui.CARD, "#ffffff", 0.08), fg=TEXT, relief="flat", highlightthickness=0, bd=0,
                   font=ui.font(9), activebackground=GOLD_DIM)
        apm["menu"].config(bg=PANEL, fg=TEXT, activebackground=GOLD_DIM)
        apm.pack(side="left", padx=(6, 6))

        def _fc_set():
            at = self.next_clock_time(self.fc_h.get(), self.fc_m.get(), self.fc_ap.get())
            self._save_setting("fc_start_at", at)
            log(f"[schedule] Food Club start set for {time.strftime('%a %I:%M %p', time.localtime(at))}.")
            self._fc_start_show()

        def _fc_off():
            self._save_setting("fc_start_at", 0)
            log("[schedule] Food Club start timer cancelled.")
            self._fc_start_show()
        ui.button(tr, "Set", _fc_set, primary=True).pack(side="left")
        ui.button(tr, "Off", _fc_off, bg=ui.CARD).pack(side="left", padx=(6, 0))
        self.fc_start_label = tk.Label(tr, text="", font=ui.font(9), bg=ui.CARD, fg=DIM_TEXT)
        self.fc_start_label.pack(side="left", padx=(8, 0))
        self._fc_start_show()
        switch(box, "Clipboard orders when the event board can't be found", self.event_clip_fallback_var,
               "event_clip_fallback",
               "Off (default): the bot keeps trying to get the Food Club board back -- Back key and closing panels "
               "first, then restarting the game (max every 15 min), then LDPlayer -- and never works clipboard orders "
               "for Food Club. On: after 5 misses it works clipboard orders and looks for the board every 6 cycles.")
        switch(box, "Prestock before serving", self.prestock_hold_var, "prestock_hold",
               "When a regular card is ready but serving it would empty storage, the bot tops those dishes back up "
               "to the prestock number first (at most 12 min), so an express that comes next finds them ready. "
               "Never during an express or when storage is full.")
        switch(box, "Delete an order when storage stays full", self.storage_purge_var, "storage_purge",
               "When the 'storage is full' message comes back 3 times in 30 min, the bot deletes ONE order -- the "
               "one furthest from done -- and keeps working the others. If it keeps coming back within 2 h, the next "
               "time it deletes 2. Never the gold express card, never a ready card; one card is always left.")

        box = section(0, "Daily rewards")                      # 10/31 (owner): "a setting ... spin daily prize wheel"
        switch(box, "Spin daily prize wheel", self.wheel_var, "daily_wheel",
               "Travels to the pier by the Fisherman's Lighthouse and spins the free wheel (never the gem "
               "'Spin again'). Needs a fish order on the clipboard to get there; tries again every 30 min.")
        number(box, "Spin it every", self.wheel_hours_var, "wheel_hours", 6, 24, 6, " h",
               note="How long after a spin (or an 'already used' wheel) the bot goes back. The game's real reset "
                    "time is not known yet -- 24 h is safe, 12 h checks twice a day.")
        coming_soon(box, "Collect the pier prize",
                    note="The gold billboard with the gift on the pier past the prize wheel. The Tests job is still "
                         "learning to collect it; this switch turns on once it works.")

        box = section(0, "Orchard")                                # 11/8 O.R.C.H.A.R.D. (owner)
        switch(box, "Remove spent trees and bushes", self.orchard_cut_var, "orchard_cut",
               "A tree or bush whose Ask for Help is used up and has fruited again is removed: a saw for trees, a "
               "Helping Hand for bushes -- only when you have one (they come from the hot dog man and the pier "
               "billboard). Never when a red hand sign hangs over it (help asked, visitor not here yet), never within "
               "24 h of asking help on that kind, at most 3 a day.")
        switch(box, "Replant on the same spot", self.orchard_replant_var, "orchard_replant",
               "Right after cutting a spent APPLE tree: build menu -> Farming -> drags the Apple Tree card onto the "
               "spot the old tree stood on -> green check (35 coins). A spot the game does not allow (grey check) is "
               "cancelled with the red X. At most 3 a day; stops for the run if gems ever move. Other trees: later.")

        box = section(0, "Busy Mode")                              # 11/9 B.U.S.Y. (owner: "max out the coins")
        coming_soon(box, "Busy Mode job",
                    note="B.U.S.Y. -- Best Use of Stoves & Yards. A job that keeps every stove and crop plot working and "
                         "sells what it makes for the most coins per minute. Being built; see the Busy Mode tab.")

        box = section(0, "Ads")                                    # 11/1 (owner: "a working setting to play and skip ads")
        switch(box, "Watch ads for free rewards", self.watch_ads_var, "watch_ads",
               "While the bot waits for its own batch at an event station (or a growing crop's timer card), it taps "
               "the green Skip [video] and then the square VIDEO button (never the gem Skip), sits through the ad "
               "(Google Play -> Back key -> X for AppLovin ads, Skip after the countdown for Facebook ads) and the "
               "item is finished. The game only offers the video in a timer's last ~5 min and seems to allow about "
               "10 a day -- the bot stops trying once a few short timers in a row show no video button. Never taps "
               "anything inside the Play Store.", sub="off by default")
        switch(box, "Save ads for event dishes", self.ads_event_var, "ads_event_only",
               "On: no ads on crop plots -- the few ads a day go to event dishes at event stations (Ghost Merchant, "
               "Witch's Cauldron ...), where finishing a dish frees the station for the next one. Off: crops get "
               "ads too.", sub="on by default")
        number(box, "Only when the timer has more than", self.ads_min_var, "ads_min_left", 1, 15, 1, " min",
               "11/2: the bot needs 1.5-3 min per ad (you need 30-45 s), so short timers are not worth it. Set it "
               "low (1) only while testing ads.")

        box = section(0, "Experimental")
        r = row(box, "Schedule tab",
                "11/14: adds a Schedule tab -- drag jobs onto a Today / Tomorrow calendar (arrows for later days). Its "
                "own 'Run the schedule' switch (off at first) makes blocks tick and untick their jobs.")
        ui.Switch(r, self.schedule_on_var, command=self._apply_schedule, bg=ui.CARD).pack(side="right", before=r.winfo_children()[0])
        r = row(box, "Chat relay",
                "11/14: read the club chat on your phone. Adds a 'Chat update' job that opens the chat every few "
                "minutes and saves a picture to a small web page on this PC (phone on the same Wi-Fi). Log in with "
                "the 6-digit code below -- it changes every 30 s. Messages typed on the phone are sent by the bot (plain letters only, no emoji).")
        ui.Switch(r, self.chat_on_var, command=self._apply_chat, bg=ui.CARD).pack(side="right", before=r.winfo_children()[0])
        self._chat_code_label = tk.Label(box, text="", font=("Courier New", 11), bg=ui.CARD, fg=GOLD,
                                         justify="left", anchor="w")
        self._chat_code_label.pack(fill="x", padx=12, pady=(0, 2))
        lk = tk.Frame(box, bg=ui.CARD)                  # 11/14 (owner: "an IP, not a link"): click opens, Copy copies
        lk.pack(fill="x", padx=12, pady=(0, 8))
        self._chat_link_frame = lk
        self._chat_links_shown = None
        self._chat_code_tick()

        box = section(0, "Alarms")
        switch(box, "Express alarm", self.alarm_var, "express_alarm",
               "When an express order appears on the Food Club board.", sub="beeps + pop-up")

        box = section(1, "Clipboard Orders")                    # 10/23 rework (owner: mock-up "looks great")

        def group(text, note=""):
            g = tk.Frame(box, bg=ui.CARD)
            g.pack(fill="x", padx=12, pady=(8, 4))
            tk.Label(g, text=text.upper(), font=ui.font(8, True), bg=ui.CARD, fg=ui.DIM).pack(side="left")
            if note:
                tk.Label(g, text=note, font=ui.font(8), bg=ui.CARD, fg=ui.DIM).pack(side="left", padx=(6, 0))

        def choice(text, var, key, options, note=None):
            r = row(box, text, note)
            labels = dict(options)
            btn = ui.RoundButton(r, text=labels.get(var.get(), options[0][1]) + "  ▾", bg=ui.PANEL, font=ui.font(10))

            def pick(v):
                var.set(v)
                self._save_setting(key, v)
                btn.config(text=labels[v] + "  ▾")
            menu = tk.Menu(r, tearoff=0, bg=ui.PANEL, fg=ui.TEXT, activebackground=GOLD_DIM)
            for v, lab in options:
                menu.add_command(label=lab, command=lambda v=v: pick(v))
            btn.config(command=lambda: menu.tk_popup(btn.winfo_rootx(), btn.winfo_rooty() + btn.winfo_height()))
            btn.pack(side="right", before=r.winfo_children()[0])
            return r

        choice("Which order first", self.quick_first_var, "quick_first",
               [(2, "Best coins/hour"), (1, "Quickest first"), (0, "Board order")],
               note="Quickest first: works the order that finishes soonest (recipe-book time, the ⏱ on each card) "
                    "before slower ones -- coins come in when an order is finished, so quick ones first means more "
                    "finished orders per hour. Orders with no known time come last; the card being worked on shows "
                    "⚡ next up. Best coins/hour: the order paying the most coins per hour of the time it still needs "
                    "(coin reward read off the card / the ⏱ time) goes first. Board order: down the clipboard as it is.")

        switch(box, "Jobs higher in the list come first", self.truck_first_var, "truck_first",
               "O.R.D.E.R.: the jobs list is a priority list. A job lower in the list does not cook or serve with "
               "anything a job above it still needs -- the whole chain (mac & cheese -> cheese -> milk -> cabbage), "
               "for Food Truck, Food Club, Clipboard Orders and Prep. Once enough is made (say all the milk), the rest "
               "is free again, and stoves no higher job uses keep working for the lower ones. Expresses still beat "
               "everything. Drag the jobs to set the order.")

        group("Stuck orders")
        number(box, "Give up on a stuck order after", self.dismiss_min_var, "dismiss_min", 0, 240, 10, "min",
               note="An order with no real progress this long is given up on (see 'Then'). Covers orders it can't "
                    "work right now (harvesting the same empty bush, a route it hasn't learned) AND orders that take "
                    "too long (rice growing for hours: it plants the rice, but if nothing can be made in this time "
                    "it still gives up). A dish that cooks longer than TWICE this time (ice cream 3 h) does not "
                    "count as progress; shorter ones do (a 35 min soup is not thrown away mid-cook). Real progress "
                    "= something queued or collected, or an ingredient count going up. 0 = never give up.")
        number(box, "Dismiss orders that take longer than", self.long_order_min_var, "long_order_min", 0, 720, 30,
               "min", note="An order whose recipe-book time (the ⏱ on its card: what is still missing, cooked and "
                           "grown) is longer than this is dismissed right away -- usual guards, never a gem button. "
                           "A new order arrives about 30 min later. The Sell Apple Juice order is never dismissed. "
                           "0 = off.")
        choice("Then", self.giveup_dismiss_var, "giveup_dismiss", [(1, "Dismiss it"), (0, "Skip it for 1 hour")],
               note="Dismiss it: the order is thrown away (usual guards -- never a gem button) and a new one arrives "
                    "about 30 min later. Skip it for 1 hour: the order stays; the bot works the others and tries it "
                    "again later. A note pops up either way.")

        group("Crops")
        number(box, "Keep at least this many of each crop", self.crop_reserve_var, "crop_reserve", 0, 10, 1,
               note="The bot won't cook a dish if it would leave a raw crop (rice, cabbage, onion ...) below this "
                    "number -- it plants that crop instead, and the plot walk below plants crops up to this number "
                    "too. One seed grows into 2, so the stock keeps growing instead of being cooked away. Dishes "
                    "are not affected. 0 = off.")
        switch(box, "Walk the plots while waiting", self.plant_wait_var, "plant_while_waiting",
               "While orders wait on ingredients, the bot walks the crop plots about every 20 min: harvests what "
               "is ready and plants the empty plots from stock or Free seeds. Never gems.")
        group("Selling quick crops")
        switch(box, "Stall fill while waiting", self.stall_wait_var, "stall_fill_waiting",
               "While a picked tree is waiting for a visitor's help, the bot lists 1-3 spare quick crops (wheat, "
               "corn, tomato, cabbage) about every 10 min -- visitors come when something is for sale. Keeps the crops "
               "you keep for replanting and what open orders need. Never saws. Off = no stall fill at all.")
        switch(box, "Pantry relief", self.pantry_relief_var, "pantry_relief",
               "When the game says 'Your Pantry is full!', the bot sells up to 5 of a quick crop (then apples / "
               "lemons, then other crops) at max price to make room. Keeps the crops you keep for replanting and "
               "your Prep list. Never saws or tools.")

        group("Only when Food Club is ticked too")
        fc_rows = []
        fc_rows.append(number(box, "Clipboard turn length", self.clip_turn_var, "clip_turn_min", 1, 30, 1, "min",
                              note="With Food Club ticked too, the clipboard gets this long per round, then Food "
                                   "Club gets its turn."))
        fc_rows.append(number(box, "Keep long cooks off its stations: longer than", self.long_cook_limit_var,
                              "long_cook_limit", 0, 180, 5, "min",
                              note="While Food Club is ticked, Clipboard Orders won't queue a dish that cooks longer "
                                   "than this at a station Food Club needs (an ice cream is 3 h and blocks Cream at "
                                   "the Dairy). 0 = off."))

        def fc_dim(*_a):
            on = bool(self.event_orders_var.get())
            for r in fc_rows:
                for w in r.winfo_children():
                    if isinstance(w, tk.Label):
                        w.config(fg=ui.TEXT if on else ui.DIM)
        try:
            self.event_orders_var.trace_add("write", fc_dim)
        except tk.TclError:
            pass
        fc_dim()

        box = section(0, "Speed")                              # 11/1 (owner): FLASH step 2
        switch(box, "FLASH fast capture", self.flash_var, "flash_capture",
               "The bot looks at the game by copying LDPlayer's window (about 0.05-0.2 s) instead of asking adb for "
               "a screenshot (1-4 s). Keep LDPlayer OPEN -- it may sit behind other windows, but not minimised. If "
               "the copy is ever black or the wrong shape, that look uses adb as before. Taps still use adb.",
               sub="off = adb screenshots, as before")
        switch(box, "FLASH fast taps", self.fast_taps_var, "flash_fast_taps",
               "Taps, swipes and the Back key go through one adb connection that stays open, instead of starting "
               "adb again for every tap. If that connection ever breaks or stops answering, the bot goes back to "
               "the old way for 5 minutes, then tries again. Never taps twice.",
               sub="on by default (11/1); off = one adb per tap, as before")

        box = section(0, "Windows")
        switch(box, "Always start as administrator", self.admin_var, "run_as_admin",
               "LDPlayer runs with administrator rights, so only an administrator AFSD can close it when it freezes "
               "(the watchdog). ON: AFSD asks Windows for administrator rights every time it opens -- click Yes on "
               "the prompt. Same as ticking 'Run as administrator' on the shortcut.")
        st = tk.Frame(box, bg=ui.CARD)
        st.pack(fill="x", padx=12, pady=(0, 10))
        admin_now = is_admin()
        tk.Label(st, text="Now: running as administrator \u2713" if admin_now else "Now: not administrator",
                 font=ui.font(9), bg=ui.CARD, fg="#6fcf6f" if admin_now else "#f0c040").pack(side="left")
        if not admin_now:
            def reopen():
                self._save_setting("run_as_admin", int(self.admin_var.get()))
                was = self.running
                if start_as_admin(["--start"] if was else []):
                    if self.running:
                        self.toggle_running()
                    self._relaunching = True
                    self.root.after(300, self.on_close)
                else:
                    self.set_status("Windows did not allow administrator rights (the prompt was closed or said No).")
            ui.button(st, "Reopen as admin", reopen, bg=ui.CARD, size=9).pack(side="right")

        box = section(1, "Tests")
        tk.Label(box, text="Tick the Tests job on the left. One test per turn; when every test has had its turn the next "
                           "round starts. Proven tests are skipped. Tests only look, open and close.", font=ui.font(8), bg=ui.CARD, fg=ui.DIM, justify="left", wraplength=300
                 ).pack(anchor="w", padx=12, pady=(0, 8))
        notes = {"stock": "Opens up to 3 stations from the clipboard and reads every card's stock box.",
                 "back": "Opens a station and presses Android Back -- does the panel close?",
                 "farmer": "Goes to the event crop plots, looks up-left for the Crop Farmer, opens it, reads it.",
                 "apples": "Goes to the apple trees and counts the ripe apples it can see (picks none)."}
        try:
            import tests_job
            labels = dict(tests_job.TESTS)
        except Exception:                                # noqa: BLE001
            labels = {"stock": "Stock reader", "back": "Back key", "farmer": "Find the Crop Farmer", "apples": "Apples"}
        for k in ("stock", "back", "apples"):
            switch(box, labels.get(k, k), getattr(self, f"test_{k}_var"), f"test_{k}", notes[k])
        switch(box, "Sell Apple Juice", self.test_sell_apple_juice_var, "test_sell_apple_juice",
               "Off by default. On: the Tests job makes one Apple Juice at the Smoothie Bar (picking apples if "
               "needed) and puts one up for sale at the max price -- coins only, never gems. While it is on, ONE "
               "clipboard order that leads to the Smoothie Bar is kept on the board as the way there: the bot does "
               "not work, serve or dismiss that order and works the others as usual. Turn it off to free that order.")
        self.tests_result = tk.Label(box, text="", font=ui.font(8), bg=ui.CARD, fg=TEXT, justify="left", anchor="w",
                                     wraplength=300)
        self.tests_result.pack(fill="x", padx=12, pady=(0, 6))
        r = row(box, "Run all tests again today", None)
        ui.button(r, "Reset", self._tests_reset, bg=ui.CARD, size=9).pack(side="right")
        self.refresh_tests_status()

        box = section(1, "Updates and logs")
        switch(box, "Auto-update at every Start", self.auto_update_var, "auto_update",
               "ON: Start installs the newest code from GitHub first (old files kept in backups\\).\n"
               "OFF: Start only checks, and says so when an update is waiting.")
        switch(box, "Send logs at every Stop", self.send_at_stop_var, "send_at_stop",
               "Sends the run that just ended, in the background.")
        switch(box, "Send logs after Let Me Play", self.send_after_play_var, "send_after_play",
               "When you press Done playing, your recording (tap pictures + notes) is sent to Claude at once --\n"
               "no need to press Send logs. Then just say: check the Let Me Play.")
        number(box, "Restart every (0 = off)", self.auto_cycle_min_var, "auto_cycle_min", 0, 720, 30, "min",
               "While running: every N minutes AFSD presses Stop (sends the logs) and Start again (checks for an\n"
               "update -- installs it when Auto-update is ON). Waits while an express order is on the board.")
        r = row(box, "Send logs now", None)
        b = ui.button(r, "Send", lambda: self.run_tool_inline("send"), bg=ui.CARD, size=9)
        b.pack(side="right")
        self.tool_buttons["send"] = b
        switch(box, "Delete old debug pictures at Start", self.auto_clean_var, "auto_clean",
               "11/14: the screens the bot saves for Claude (fail pictures, tests, recordings ...) older than 7 days\n"
               "are deleted at every Start. They are already on GitHub. Pictures the bot plays with are never touched.")
        r = row(box, "Free up space", None)
        b = ui.button(r, "Clean up", self._free_space, bg=ui.CARD, size=9)
        b.pack(side="right")
        self.tool_buttons["clean"] = b
        tk.Label(box, textvariable=self.version_var, font=ui.font(8), bg=ui.CARD, fg=ui.DIM, justify="left",
                 anchor="w", wraplength=300).pack(fill="x", padx=12, pady=(0, 10))

    def refresh_tests_status(self):
        """Thread-safe: today's result per test under the Tests switches."""
        def ui_():
            try:
                import tests_job
                lines = []
                for lab, res in tests_job.summary():
                    lines.append(f"{lab}: " + (res[:90] + ("..." if len(res) > 90 else "") if res else "not run today"))
                self.tests_result.config(text="\n".join(lines))
            except Exception:                            # noqa: BLE001
                pass
        try:
            self.root.after(0, ui_)
        except Exception:                                # noqa: BLE001
            pass

    def _tests_reset(self):
        try:
            import tests_job
            tests_job.reset_today()
            log("[tests] today's results cleared -- the tests run again.")
        except Exception as e:                           # noqa: BLE001
            log(f"[tests] reset failed: {e!r}")
        self.refresh_tests_status()

    def info_icon(self, parent, text, bg=None):
        """10/19 (owner): a small (i) -- hover it to see more. Returns the label; the caller packs it."""
        bg = bg or PANEL
        lab = tk.Label(parent, text="\u24d8", font=tkfont.Font(family="Segoe UI", size=11), bg=bg, fg=DIM_TEXT,
                       cursor="question_arrow")
        tip = {}

        def show(_e):
            if tip.get("w"):
                return
            w = tk.Toplevel(lab)
            w.wm_overrideredirect(True)
            w.configure(bg=GOLD_DIM)
            tk.Label(w, text=text, justify="left", bg=PANEL, fg=TEXT, wraplength=340, padx=10, pady=6,
                     font=tkfont.Font(family="Segoe UI", size=9)).pack(padx=1, pady=1)
            w.wm_geometry(f"+{lab.winfo_rootx() + 18}+{lab.winfo_rooty() + 20}")
            tip["w"] = w
            lab.config(fg=GOLD)

        def hide(_e):
            if tip.get("w"):
                tip.pop("w").destroy()
            lab.config(fg=DIM_TEXT)
        lab.bind("<Enter>", show)
        lab.bind("<Leave>", hide)
        return lab

    def _code_version(self):
        try:
            import afsd_tools
            return afsd_tools.code_version()
        except Exception as e:                           # noqa: BLE001
            return f"unknown ({e})"

    TOAST_SHOW_MS = 4000

    def _toast_show(self):
        if self._toast_job is not None:
            self.root.after_cancel(self._toast_job)
            self._toast_job = None
        if not self.toast.winfo_ismapped():
            self.toast.pack(fill="x", padx=14, pady=(12, 0), before=self._tab_bar)
        self.root.update_idletasks()
        self.toast.config(height=self._toast_strip.winfo_reqheight())
        self._fit_left_column()

    def _fit_left_column(self):
        """10/18 (owner): the Relaunch button got cut off -- when the left column needs more room than the window
        has, Tk HIDES the last widgets (the toast) instead of squeezing them. Grow the window to fit."""
        try:
            self.root.update_idletasks()
            need = self.toast.master.winfo_reqheight() + 10
            if self.root.winfo_height() < need:
                h = min(need, self.root.winfo_screenheight() - 60)
                self.root.geometry(f"{self.root.winfo_width()}x{h}")
                self.root.update_idletasks()
        except tk.TclError:
            pass

    def _toast_hide(self, step=0):
        """Slide the toast away (shrinks to nothing in ~0.25 s)."""
        if step == 0 and self._toast_job is not None:
            self.root.after_cancel(self._toast_job)
        h = self.toast.winfo_height() - 8
        if h <= 1:
            self.toast.pack_forget()
            self._toast_job = None
            return
        self.toast.config(height=h)
        self._toast_job = self.root.after(20, lambda: self._toast_hide(step + 1))

    def _tool_tick(self):
        """While a send / update works: add the seconds to the step text, so a long step never looks frozen."""
        st = getattr(self, "_tool_started", None)
        if st is None:
            return
        self.tool_var.set(f"{self._tool_text}   \u00b7 {int(time.time() - st)} s")
        self._toast_show()
        self.root.after(1000, self._tool_tick)

    def _tool_progress(self, text, frac=None):
        """Thread-safe: show a Send logs / Update step in the toast under Status."""
        def ui():
            self._toast_show()
            self.copy_button.pack_forget()
            self.relaunch_button.pack_forget()
            self._tool_text = text
            if getattr(self, "_tool_started", None) is None:
                self._tool_started = time.time()
                self.root.after(1000, self._tool_tick)
            self.tool_var.set(f"{text}   \u00b7 {int(time.time() - self._tool_started)} s")
            self._toast_show()                           # re-measure: a longer text wraps to more lines
            self.tool_label.config(fg=TEXT)
            if frac is not None:
                self._tool_frac = (frac, GOLD)
            self._draw_tool_bar()
        self.root.after(0, ui)

    def _draw_tool_bar(self, _event=None):
        """The bar is drawn from the stored fraction, again whenever the canvas gets its real width."""
        frac, col = getattr(self, "_tool_frac", (0.0, GOLD))
        self.tool_bar.delete("all")
        w = self.tool_bar.winfo_width()
        if w > 1 and frac > 0:
            self.tool_bar.create_rectangle(0, 0, int(w * frac), 6, fill=col, width=0)

    def _copy_tool_error(self):
        try:
            self.root.clipboard_clear()
            self.root.clipboard_append(self._tool_error)
            self.copy_button.config(text="\u2713 Copied -- paste it to Claude")
        except tk.TclError:
            pass

    def _tool_done(self, ok, msg):
        def ui():
            self._tool_started = None                    # stops the seconds counter
            self._tool_frac = (0.0, GOLD)
            self._toast_show()
            self.tool_var.set(msg)
            warn = (not ok) or "WAITING" in msg or "close AFSD" in msg or msg.startswith(("Set aside", "Dismissed"))  # 10/22
            self.tool_label.config(fg="#f0c040" if warn else "#6fcf6f")
            self._tool_frac = (1.0, "#6fcf6f" if not warn else "#f0c040") if ok else (0.0, GOLD)
            self._draw_tool_bar()
            self.version_var.set("Code version: " + self._code_version())
            if not ok:                                   # an error: offer to copy it (the full text, not the shortened one)
                self._tool_error = f"AFSD {time.strftime('%Y-%m-%d %H:%M:%S')} -- {msg}\nCode version: {self._code_version()}"
                self.copy_button.config(text="Copy error for Claude")
                self.copy_button.pack(anchor="w", padx=8, pady=(0, 7))
            else:
                self.copy_button.pack_forget()
            restart = "close AFSD" in msg
            if restart:
                self.relaunch_button.pack(anchor="w", padx=8, pady=(0, 7))
                self.tool_var.set(msg)
            else:
                self.relaunch_button.pack_forget()
            if warn and not restart:
                self.tool_var.set(msg + "   (click to dismiss)")
            self._toast_show()                           # re-measure FIRST: it cancels any pending slide-away
            if not warn:                                 # good news: show it briefly, then slide away
                self._toast_job = self.root.after(self.TOAST_SHOW_MS, self._toast_hide)
        self.root.after(0, ui)

    def relaunch(self):
        """Stop the bot, open a fresh AFSD (it presses Start by itself), close this one. 10/18 (owner)."""
        import subprocess
        self._relaunching = True
        was_running = self.running
        if self.running:
            self.toggle_running()
        args = [sys.executable, os.path.abspath(__file__)] + (["--start"] if was_running else [])
        try:
            subprocess.Popen(args, cwd=os.path.dirname(os.path.abspath(__file__)),
                             creationflags=getattr(subprocess, "DETACHED_PROCESS", 0)
                             | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0))
        except Exception as e:                           # noqa: BLE001
            self._relaunching = False
            self.set_status(f"Relaunch failed ({e}) -- close AFSD and open it again by hand.")
            log(f"Relaunch failed: {e!r}")
            return
        log("Relaunch: opening a fresh AFSD (it presses Start by itself) and closing this one.")
        self.root.after(300, self.on_close)

    def run_tool_inline(self, kind):
        """Send logs / Update in a background thread; progress shows under Status (no console window)."""
        if kind == "update" and self.running:
            self.set_status("Stop first, then Update.")
            return
        if not self._tool_lock.acquire(blocking=False):
            self.set_status("Send logs / Update is already working -- wait for it to finish.")
            return
        log(f"{'Send logs' if kind == 'send' else 'Update'}: started (inside AFSD).")

        def work():
            try:
                import afsd_tools
                fn = afsd_tools.send_logs if kind == "send" else afsd_tools.update
                ok, msg = fn(self._tool_progress)
            except Exception as e:                       # noqa: BLE001
                ok, msg = False, f"{'Send logs' if kind == 'send' else 'Update'} failed: {e!r}"
            try:
                self._tool_done(ok, msg)
                log(msg)
            finally:
                self._tool_lock.release()                # never leave the buttons locked
        threading.Thread(target=work, daemon=True).start()

    def _free_space(self):
        """11/14 (owner: "my PC is filling up"): delete old debug pictures (> 3 days) and shrink git's history."""
        from tkinter import messagebox
        if self.running:
            self.set_status("Stop first, then Clean up.")
            return
        try:
            import cleanup
            paths, size = cleanup.plan()
        except Exception as e:                           # noqa: BLE001
            self.set_status(f"Clean up failed: {e!r}")
            return
        if not messagebox.askyesno("Free up space",
                                   f"Delete {len(paths)} old debug pictures ({cleanup.gb(size)}) -- screens the bot saved "
                                   f"for Claude, older than {cleanup.KEEP_DAYS} days (already on GitHub)?\n\n"
                                   "Also shrink git's copy of the old history (the .git folder, often several GB). "
                                   "This needs the internet and can take a few minutes.\n\n"
                                   "Pictures the bot plays with are never touched."):
            return
        if not self._tool_lock.acquire(blocking=False):
            self.set_status("Send logs / Update is working -- try Clean up when it is done.")
            return
        log("[cleanup] Free up space: started.")

        def work():
            try:
                import afsd_tools
                import cleanup
                ok, msg = cleanup.free_space(afsd_tools._git, self._tool_progress)
            except Exception as e:                       # noqa: BLE001
                ok, msg = False, f"Free up space failed: {e!r}"
            try:
                self._tool_done(ok, msg)
                log(f"[cleanup] {msg}")
            finally:
                self._tool_lock.release()
        threading.Thread(target=work, daemon=True).start()

    def _start_update_check(self, my_flag):
        """Called in the run thread before anything else (10/18): auto-update ON installs, OFF only checks.
        Returns the update message, or None when skipped. Gives up at once when this run is stopped."""
        got = False
        for _ in range(180):                             # a Send logs from the last Stop may still be going
            if my_flag.is_set():
                return None
            if self._tool_lock.acquire(timeout=0.5):
                got = True
                break
        if not got:
            log("[update] skipped at Start: Send logs / Update was still running after 90 s.")
            return None
        try:
            import afsd_tools
            if getattr(self, "_auto_update_now", False):
                ok, msg = afsd_tools.update(self._tool_progress)
            else:
                ok, msg = afsd_tools.check(self._tool_progress)
        except Exception as e:                           # noqa: BLE001
            ok, msg = False, f"Update check skipped: {e!r}"
        try:
            self._tool_done(ok, msg)
            log(f"[update] {msg}")
        except Exception:                                # noqa: BLE001 -- a log line must never stop Start
            pass
        finally:
            self._tool_lock.release()
        return msg

    # --- Prep (10/18, owner: "I am the manager, the bot is the worker"): your own order for a day and time. GUI only for now -- the bot does not cook it yet.
    CATERING_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".prep.json")
    CATERING_MARGIN_SEC = 5 * 60

    # ------------------------------------------------------------------
    # Prep work tab -- 10/20 redesign (report lab-p9w2r): "Add items" on the left, "Keep in stock" on the right
    # (your list IS the status board), ASAP / At a time + Save list at the bottom. Same .prep.json underneath, same
    # prep_engine; only the look and the way the list is edited changed. Not built on purpose (owner: no untested
    # features in a redesign): "Keep it up", the Pet food filter, "After it's made" (still saved as "keep").
    # ------------------------------------------------------------------
    def _dismiss_order(self, no, sig):
        """10/21 (owner): ask, then queue the order for the bot to trash on its next cycle (delete_order guards)."""
        from tkinter import messagebox
        if not messagebox.askyesno("Dismiss order", f"Dismiss clipboard order {no}?\n\nThe bot trashes it in the game "
                                   "at the start of its next cycle (only while it is running). It never spends gems "
                                   "and answers No if anything unexpected shows up."):
            return
        try:
            import order_fulfill
            order_fulfill.DISMISS_REQUESTS.append((no, sig))
            order_fulfill.mark_dismiss(sig, "queued")             # 10/23: the card says "Dismissing..." at once
            order_fulfill.log(f"DISMISS: order {no} queued by the owner -- the bot stops its current item and dismisses it.")
            self.set_status(f"Order {no} queued for dismissing -- the bot does it after the item it is on now; the "
                            "card disappears as soon as it is gone from the game.")
        except Exception as e:                           # noqa: BLE001
            self.set_status(f"Could not queue the dismiss: {e!r}")

    def _build_prep(self, win):
        import datetime as _dt
        import json
        import ui_kit as ui
        self.cat_items = dict(rb.load(force=True)["items"])
        self._prep_add_event_items()                      # 11/13: Food Club event dishes / merchant items / crops
        items = self.cat_items
        self.cat_order = {}
        self.cat_saved_items = {}
        # 10/20 (owner: "it doesn't tell us anything about the progress"): Now: bar like the Orders tab
        nowbar = ui.card(win, edge=GOLD_DIM)
        nowbar.pack(fill="x", padx=14, pady=(4, 6))
        tk.Label(nowbar, text="Now:", font=ui.font(10, True), bg=ui.CARD, fg=GOLD).pack(side="left", padx=(10, 6),
                                                                                       pady=5)
        self.cat_now = tk.Label(nowbar, text="", font=ui.font(10), bg=ui.CARD, fg=TEXT, anchor="w", justify="left",
                                wraplength=600)
        self.cat_now.pack(side="left", fill="x", expand=True)
        # 11/13 (owner: "make it more of a scrollable page to fill out"): ONE scrolling page -- Keep in stock on top,
        # Add items under it -- instead of two side-by-side boxes that each scroll on their own.
        page = ui.scroll_area(win, bg=BG)
        self.cat_page = page
        cols = page

        # ---- Add items (under Keep in stock) ----
        left = ui.card(page.body)
        head = tk.Frame(left, bg=ui.CARD)
        head.pack(fill="x", padx=12, pady=(10, 6))
        ui.title(head, "Add items", bg=ui.CARD).pack(side="left")
        ui.info(head, "Press + to put an item on your list, then set how many to keep on the right.\n"
                      "Hover a name to see its recipe.", bg=ui.CARD).pack(side="left", padx=(6, 0))
        sr = tk.Frame(left, bg=ui.CARD)
        sr.pack(fill="x", padx=12)
        tk.Label(sr, text="⌕", font=ui.font(12), bg=ui.CARD, fg=ui.DIM).pack(side="left")
        self.cat_q = tk.StringVar()
        ui.entry(sr, self.cat_q, width=18).pack(side="left", fill="x", expand=True, padx=(4, 0), ipady=2)
        self.cat_filter = "all"
        self.cat_chips = tk.Frame(left, bg=ui.CARD)
        self.cat_chips.pack(fill="x", padx=12, pady=(8, 6))
        self.cat_left_body = tk.Frame(left, bg=ui.CARD)
        self.cat_left_body.pack(fill="x", padx=(6, 6), pady=(0, 8))
        self.cat_q.trace_add("write", lambda *_: self._prep_search_later())

        # ---- right: Keep in stock ----
        right = ui.card(page.body)
        right.pack(fill="x", padx=(0, 4), pady=(0, 10))
        left.pack(fill="x", padx=(0, 4), pady=(0, 10))
        head = tk.Frame(right, bg=ui.CARD)
        head.pack(fill="x", padx=12, pady=(10, 6))
        ui.title(head, "Keep in stock", bg=ui.CARD).pack(side="left")
        ui.info(head, "The bot makes each item until you have this many (what you already have counts).\n"
                      "Rules: an express on the board comes first; Food Club Event higher in the Jobs list = Prep "
                      "work does not run. Tick Prep work on the left: one item per turn, reached through the "
                      "clipboard's '?' routes. 5 min safety margin.", bg=ui.CARD).pack(side="left", padx=(6, 0))
        act = tk.Frame(right, bg=ui.CARD)                   # Activity: the last few things Prep work did
        act.pack(side="bottom", fill="x", padx=12, pady=(0, 10))
        tk.Frame(act, bg=ui.mix(ui.CARD, "#ffffff", 0.08), height=1).pack(fill="x", pady=(0, 6))
        tk.Label(act, text="ACTIVITY", font=ui.font(8, True), bg=ui.CARD, fg=ui.DIM).pack(anchor="w")
        self.cat_activity = tk.Frame(act, bg=ui.CARD)
        self.cat_activity.pack(fill="x")
        self.cat_right_body = tk.Frame(right, bg=ui.CARD)
        self.cat_right_body.pack(fill="x", padx=(6, 6), pady=(0, 8), before=act)
        self._prep_rows, self._prep_sig, self._prep_last = {}, None, {}
        self._prep_log_sig = None

        # ---- footer ----
        foot = ui.card(win)
        foot.pack(fill="x", padx=14, pady=(10, 10), side="bottom")     # stays put under the scrolling page
        page.pack(fill="both", expand=True, padx=(14, 10), pady=(0, 0))
        r1 = tk.Frame(foot, bg=ui.CARD)
        r1.pack(fill="x", padx=12, pady=(10, 4))
        tk.Label(r1, text="Start", font=ui.font(10, True), bg=ui.CARD, fg=GOLD).pack(side="left", padx=(0, 8))
        self.cat_asap = tk.BooleanVar(value=True)
        self.cat_mode = tk.Frame(r1, bg=ui.CARD)
        self.cat_mode.pack(side="left")
        today = _dt.date.today()
        days = [today + _dt.timedelta(days=i) for i in range(8)]
        self.cat_day_labels = [d.strftime("%a %b %d") for d in days]
        self.cat_days = dict(zip(self.cat_day_labels, days))
        self.cat_day = tk.StringVar(value=self.cat_day_labels[0])
        self.cat_hour = tk.StringVar(value="7")
        self.cat_min = tk.StringVar(value="00")
        self.cat_ampm = tk.StringVar(value="PM")
        self.cat_time = tk.Frame(r1, bg=ui.CARD)            # shown only for "At a time"
        om = tk.OptionMenu(self.cat_time, self.cat_day, *self.cat_day_labels)
        ap = tk.OptionMenu(self.cat_time, self.cat_ampm, "AM", "PM")
        for m in (om, ap):
            m.config(bg=ui.mix(ui.CARD, "#ffffff", 0.08), fg=TEXT, relief="flat", highlightthickness=0,
                     activebackground=GOLD_DIM, font=ui.font(9), bd=0)
            m["menu"].config(bg=PANEL, fg=TEXT, activebackground=GOLD_DIM)
        spin = dict(width=3, justify="center", bg=ui.mix(ui.CARD, "#000000", 0.25), fg=TEXT, relief="flat",
                    buttonbackground=ui.mix(ui.CARD, "#ffffff", 0.08), insertbackground=TEXT, font=ui.font(9))
        om.pack(side="left", padx=(10, 6))
        sh = tk.Spinbox(self.cat_time, from_=1, to=12, textvariable=self.cat_hour, **spin)
        sh.pack(side="left")
        tk.Label(self.cat_time, text=":", font=ui.font(10), bg=ui.CARD, fg=TEXT).pack(side="left")
        sm = tk.Spinbox(self.cat_time, values=("00", "15", "30", "45"), textvariable=self.cat_min, **spin)
        sm.pack(side="left")
        ap.pack(side="left", padx=(6, 0))
        self._cat_time_widgets = (om, sh, sm, ap)
        self.cat_start = tk.StringVar(value="")
        self.cat_start_label = tk.Label(foot, textvariable=self.cat_start, font=ui.font(9), bg=ui.CARD, fg=ui.DIM,
                                        anchor="w", justify="left", wraplength=640)
        self.cat_start_label.pack(fill="x", padx=12)
        r2 = tk.Frame(foot, bg=ui.CARD)
        r2.pack(fill="x", padx=12, pady=(4, 10))
        self.cat_summary = tk.Label(r2, text="", font=ui.font(9), bg=ui.CARD, fg=ui.DIM, anchor="w", justify="left",
                                    wraplength=480)
        ui.button(r2, "Save list", self._cat_place, primary=True).pack(side="right")
        ui.button(r2, "Clear list", self._cat_clear, bg=ui.CARD).pack(side="right", padx=(0, 6))
        # 11/2 (#15d/e): saved lists
        self.cat_hist_btn = ui.button(r2, "🕘 History ▾", lambda: self._prep_lists_menu("history"),
                                      bg=ui.CARD)
        self.cat_hist_btn.pack(side="right", padx=(0, 6))
        self.cat_fav_btn = ui.button(r2, "⭐ Favorites ▾", lambda: self._prep_lists_menu("fav"), bg=ui.CARD)
        self.cat_fav_btn.pack(side="right", padx=(0, 6))
        # 11/3: the summary is packed AFTER the buttons and wraps to the room left over -- it used to cover Favorites
        self.cat_summary.pack(side="left", fill="x", expand=True)

        def _fit_summary(e, r2=r2):
            others = sum(w.winfo_reqwidth() + 6 for w in r2.winfo_children() if w is not self.cat_summary)
            want = max(80, e.width - others - 8)
            if abs(int(self.cat_summary.cget("wraplength")) - want) > 4:
                self.cat_summary.config(wraplength=want)
        r2.bind("<Configure>", _fit_summary, add="+")
        self.cat_after = tk.StringVar(value="keep")         # "After it's made" placeholder: saved, not shown yet
        self.cat_placed = tk.StringVar(value="")
        self.cat_progress = tk.StringVar(value="")
        for v in (self.cat_day, self.cat_hour, self.cat_min, self.cat_ampm):
            v.trace_add("write", lambda *_: self._cat_refresh())
        try:
            with open(self.CATERING_FILE, encoding="utf-8") as fh:
                saved = json.load(fh)
            for k in saved.get("items", {}):
                if str(k).startswith("ev:") and k not in items:      # an event item the catalog no longer lists
                    self._prep_add_event_items([(k[3:], "dish", "Food Club event")])
            self.cat_order.update({k: int(n) for k, n in saved.get("items", {}).items() if k in items})
            if saved.get("placed"):
                self.cat_saved_items = dict(self.cat_order)
                self.cat_placed.set(saved.get("summary", ""))
            if saved.get("after") in ("keep", "sell_extras", "sell"):
                self.cat_after.set(saved["after"])
            self.cat_asap.set(bool(saved.get("asap", not saved.get("placed"))))
        except Exception:                                # noqa: BLE001
            pass
        self._cat_asap_toggled()
        self._prep_draw_left()
        self.refresh_prep_status()
        self.root.after(1500, self._prep_poll)

    PREP_PILLS = (("done", "\u2713 stocked", "#6fcf6f"), ("cooking", "cooking", "#f0a040"),
                  ("working", "working", GOLD), ("waiting", "waiting", "#9a9a9a"),
                  ("needs", "next up", "#9a9a9a"), ("growing", "growing", "#4fc3a1"),
                  ("picked", "picked", "#6fcf6f"), ("nothing ready", "waiting", "#9a9a9a"),
                  ("Food Club keeps", "Food Club", GOLD))

    def _prep_state(self, status):
        """(pill text, colour, detail, fraction or None) for one engine status line."""
        st = status or "waiting"
        m = re.match(r"cooking \(have (\d+), \+(\d+) on the way, want (\d+)\)", st)
        if m:
            have, way, want = (int(x) for x in m.groups())
            return "cooking", "#f0a040", f"have {have} · {way} on the way", (have + way) / max(1, want)
        m = re.match(r"done \(have (\d+)(?:, (\d+) cooking)?\)", st)
        if m:
            return "✓ stocked", "#6fcf6f", f"have {m.group(1)}" + (f" · {m.group(2)} cooking" if m.group(2)
                                                                        else ""), 1.0
        for key, text, col in self.PREP_PILLS:
            if st.startswith(key):
                return text, col, (st if key == "needs" else st[len(key):].strip(" ()") or ""), None
        return "blocked", "#e06060", st, None

    def _prep_search_later(self):
        """11/2 (owner: "something glitchy about searching"): redraw once typing pauses (150 ms), not on every key --
        each redraw rebuilds ~70 rows."""
        try:
            if getattr(self, "_prep_search_job", None):
                self.root.after_cancel(self._prep_search_job)
        except Exception:                                # noqa: BLE001
            pass
        self._prep_search_job = self.root.after(150, self._prep_draw_left)

    @staticmethod
    def prep_search_rank(q, name, station, key, ingredients):
        """Pure: None = no match; else a sort rank -- name starts with the text 0, a word of the name starts with it 1,
        name contains it 2, station 3, ingredient 4 (so typing "egg" lists Egg before the dishes that use eggs)."""
        q = (q or "").strip().lower()
        if not q:
            return 0
        nm = name.lower()
        if nm.startswith(q):
            return 0
        if any(w.startswith(q) for w in re.split(r"[\s_-]+", nm)):
            return 1
        if q in nm or q in key.lower().replace("_", " ") or q in key.lower():
            return 2
        if q in station.lower():
            return 3
        if any(q in i.lower().replace("_", " ") for i in ingredients):
            return 4
        return None

    def _prep_draw_left(self):
        import ui_kit as ui
        self._prep_search_job = None
        try:
            body = self.cat_left_body
        except AttributeError:
            return
        for w in self.cat_chips.winfo_children():
            w.destroy()
        for key, text in (("all", "All"), ("dish", "Dishes"), ("crop", "Crops"), ("event", "\U0001f354 Event")):
            ui.chip(self.cat_chips, text, key == self.cat_filter,
                    lambda k=key: (setattr(self, "cat_filter", k), self._prep_draw_left()), bg=ui.CARD
                    ).pack(side="left", padx=(0, 4))
        for w in body.winfo_children():
            w.destroy()
        self._prep_left_rows = {}
        if self.cat_filter in ("event", "all"):
            self._prep_add_event_items()                  # 11/13: menus learned since the window opened show up too
        items, t = self.cat_items, self.cat_q.get().strip().lower()
        rows = []
        for k, it in items.items():
            dish = it.get("show_on_page", True)
            ev = bool(it.get("event"))
            if (self.cat_filter == "event") != ev and self.cat_filter != "all":
                continue
            if (self.cat_filter == "dish" and not dish) or (self.cat_filter == "crop" and dish):
                continue
            rank = self.prep_search_rank(t, it["name"], it["station"] or "", k, [i for i, _ in it["ingredients"]])
            if rank is None:
                continue
            rows.append((rank, it["name"].lower(), k))
        if self.cat_filter == "event":
            tk.Label(body, text="Food Club event items the bot has seen this event. Food Club keeps them in stock "
                                "(while Food Club is ticked) -- the number you set is how many to keep.",
                     font=ui.font(8), bg=ui.CARD, fg=ui.DIM, anchor="w", justify="left", wraplength=520
                     ).pack(fill="x", padx=6, pady=(0, 6))
        if not rows:
            tk.Label(body, text="No event items seen yet -- run Food Club first." if self.cat_filter == "event"
                     else "Nothing matches.", font=ui.font(9), bg=ui.CARD, fg=ui.DIM).pack(pady=20)
        for _r, _n, k in sorted(rows):
            it = items[k]
            r = tk.Frame(body, bg=ui.CARD)
            r.pack(fill="x", padx=6, pady=1)
            txt = tk.Frame(r, bg=ui.CARD)
            txt.pack(side="left", fill="x", expand=True)
            name = tk.Label(txt, text=it["name"], font=ui.font(10, True), bg=ui.CARD, fg=TEXT, anchor="w")
            name.pack(anchor="w")
            ct = it["cook_sec"]
            tk.Label(txt, text=(f"event {it.get('kind', 'dish')} · " if it.get("event") else "") +
                     it['station'] + ("" if ct == 0 else f" · {'?' if ct is None else rb.fmt(ct)}"), font=ui.font(8),
                     bg=ui.CARD, fg=ui.DIM, anchor="w").pack(anchor="w")
            ui.hover_card(name, lambda k=k: self._prep_recipe_text(k))
            self._prep_left_rows[k] = r
            self._prep_left_mark(k)
            tk.Frame(body, bg=ui.mix(ui.CARD, "#ffffff", 0.05), height=1).pack(fill="x", padx=6, pady=(3, 3))
        page = getattr(self, "cat_page", None)
        if page is not None:                              # 11/2: re-measure the page (a search makes it shorter)
            ui.fix_scroll(page.canvas, page.body, top=False)

    def _prep_add_event_items(self, rows=None):
        """11/13: Food Club event items (from what the bot has read on event stations) as "ev:<name>" list items."""
        try:
            if rows is None:
                import event_orders
                rows = event_orders.event_catalog()
            for name, kind, where in rows:
                self.cat_items["ev:" + name] = {"name": name, "station": where or "Food Club event", "cook_sec": 0,
                                                "ingredients": [], "show_on_page": kind != "crop", "kind": kind,
                                                "event": True}
        except Exception as e:                           # noqa: BLE001
            log(f"[prep] event items not listed: {e!r}")

    def _prep_recipe_text(self, k):
        items = self.cat_items
        it = items[k]
        if it.get("event"):
            return (f"{it['name']}  ·  {it['station']}\nFood Club event {it.get('kind', 'dish')} -- Food Club's "
                    "prestock keeps this many in event storage while Food Club is ticked.")
        ct = "not recorded" if it["cook_sec"] is None else rb.fmt(it["cook_sec"])
        lines = [f"{it['name']}  ·  {it['station']}  ·  {ct}" + (f"  ·  makes {it['yield']}"
                                                                           if it.get("yield", 1) > 1 else "")]
        if it["ingredients"]:
            needs = []
            for ik, cnt in it["ingredients"]:
                nm = items.get(rb.resolve(ik), {}).get("name", ik)
                needs.append(f"{nm} ×{cnt}" if it.get("counts_confirmed") else nm)
            lines.append("needs: " + ", ".join(needs))
        if it.get("note"):
            lines.append(it["note"])
        return "\n".join(lines)

    def _prep_left_mark(self, k):
        """The + (not on the list) or \u2713 (on the list) at the end of one Add items row."""
        import ui_kit as ui
        r = getattr(self, "_prep_left_rows", {}).get(k)
        if r is None:
            return
        try:
            old = getattr(r, "_mark", None)
            if old is not None:
                old.destroy()
            if k in self.cat_order:
                m = tk.Label(r, text="\u2713", font=ui.font(11, True), bg=ui.CARD, fg="#6fcf6f", width=2)
            else:
                m = tk.Label(r, text="+", font=ui.font(12, True), bg=ui.mix(ui.CARD, "#ffffff", 0.08), fg=GOLD,
                             width=2, cursor="hand2")
                m.bind("<Button-1>", lambda e, k=k: self._prep_set(k, 1))
            m.pack(side="right", before=r.winfo_children()[0])
            r._mark = m
        except tk.TclError:
            pass

    def _prep_set(self, k, n):
        """10/20 (owner: the whole list glitched on every \u2212/+): a new amount only changes that number and the
        summary; only adding or removing an item redraws the list on the right."""
        was_on = k in self.cat_order
        if n <= 0:
            self.cat_order.pop(k, None)
        else:
            self.cat_order[k] = min(99, n)
        if was_on != (k in self.cat_order):
            self._prep_left_mark(k)
            self._prep_draw_right(force=True)
        else:
            self._prep_summary()
        self._cat_refresh()

    def _prep_statuses(self):
        try:
            import prep_engine
            return {name: st for name, _q, st in prep_engine.status_lines()} if self.cat_saved_items else {}
        except Exception:                                # noqa: BLE001
            return {}

    def _prep_draw_right(self, force=False):
        """Keep in stock list. Redrawn only when an item is added/removed or an item's state changed."""
        import ui_kit as ui
        try:
            body = self.cat_right_body
        except AttributeError:
            return
        status = self._prep_statuses()
        sig = (tuple(self.cat_order), tuple(sorted(self.cat_saved_items)), tuple(sorted(status.items())),
               tuple(sorted(self._prep_last.items())))
        if sig == self._prep_sig and not force:
            self._prep_summary()
            return
        self._prep_sig = sig
        # 10/25 (#15f, flicker): while the engine works, the latest step changes every few seconds. When the same
        # rows with the same parts (latest-step line, bar) would be drawn, update them in place instead.
        looks = {}
        for k in self.cat_order:
            it = self.cat_items.get(k, {"name": k, "station": "?"})
            saved = k in self.cat_saved_items
            looks[k] = (self._prep_state(status.get(it["name"])) if saved else
                        ("not saved", "#9a9a9a", "press Save list", None),
                        self._prep_last.get(it["name"].lower()) if saved else None, it, saved)
        struct = (tuple(self.cat_order), tuple(sorted(self.cat_saved_items)),
                  tuple((k, lk[1] is not None, lk[0][3] is not None) for k, lk in looks.items()))
        if not force and struct == getattr(self, "_prep_struct", None) and getattr(self, "_prep_rows", None):
            try:
                self._prep_patch_right(looks)
                self._prep_summary()
                return
            except Exception:                            # noqa: BLE001 -- fall back to a full redraw
                pass
        self._prep_struct = struct
        self._prep_rows = {}
        for w in body.winfo_children():
            w.destroy()
        self._prep_counts = {}
        if not self.cat_order:
            tk.Label(body, text="Your list is empty.\nPress + next to an item below.", font=ui.font(10),
                     bg=ui.CARD, fg=ui.DIM, justify="center").pack(pady=40)
        for k, n in self.cat_order.items():
            it = self.cat_items.get(k, {"name": k, "station": "?"})
            saved = k in self.cat_saved_items
            pill, col, detail, frac = self._prep_state(status.get(it["name"])) if saved else \
                ("not saved", "#9a9a9a", "press Save list", None)
            self._prep_counts[pill] = self._prep_counts.get(pill, 0) + 1
            last = self._prep_last.get(it["name"].lower()) if saved else None
            if last and detail.startswith("retrying"):
                detail = ""                              # the latest step below says why
            r = tk.Frame(body, bg=ui.CARD)
            r.pack(fill="x", padx=6, pady=(4, 2))
            pl = ui.pill(r, pill, col, bg=ui.CARD, chars=9)
            pl.pack(side="right", padx=(8, 0))
            var = tk.IntVar(value=n)
            stp = ui.Stepper(r, var, 0, 99, 1, command=lambda v, k=k: self._prep_set(k, v), bg=ui.CARD, width=2)
            stp.pack(side="right")
            row = self._prep_rows[k] = {"row": r, "pill": pl, "pill_key": (pill, col), "stepper": stp,
                                        "last": None, "bar": None}
            txt = tk.Frame(r, bg=ui.CARD)
            txt.pack(side="left", fill="x", expand=True)
            tk.Label(txt, text=it["name"], font=ui.font(10, True), bg=ui.CARD, fg=TEXT, anchor="w").pack(anchor="w")
            sub = tk.Frame(body, bg=ui.CARD)              # detail lines under the row, full width (not under -/+)
            sub.pack(fill="x", padx=6)
            row["detail"] = tk.Label(sub, text=f"{it['station']}" + (f" \u00b7 {detail}" if detail else ""),
                                     font=ui.font(8), bg=ui.CARD, fg=ui.DIM, anchor="w", justify="left", wraplength=360)
            row["detail"].pack(anchor="w")
            if last:                                     # its latest step, from the log
                row["last"] = tk.Label(sub, text=f"{last[0]}  {last[1]}", font=ui.font(8), bg=ui.CARD,
                                       fg=ui.mix(col, TEXT, 0.35), anchor="w", justify="left", wraplength=360)
                row["last"].pack(anchor="w")
            if frac is not None:
                bw = tk.Frame(body, bg=ui.CARD)
                bw.pack(fill="x", padx=6)
                row["bar"] = ui.bar(bw, frac, col, width=200, height=4)
                row["bar"].pack(anchor="w")
            tk.Frame(body, bg=ui.mix(ui.CARD, "#ffffff", 0.05), height=1).pack(fill="x", padx=6, pady=(5, 2))
        page = getattr(self, "cat_page", None)
        if page is not None:                              # 11/13: one page -- re-measure, keep the scroll spot
            body.after_idle(lambda: ui.fix_scroll(page.canvas, page.body, top=False))
        self._prep_summary()

    def _prep_patch_right(self, looks):
        """In-place update of the Keep in stock rows (pill, station/detail line, latest step, bar)."""
        import ui_kit as ui
        counts = {}
        for k, ((pill, col, detail, frac), last, it, saved) in looks.items():
            row = self._prep_rows[k]
            counts[pill] = counts.get(pill, 0) + 1
            if last and detail.startswith("retrying"):
                detail = ""
            if row["pill_key"] != (pill, col):           # fixed-size pill: swap it in the same spot
                new = ui.pill(row["row"], pill, col, bg=ui.CARD, chars=9)
                new.pack(side="right", padx=(8, 0), before=row["stepper"])
                row["pill"].destroy()
                row["pill"], row["pill_key"] = new, (pill, col)
            row["detail"].config(text=f"{it['station']}" + (f" \u00b7 {detail}" if detail else ""))
            if row["last"] is not None and last:
                row["last"].config(text=f"{last[0]}  {last[1]}", fg=ui.mix(col, TEXT, 0.35))
            if row["bar"] is not None and frac is not None:
                ui.set_bar(row["bar"], frac, col)
        self._prep_counts = counts

    def _prep_summary(self):
        counts = getattr(self, "_prep_counts", {})
        parts = [f"{len(self.cat_order)} item{'s' if len(self.cat_order) != 1 else ''}"]
        for key in ("\u2713 stocked", "cooking", "working", "waiting", "blocked"):
            if counts.get(key):
                parts.append(f"{counts[key]} {key.lstrip(chr(0x2713) + ' ')}")
        dirty = self.cat_order != self.cat_saved_items
        msg = " \u00b7 ".join(parts) if self.cat_order else "Nothing on the list."
        if dirty and (self.cat_order or self.cat_saved_items):
            msg += "   \u2022 changes not saved yet"
        elif self.cat_saved_items:
            msg += "   \u2022 saved \u2713"
        try:
            self.cat_summary.config(text=msg, fg="#f0c040" if dirty and (self.cat_order or self.cat_saved_items)
                                    else DIM_TEXT)
        except (tk.TclError, AttributeError):
            pass

    PREP_SKIP = ("stock box read as", "stock number not readable", "list saved:", "order cancelled")
    PREP_CODES = {"blocked_on_ingredient": "missing an ingredient", "dish_card_not_found": "couldn't find its card",
                  "long_cook_held": "held (long cook on a Food Club station)", "travel_failed": "travel failed"}

    def _prep_tidy(self, msg):
        """A [prep] log line in plain words (or None to leave it out of Activity)."""
        if any(x in msg for x in self.PREP_SKIP):
            return None
        m = re.match(r"(.+?): at its station the result was '([^']+)'", msg)
        if m:
            return f"{m.group(1)}: {self.PREP_CODES.get(m.group(2), m.group(2).replace('_', ' '))}"
        m = re.match(r"route: (.+?) \(\d+ hops?\): (.*)", msg)
        if m:
            return f"{m.group(1)}: travelling \u2192 {m.group(2).split('-> ')[-1]}"
        m = re.match(r"working on (.+?): stock it up to (\d+)", msg)
        if m:
            return f"{m.group(1)}: started (want {m.group(2)})"
        m = re.match(r"no route to (.+?): nothing on the clipboard leads to (.+?) right now", msg)
        if m:                                     # 11/8: was left as-is, so the item's step stayed "started (want 5)"
            return f"{m.group(1)}: no clipboard order leads to {m.group(2)} yet -- trying again in 15 min"
        m = re.match(r"(.+?): have (\d+), cooking (\d+), want (\d+) -> make (\d+)", msg)
        if m:
            return f"{m.group(1)}: have {m.group(2)}, {m.group(3)} cooking \u2192 making {m.group(5)}"
        return msg

    def _prep_poll(self):
        """Every 3 s while the Prep work tab is open: Now: bar, Activity and each item's latest step from the
        [prep] lines of run_log.txt. Display only."""
        import ui_kit as ui
        try:
            if self._tab == "recipes":
                size = os.path.getsize(LOG)
                with open(LOG, "rb") as fh:
                    fh.seek(max(0, size - 150000))
                    lines = fh.read().decode("utf-8", "replace").splitlines()
                events = []
                for ln in lines:
                    if "[prep]" not in ln:
                        continue
                    m = re.match(r"\[\d{4}-\d\d-\d\dT(\d\d):(\d\d):\d\d\].*?\[prep\] (.*)", ln)
                    if not m:
                        continue
                    text = self._prep_tidy(m.group(3))
                    if text:
                        h = int(m.group(1))
                        events.append((f"{h % 12 or 12}:{m.group(2)} {'PM' if h >= 12 else 'AM'}", text))
                sig = tuple(events[-8:])
                if sig != self._prep_log_sig:
                    self._prep_log_sig = sig
                    last = {}
                    for when, text in events:
                        name, _, rest = text.partition(": ")
                        if rest and name.lower() in {it["name"].lower() for k, it in self.cat_items.items()
                                                     if k in self.cat_order}:
                            last[name.lower()] = (when, rest)
                    self._prep_last = last
                    for w in self.cat_activity.winfo_children():
                        w.destroy()
                    for when, text in reversed(events[-5:]):
                        r = tk.Frame(self.cat_activity, bg=ui.CARD)
                        r.pack(fill="x", pady=1)
                        tk.Label(r, text=when, font=ui.font(8), bg=ui.CARD, fg=ui.DIM, width=8, anchor="w").pack(
                            side="left")
                        tk.Label(r, text=text, font=ui.font(8), bg=ui.CARD, fg=TEXT, anchor="w", justify="left",
                                 wraplength=260).pack(side="left", fill="x", expand=True)
                    if not events:
                        tk.Label(self.cat_activity, text="nothing yet -- tick Prep work and press Start",
                                 font=ui.font(8), bg=ui.CARD, fg=ui.DIM).pack(anchor="w")
                    self._prep_draw_right()
                if events:
                    when, text = events[-1]
                    self.cat_now.config(text=f"{text}   \u00b7  {when}",
                                        fg=TEXT if self.running and self.prep_var.get() else DIM_TEXT)
                else:
                    self.cat_now.config(text="Prep work hasn't done anything yet." if self.prep_var.get() else
                                        "Prep work is not ticked on the left.", fg=DIM_TEXT)
        except Exception:                                # noqa: BLE001 -- display only
            pass
        self.root.after(3000, self._prep_poll)

    def refresh_prep_status(self):
        """Thread-safe: redraw the Keep in stock list if an item's state changed."""
        def ui_():
            try:
                self._prep_draw_right()
            except Exception:                            # noqa: BLE001
                pass
        try:
            self.root.after(0, ui_)
        except Exception:                                # noqa: BLE001
            pass

    def _cat_asap_toggled(self):
        """11/2 (#15c): one "⏰ ASAP ▾" button; a delayed start is picked in a small pop-up (_cat_time_popup)."""
        import ui_kit as ui
        try:
            for w in self.cat_mode.winfo_children():
                w.destroy()
            self.cat_time.pack_forget()
            if self.cat_asap.get():
                text = "⏰ ASAP ▾"
            else:
                text = (f"⏰ {self.cat_day.get()} {self.cat_hour.get()}:{self.cat_min.get()} "
                        f"{self.cat_ampm.get()} ▾")
            ui.button(self.cat_mode, text, self._cat_time_popup, bg=ui.CARD, size=9).pack(side="left")
        except (AttributeError, tk.TclError):
            pass
        self._cat_refresh()

    def _cat_time_popup(self):
        import ui_kit as ui
        try:
            if getattr(self, "_cat_pop", None) is not None and self._cat_pop.winfo_exists():
                self._cat_pop.destroy()
        except tk.TclError:
            pass
        pop = tk.Toplevel(self.root)
        self._cat_pop = pop
        pop.title("When should it be ready?")
        pop.configure(bg=ui.CARD)
        pop.transient(self.root)
        pop.resizable(False, False)
        tk.Label(pop, text="Start", font=ui.font(10, True), bg=ui.CARD, fg=GOLD).pack(anchor="w", padx=14, pady=(12, 6))

        def done(asap):
            self.cat_asap.set(asap)
            pop.destroy()
            self._cat_asap_toggled()
        ui.button(pop, "ASAP -- as soon as possible", lambda: done(True), primary=self.cat_asap.get()
                  ).pack(fill="x", padx=14)
        tk.Label(pop, text="or ready at:", font=ui.font(9), bg=ui.CARD, fg=ui.DIM).pack(anchor="w", padx=14,
                                                                                          pady=(10, 2))
        row = tk.Frame(pop, bg=ui.CARD)
        row.pack(padx=14, anchor="w")
        om = tk.OptionMenu(row, self.cat_day, *self.cat_day_labels)
        ap = tk.OptionMenu(row, self.cat_ampm, "AM", "PM")
        for m in (om, ap):
            m.config(bg=ui.mix(ui.CARD, "#ffffff", 0.08), fg=TEXT, relief="flat", highlightthickness=0,
                     activebackground=GOLD_DIM, font=ui.font(9), bd=0)
            m["menu"].config(bg=PANEL, fg=TEXT, activebackground=GOLD_DIM)
        spin = dict(width=3, justify="center", bg=ui.mix(ui.CARD, "#000000", 0.25), fg=TEXT, relief="flat",
                    buttonbackground=ui.mix(ui.CARD, "#ffffff", 0.08), insertbackground=TEXT, font=ui.font(9))
        om.pack(side="left", padx=(0, 6))
        tk.Spinbox(row, from_=1, to=12, textvariable=self.cat_hour, **spin).pack(side="left")
        tk.Label(row, text=":", font=ui.font(10), bg=ui.CARD, fg=TEXT).pack(side="left")
        tk.Spinbox(row, values=("00", "15", "30", "45"), textvariable=self.cat_min, **spin).pack(side="left")
        ap.pack(side="left", padx=(6, 0))
        ui.button(pop, "Use this time", lambda: done(False), primary=not self.cat_asap.get()
                  ).pack(fill="x", padx=14, pady=(10, 14))
        try:
            pop.update_idletasks()
            x = self.cat_mode.winfo_rootx()
            y = self.cat_mode.winfo_rooty() - pop.winfo_reqheight() - 8
            pop.geometry(f"+{max(0, x)}+{max(0, y)}")
        except tk.TclError:
            pass

    def _toggle_jobs_column(self):
        self._jobs_hidden = not getattr(self, "_jobs_hidden", False)
        self._save_setting("hide_jobs", int(self._jobs_hidden))
        self._apply_jobs_column()

    def _apply_jobs_column(self):
        """11/9: the Jobs column is hidden on every tab while the owner has it hidden (caret "›" brings it back)."""
        try:
            if not hasattr(self, "_jobs_hidden"):
                self._jobs_hidden = bool(self._load_setting("hide_jobs", self._load_setting("prep_hide_jobs", 0)))
            hide = self._jobs_hidden
            if hide and self._left_col.winfo_ismapped():
                self._left_col.pack_forget()
            elif not hide and not self._left_col.winfo_ismapped():
                self._left_col.pack(side="left", fill="y", before=self._left_sep)
            self._jobs_caret.config(text="›" if hide else "‹")
        except (AttributeError, tk.TclError):
            pass

    def _prep_lists_menu(self, which):
        """⭐ Favorites / 🕘 History drop-downs (prep_lists.py keeps the file)."""
        import prep_lists
        d = prep_lists.load()
        names = {k: it["name"] for k, it in self.cat_items.items()}
        m = tk.Menu(self.root, tearoff=0, bg=PANEL, fg=TEXT, activebackground=GOLD_DIM, activeforeground="#1e1e1e")
        if which == "fav":
            for name, items in sorted(d["favorites"].items()):
                m.add_command(label=f"{name}  ·  {prep_lists.describe(items, names)}",
                              command=lambda it=items, n=name: self._prep_load_list(it, f"favorite '{n}'"))
            if d["favorites"]:
                m.add_separator()
            m.add_command(label="Save the current list as a favorite…", command=self._prep_save_favorite,
                          state="normal" if self.cat_order else "disabled")
            if d["favorites"]:
                dm = tk.Menu(m, tearoff=0, bg=PANEL, fg=TEXT, activebackground=GOLD_DIM)
                for name in sorted(d["favorites"]):
                    dm.add_command(label=name, command=lambda n=name: self._prep_delete_favorite(n))
                m.add_cascade(label="Delete a favorite", menu=dm)
        else:
            if not d["history"]:
                m.add_command(label="No saved lists yet -- Save list adds one here.", state="disabled")
            for h in d["history"]:
                when = time.strftime("%a %I:%M %p", time.localtime(h.get("t", 0))).replace(" 0", " ")
                m.add_command(label=f"{when}  ·  {prep_lists.describe(h['items'], names)}",
                              command=lambda it=h["items"]: self._prep_load_list(it, "a saved list"))
        btn = self.cat_fav_btn if which == "fav" else self.cat_hist_btn
        try:
            m.tk_popup(btn.winfo_rootx(), btn.winfo_rooty() - 10 - 22 * max(1, m.index("end") + 1))
        finally:
            m.grab_release()

    def _prep_load_list(self, items, what):
        """Put a saved list on the right (not saved/placed until Save list)."""
        self.cat_order.clear()
        self.cat_order.update({k: int(n) for k, n in items.items() if k in self.cat_items and int(n) > 0})
        self._prep_draw_left()
        self._prep_draw_right(force=True)
        self._cat_refresh()
        missing = [k for k in items if k not in self.cat_items]
        self.set_status(f"Loaded {what} -- press Save list to start it." +
                        (f" ({len(missing)} item(s) no longer in the recipe book were left out.)" if missing else ""))

    def _prep_save_favorite(self):
        import prep_lists
        from tkinter import simpledialog
        name = simpledialog.askstring("Save favorite", "Name for this list (e.g. Pet food):", parent=self.root)
        if not name or not name.strip():
            return
        d = prep_lists.load()
        prep_lists.set_favorite(d, name, self.cat_order)
        prep_lists.save(d)
        self.set_status(f"Saved favorite '{name.strip()}'.")

    def _prep_delete_favorite(self, name):
        import prep_lists
        from tkinter import messagebox
        if not messagebox.askyesno("Delete favorite", f"Delete the favorite '{name}'?", parent=self.root):
            return
        d = prep_lists.load()
        prep_lists.delete_favorite(d, name)
        prep_lists.save(d)
        self.set_status(f"Deleted favorite '{name}'.")

    def _cat_deliver(self):
        import datetime as _dt
        if getattr(self, "cat_asap", None) is not None and self.cat_asap.get():
            wall, _ = self._cat_calc()
            if wall is None:
                return None
            return _dt.datetime.now() + _dt.timedelta(seconds=wall + self.CATERING_MARGIN_SEC)
        try:
            h = int(self.cat_hour.get()) % 12 + (12 if self.cat_ampm.get() == "PM" else 0)
            m = int(self.cat_min.get())
            d = self.cat_days[self.cat_day.get()]
            return _dt.datetime(d.year, d.month, d.day, h, m)
        except (ValueError, KeyError):
            return None

    def _cat_calc(self):
        """(wall seconds or None, unknown) for the current order -- the recipe book's own time math."""
        if not self.cat_order:
            return None, False
        book = {k: n for k, n in self.cat_order.items() if not str(k).startswith("ev:")}   # event items: Food Club's
        if not book:
            return 0, False
        r = rb.cost(book)
        return r["wall"], bool(r["unknown"])

    def _cat_refresh(self):
        import datetime as _dt
        try:
            wall, unknown = self._cat_calc()
        except Exception:                                # noqa: BLE001
            wall, unknown = None, False
        deliver = self._cat_deliver()
        if wall is None:
            self.cat_start.set("Add items -- the time shows up here.")
            self.cat_start_label.config(fg=DIM_TEXT)
            return
        if deliver is None:
            self.cat_start.set("")
            return
        start = deliver - _dt.timedelta(seconds=wall + self.CATERING_MARGIN_SEC)
        fmt = lambda t: t.strftime("%a %I:%M %p").replace(" 0", " ")                 # noqa: E731
        took = f"{'at least ' if unknown else ''}{rb.fmt(wall)} + 5 min margin"
        if self.cat_asap.get():
            self.cat_start.set(f"ready about {fmt(deliver)}  ({took})")
            self.cat_start_label.config(fg="#f0c040")
        elif start < _dt.datetime.now():
            self.cat_start.set(f"start time {fmt(start)} has passed -- pick a later time or fewer items")
            self.cat_start_label.config(fg="#e06060")
        else:
            self.cat_start.set(f"starts {fmt(start)} \u2192 ready {fmt(deliver)}  ({took})")
            self.cat_start_label.config(fg="#f0c040")

    def _cat_place(self):
        """Save list: saving the list is placing the order (prep_engine reads .prep.json)."""
        import json
        if not self.cat_order:
            self._cat_clear()
            return
        try:
            wall, _ = self._cat_calc()
        except Exception:                                # noqa: BLE001
            wall = None
        deliver = self._cat_deliver()
        if wall is None or deliver is None:
            self.cat_summary.config(text="Could not work out the time for this list.", fg="#e06060")
            return
        summary = f"Placed: {self.cat_start.get()}"
        data = {"items": dict(self.cat_order), "deliver": deliver.timestamp(),
                "start": deliver.timestamp() - wall - self.CATERING_MARGIN_SEC, "placed": True, "summary": summary,
                "after": self.cat_after.get(), "asap": bool(self.cat_asap.get())}
        try:
            with open(self.CATERING_FILE, "w", encoding="utf-8") as fh:
                json.dump(data, fh)
        except OSError as e:
            self.cat_summary.config(text=f"Could not save the list: {e}", fg="#e06060")
            return
        self.cat_saved_items = dict(self.cat_order)
        self.cat_placed.set(summary)
        try:                                             # 11/2 (#15e): 🕘 History keeps the last 10 saved lists
            import prep_lists
            prep_lists.save(prep_lists.add_history(prep_lists.load(), self.cat_order))
        except Exception:                                # noqa: BLE001
            pass
        self.refresh_prep_status()
        log(f"[prep] list saved: {self.cat_order}, {self.cat_start.get()}")

    def _cat_clear(self):
        """Clear list: empties the list and cancels the saved order."""
        self.cat_order.clear()
        self._cat_cancel()
        self.cat_saved_items = {}
        self._prep_draw_left()
        self._cat_refresh()

    def _cat_cancel(self):
        try:
            os.remove(self.CATERING_FILE)
        except OSError:
            pass
        self.cat_placed.set("")
        self.cat_saved_items = {}
        self.refresh_prep_status()
        log("[prep] order cancelled.")

    def run_tool(self, script, title):
        """Runs tools/<script> in its own console window so its progress and result stay visible."""
        import subprocess
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tools", script)
        if not os.path.exists(path):
            self.set_status(f"{title}: tools\\{script} is missing -- run the update script from the desktop once.")
            return
        try:
            subprocess.Popen(["cmd", "/c", path], cwd=os.path.dirname(path),
                             creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
        except Exception as e:                           # noqa: BLE001
            log(f"{title} failed to start: {e}")
            self.set_status(f"{title} failed to start: {e}")
            return
        log(f"{title}: started tools\\{script}.")
        if script == "get_afsd_update.bat":
            self.set_status("Updating in a separate window. When it says Updated, close AFSD and open it again.")
        else:
            self.set_status("Sending logs in a separate window. When it says Sent, tell Claude: check the logs.")

    def train_event_icon(self):
        """Screenshot the game, show the bottom bar, and save the icon the owner clicks as the new
        Food Club event icon (templates/event_board_icon.png; the old one is kept as a backup)."""
        self.set_status("New event icon: taking a screenshot...")
        result = {}                                      # filled by the worker; read only by the Tk thread

        def work():
            try:
                import adb_helper
                img = adb_helper.screenshot()
                if img is None:
                    raise RuntimeError("no screenshot from the emulator")
                result["img"] = img
            except Exception as e:                       # noqa: BLE001
                log(f"New event icon: screenshot failed: {e}")
                result["error"] = str(e)

        def poll():
            if "img" in result:
                self._show_icon_picker(result["img"])
            elif "error" in result:
                self.set_status(f"New event icon: screenshot failed: {result['error']}")
            else:
                self.root.after(100, poll)
        threading.Thread(target=work, daemon=True).start()
        self.root.after(100, poll)

    def _show_icon_picker(self, img):
        import base64
        import cv2
        import event_icon_trainer as eit
        importlib.reload(eit)
        x1, y1, _, _ = eit.REGION
        ok, png = cv2.imencode(".png", eit.bar_picture(img))
        if not ok:
            self.set_status("New event icon: could not show the screenshot.")
            return
        win = tk.Toplevel(self.root)
        win.title("New event icon")
        win.configure(bg=BG)
        tk.Label(win, text="Click the MIDDLE of the Food Club event icon.\n"
                           "(Make sure the game shows the plain map first.)",
                 bg=BG, fg=TEXT, justify="center").pack(padx=10, pady=(10, 6))
        photo = tk.PhotoImage(data=base64.b64encode(png.tobytes()).decode("ascii"))
        canvas = tk.Canvas(win, width=photo.width(), height=photo.height(),
                           highlightthickness=0, cursor="crosshair")
        canvas.create_image(0, 0, image=photo, anchor="nw")
        canvas.image = photo                                 # keep a reference
        canvas.pack(padx=10, pady=(0, 6))
        hw, hh = eit.ICON_W // 2, eit.ICON_H // 2
        box = canvas.create_rectangle(0, 0, 0, 0, outline=GOLD, width=2)
        canvas.bind("<Motion>", lambda e: canvas.coords(box, e.x - hw, e.y - hh, e.x + hw, e.y + hh))

        def on_click(e):
            done, msg = eit.save_icon(img, x1 + e.x, y1 + e.y)
            log(f"New event icon: {msg}")
            self.set_status(msg)
            if done:
                win.destroy()
        canvas.bind("<Button-1>", on_click)
        tk.Button(win, text="Cancel", command=win.destroy, bg=PANEL, fg=TEXT,
                  relief="flat").pack(pady=(0, 10))
        self.set_status("New event icon: click the event icon in the new window.")

    def take_training_shot(self):
        """Saves the current screen to templates/training_shots/ (flagged _BLANK if empty)."""
        def work():
            try:
                ad_skip.save_snapshot(set_status=self.set_status)
            except Exception as e:                       # noqa: BLE001
                log(f"Training screenshot failed: {e}")
                self.set_status(f"Screenshot failed: {e}")
        threading.Thread(target=work, daemon=True).start()

    def _express_ok(self, what):
        """11/2 (owner: missed an express while recording an ad): warn before anything that stops the bot while an
        express card is on the board. True = go ahead."""
        try:
            import event_orders
            if not event_orders.express_active():
                return True
        except Exception:                                # noqa: BLE001
            return True
        from tkinter import messagebox
        ok = messagebox.askyesno(
            "Express order on the board",
            f"An EXPRESS order is on the board right now.\n\n{what} stops the bot, and nobody will finish or "
            f"hand in the express while it is stopped.\n\nDo it anyway?", icon="warning", default="no")
        log(f"[express] owner warned before '{what}' during an express -- {'went ahead' if ok else 'cancelled'}.")
        return ok

    def _start_stop_clicked(self):
        if self.running and not self._express_ok("Stop"):
            return
        self.toggle_running()

    def let_me_play(self):
        if self.playing:
            self._play_cancel.set()
            return
        if self.recording_ad:
            self.set_status("Finish the ad recording first.")
            return
        if not self._express_ok("Let Me Play"):
            return
        was_running = self.running
        if was_running:
            self.toggle_running()
        self.playing = True
        self._play_cancel = threading.Event()
        self.play_button.config(text="Done playing", bg=GOLD, fg="#1e1e1e")
        self.start_button.config(state="disabled")
        log("[play] Let Me Play: the bot is paused -- play by hand; every tap you make is recorded (nothing is "
            "tapped by the bot)." + (" It starts again when you press Done playing." if was_running else ""))
        self.set_status("Let Me Play: your turn -- I'm watching and taking notes.")

        def work():
            time.sleep(3 if was_running else 0)                # let the stopped run thread finish its last step
            try:
                ad_skip.record_session(self._play_cancel, set_status=self.set_status, play=True)
            except Exception as e:                       # noqa: BLE001
                log(f"[play] Let Me Play failed: {e}\n{traceback.format_exc()}")
                self.set_status(f"Let Me Play failed: {e}")
            finally:
                self.playing = False

                def back():
                    self.play_button.config(text="Let Me Play", bg=PANEL, fg=TEXT)
                    self.start_button.config(state="normal")
                    if self.send_after_play_var.get():   # 10/26 (owner): Done playing sends the recording
                        log("[play] Done playing -- sending the recording (Settings: Send logs after Let Me Play).")
                        self.run_tool_inline("send")     # Start below waits for this send to finish
                    if was_running and not self.running:
                        log("[play] Done playing -- starting the bot again.")
                        self.toggle_running()
                try:
                    self.root.after(0, back)
                except Exception:                        # noqa: BLE001
                    pass

        threading.Thread(target=work, daemon=True).start()

    def record_ad(self):
        if self.running:
            self.set_status("Press Stop first, then Record ad.")
            return
        if self.recording_ad:
            self._record_cancel.set()
            return
        if not self._express_ok("Record ad"):
            return
        self.recording_ad = True
        self._record_cancel = threading.Event()
        self._update_ad_button()
        self.open_log_window(prefilter="[ads]")

        def work():
            try:
                ad_skip.record_session(self._record_cancel, set_status=self.set_status)
            except Exception as e:                       # noqa: BLE001
                log(f"Record ad failed: {e}\n{traceback.format_exc()}")
                self.set_status(f"Record ad failed: {e}")
            finally:
                self.recording_ad = False
                try:
                    self.root.after(0, self._update_ad_button)
                except Exception:                        # noqa: BLE001
                    pass

        threading.Thread(target=work, daemon=True).start()

    @staticmethod
    def next_clock_time(hour12, minute, ampm, now=None):
        """Pure: the next local time (epoch) showing hour12:minute AM/PM -- today if still ahead, else tomorrow."""
        import datetime as _dt
        now = now or _dt.datetime.now()
        h = int(hour12) % 12 + (12 if str(ampm).upper() == "PM" else 0)
        t = now.replace(hour=h, minute=int(minute), second=0, microsecond=0)
        if t <= now:
            t += _dt.timedelta(days=1)
        return t.timestamp()

    def _fc_start_tick(self):
        """11/13 (owner: "start the food club event at 3am central"): at the set time tick Food Club Event, turn
        'hold serving' off and press Start if the bot is stopped. One-shot: clears itself."""
        try:
            at = float(self._load_setting("fc_start_at", 0) or 0)
            if at and time.time() >= at:
                self._save_setting("fc_start_at", 0)
                self.event_orders_var.set(True)
                self.hold_serve_var.set(False)
                log("[schedule] it is the set time -- Food Club Event ticked, hold serving off"
                    + ("." if self.running else ", pressing Start."))
                if not self.running:
                    self.toggle_running()
                self._fc_start_show()
        except Exception as e:                           # noqa: BLE001
            log(f"[schedule] Food Club start timer failed: {e!r}")
        self.root.after(20000, self._fc_start_tick)

    def _fc_start_show(self):
        try:
            at = float(self._load_setting("fc_start_at", 0) or 0)
            self.fc_start_label.config(
                text=("set for " + time.strftime("%a %I:%M %p", time.localtime(at)).replace(" 0", " ")) if at
                else "off", fg=GOLD if at else DIM_TEXT)
        except (AttributeError, tk.TclError):
            pass

    def _auto_cycle_tick(self):
        """10/22 (owner): auto Stop -> send logs -> Start (-> update) every auto_cycle_min minutes. Checks each minute."""
        try:
            mins = int(self.auto_cycle_min_var.get() or 0)
            started = getattr(self, "_run_started", None)
            try:
                import no_progress                       # 11/15: its game restart waits for an auto restart due soon
                no_progress.AUTO_RESTART_AT[0] = started + mins * 60 if (mins > 0 and self.running and started) else 0
            except Exception:                            # noqa: BLE001
                pass
            if mins > 0 and self.running and started and time.time() - started >= mins * 60:
                busy = False
                try:
                    import event_orders
                    busy = bool(event_orders.express_active())
                except Exception:                        # noqa: BLE001
                    pass
                ad_on = False
                try:
                    import ad_player                     # 11/2 live: a restart mid-ad left the ad on screen
                    ad_on = bool(ad_player.ACTIVE) and time.time() - ad_player.ACTIVE < 600
                except Exception:                        # noqa: BLE001
                    pass
                if ad_on and not busy:
                    log("[auto restart] due, but an ad is being watched -- waiting for it to end.")
                elif busy:
                    log("[auto restart] due, but an express order is on -- waiting for it to finish.")
                else:
                    log(f"[auto restart] {mins} min since Start -- Stop, send logs, Start again (update check).")
                    self.toggle_running()                    # Stop (sends logs when "Send logs at every Stop" is on)
                    if not self.send_at_stop_var.get():
                        self.run_tool_inline("send")
                    self.root.after(20000, self._auto_cycle_start)
        except Exception as e:                           # noqa: BLE001
            log(f"[auto restart] skipped: {e!r}")
        self.root.after(60000, self._auto_cycle_tick)

    def _auto_cycle_start(self):
        if not self.running:
            self.toggle_running()                            # Start waits for the send, then checks / installs updates

    def toggle_running(self):
        if self.running:
            self.stop_flag.set()
            self.running = False
            self.start_button.config(text="Start", bg=GOLD)
            self.set_status("Stopped.")
            log("Stop pressed.")
            session_lock.release()
            self._update_ad_button()
            if self.send_at_stop_var.get() and not getattr(self, "_relaunching", False):
                self.run_tool_inline("send")             # the run that just ended (takes the lock at once)
        else:
            if self._active_checkboxes() == ["none"]:      # 10/19 (owner): say it loudly instead of idling
                self.set_status("\u26a0 NOTHING IS TICKED \u2014 tick Food Club Event (or another job) on the left, "
                                "then press Start.")
                self.status_label.config(fg="#f0c040")
                self.root.after(6000, lambda: self.status_label.config(fg=TEXT))
                log("Start pressed with nothing ticked -- not starting.")
                self._toast_show()
                self.tool_var.set("\u26a0  Nothing is ticked. Tick Food Club Event (or another job) on the left, "
                                  "then press Start.")
                self.tool_label.config(fg="#f0c040")
                self._toast_job = self.root.after(8000, self._toast_hide)
                return
            # Fresh Event per Start (found live 10/2): Stop then a quick Start
            # used to clear the SAME flag before the old loop (mid map-search)
            # noticed it, so two loops drove the emulator at once. The old
            # thread keeps its own already-set flag; also give it a moment to
            # actually exit before the new loop begins.
            old = getattr(self, "thread", None)
            self.stop_flag = threading.Event()
            if old is not None and old.is_alive():
                old.join(timeout=8)
            self.running = True
            self._run_started = time.time()
            self._auto_update_now = bool(self.auto_update_var.get())     # read here: Tk vars belong to this thread
            self.start_button.config(text="Stop", bg="#a33")
            self._update_ad_button()
            self.set_status("Starting...")
            log(f"Start pressed. Active: {', '.join(self._active_checkboxes())}. "
                f"Check interval: {afsd_core.CHECK_INTERVAL_SEC}s.")
            session_lock.acquire(owner="afsd_gui")
            self.thread = threading.Thread(target=self.run_loop, daemon=True)
            self.thread.start()

    def run_loop(self):
        """Thin delegate into afsd_core.run_loop(self) -- the actual cycle
        logic lives there now specifically so Reload can refresh it (see
        afsd_core.py's module docstring). This method does a fresh
        `afsd_core.run_loop` attribute lookup every time it's called
        (rather than, say, capturing a reference once at import time), so
        a Reload that re-imports afsd_core takes effect on the very next
        Start with no app restart needed.
        10/13: Start now also re-imports afsd_core itself before running it, so an
        edit to afsd_core.py is picked up on every Start (the automation modules
        were already reloaded at Start by afsd_core.reload_modules_at_start, but
        afsd_core could not reload itself)."""
        my_flag = self.stop_flag                    # 10/18 review: this run's own flag, taken BEFORE the update step
        msg = self._start_update_check(my_flag)     # before afsd_core is re-imported, so new code loads now
        if my_flag.is_set() or my_flag is not self.stop_flag:
            log("Start: stopped (or started again) during the update step -- this run ends here.")
            return                                  # never two loops on the emulator
        if msg and "close AFSD" in msg:             # new window code: running on would mix old and new code
            log("Start: the update needs a fresh AFSD -- relaunching by itself (it presses Start again).")
            self.root.after(0, self.relaunch)
            return
        try:
            importlib.reload(afsd_core)
        except Exception as e:                      # noqa: BLE001 -- a half-written file keeps the old copy
            log(f"afsd_core could not be re-imported at Start ({e!r}) -- using the copy already loaded.")
        afsd_core.run_loop(self)

    def open_stats_overlay(self):
        """Small, collapsible, always-on-top window -- the user can drag it
        over/near the LDPlayer window. The header row is always visible
        (title + a toggle arrow button); the detail text below it only
        shows when expanded, so it can sit out of the way as a thin strip
        when the user doesn't need it. Content is whatever the most recent
        Orders cycle's format_run_report() produced -- reused as-is rather
        than building a second stats renderer."""
        if self.stats_window is not None:
            self.stats_window.lift()
            return

        win = tk.Toplevel(self.root)
        win.title("AFSD — Stats")
        win.configure(bg=PANEL)
        win.attributes("-topmost", True)
        win.protocol("WM_DELETE_WINDOW", self.close_stats_overlay)
        self.stats_window = win

        label_font = tkfont.Font(family="Segoe UI", size=10)
        arrow_font = tkfont.Font(family="Segoe UI", size=10, weight="bold")

        header = tk.Frame(win, bg=PANEL)
        header.pack(fill="x")
        tk.Label(header, text="Stats", font=label_font, bg=PANEL, fg=GOLD).pack(
            side="left", padx=(10, 4), pady=6)
        self.stats_toggle_button = tk.Button(
            header, text="▼", font=arrow_font, bg=PANEL, fg=TEXT,
            activebackground=GOLD_DIM, relief="flat", bd=0, width=2,
            command=self.toggle_stats_overlay,
        )
        self.stats_toggle_button.pack(side="right", padx=(4, 8), pady=4)

        self.stats_detail_frame = tk.Frame(win, bg=PANEL)
        self.stats_detail_frame.pack(fill="both", expand=True)
        self.stats_text_var = tk.StringVar(
            value="(no Orders check run yet this session)")
        tk.Label(self.stats_detail_frame, textvariable=self.stats_text_var,
                 font=label_font, bg=PANEL, fg=TEXT, justify="left",
                 wraplength=320, anchor="w").pack(fill="both", expand=True,
                                                    padx=10, pady=(0, 10))

        self.stats_expanded = True
        win.geometry("340x260+40+40")

    def toggle_stats_overlay(self):
        self.stats_expanded = not self.stats_expanded
        if self.stats_expanded:
            self.stats_detail_frame.pack(fill="both", expand=True)
            self.stats_toggle_button.config(text="▼")
            self.stats_window.geometry("340x260")
        else:
            self.stats_detail_frame.pack_forget()
            self.stats_toggle_button.config(text="▶")
            self.stats_window.geometry("340x36")

    def set_stats(self, text):
        """Pushes fresh report text into the overlay if it's open. Safe to
        call every cycle even when the window was never opened or was
        closed since -- becomes a no-op."""
        if self.stats_window is not None and self.stats_text_var is not None:
            self.stats_text_var.set(text)

    def close_stats_overlay(self):
        if self.stats_window is not None:
            self.stats_window.destroy()
        self.stats_window = None
        self.stats_detail_frame = None
        self.stats_toggle_button = None
        self.stats_text_var = None

    def on_close(self):
        # 10/18 (owner): closing in the middle of an update could leave half-new, half-old files. Ask first
        # (a Relaunch closes on purpose and is never asked).
        lock = getattr(self, "_tool_lock", None)
        if lock is not None and lock.locked() and not getattr(self, "_relaunching", False):
            from tkinter import messagebox
            if not messagebox.askyesno(
                    "AFSD is still working",
                    "Send logs or Update is still running.\n\nClosing now can interrupt an update half-way. "
                    "Wait a few seconds for the green \u2713 and close then.\n\nClose anyway?",
                    icon="warning", default="no"):
                return
            log("App closing while Send logs / Update was still running (owner chose to close anyway).")
        log("App closing (window closed by user).")
        self.stop_flag.set()
        if getattr(self, "_record_cancel", None) is not None:
            self._record_cancel.set()
        self.close_stats_overlay()
        self.close_log_window()
        session_lock.release()
        self.root.destroy()


def _hide_helper_windows():
    """Under pythonw.exe there is no console, so Windows opens a NEW flashing console window for
    every helper program the bot runs (adb for each tap/screenshot, PowerShell for OCR, tasklist...)
    -- seen 10/16 right after the switch. Make every subprocess start hidden unless it explicitly
    asks for its own console (the Send logs / Update buttons do)."""
    import subprocess
    no_window = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    new_console = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
    if not no_window or getattr(subprocess.Popen, "_afsd_hidden", False):
        return
    original = subprocess.Popen.__init__

    def hidden_init(self, *args, **kwargs):
        flags = kwargs.get("creationflags", 0) or 0
        if not flags & new_console:
            kwargs["creationflags"] = flags | no_window
        original(self, *args, **kwargs)
    subprocess.Popen.__init__ = hidden_init
    subprocess.Popen._afsd_hidden = True


def _no_console_setup():
    """10/16: AutoFoodStreet.bat starts the app with pythonw.exe (no black console window).
    pythonw has no console, so: print() output goes to gui_stdout.txt / gui_stderr.txt instead of
    failing, and every crash -- at start-up, in a button, or in a background thread -- is written
    to run_log.txt (where the Log button and send_logs_to_claude.bat see it)."""
    here = os.path.dirname(os.path.abspath(__file__))
    if sys.stdout is None:
        _hide_helper_windows()
    if sys.stdout is None:
        sys.stdout = open(os.path.join(here, "gui_stdout.txt"), "a", encoding="utf-8", buffering=1)
    if sys.stderr is None:
        sys.stderr = open(os.path.join(here, "gui_stderr.txt"), "a", encoding="utf-8", buffering=1)

    def crash(kind, exc_type, exc, tb):
        try:
            log(f"CRASH ({kind}): {exc_type.__name__}: {exc}\n" + "".join(traceback.format_exception(exc_type, exc, tb)))
        except Exception:                                  # noqa: BLE001
            pass
    sys.excepthook = lambda t, e, tb: crash("main", t, e, tb)
    threading.excepthook = lambda a: crash(f"thread {a.thread.name if a.thread else '?'}",
                                           a.exc_type, a.exc_value, a.exc_traceback)
    return crash


def is_admin():
    """True when AFSD runs with administrator rights (always True off Windows)."""
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:                                      # noqa: BLE001
        return True


def start_as_admin(extra_args=()):
    """Open AFSD again with administrator rights (Windows shows its "Do you want to allow" prompt).
    True = the new copy is starting (this one should close); False = refused / not possible."""
    try:
        import ctypes
        import subprocess
        args = [os.path.abspath(__file__)] + [a for a in sys.argv[1:] if a != "--no-elevate"] + list(extra_args) \
            + ["--no-elevate"]
        rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, subprocess.list2cmdline(args),
                                                 os.path.dirname(os.path.abspath(__file__)), 1)
        return rc > 32
    except Exception:                                      # noqa: BLE001
        return False


def _elevate_if_wanted():
    """10/20 (owner): Settings switch "Always start as administrator" -- the watchdog can only close a frozen LDPlayer
    (which runs elevated) when AFSD has administrator rights. --no-elevate stops a second try (prompt said No)."""
    try:
        import json
        with open(AutoFoodStreetApp.SETTINGS_FILE, encoding="utf-8") as fh:
            want = int(json.load(fh).get("run_as_admin", 0))
    except Exception:                                      # noqa: BLE001
        want = 0
    if not want or is_admin() or "--no-elevate" in sys.argv:
        return
    if start_as_admin():
        log("Settings: 'Always start as administrator' is on -- reopening AFSD with administrator rights.")
        sys.exit(0)
    log("Settings: 'Always start as administrator' is on, but Windows did not allow it -- running without.")


def _busy_price_rows(limit=8):
    """11/10 B.U.S.Y.: rows for the Busy Mode tab from .busy_prices.json (best coins/min first), or [] when none."""
    try:
        import busy
        import recipe_book as rb
        book = rb.load()["items"]
        rows = []
        for item, p, secs, cpm in busy.table(busy.load(), busy._cook_of):
            if not p:
                continue
            try:
                it = book.get(rb.resolve(item), {})
            except Exception:                          # noqa: BLE001
                it = {}
            t = f"{secs // 60}m" if secs and secs >= 60 else (f"{secs}s" if secs else "?")
            have = busy.load().get(item, {}).get("stock")
            rows.append((item.replace("_", " ").title(), it.get("station", "?"), t, str(p),
                         f"{cpm:.1f}" if cpm else "?", "?" if have is None else str(have)))
        return rows[:limit]
    except Exception:                                  # noqa: BLE001
        return []


def _icon_app_id():
    """ICON (11/1, owner: "I'm Clearly Not Python"): its own Windows app id, so the taskbar gives AFSD its
    own button instead of grouping it with every other python.exe program. Must run before the window opens."""
    try:
        if sys.platform == "win32":
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("AutoFoodStreet.Bot")
    except Exception:                                      # noqa: BLE001 -- a missing icon never stops AFSD
        pass


def _icon_set(root):
    """ICON: the chef hat + FLASH bolt picture (afsd_icon.py) on the window and its taskbar button."""
    try:
        import afsd_icon
        imgs = [tk.PhotoImage(data=afsd_icon.PNG[z]) for z in (256, 48, 32, 16)]
        root.iconphoto(True, *imgs)
        root._afsd_icons = imgs                            # keep a reference, or Tk drops the pictures
    except Exception:                                      # noqa: BLE001
        pass


def _icon_desktop():
    """ICON (11/1, owner: "project icon needs a desktop icon"): writes afsd.ico next to this file and, when it is
    missing, an "AutoFoodStreet" shortcut on the Desktop (pythonw.exe autofoodstreet.py, no console, AFSD's icon).
    An existing shortcut with that name only gets the icon. Runs in the background; never stops AFSD."""
    if sys.platform != "win32":
        return

    def work():
        try:
            import base64
            import subprocess
            import afsd_icon
            here = os.path.dirname(os.path.abspath(__file__))
            ico = os.path.join(here, "afsd.ico")
            data = afsd_icon.build_ico({z: base64.b64decode(afsd_icon.PNG[z]) for z in (16, 32, 48, 256)})
            if not os.path.exists(ico) or open(ico, "rb").read() != data:
                with open(ico, "wb") as f:
                    f.write(data)
            exe = sys.executable
            pyw = os.path.join(os.path.dirname(exe), "pythonw.exe")
            if os.path.exists(pyw):
                exe = pyw
            script = os.path.join(here, "autofoodstreet.py")
            q = lambda t: t.replace("'", "''")                  # noqa: E731 -- PowerShell single quotes
            ps = ("$d=[Environment]::GetFolderPath('Desktop'); $p=Join-Path $d 'AutoFoodStreet.lnk'; "
                  "$w=New-Object -ComObject WScript.Shell; $new=-not (Test-Path $p); $s=$w.CreateShortcut($p); "
                  f"if($new){{$s.TargetPath='{q(exe)}'; $s.Arguments='\"{q(script)}\"'; "
                  f"$s.WorkingDirectory='{q(here)}'; $s.Description='AutoFoodStreet'}}; "
                  f"if($s.IconLocation -ne '{q(ico)},0'){{$s.IconLocation='{q(ico)},0'; $s.Save(); "
                  "if($new){'made'}else{'icon'}}else{'ok'}")
            r = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], capture_output=True,
                               text=True, errors="replace", timeout=30,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            said = (r.stdout or "").strip()
            if said == "made":
                log("[icon] made the AutoFoodStreet shortcut on the Desktop (chef hat + bolt).")
            elif said == "icon":
                log("[icon] gave the Desktop's AutoFoodStreet shortcut the AFSD icon.")
            elif said != "ok":
                log(f"[icon] desktop shortcut not made: {(r.stderr or said).strip()[:200]}")
        except Exception as e:                                  # noqa: BLE001
            try:
                log(f"[icon] desktop shortcut not made: {e!r}"[:200])
            except Exception:                                   # noqa: BLE001
                pass

    threading.Thread(target=work, daemon=True).start()


if __name__ == "__main__":
    _crash = _no_console_setup()
    log("=== AFSD app launched ===" + (" (administrator)" if is_admin() else ""))
    _elevate_if_wanted()
    try:
        _icon_app_id()
        root = tk.Tk()
        # 11/15: build behind the loading window. NOT withdraw(): a withdrawn window on Windows came up with only the
        # left column laid out -- it is built mapped but fully transparent instead, then made visible.
        try:
            root.attributes("-alpha", 0.0)
        except tk.TclError:
            pass
        _splash_t0 = time.time()
        try:
            import splash                                  # its own process, so the GIF plays smoothly meanwhile
            _splash_proc = splash.start()
        except Exception:                                  # noqa: BLE001
            splash, _splash_proc = None, None
        _icon_set(root)
        _icon_desktop()
        root.report_callback_exception = lambda t, e, tb: _crash("button/window", t, e, tb)
        # 11/9 (owner: the window froze half-drawn after an update, "python is not responding", nothing in the log):
        # (a) HANG RECORDER -- if the window has not finished opening after 40 s, the stack of every thread goes into
        # run_log.txt (Send logs carries it); (b) SAFE MODE -- a launch that never finished opening leaves
        # .window_building behind, and the next launch then skips the newest window extras (thin scrollbars, the
        # resizing Food Truck tab) and says so in the log.
        _building = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".window_building")
        _hang_fh = None
        try:
            import faulthandler
            _hang_fh = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "run_log.txt"), "a")
            _hang_fh.write(f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] [afsd] (hang recorder armed: a stack dump "
                           "follows here only if the window takes over 40 s to open)\n")
            _hang_fh.flush()
            faulthandler.dump_traceback_later(40, exit=False, file=_hang_fh)
        except Exception:                                  # noqa: BLE001
            faulthandler = None
        if os.path.exists(_building):
            log("[window] SAFE MODE: the last launch never finished opening its window -- starting without the thin "
                "scrollbars and the resizing Food Truck tab. Press Send logs and tell Claude.")
            ui_kit.ThinScrollbar = lambda parent, command=None, bg=None, **kw: tk.Scrollbar(parent, command=command)
            AutoFoodStreetApp.TRUCK_RESIZE = False
        try:
            with open(_building, "w") as _fh:
                _fh.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
        except OSError:
            pass

        def _opened():
            try:
                if faulthandler is not None:
                    faulthandler.cancel_dump_traceback_later()
                os.remove(_building)
            except Exception:                              # noqa: BLE001
                pass
        try:
            app = AutoFoodStreetApp(root)
            root.update_idletasks()                        # lay everything out while still hidden
        finally:
            def _show_when_ready():
                try:
                    ready = splash is None or splash.closed(_splash_proc, _splash_t0)
                except Exception:                          # noqa: BLE001
                    ready = True
                if not ready:
                    root.after(50, _show_when_ready)
                    return
                try:
                    root.update_idletasks()
                    root.attributes("-alpha", 1.0)
                except tk.TclError:
                    pass
                root.deiconify()
                root.lift()
                try:
                    root.focus_force()
                except tk.TclError:
                    pass
            try:
                if splash is not None:
                    splash.built()
            except Exception:                              # noqa: BLE001
                pass
            _show_when_ready()
        root.after(3000, _opened)
        if "--start" in sys.argv:                          # 10/18: opened by Relaunch -- carry on where it left off
            log("Relaunched after an update -- pressing Start.")
            app.set_status("Relaunched after an update -- Start presses itself in a few seconds (no need to click).")
            # only if nobody pressed Start meanwhile (10/18 live: owner clicked too, the two cancelled out)
            root.after(3000, lambda: None if app.running else app.toggle_running())
    except Exception:                                      # noqa: BLE001 -- no console to show it, so say it
        _crash("start-up", *sys.exc_info())
        try:
            from tkinter import messagebox
            messagebox.showerror("AFSD could not start",
                                 "AFSD hit an error while starting. It is written at the end of run_log.txt.\n\n"
                                 + traceback.format_exc()[-800:])
        except Exception:                                  # noqa: BLE001
            pass
        raise
    root.mainloop()
    log("=== AFSD app exited ===")
