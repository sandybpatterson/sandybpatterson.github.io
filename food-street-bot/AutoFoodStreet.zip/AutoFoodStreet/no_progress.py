"""No-progress ceiling (10/26, owner: "yes start workstream A" -- the 24-hour plan).

The stall guard only acts when the log is full of FAILURE lines. The costly nights were different: the bot was busy
and wrong (one empty coffee bush "harvested" 527 times, a tomato plot tapped every 30 s behind a Pantry-full popup,
a panel that held it 7 h) -- lots of activity, nothing real done. This module watches only REAL progress (a batch
queued, an order served, a crop harvested or planted, something listed for sale, a Food Club card completed) and
climbs a ladder when there has been none for a while:

  PROGRESS_CEILING_MIN (30)  -> restart the game (normal launch steps)
  + LADDER_STEP_MIN    (60)  -> restart LDPlayer (watchdog_restart, with its own limits)
  + ALARM_MIN          (90)  -> call the owner once (beeps + a pop-up on top) -- the one intervention
After the alarm it keeps restarting the game every 30 min. Any real progress resets everything.

Only counts while a job that can make progress is ticked (Clipboard Orders, Prep, Food Club, ...); a Tests-only or
Chef-only run is never restarted. A gap of 10+ min between checks (PC asleep, AFSD paused) restarts the clock, so
waking the laptop never fires a restart by itself. Never taps anything in the game itself.
"""
import datetime
import os
import re
import time

BASE = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE, "run_log.txt")
TAIL_BYTES = 800_000

PROGRESS_CEILING_MIN = 30
ERROR_CEILING_MIN = 5        # 11/12 (owner: "5 minute before restarting"; Muse caution): every cycle ERRORING for 5 min
                             # -> restart the game at once. Clean-but-slow runs keep the 30-min rung (false restarts).
LADDER_STEP_MIN = 60
ALARM_MIN = 90
RESTART_EVERY_MIN = 30
SLEEP_GAP_SEC = 10 * 60
AUTO_RESTART_AT = [0]         # 11/15: when the window's auto restart fires next (epoch, 0 = off) -- set each minute
AUTO_SOON_SEC = 300           # a game restart this close to the auto restart is skipped (the Start does it anyway)
ALARM_TITLE = "AFSD - needs you"
WORKING_JOBS = {"Clipboard Orders", "Prep work", "Food Club Event", "Delivery Event", "Food Truck Event",
                "Food Truck (street)", "Pork", "Whipped Cream", "Carrots"}

# real progress only -- "Harvested 0 ready", "already queued 1 batch ... waiting" and "harvested earlier" are NOT
_PROGRESS = re.compile(
    r"queued successfully|SERVED order|\bserved [1-9]|tapping Complete|"
    r"Harvested [1-9]\d* ready|plot round done: harvested [1-9]|plot round done: harvested \d+, planted [1-9]|"
    r"(?<!already )queued [1-9]\d* batch|(?<!already )queued x\d|: queued [1-9]|: queued$|"
    r"planted [1-9]|planted x\d|: planted$|Merchant stock: queued|selling \d+ x |completed [1-9]", re.I)
_TS = re.compile(r"^\[(\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d)\]")

_st = {"since": None, "last_check": 0.0, "level": 0, "last_action": 0.0, "alarmed": False}


def _ts(line):
    m = _TS.match(line)
    if not m:
        return None
    try:
        return datetime.datetime.strptime(m.group(1), "%Y-%m-%dT%H:%M:%S").timestamp()
    except ValueError:
        return None


def last_progress(lines):
    """-> (timestamp of the last real-progress line after the last 'Start pressed', timestamp of that Start)."""
    start_i, start_t = 0, None
    for i, ln in enumerate(lines):
        if "Start pressed" in ln:
            start_i, start_t = i, _ts(ln)
    last = None
    for ln in lines[start_i:]:
        if _PROGRESS.search(ln):
            t = _ts(ln)
            if t is not None:
                last = t
    return last, start_t


def decide(idle_min, level, since_action_min):
    """Pure ladder step -> (action, new_level). action: ok | restart_game | restart_ldplayer | alarm."""
    if idle_min < PROGRESS_CEILING_MIN:
        return "ok", 0
    if level == 0:
        return "restart_game", 1
    if level == 1 and idle_min >= LADDER_STEP_MIN and since_action_min >= 25:
        return "restart_ldplayer", 2
    if level == 2 and idle_min >= ALARM_MIN:
        return "alarm", 3
    if level >= 3 and since_action_min >= RESTART_EVERY_MIN:
        return "restart_game", 3
    return "ok", level


def _read_tail(path):
    try:
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            f.seek(max(0, f.tell() - TAIL_BYTES))
            return f.read().decode("utf-8", "replace").splitlines()
    except OSError:
        return []


def error_restart(err_min, since_action_min):
    """Pure (11/12): restart the game when every cycle has ended in an error for ERROR_CEILING_MIN, at most once per
    ERROR_CEILING_MIN."""
    return bool(err_min and err_min >= ERROR_CEILING_MIN and since_action_min >= ERROR_CEILING_MIN)


def auto_soon(now, at=None):
    """Pure-ish (11/15): True when the auto restart fires within AUTO_SOON_SEC (both used to fire seconds apart)."""
    at = AUTO_RESTART_AT[0] if at is None else at
    return bool(at) and -60 <= at - now <= AUTO_SOON_SEC


def check(logf, active_jobs, log_path=None, now=None, err_since=None):
    """Call once per cycle. Returns ok | restart_game | restart_ldplayer | alarm (the caller acts on it).
    err_since = time the current run of erroring cycles began (None when the last cycle was fine)."""
    try:
        now = now or time.time()
        if err_since and error_restart((now - err_since) / 60.0, (now - _st["last_action"]) / 60.0):
            _st["last_action"] = now
            logf(f"[no progress] every cycle has ended in an error for {(now - err_since) / 60:.0f} min -- "
                 "restarting the game now (not waiting 30 min).")
            return "restart_game"
        gap = now - _st["last_check"] if _st["last_check"] else 0
        _st["last_check"] = now
        if not (set(active_jobs or ()) & WORKING_JOBS):
            _st.update(since=now, level=0)
            return "ok"
        last, start = last_progress(_read_tail(log_path or LOG_PATH))
        ref = max(t for t in (last, start, _st["since"]) if t) if (last or start or _st["since"]) else now
        if gap > SLEEP_GAP_SEC:                      # PC asleep / AFSD paused -- not the bot's fault, fresh clock
            ref = now
        if last is not None and _st["since"] is not None and last > _st["since"]:
            if _st["level"]:
                logf(f"[no progress] real progress again -- ladder reset (it had reached step {_st['level']}).")
            _st.update(level=0, alarmed=False)
        _st["since"] = ref
        idle = (now - ref) / 60.0
        action, level = decide(idle, _st["level"], (now - _st["last_action"]) / 60.0)
        if action == "ok":
            _st["level"] = level
            return "ok"
        if action == "restart_game" and auto_soon(now):
            return "ok"                              # 11/15: the auto restart a few min away restarts the game anyway
        _st["level"], _st["last_action"] = level, now
        what = {"restart_game": "restarting the game", "restart_ldplayer": "restarting LDPlayer",
                "alarm": "calling the owner (beeps + pop-up)"}[action]
        logf(f"[no progress] nothing real done for {idle:.0f} min (no batch queued, order served, crop harvested or "
             f"planted, sale listed) -- step {level}: {what}.")
        return action
    except Exception as e:                               # noqa: BLE001
        try:
            logf(f"[no progress] check failed (ignored): {e!r}")
        except Exception:                                # noqa: BLE001
            pass
        return "ok"


def alarm(idle_min=None, text=None):
    """The one call to the owner: beeps + a pop-up on top of every window (closes itself after 30 min)."""
    def ring():
        try:
            import winsound
            for _ in range(3):
                for f in (660, 880, 660, 880):
                    winsound.Beep(f, 250)
                time.sleep(0.5)
        except Exception:                                # noqa: BLE001
            pass

    def popup():
        try:
            import ctypes
            u = ctypes.windll.user32
            h = u.FindWindowW(None, ALARM_TITLE)
            if h:
                u.PostMessageW(h, 0x0010, 0, 0)
                time.sleep(0.2)
            msg = text or (f"AFSD has done nothing useful for {ALARM_MIN} min (since about "
                    f"{time.strftime('%H:%M', time.localtime(time.time() - ALARM_MIN * 60))}).\n\n"
                    "It already restarted the game and LDPlayer. Please take a look at the emulator, then press "
                    "Send logs and tell Claude.\n(This closes by itself after 30 min.)")
            u.MessageBoxTimeoutW(0, msg, ALARM_TITLE, 0x0 | 0x30 | 0x40000 | 0x10000, 0, 30 * 60 * 1000)
        except Exception:                                # noqa: BLE001
            pass
    import threading
    threading.Thread(target=ring, daemon=True).start()
    threading.Thread(target=popup, daemon=True).start()


def reset():
    """Start pressed: a fresh clock."""
    _st.update(since=time.time(), last_check=0.0, level=0, last_action=0.0, alarmed=False)
