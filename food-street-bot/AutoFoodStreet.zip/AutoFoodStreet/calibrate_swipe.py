"""Swipe-distance calibration -- measures how far the camera's content
actually shifts on screen for a given `swipe()` call, instead of assuming
the nominal (x2-x1, y2-y1) distance is what actually happens. Needed
because `input swipe` has fling/momentum physics (documented in CLAUDE.md):
a swipe is not a 1:1 pixel drag, and find_and_center.py's centering phase
currently assumes it is (computing the next hop as if a previous hop of N
pixels moved the target by exactly N pixels).

Method: crop a distinctive patch from the pre-swipe screenshot, perform the
swipe, then find that same patch in the post-swipe screenshot via template
matching. The patch's start-vs-found position gives the actual on-screen
shift. A patch that can't be confidently re-found (e.g. the swipe crossed
a scene change, or hit a map boundary and nothing moved) is reported as a
failed measurement rather than a guessed number.
"""
import os
import sys
import time
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from adb_helper import screenshot, swipe

# Safe patch region: comfortably inside the game world, clear of the top
# HUD bar (y<70), the top-right event-badge cluster (x>1400, y<320), and
# the bottom nav bar -- matches the same "never trust a UI-adjacent crop"
# lesson as HUD_EXCLUSION_ZONES in find_and_center.py.
PATCH_BOX = (700, 150, 1250, 550)  # x1, y1, x2, y2 -- picked live 9/25 over
                                    # the undeveloped wild-grass boundary
                                    # plot (trees/rocks/a log, no walking
                                    # NPCs or vehicles crossing through it) --
                                    # the most reliably static region found
                                    # after roads, crosswalks and building
                                    # interiors all proved to have moving
                                    # content that corrupted the match
MATCH_CONFIDENCE_FLOOR = 0.8  # this is an exact crop of the same content,
                               # not a generic template -- a real re-find
                               # should score very high; anything lower
                               # means the patch moved off-screen, the
                               # scene changed, or the swipe hit a boundary

BOUNDARY_FRAME_DIFF_FLOOR = 8.0  # confirmed live 9/25: a real map boundary
                                  # (camera pinned, nothing actually pans)
                                  # produces a whole-frame diff of only a
                                  # few points (animation noise), same
                                  # order of magnitude as find_and_center.py's
                                  # boundary detection. Without this check,
                                  # a boundary-hit swipe can still produce a
                                  # deceptively confident (but meaningless)
                                  # patch "match" at ~zero shift, which looks
                                  # identical to a genuine near-zero-movement
                                  # measurement -- confirmed live when a
                                  # duration-sweep test drifted into the
                                  # townhouse-row boundary mid-run and kept
                                  # reporting "confident" results anyway.


def frame_diff(before_img, after_img):
    """Whole-frame mean-abs-diff on downsampled grayscale -- same technique
    as find_and_center.py's boundary detection. A real pan scores 50+; a
    boundary no-op scores only a few points of animation noise."""
    b = cv2.cvtColor(cv2.resize(before_img, (160, 90)), cv2.COLOR_BGR2GRAY)
    a = cv2.cvtColor(cv2.resize(after_img, (160, 90)), cv2.COLOR_BGR2GRAY)
    return float(np.mean(np.abs(b.astype(np.int16) - a.astype(np.int16))))


def measure_camera_shift(before_img, after_img, patch_box=PATCH_BOX):
    """Returns ((dx, dy), confidence) -- how far the patch's content moved
    on screen, or (None, confidence) if it couldn't be confidently
    re-found."""
    x1, y1, x2, y2 = patch_box
    patch = before_img[y1:y2, x1:x2]
    res = cv2.matchTemplate(after_img, patch, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)
    if max_val < MATCH_CONFIDENCE_FLOOR:
        return None, max_val
    dx = max_loc[0] - x1
    dy = max_loc[1] - y1
    return (dx, dy), max_val


def calibrate(dx_in, dy_in, duration_ms=500, origin=(800, 450)):
    """Performs one swipe of nominal vector (dx_in, dy_in) from `origin`
    and measures the actual resulting on-screen content shift. Returns a
    dict with the nominal input, the measured actual shift, the match
    confidence, and the ratio actual/nominal (the calibration factor) --
    or None for actual/ratio if the shift couldn't be measured."""
    before = screenshot()
    x1, y1 = origin
    x2, y2 = x1 + dx_in, y1 + dy_in
    swipe(x1, y1, x2, y2, duration_ms)
    time.sleep(1)  # let any pan animation/momentum fully settle
    after = screenshot()
    diff = frame_diff(before, after)
    shift, conf = measure_camera_shift(before, after)

    result = {
        "nominal": (dx_in, dy_in),
        "duration_ms": duration_ms,
        "actual": shift,
        "confidence": conf,
        "ratio": None,
        "frame_diff": diff,
        "boundary_hit": diff < BOUNDARY_FRAME_DIFF_FLOOR,
    }
    if result["boundary_hit"]:
        # Whatever the patch-match found (even at high confidence) isn't a
        # real measurement of swipe behavior -- the camera didn't actually
        # pan. Report it as such instead of letting a coincidental match
        # produce a misleading ratio.
        result["actual"] = None
        result["ratio"] = None
        return result
    if shift is not None:
        nominal_dist = (dx_in ** 2 + dy_in ** 2) ** 0.5
        actual_dist = (shift[0] ** 2 + shift[1] ** 2) ** 0.5
        if nominal_dist > 0:
            result["ratio"] = actual_dist / nominal_dist
    return result


def _fmt(result):
    dx_in, dy_in = result["nominal"]
    if result.get("boundary_hit"):
        return (f"swipe({dx_in:+d},{dy_in:+d}) @ {result['duration_ms']}ms -> "
                f"BOUNDARY HIT (frame_diff={result['frame_diff']:.1f}, camera didn't "
                "actually pan -- not a real measurement)")
    if result["actual"] is None:
        return (f"swipe({dx_in:+d},{dy_in:+d}) @ {result['duration_ms']}ms -> "
                f"COULD NOT MEASURE (best match confidence {result['confidence']:.2f})")
    ax, ay = result["actual"]
    return (f"swipe({dx_in:+d},{dy_in:+d}) @ {result['duration_ms']}ms -> "
            f"actual shift ({ax:+d},{ay:+d}), confidence {result['confidence']:.2f}, "
            f"ratio actual/nominal = {result['ratio']:.2f}")


def calibrate_round_trip(dx_in, dy_in, duration_ms=500, origin=(800, 450)):
    """Like calibrate(), but swipes back afterward (best-effort, using the
    same nominal reverse vector) so a multi-distance sweep doesn't drift
    the camera toward a map edge and contaminate later measurements with
    boundary clamping."""
    result = calibrate(dx_in, dy_in, duration_ms=duration_ms, origin=origin)
    swipe(origin[0] + dx_in, origin[1] + dy_in, origin[0], origin[1], duration_ms)
    time.sleep(1)
    return result


def sweep(distances, duration_ms=500, origin=(800, 450)):
    """Calibrates a spread of rightward swipe distances, returning to the
    starting view after each, and reports whether the actual/nominal ratio
    looks like a flat constant (simple multiply-by-k fix) or genuinely
    distance-dependent (needs a real lookup/curve instead)."""
    results = []
    for d in distances:
        r = calibrate_round_trip(d, 0, duration_ms=duration_ms, origin=origin)
        print("  " + _fmt(r))
        results.append(r)
    boundary_hits = sum(1 for r in results if r.get("boundary_hit"))
    ratios = [r["ratio"] for r in results if r["ratio"] is not None]
    if boundary_hits:
        print(f"\n{boundary_hits}/{len(results)} measurements hit a map boundary -- excluded from ratios.")
    if ratios:
        print(f"Ratios across {len(ratios)}/{len(results)} successful measurements: "
              f"{[round(r, 2) for r in ratios]}")
        print(f"  mean={sum(ratios)/len(ratios):.2f}, "
              f"min={min(ratios):.2f}, max={max(ratios):.2f}, "
              f"spread={max(ratios)-min(ratios):.2f}")
    return results


def sweep_duration(dx_in, dy_in, durations, origin=(800, 450)):
    """Holds swipe distance fixed and varies duration instead -- tests
    whether velocity (distance/duration), not raw distance, is what
    actually drives the fling/overshoot behavior seen in sweep()."""
    results = []
    for ms in durations:
        r = calibrate_round_trip(dx_in, dy_in, duration_ms=ms, origin=origin)
        velocity = (dx_in ** 2 + dy_in ** 2) ** 0.5 / ms
        print(f"  velocity={velocity:.3f}px/ms -- " + _fmt(r))
        results.append(r)
    boundary_hits = sum(1 for r in results if r.get("boundary_hit"))
    ratios = [r["ratio"] for r in results if r["ratio"] is not None]
    if boundary_hits:
        print(f"\n{boundary_hits}/{len(results)} measurements hit a map boundary -- excluded from ratios.")
    if ratios:
        print(f"Ratios across {len(ratios)}/{len(results)} successful measurements: "
              f"{[round(r, 2) for r in ratios]}")
    return results


if __name__ == "__main__":
    # Two tests: the exact hop distance find_and_center.py's spiral search
    # uses (SEARCH_HOP_PX=160, rightward), and the exact hop distance/origin
    # its centering phase uses (up to HOP_CAP_PX=170, from (900,450)) --
    # calibrating against the real call sites, not arbitrary numbers.
    print("Test 1: spiral-search hop (dx=160, dy=0, from (800,450), 500ms)")
    r1 = calibrate(160, 0, duration_ms=500, origin=(800, 450))
    print("  " + _fmt(r1))

    print("Test 2: centering-phase hop (dx=170, dy=0, from (900,450), 500ms)")
    r2 = calibrate(170, 0, duration_ms=500, origin=(900, 450))
    print("  " + _fmt(r2))
