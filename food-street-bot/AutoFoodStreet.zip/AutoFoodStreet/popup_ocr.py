"""Reads the text of a screenshot with Windows' built-in OCR (ocr_image.ps1) so popups can be
logged IN FULL ("Your Food Club Storage is full! Get more space by upgrading ..."). Takes ~1-3 s
(PowerShell start-up), so call it only when a popup is being handled or an unknown screen is
saved -- never every cycle. Never raises; returns "" when OCR is unavailable."""
import os
import subprocess
import tempfile
import time

import cv2

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCRIPT = os.path.join(BASE_DIR, "ocr_image.ps1")


def read_text(img, region=None, timeout=25):
    """OCR of the whole image or of region=(x1, y1, x2, y2). Returns one line of text."""
    if not os.path.exists(SCRIPT):                     # 11/28: never run PowerShell on a missing script
        return ""
    try:
        if region:
            x1, y1, x2, y2 = region
            img = img[y1:y2, x1:x2]
        path = os.path.join(tempfile.gettempdir(), f"afsd_ocr_{int(time.time() * 1000)}.png")
        cv2.imwrite(path, img)
        try:
            r = subprocess.run(
                ["powershell", "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", SCRIPT, "-Path", path],
                capture_output=True, text=True, errors="replace", timeout=timeout)
            out = " ".join((r.stdout or "").split())
            return "" if out.startswith("Windows PowerShell") else out
        finally:
            try:
                os.remove(path)
            except OSError:
                pass
    except Exception:                                  # noqa: BLE001
        return ""
