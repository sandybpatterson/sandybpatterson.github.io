"""Ad training tools (10/3). NOTHING here taps or closes anything.

  * record_session(): the "Record ad" button. AFSD must be stopped; you press the
    watch-an-ad button yourself; it saves a frame every 5 s (changed frames only) plus a log
    line per frame with the focused Android app (a Google Play page shows as
    com.android.vending) until the map is back. See the notes in record_session's block.
  * find_skip_ad_icon(): template search for the two watch-an-ad buttons
    (templates/skip_ad_icon.png video-icon button, templates/skip_ad_button.png
    "Skip [video][gem]"). Not called by anything yet -- for the future ad handler.

NOTES / TODO (closing ads is NOT implemented):
  * Ads last ~30 s and some open the Google Play Store, which will also have to be closed.
  * Never press the "Skip [video][gem]" button until a real screen proves it only opens an
    ad and cannot charge gems (hard rule: never spend gems).
  * Never use the Android back key (quit prompt). Take session_lock and warn the user first.
"""
import os
import time
import cv2

from adb_helper import screenshot
from find_and_center import interruptible_sleep, check_stop

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ICON_NAMES = ("skip_ad_icon.png", "skip_ad_button.png")  # video-icon button; "Skip [video][gem]" button (add when saved)
TRAIN_DIR = os.path.join(BASE_DIR, "templates", "ad_training")
LOG_PATH = os.path.join(BASE_DIR, "run_log.txt")
ICON_THRESHOLD = 0.8
SCALES = (0.8, 0.9, 1.0, 1.1, 1.25)



def log(msg):
    line = f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] [ads] {msg}"
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def find_skip_ad_icon(img):
    """(loc, confidence) of the best watch-an-ad button among ICON_NAMES, loc None if not
    found. Never taps."""
    best, loc = 0.0, None
    for name in ICON_NAMES:
        tpl = cv2.imread(os.path.join(BASE_DIR, "templates", name))
        if tpl is None:
            continue
        for s in SCALES:
            t = cv2.resize(tpl, None, fx=s, fy=s)
            if t.shape[0] >= img.shape[0] or t.shape[1] >= img.shape[1]:
                continue
            r = cv2.matchTemplate(img, t, cv2.TM_CCOEFF_NORMED)
            _, v, _, l = cv2.minMaxLoc(r)
            if v > best:
                best, loc = v, (l[0] + t.shape[1] // 2, l[1] + t.shape[0] // 2)
    return (loc if best >= ICON_THRESHOLD else None), best


# --------------------------------------------------------------------------
# 11/1 AD SPOTTER (log only; owner: "build a working setting to play and skip ads"): before any ad is tapped, learn
# WHERE the game offers them. Every screenshot the bot takes is checked (at most every SPOT_GAP_SEC, in a background
# thread) for the two watch-an-ad buttons; a hit logs `[ad test] ...` and saves one picture (max SPOT_PICS_MAX per
# run) to templates/ad_training/ (Send logs carries the newest). Taps NOTHING.
# --------------------------------------------------------------------------
SPOT_GAP_SEC = 20
AD_MIN_LEFT_SEC = 60        # owner 11/1: an ad takes 30-45 s to get past and close -- not worth it for under 1 min left
SPOT_PICS_MAX = 6
_spot = {"t": 0.0, "busy": False, "pics": 0, "last": None, "seen": 0}


def spot_hits(img):
    """Pure-ish: [(name, (x, y), score)] of watch-an-ad buttons in a full screenshot (half-size grey search)."""
    out = []
    g = cv2.cvtColor(cv2.resize(img, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
    for name in ICON_NAMES:
        tpl = cv2.imread(os.path.join(BASE_DIR, "templates", name), 0)
        if tpl is None:
            continue
        best, loc = 0.0, None
        for sc in SCALES:
            t = cv2.resize(tpl, None, fx=sc * 0.5, fy=sc * 0.5, interpolation=cv2.INTER_AREA)
            if t.shape[0] >= g.shape[0] or t.shape[1] >= g.shape[1] or min(t.shape) < 8:
                continue
            r = cv2.matchTemplate(g, t, cv2.TM_CCOEFF_NORMED)
            _, v, _, l = cv2.minMaxLoc(r)
            if v > best:
                best, loc = v, (2 * l[0] + t.shape[1], 2 * l[1] + t.shape[0])
        if loc is not None and best >= ICON_THRESHOLD:
            out.append((name[:-4], loc, round(best, 2)))
    return out


def _spot_work(img):
    try:
        hits = spot_hits(img)
        if not hits:
            return
        key = tuple((n, x // 40, y // 40) for n, (x, y), _ in hits)
        _spot["seen"] += 1
        if key == _spot["last"]:
            return
        _spot["last"] = key
        what = ", ".join(f"{'the video button' if n == 'skip_ad_icon' else 'the Skip [video][gem] button'} at "
                         f"({x},{y}) match {v}" for n, (x, y), v in hits)
        pic = ""
        if _spot["pics"] < SPOT_PICS_MAX:
            _spot["pics"] += 1
            os.makedirs(TRAIN_DIR, exist_ok=True)
            pic = os.path.join(TRAIN_DIR, f"seen_{time.strftime('%Y%m%d_%H%M%S')}.jpg")
            cv2.imwrite(pic, img, [cv2.IMWRITE_JPEG_QUALITY, 80])
        log(f"[ad test] watch-an-ad button on screen: {what}; screen {_kind(img)}"
            + (f" (picture {os.path.basename(pic)})" if pic else "") + " -- log only, nothing tapped.")
    except Exception:                                  # noqa: BLE001
        pass
    finally:
        _spot["busy"] = False


def _ad_observer(img):
    if img is None or _spot["busy"] or time.time() - _spot["t"] < SPOT_GAP_SEC:
        return
    _spot["t"], _spot["busy"] = time.time(), True
    import threading
    threading.Thread(target=_spot_work, args=(img.copy(),), daemon=True).start()


def spot_reset():
    _spot.update({"t": 0.0, "busy": False, "pics": 0, "last": None, "seen": 0})


try:
    import adb_helper as _ah
    _ah.SCREENSHOT_OBSERVERS[:] = [f for f in _ah.SCREENSHOT_OBSERVERS
                                   if getattr(f, "__name__", "") != "_ad_observer"] + [_ad_observer]
except Exception:                                      # noqa: BLE001
    pass


# --------------------------------------------------------------------------
# "Record ad" -- user-driven recording (10/3). Observe only: NEVER taps or closes anything.
# --------------------------------------------------------------------------
# The GUI button is greyed out while AFSD is running; Stop first. Click Record, then press
# the watch-an-ad button YOURSELF. A frame is taken every REC_STEP_SEC; frames that changed
# are saved to templates/ad_training/rec_<time>/ and every frame is logged with its kind
# (map / panel / other) and the focused Android app (so a Google Play Store page that an
# ad opens shows up as com.android.vending). Ads run ~30 s and some open the Play Store, so
# recording continues until the map has been back for 2 frames in a row (or REC_MAX_SEC
# after the ad started). Closing ads / the Play Store is NOT implemented.

REC_STEP_SEC = 0.3           # pause between captures (a screenshot itself takes ~2 s)
REC_WAIT_FOR_AD_SEC = 90      # how long to wait for you to press the ad button
REC_MAX_SEC = 300             # max length once the ad has started
REC_MAX_FRAMES = 150


def _focus():
    """Focused Android window (package/activity) -- tells ad / Play Store / game apart."""
    try:
        import adb_helper
        r = adb_helper._run(["shell", "dumpsys window | grep mCurrentFocus"])
        txt = (r.stdout or b"").decode("utf-8", "ignore").strip()
        return txt.split("{")[-1].strip("} ") if txt else "?"
    except Exception as e:                     # noqa: BLE001
        return f"? ({e.__class__.__name__})"


def _kind(img):
    import event_orders
    import order_fulfill as of
    try:
        if event_orders.hud_is_bright(img):
            return "map"
        if of.panel_is_open(img):
            return "panel"
    except Exception:                          # noqa: BLE001
        pass
    return "other"


SHOT_DIR = os.path.join(BASE_DIR, "templates", "training_shots")


def looks_blank(img):
    """True for a black / flat frame (an ad video layer or a protected window can come back
    empty from screencap). Returns (blank, mean, std)."""
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    m, sd = float(g.mean()), float(g.std())
    return (sd < 6.0 or m < 8.0), m, sd


def save_snapshot(set_status=None):
    """One screenshot of the CURRENT screen for training data -> templates/training_shots/.
    Read-only (safe while AFSD runs). The file name carries the kind (map/panel/other) and
    _BLANK when the frame has no content; the log line adds the focused Android app."""
    img = screenshot()
    blank, m, sd = looks_blank(img)
    kind = _kind(img)
    os.makedirs(SHOT_DIR, exist_ok=True)
    path = os.path.join(SHOT_DIR, f"{time.strftime('%Y%m%d_%H%M%S')}_{kind}{'_BLANK' if blank else ''}.png")
    cv2.imwrite(path, img)
    msg = (f"Training screenshot saved: {os.path.basename(path)} (kind={kind}, focus={_focus()}, "
           f"mean={m:.0f}, spread={sd:.0f})" + (" -- LOOKS BLANK, no content captured!" if blank else ""))
    log(msg)
    if set_status:
        set_status(("BLANK frame! " if blank else "Saved: ") + os.path.basename(path))
    return path, blank


# ---- user-tap recording (getevent on the emulator's touch device) ----

class TapWatcher:
    """Streams `adb shell getevent -lt <touch device>` and turns it into taps / drags the USER
    makes with the mouse in the LDPlayer window. Read-only: nothing is injected. Coordinates
    are scaled to the 1600x900 screen using the device's reported max values."""

    def __init__(self):
        import subprocess
        import threading
        import adb_helper
        self.events = []                 # [{"t","kind","x","y","x2","y2"}] in host time
        self._lock = threading.Lock()
        self._proc = None
        self._dev = adb_helper.TOUCH_DEVICE
        self.max_x, self.max_y = 1599, 899
        try:
            r = adb_helper._run(["shell", "getevent", "-lp", self._dev])
            txt = (r.stdout or b"").decode("utf-8", "ignore")
            import re
            for axis, attr in (("ABS_MT_POSITION_X", "max_x"), ("ABS_MT_POSITION_Y", "max_y")):
                m = re.search(axis + r".*?max (\d+)", txt)
                if m:
                    setattr(self, attr, int(m.group(1)))
        except Exception:                              # noqa: BLE001
            pass
        # getevent's own timestamps (device uptime) are exact, but adb hands the lines to us in
        # bursts, so "when we received it" is wrong (10/4: ten taps all logged at the same second).
        # Anchor the device clock to the host clock once, then use each line's own timestamp.
        self.offset = None
        try:
            t_a = time.time()
            r = adb_helper._run(["shell", "cat", "/proc/uptime"])
            t_b = time.time()
            up = float((r.stdout or b"").decode("utf-8", "ignore").split()[0])
            self.offset = (t_a + t_b) / 2 - up
        except Exception:                              # noqa: BLE001
            self.offset = None
        log(f"Tap watcher: touch device {self._dev}, raw range 0..{self.max_x} x 0..{self.max_y}, "
            f"device-clock anchor {'ok' if self.offset is not None else 'missing (using arrival time)'}.")
        self._proc = subprocess.Popen(
            # 11/1: "-tt" = a terminal on the emulator side, so getevent writes each line at once. Without it the
            # output sat in a 4 KB buffer: a few taps never filled it and ad recordings 2-4 logged 0 taps.
            [adb_helper.ADB, "-s", adb_helper._resolve_device(), "shell", "-tt", "getevent", "-lt", self._dev],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        time.sleep(1.0)
        if self._proc.poll() is not None:                # this adb refused "-tt" -- the old way (taps arrive late)
            log("Tap watcher: 'shell -tt' not accepted -- using plain getevent (taps may arrive in bursts).")
            self._proc = subprocess.Popen(
                [adb_helper.ADB, "-s", adb_helper._resolve_device(), "shell", "getevent", "-lt", self._dev],
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self._thread = threading.Thread(target=self._read, daemon=True)
        self._thread.start()

    def _read(self):
        import re
        x = y = None
        down = None
        self.nlines = 0
        self.raw_head = []
        self.error = None
        try:
            self._read_loop(re, x, y, down)
        except Exception as e:                         # noqa: BLE001
            self.error = repr(e)

    def _read_loop(self, re, x, y, down):
        for raw in iter(self._proc.stdout.readline, b""):
            line = raw.decode("utf-8", "ignore")
            self.nlines += 1
            if len(self.raw_head) < 12:
                self.raw_head.append(line.rstrip())
            now = time.time()
            m_ts = re.match(r"\s*\[\s*([\d.]+)\]", line)
            if m_ts and getattr(self, "offset", None) is not None:
                cand = self.offset + float(m_ts.group(1))
                if abs(cand - now) < 3600:
                    now = cand
            if "ABS_MT_POSITION_X" in line:
                x = int(line.split()[-1], 16)
            elif "ABS_MT_POSITION_Y" in line:
                y = int(line.split()[-1], 16)
            elif "BTN_TOUCH" in line and "DOWN" in line:
                # the NEW position is reported after DOWN (in the same batch), so fill it in at
                # the first SYN_REPORT -- x,y right now are still the PREVIOUS touch's end point
                down = {"t": now, "x": None, "y": None}
            elif "BTN_TOUCH" in line and "UP" in line and down is not None:
                sx = lambda v: None if v is None else int(round(v * 1600 / (self.max_x + 1)))
                sy = lambda v: None if v is None else int(round(v * 900 / (self.max_y + 1)))
                moved = (down["x"] is not None and x is not None and y is not None and down["y"] is not None
                         and (abs(x - down["x"]) + abs(y - down["y"])) > 40)
                ev = {"t": down["t"], "kind": "drag" if moved else "tap",
                      "x": sx(down["x"]), "y": sy(down["y"]), "x2": sx(x), "y2": sy(y)}
                with self._lock:
                    self.events.append(ev)
                down = None
            elif "SYN_REPORT" in line and down is not None and down["x"] is None:
                down["x"], down["y"] = x, y     # first report of the touch carries the position

    def pop(self):
        with self._lock:
            out, self.events = self.events, []
        return out

    def stop(self):
        try:
            if self._proc is not None:
                self._proc.terminate()
        except Exception:                              # noqa: BLE001
            pass


PLAY_DIR = os.path.join(BASE_DIR, "templates", "let_me_play")
PLAY_MAX_SEC = 2 * 3600


def _lesson(fh, n, ev, rel, pre):
    """10/25 (owner: "Let Me Play"): one line per tap/drag -- what the screen looked like (a small fingerprint, same
    as unstuck's) and where the owner touched. Groundwork for "do what the owner did on this screen"."""
    try:
        import json
        fp = None
        try:
            import unstuck
            fp = unstuck.fingerprint(pre)
        except Exception:                              # noqa: BLE001
            pass
        fh.write(json.dumps({"n": n, "t": round(rel, 1), "kind": ev["kind"], "x": ev["x"], "y": ev["y"],
                             "x2": ev.get("x2"), "y2": ev.get("y2"), "screen": fp,
                             "pre": f"tap{n:02d}_pre.png", "post": f"tap{n:02d}_post.png"}) + "\n")
        fh.flush()
    except Exception:                                  # noqa: BLE001
        pass


def _mark(img, ev):
    out = img.copy()
    if ev.get("x") is not None:
        cv2.circle(out, (ev["x"], ev["y"]), 24, (0, 0, 255), 4)
        cv2.circle(out, (ev["x"], ev["y"]), 3, (0, 0, 255), -1)
        if ev["kind"] == "drag" and ev.get("x2") is not None:
            cv2.arrowedLine(out, (ev["x"], ev["y"]), (ev["x2"], ev["y2"]), (0, 0, 255), 3)
    return out


def record_session(cancel, set_status=None, play=False):
    """Records one ad / any training session: a screenshot after every change AND, for every
    tap or drag YOU make in the emulator, the screen as you saw it just before ("tapNN_pre",
    clean, plus a copy with a red marker) and the screen right after ("tapNN_post"). Taps are
    also logged as `USER TAP at (x, y)`. Observe only -- nothing is tapped by this code.
    Returns the folder written (or None)."""
    import numpy as np
    import session_lock
    say = set_status or (lambda m: None)
    try:
        st = session_lock.status()
        if st and st.get("owner") == "afsd_gui" and not st.get("stale", False):
            log("Record ad refused: AFSD is running (press Stop first).")
            say("Stop AFSD first, then Record ad.")
            return None
    except Exception:                          # noqa: BLE001
        pass
    session_lock.acquire(owner="ad_record")
    folder = os.path.join(PLAY_DIR if play else TRAIN_DIR, ("play_" if play else "rec_") + time.strftime("%Y%m%d_%H%M%S"))
    os.makedirs(folder, exist_ok=True)
    lessons = open(os.path.join(folder, "lessons.jsonl"), "a", encoding="utf-8") if play else None
    log(f"RECORD started -> {folder}. Do the ad yourself; your taps are logged, nothing is tapped by me.")
    say("Recording... do your thing; I log your taps.")
    watcher = None
    try:
        watcher = TapWatcher()
    except Exception as e:                     # noqa: BLE001
        log(f"Tap watcher could not start ({e}); recording screenshots only.")
        say("Tap watcher failed - screenshots only (see run_log.txt)")
    t0 = time.time()
    ad_started = None
    map_streak = 0
    last_small = None
    from collections import deque
    frames = deque(maxlen=16)    # (capture_midpoint_time, img) -- recent screenshots
    saved = 0
    tap_no = 0
    pending_post = []            # [(tap_no, ev, not_before_time)]
    last_activity = t0
    try:
        while not cancel.is_set():
            tb = time.time()
            img = screenshot()
            tcap = time.time()
            frames.append(((tb + tcap) / 2, img))
            now = tcap - t0
            kind = _kind(img)
            small = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (80, 45)).astype(np.int16)
            changed = last_small is None or float(np.abs(small - last_small).mean()) >= 3.0
            path = ""
            if changed and saved < REC_MAX_FRAMES and not play:
                blank, _m, _sd = looks_blank(img)
                path = os.path.join(folder, f"f{saved:03d}_t{int(now):03d}s_{kind}{'_BLANK' if blank else ''}.png")
                cv2.imwrite(path, img)
                saved += 1
                last_small = small
            focus = _focus()
            wst = (f" watcher[lines={getattr(watcher, 'nlines', 0)} alive="
                   f"{watcher._proc.poll() is None} err={getattr(watcher, 'error', None)}]") if watcher else " watcher[off]"
            log(f"REC t={int(now)}s kind={kind} focus={focus}{wst} "
                f"{'saved ' + os.path.basename(path) if path else '(unchanged)'}")
            say(f"REC t={int(now)}s {kind} | {focus.split('/')[-1][-34:]} | frames {saved}, taps {tap_no}")
            # taps made since the last capture: the PRE frame is the previous capture
            for ev in (watcher.pop() if watcher else []):
                tap_no += 1
                last_activity = time.time()
                rel = ev["t"] - t0
                desc = (f"({ev['x']},{ev['y']})" if ev["kind"] == "tap"
                        else f"from ({ev['x']},{ev['y']}) to ({ev['x2']},{ev['y2']})")
                earlier = [f for f in frames if f[0] <= ev["t"]]
                pre = (earlier[-1] if earlier else frames[0])[1]     # the newest frame BEFORE the tap
                cv2.imwrite(os.path.join(folder, f"tap{tap_no:02d}_pre.png"), pre)
                if play:                                 # Let Me Play: small JPEGs are what Send logs carries
                    cv2.imwrite(os.path.join(folder, f"tap{tap_no:02d}_pre_marked.jpg"), _mark(pre, ev),
                                [cv2.IMWRITE_JPEG_QUALITY, 70])
                    _lesson(lessons, tap_no, ev, rel, pre)
                else:
                    cv2.imwrite(os.path.join(folder, f"tap{tap_no:02d}_pre_marked.png"), _mark(pre, ev))
                log(f"USER {ev['kind'].upper()} #{tap_no} at t={rel:.1f}s {desc} -- saved tap{tap_no:02d}_pre*.png "
                    f"(the screen as you saw it just before)")
                say(f"USER {ev['kind'].upper()} #{tap_no} at {desc} (t={rel:.0f}s)")
                pending_post.append((tap_no, ev, ev["t"] + 0.5))
            still = []
            for n, ev, not_before in pending_post:
                later = [f for f in frames if f[0] >= not_before]
                if later:
                    cv2.imwrite(os.path.join(folder, f"tap{n:02d}_post.png"), later[0][1])
                    if play:
                        cv2.imwrite(os.path.join(folder, f"tap{n:02d}_post.jpg"), later[0][1],
                                    [cv2.IMWRITE_JPEG_QUALITY, 70])
                    log(f"tap #{n}: post-tap screen saved (kind={kind}, focus={focus}).")
                    say(f"tap #{n}: after-tap screen saved ({kind})")
                else:
                    still.append((n, ev, not_before))
            pending_post = still
            if play:                                     # Let Me Play: no ad logic -- until "Done playing" (max 2 h)
                if now > PLAY_MAX_SEC:
                    log("Let Me Play: 2 hours -- recording stopped by itself.")
                    break
                time.sleep(REC_STEP_SEC)
                continue
            if kind != "map" and ad_started is None:
                ad_started = now
                last_activity = time.time()
                log("Something other than the map appeared (an ad?) -- recording until the map returns.")
                say("Recording...")
            if ad_started is not None:
                # 11/1: the Play Store page an ad opened counted as "map" (bright corner) and ended the recording at
                # 76 s with the owner still in the store -- the map only counts with the GAME in front
                in_game = "UnityPlayerActivity" in focus or focus.startswith("?")
                map_streak = map_streak + 1 if (kind == "map" and in_game) else 0
                if map_streak >= 3 and not pending_post and time.time() - last_activity > 20:
                    log("The map is back -- recording finished.")
                    break
                if now - ad_started > REC_MAX_SEC:
                    log(f"Still not back on the map {REC_MAX_SEC}s after it started -- stopping the "
                        "recording; NOTHING was closed.")
                    break
            elif time.time() - last_activity > REC_WAIT_FOR_AD_SEC:
                log("Nothing happened within the wait window -- recording cancelled.")
                break
            time.sleep(REC_STEP_SEC)
    finally:
        if watcher:
            watcher.stop()
        if lessons is not None:
            lessons.close()
        session_lock.release()
        log(f"RECORD finished: {saved} frame(s), {tap_no} user tap(s)/drag(s) in {folder}")
        say(f"Recorded {saved} frames, {tap_no} taps. Folder: {os.path.basename(folder)}")
    return folder
