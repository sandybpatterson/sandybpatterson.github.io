"""Auto Fulfill Orders -- reads the game's own Orders board to find a
missing item and chases it down via the quick-travel tooltip trick used
throughout this project, instead of hardcoding one checkbox per item.

Built 9/25 after manually proving out the whole pipeline live over many
real taps (see CLAUDE.md for the full blow-by-blow). Key lessons baked in
here:
  - The "?" quick-travel button's position varies with the tooltip's text
    length (a longer dish name pushes it further right) -- confirmed live,
    so it's found via template match, never a fixed offset.
  - Tapping a red ingredient INSIDE a station's own recipe panel can
    trigger a "Buy missing dishes?" gem prompt instead of a travel
    tooltip if the tap isn't precisely on the count-text glyphs. Detected
    the same way (look for the "?" template; if it's not there, don't
    guess -- log and stop rather than risk a wrong tap near a gem button).
  - Pasta Counter, Pizza Oven, and Cake Oven (and by the project's own
    "general station pattern" note, likely Breakfast Stove and others)
    all share the exact same 3-recipe-card panel layout: dish images at
    fixed x positions, an ingredient row below each, and a Cook/Bake/
    Produce button below that, all at consistent y-offsets. That's
    reused here as a generic reader instead of one-off per-station code.

v1 scope: find ONE missing item, travel to it, identify which recipe card
matches (via the item's own icon, cropped from the Orders board), read
that card's ingredients, and Cook/Bake/Produce it if everything is
already green. If an ingredient is still missing, recursion is scoped
specifically to Wheat (see recurse_wheat_ingredient) -- the single
biggest shared bottleneck found live -- chasing it to the Garden Plot,
harvesting, and replanting if the plant bar auto-opens. Any other missing
ingredient is logged clearly and left alone rather than guessed at.
"""
import os
import sys
import glob
import time
import json
import datetime
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from adb_helper import screenshot, tap, swipe
from find_and_center import close_any_open_panel, check_stop, interruptible_sleep, StopRequested, dismiss_second_device_dialog, frame_diff

LOG = os.path.join(BASE_DIR, "run_log.txt")

SCREEN_CENTER = (800, 450)  # quick-travel reliably centers its
                             # destination here -- used to clear a
                             # blocking ready-to-collect item without
                             # needing a per-dish template

ORDERS_ICON_LOC = (1525, 825)
CLOSE_X_LOC = (1541, 124)
CLOSE_X_REGION = (1510, 95, 1570, 150)  # same region close_any_open_panel checks

QUESTION_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "quicktravel_question.png"))
QUESTION_MATCH_THRESHOLD = 0.75

# Orders board card layout -- up to 4-5 cards visible at once (a partial
# one often sits at the screen edge), up to 4 item slots each (2x2 grid).
# Card x-positions are no longer hardcoded -- see find_card_positions()
# below, which locates them dynamically in each screenshot instead.
SLOT_DX = [0, 140]
# (icon_y, count_text_y). Row 2's text_y corrected 9/27: the original 596
# was measured/assumed but never actually verified against a real 4-item
# card whose bottom row was genuinely green -- every prior serve/scan
# success happened to only ever involve 1-row (2-item) cards. Live bug
# found via a real 4-item order (French Toast/Cream of Mushroom/Veggie
# Juice/Carrot, all green): sampling at y=596 landed just ABOVE the real
# text (in the icon-to-text gap), reading 'red'/None instead of the true
# 'green' on both bottom slots -- exactly why serve_ready_orders kept
# reporting "served 0" on an order that was actually fully ready.
# Measured directly: y=605 through 625 all correctly read green; 615
# is the middle of that safe range.
SLOT_ROWS = [(430, 459), (565, 615)]  # (icon_y, count_text_y)
ICON_CROP_TOP = 42   # crop bounds relative to icon_y -- confirmed live 9/25
ICON_CROP_BOTTOM = 16  # a symmetric crop bled into the red/green count
                        # text sitting just below the icon, contaminating
                        # the crop used for identification

# Dynamic card-position detection -- replaces the earlier fixed
# CARD_X_CENTERS + SCROLL_OFFSET_PER_STEP hack. That hack assumed a single
# constant pixel shift per scroll, which wasn't reliably true (same
# swipe-distance unpredictability seen everywhere else in this project)
# and still needed a hardcoded starting grid. Instead, every card's own
# "Serve" button -- a big, distinctive, fixed-shape green anchor at a
# constant offset from that card's dish-icon column -- is located
# directly in each fresh screenshot via template matching. This works
# identically on page 0 and any scrolled page, with no assumption about
# how far a scroll actually moved anything.
SERVE_BUTTON_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "orders_serve_button.png"))
SERVE_BUTTON_ROW = (793, 850)  # y-range the Serve button sits in
SERVE_MATCH_THRESHOLD = 0.75
MIN_CARD_SPACING = 300  # cards are ~365px apart -- collapse anything closer
                          # into one match (avoids double-counting a single
                          # button's own multi-pixel-wide correlation peak)
BUTTON_LEFT_TO_CARD_CENTER_DX = 105 - 147  # measured from the same crop
                                             # used to build the template:
                                             # card 1's icon column1 sits
                                             # 42px left of its Serve
                                             # button's left edge


def find_cards(img):
    """Returns a list of {icon_col1_x, serve_button} dicts, sorted left to
    right, for every Orders card currently visible on screen -- located by
    finding each card's own Serve button rather than trusting a fixed/
    guessed grid. `serve_button` is that button's own tap-able center."""
    y1, y2 = SERVE_BUTTON_ROW
    strip = img[y1:y2, :]
    res = cv2.matchTemplate(strip, SERVE_BUTTON_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    best_per_col = res.max(axis=0)
    xs = np.where(best_per_col >= SERVE_MATCH_THRESHOLD)[0]
    if len(xs) == 0:
        return []
    groups = [[int(xs[0])]]
    for x in xs[1:]:
        if x - groups[-1][-1] <= MIN_CARD_SPACING // 3:
            groups[-1].append(int(x))
        else:
            groups.append([int(x)])
    th, tw = SERVE_BUTTON_TEMPLATE.shape[:2]
    button_y = y1 + th // 2
    cards = []
    for g in groups:
        best_x = max(g, key=lambda x: best_per_col[x])
        cards.append({
            "icon_col1_x": best_x + BUTTON_LEFT_TO_CARD_CENTER_DX,
            "serve_button": (best_x + tw // 2, button_y),
        })
    return sorted(cards, key=lambda c: c["icon_col1_x"])


def find_card_positions(img):
    """Backward-compatible wrapper -- just the icon-column1 x-centers."""
    return [c["icon_col1_x"] for c in find_cards(img)]


# Card fingerprinting -- replaces the earlier "no visible pixel change"
# heuristic for detecting the end of the (scrollable) Orders list. That
# heuristic was fooled live 9/25: a scroll can bounce/overscroll enough to
# register a real pixel diff even at the true boundary, and conversely two
# different pages can occasionally look similar enough to register as
# "unchanged." A card's own reward numbers (coins + stars, shown above its
# items) are a much more meaningful signal -- they're effectively unique
# per order and don't change while scrolling, so "have I already recorded
# this exact card" is a real semantic check, not a pixel guess.
# REAL BUG found and fixed 9/26: the (32,8) downscale + threshold=10 pair
# below was nowhere near discriminating enough. Measured directly against
# 7 real cards from a live board: genuinely different orders' signatures
# came out only 2.28-7.10 apart (mean abs diff) at that resolution --
# BELOW the old threshold of 10, meaning a different card was very often
# misclassified as "already seen." This silently made scan_full_orders_
# board/main()'s forward-scan conclude "reached the end of the list" the
# moment 2-3 cards had been recorded, even with real new orders sitting
# on the very next page (confirmed live: two genuinely new orders, a
# pizza and a cupcake/corn/lettuce card, were both swallowed by this).
# The reward header is mostly a coin-icon + star-icon layout that's near-
# identical across every card, with only the actual digits varying, and
# an 8-row-tall thumbnail was too coarse to preserve any real digit shape
# -- it was mostly just re-measuring "does this look like a reward
# header," not "is this the SAME reward header." Fixed by keeping far
# more resolution (128x32 -- 16x the pixel count) and tightening the
# threshold accordingly. Re-measured on the same 7 real cards at the new
# resolution: genuinely different cards now sit 6.41-15.63 apart, while
# the one confirmed same-card-reseen-after-scrolling pair measured 0.00
# -- a wide, safe margin either side of the new threshold.
REWARD_REGION_Y = (280, 345)
REWARD_REGION_DX = (-45, 235)
SIGNATURE_SIZE = (128, 32)
SIGNATURE_MATCH_THRESHOLD = 4.0  # mean abs pixel diff below this = same card


def _card_signature(img, cx):
    y1, y2 = REWARD_REGION_Y
    dx1, dx2 = REWARD_REGION_DX
    x1, x2 = cx + dx1, cx + dx2
    if x1 < 0 or x2 > img.shape[1]:
        return None  # card's reward header is cut off -- can't fingerprint it
    region = img[y1:y2, x1:x2]
    small = cv2.resize(region, SIGNATURE_SIZE, interpolation=cv2.INTER_AREA)
    return cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)


def sig_diff(a, b):
    """11/17: THE one header-signature comparison (was copied ~9 times). Mean pixel difference of two stored header
    crops (arrays or saved lists), or None when either is missing / unreadable. Same card 0.0; other cards >= ~4."""
    try:
        if a is None or b is None:
            return None
        a = np.asarray(a, dtype=np.int16)
        b = np.asarray(b, dtype=np.int16)
        if a.shape != b.shape:
            b = b.reshape(a.shape)
        return float(np.mean(np.abs(a - b)))
    except Exception:                                  # noqa: BLE001
        return None


def same_sig(a, b):
    d = sig_diff(a, b)
    return d is not None and d < SIGNATURE_MATCH_THRESHOLD


def _signature_seen(sig, seen_list):
    if sig is None:
        return False
    return any(same_sig(sig, s) for s in seen_list)


EDGE_SKIP_PX = 40


def _slot_already_skipped(card_sig, dx, row_idx, skip_slots, img=None, cx=None):
    """Identity-based version of the old (x, icon_y) position skip. A
    scrolled page's exact pixel position can drift a few px between
    separate main() calls (confirmed live, see process_all_visible's own
    comment) -- keying skip state by absolute screen coordinates means a
    blocked item can silently stop being recognized as "already tried"
    the moment the board happens to land a few px differently, which
    risks either pointless reprocessing or, worse, an item near the edge
    of the board never lining up with its recorded position again. Card
    signatures (the reward-header fingerprint, already proven stable
    across scroll positions for end-of-list detection) let us recognize
    "this is the same order I was already blocked on" by its actual
    content instead of by where it happened to render -- same idea as
    recognizing a station by its shape instead of extrapolating a
    remembered coordinate (see find_and_center.py's history)."""
    if card_sig is None:
        # 11/10: a card cut off at the board edge has no header signature, so a held order there (caprese, x=98) was
        # never recognised and got re-tried 10x in 90 s. Such keys carry the card's x instead: same slot, same spot.
        return cx is not None and any(dx == s["dx"] and row_idx == s["row"] and s.get("sig") is None
                                      and s.get("cx") is not None and abs(s["cx"] - cx) <= EDGE_SKIP_PX
                                      for s in skip_slots)

    def same(stored):
        # 11/8: with FLASH a card lands a pixel or two off between looks, and a 2-px shift changes the header
        # signature MORE than a different card does (15 vs ~11 on saved boards) -- so "wait out" / "set aside" lost
        # the order and the bot re-checked a growing cabbage 5x in 2 min. When the current picture is known, re-cut
        # the header at cx-4..cx+4 (sig_distance, as Dismiss does since 11/1): same card 0.0, other cards >= 4.06.
        if img is not None and cx is not None:
            d = sig_distance(img, cx, stored)
            if d is not None:
                return d < SIGNATURE_MATCH_THRESHOLD
        return same_sig(card_sig, stored)
    return any(dx == s["dx"] and row_idx == s["row"] and s["sig"] is not None and same(s["sig"])
               for s in skip_slots)


# Generic 3-recipe-card station panel layout -- confirmed identical across
# Pasta Counter, Pizza Oven, and Cake Oven live 9/25.
RECIPE_CARD_X = [260, 620, 978]
DISH_IMAGE_Y = 390
INGREDIENT_DX = [-72, 0, 72]
INGREDIENT_ICON_Y = 505
INGREDIENT_TEXT_Y = 523
ACTION_BUTTON_Y = 585

# Trainable dish library -- maps a dish's own small Orders-board icon to
# its NAME. Built incrementally ("training"), not generic image matching:
# confirmed live 9/25 that the Orders board's small icon and the station
# panel's big dish illustration are different art at different scales, so
# directly matching one against the other doesn't work reliably (best
# score ~0.38 even for the correct dish). Matching a small icon against
# another small icon of the SAME dish (this library) should self-match
# far more confidently.
DISH_LIBRARY_DIR = os.path.join(BASE_DIR, "templates", "dishes")
DISH_LIBRARY_FILE = os.path.join(DISH_LIBRARY_DIR, "library.json")
DISH_MATCH_THRESHOLD = 0.85
PENDING_DIR = os.path.join(BASE_DIR, "templates", "dishes_pending")

# A SECOND library, keyed the same way by dish name, maps a dish to its
# own big station-panel illustration -- used to find WHICH x-position its
# recipe card is sitting at right now, by sight, instead of trusting a
# fixed RECIPE_CARD_X[card_index]. Added 9/26 after discovering Soup
# Station has 4 usable cards (not 3) plus a 5th locked one reachable only
# by scrolling -- RECIPE_CARD_X's fixed-3-card assumption silently breaks
# on any station shaped differently, which is why Chicken Broth and
# friends were left untrained rather than risk a wrong ingredient-read/
# Cook-tap. `card_index` is kept on dishes trained before this existed as
# a fallback (still correct for actual 3-card stations), but every dish
# trained from here on should also get a panel illustration -- see
# train_dish()/find_dish_in_panel().
DISH_PANEL_LIBRARY_DIR = os.path.join(BASE_DIR, "templates", "dish_panels")
DISH_PANEL_MATCH_THRESHOLD = 0.85
PANEL_DISH_IMAGE_REGION = (245, 485)  # (y1, y2) around DISH_IMAGE_Y=390,
                                        # wide enough for the bowl/plate
                                        # art without bleeding into the
                                        # cook-time label above or the
                                        # ingredient row below
PANEL_DISH_IMAGE_HALF_WIDTH = 130
PANEL_SWIPE_Y = 400  # confirmed live 9/26: the same long, slow swipe that
                      # fixed Orders-board scrolling works identically on
                      # a station panel's own card row -- verified a full
                      # round trip on Soup Station (one swipe reaches the
                      # true right boundary, a second swipe is a no-op,
                      # the reverse swipe returns exactly to the start)


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] [order_fulfill] {msg}\n")
    try:
        print(f"[{ts}] [order_fulfill] {msg}")
    except (AttributeError, OSError):
        pass
    try:                                              # pass 49: run trace (reasons, stats, fail pictures)
        import run_trace
        run_trace.note_log(msg)
    except Exception:                                 # noqa: BLE001
        pass


def _sample_color(img, x, y):
    """Classifies the count-text color at (x, y) as 'red' (insufficient),
    'green' (sufficient), or None (ambiguous / empty slot)."""
    region = img[max(0, y - 8):y + 8, max(0, x - 25):x + 25]
    if region.size == 0:
        return None
    b, g, r = region[:, :, 0].mean(), region[:, :, 1].mean(), region[:, :, 2].mean()
    if r > g + 25:
        return "red"
    if g > r + 25:
        return "green"
    return None


# ---------------------------------------------------------------------------------------------------------------
# pass 55: remember what is already cooking so the same batch is not queued twice
# ---------------------------------------------------------------------------------------------------------------
COOKING_FILE = os.path.join(BASE_DIR, ".cooking_state.json")
COOKING_MARGIN_SEC = 120            # a batch counts as "in progress" for its cook time plus this much (collecting takes a moment)
COOKING_DEFAULT_SEC = 300
_COOKING = None                     # dish -> [finish timestamps]
_DEFICIT = {}                       # ingredient -> need - have, read from the last station card that listed it
_COOK_SECS = None


def _cook_secs(name):
    global _COOK_SECS
    if _COOK_SECS is None:
        try:
            d = json.load(open(os.path.join(BASE_DIR, "recipes.json"), encoding="utf-8"))
            items = d.get("items", d)
            _COOK_SECS = {k: v.get("cook_sec") for k, v in items.items() if isinstance(v, dict)}
        except Exception:                              # noqa: BLE001
            _COOK_SECS = {}
    return _COOK_SECS.get(name) or COOKING_DEFAULT_SEC


def _cooking_state():
    global _COOKING
    if _COOKING is None:
        try:
            _COOKING = {k: list(v) for k, v in json.load(open(COOKING_FILE, encoding="utf-8")).items()}
        except Exception:                              # noqa: BLE001
            _COOKING = {}
    now = time.time()
    for k in list(_COOKING):
        _COOKING[k] = [t for t in _COOKING[k] if t > now]
        if not _COOKING[k]:
            del _COOKING[k]
    return _COOKING


def _cooking_save():
    try:
        with open(COOKING_FILE, "w", encoding="utf-8") as fh:
            json.dump(_COOKING or {}, fh)
    except OSError:
        pass


def note_queued(name, n=1):
    """Remember that n batches of `name` were just queued (they finish after the dish's cook time + a margin)."""
    st = _cooking_state()
    finish = time.time() + _cook_secs(name) + COOKING_MARGIN_SEC
    st.setdefault(name, []).extend([finish] * max(1, int(n)))
    _cooking_save()
    _jam_test(name, n)
    _prep_hook("used", name, n)
    log(f"Noted {n} batch(es) of '{name}' cooking until about {time.strftime('%H:%M', time.localtime(finish))} "
        f"(cook time {_cook_secs(name)}s + {COOKING_MARGIN_SEC}s margin).")


def _prep_hook(what, *args):
    """11/13: tell Prep work what other jobs saw / cooked (prep_engine.seen_card / used / topup). Never breaks a job."""
    try:
        import prep_engine
        return getattr(prep_engine, what)(*args)
    except Exception:                                 # noqa: BLE001
        return None


def in_progress(name):
    return len(_cooking_state().get(name, []))


def covered_by_cooking(name, deficit):
    """True when batches already cooking for `name` cover what is still missing (deficit None -> 1)."""
    cooking = in_progress(name)
    need = deficit if (deficit is not None and deficit > 0) else 1
    return cooking >= need


def _set_deficits(img, ingredients):
    """Read have/need under each named ingredient icon of a station card and remember need - have."""
    import event_digits
    for color, x, y, name in ingredients:
        if not name:
            continue
        c = event_digits.read_count(img, x, 522, save_unknown=False)
        if c:
            _DEFICIT[name] = max(0, c["need"] - c["have"])


def _pending_duplicate(icon):
    """pass 59: path of a picture already waiting in dishes_pending that is the same icon (mean abs pixel diff < 6), else None."""
    try:
        for f in sorted(glob.glob(os.path.join(PENDING_DIR, "*.png"))):
            other = cv2.imread(f)
            if other is not None and other.shape == icon.shape and float(np.abs(other.astype(np.int16) - icon.astype(np.int16)).mean()) < 6.0:
                return f
    except Exception:                                  # noqa: BLE001
        pass
    return None


# ---------------------------------------------------------------------------------------------------------------
# pass 60: delete an order that has been "unrecognised" UNTRAINED_DELETE_AFTER times
# ---------------------------------------------------------------------------------------------------------------
DELETE_UNTRAINED_ORDERS = True
UNTRAINED_DELETE_AFTER = 5
UNTRAINED_MAX_DELETES_PER_RUN = 2
UNTRAINED_FILE = os.path.join(BASE_DIR, ".untrained_orders.json")
UNTRAINED_FORGET_SEC = 6 * 3600
TRASH_DX_FROM_SERVE = -156          # the card's red trash button sits this far left of its Serve button (same y); 37% red on every saved board
_DELETES_THIS_RUN = 0


def _untrained_load():
    try:
        data = json.load(open(UNTRAINED_FILE, encoding="utf-8"))
    except Exception:                                  # noqa: BLE001
        return []
    now = time.time()
    return [e for e in data if now - e.get("last", 0) < UNTRAINED_FORGET_SEC]


def _untrained_save(entries):
    try:
        with open(UNTRAINED_FILE, "w", encoding="utf-8") as fh:
            json.dump(entries, fh)
    except OSError:
        pass


def untrained_count_add(sig):
    """Count one more 'unrecognised' sighting of the order whose header signature is `sig`; returns the new count."""
    entries = _untrained_load()
    for e in entries:
        if same_sig(sig, e["sig"]):
            e["n"] += 1
            e["last"] = time.time()
            _untrained_save(entries)
            return e["n"]
    entries.append({"sig": [int(v) for v in sig.reshape(-1)], "n": 1, "last": time.time()})
    _untrained_save(entries)
    return 1


def untrained_count_clear(sig):
    entries = _untrained_load()
    keep = [e for e in entries
            if not same_sig(sig, e["sig"])]
    _untrained_save(keep)


def _trash_is_red(img, pt):
    x, y = pt
    patch = img[max(0, y - 22):y + 22, max(0, x - 22):x + 22]
    if patch.size == 0:
        return False
    px = patch.reshape(-1, 3).astype(int)
    return float(((px[:, 2] > 170) & (px[:, 1] < 100) & (px[:, 0] < 100)).mean()) >= 0.08


SIG_SEARCH_DX = 4               # 11/1: look a few px either side of where find_cards puts the card


def sig_distance(img, cx, sig):
    """Smallest header-signature difference for the card at cx, trying cx-4..cx+4. 11/1: with FLASH the window copy
    is scaled up from 85%, find_cards can place a card a pixel or two off, and the header crop then differs ~9 (limit
    4) -- 'DISMISS: order 2 is not on the board any more' while it was there. Exact adb pictures: 0 either way."""
    best = None
    for dx in range(-SIG_SEARCH_DX, SIG_SEARCH_DX + 1):
        s = _card_signature(img, cx + dx)
        if s is None:
            continue
        d = sig_diff(sig, s)
        if d is None:
            continue
        if best is None or d < best:
            best = d
    return best


def find_card_for_signature(img, sig):
    """The visible Orders card whose header signature matches `sig`, or None."""
    best, best_d = None, None
    for card in find_cards(img):
        d = sig_distance(img, card["icon_col1_x"], sig)
        if d is not None and d < SIGNATURE_MATCH_THRESHOLD and (best_d is None or d < best_d):
            best, best_d = card, d
    return best


def delete_order(img, sig, stop_flag=None, answer_yes=True, why=None):
    """Discard the Orders card with header signature `sig` (it must be visible in `img`). Every guard of the storage-full purge applies.
    answer_yes=False stops at the question and answers No (used to test the geometry without deleting). Returns True only when the order was discarded."""
    global DELETE_UNTRAINED_ORDERS
    import event_orders as eo
    import find_and_center as fac
    card = find_card_for_signature(img, sig)
    if card is None:
        log("DELETE ORDER: could not find that order card on this screen -- nothing deleted.")
        return False
    sx, sy = card["serve_button"]
    pt = (sx + TRASH_DX_FROM_SERVE, sy)
    if not _trash_is_red(img, pt):
        log(f"DELETE ORDER: the trash button at {pt} is not red -- nothing deleted.")
        return False
    try:
        import run_trace
        run_trace.fail_picture("deleting_order", f"about to discard the order at x={card['icon_col1_x']}")
    except Exception:                                  # noqa: BLE001
        pass
    log(f"DELETE ORDER: tapping the trash button at {pt} of the order at x={card['icon_col1_x']}.")
    tap(*pt)
    interruptible_sleep(1.3, stop_flag)
    img2 = screenshot()
    if not eo.discard_dialog_open(img2):
        log("DELETE ORDER: tapped trash but the discard question did not appear -- stopping, nothing deleted.")
        return False
    if eo._gem_icon_near(img2, eo.DISCARD_YES_LOC):
        log("DELETE ORDER: the discard Yes button shows a gem icon -- answering No and switching deleting off.")
        tap(*fac.DISCARD_NO_LOC)
        DELETE_UNTRAINED_ORDERS = False
        return False
    if not answer_yes:
        log("DELETE ORDER (test): the discard question is up -- answering No.")
        tap(*fac.DISCARD_NO_LOC)
        interruptible_sleep(1.0, stop_flag)
        return False
    g_before = eo.read_gems(img2)
    if g_before is None:                                # pass 61: never press Yes without being able to watch the gem counter
        log("DELETE ORDER: cannot read the gem counter -- answering No, nothing deleted.")
        tap(*fac.DISCARD_NO_LOC)
        interruptible_sleep(1.0, stop_flag)
        return False
    tap(*eo.DISCARD_YES_LOC)
    interruptible_sleep(2.0, stop_flag)
    img3 = screenshot()
    g_after = eo.read_gems(img3)
    if g_before is not None and g_after is not None and g_after < g_before:
        DELETE_UNTRAINED_ORDERS = False
        log(f"GEM DROP while deleting an order: {g_before} -> {g_after} -- deleting switched OFF.")
        return False
    if eo.discard_dialog_open(img3):
        log("DELETE ORDER: the discard question is still open after Yes -- answering No and stopping.")
        tap(*fac.DISCARD_NO_LOC)
        return False
    no, _nc = find_no_button(img3)
    if no is not None:
        log("DELETE ORDER: a gem-buy prompt appeared -- declining and stopping.")
        tap(*no)
        return False
    if g_after is None:
        log("DELETE ORDER: warning -- could not read the gem counter afterwards, so a gem drop could not be ruled out; check the gems.")
    log("ORDER DELETED (" + (why or "unrecognised too many times") + ").")
    return True


NEW_ORDER_AFTER_DISMISS_SEC = 30 * 60
DISMISS_REQUESTS = []        # 10/21 (owner): [(order no, header signature)] from the Orders tab's Dismiss button
# 10/23 (owner: dismissed orders "not going away fast enough or maybe at all" on the bot's screen -- the game deleted
# them, but the Orders tab kept drawing the last board read until the next one): every dismiss is marked here by its
# header signature -- "queued" (card shows "Dismissing...") then "gone" (card hidden at once, and kept hidden while the
# stale board read is still around).
_DISMISS_MARKS = []          # [{"sig", "state", "t"}]
DISMISS_HIDE_SEC = 3600


_same_sig = same_sig          # 11/17: kept for callers (afsd_core, orders_view)


def mark_dismiss(sig, state):
    now = time.time()
    _DISMISS_MARKS[:] = [m for m in _DISMISS_MARKS if now - m["t"] < DISMISS_HIDE_SEC and not _same_sig(m["sig"], sig)]
    if state:
        _DISMISS_MARKS.append({"sig": sig, "state": state, "t": now})
    try:
        import orders_view
        orders_view.mark_dismissed(orders_view.CLIPBOARD, lambda s2: _same_sig(s2, sig), state)
    except Exception:                                # noqa: BLE001
        pass


def dismiss_state(sig):
    """"queued" / "gone" / None for an order header signature."""
    now = time.time()
    for m in _DISMISS_MARKS:
        if now - m["t"] < DISMISS_HIDE_SEC and _same_sig(m["sig"], sig):
            return m["state"]
    return None


def run_dismiss_requests(stop_flag=None):
    """Owner pressed Dismiss on a clipboard order (and confirmed it): open the board, find that exact card by its
    header signature (first page, then the far end), and discard it with every delete_order guard (gem checks,
    No on anything unexpected). Returns how many were discarded."""
    done = 0
    while DISMISS_REQUESTS:
        req = DISMISS_REQUESTS.pop(0)
        no, sig = req[0], req[1]
        mark_dismiss(sig, "queued")
        why = req[2] if len(req) > 2 else f"dismissed by the owner, order {no}"
        log(f"DISMISS: order {no} -- {why}.")
        try:
            close_any_open_panel(quiet=True, thorough=True)
            tap(*ORDERS_ICON_LOC)
            interruptible_sleep(1.5, stop_flag)
            reset_orders_scroll(stop_flag)
            wait_for_screen_stable(stop_flag)
            img = screenshot()
            if find_card_for_signature(img, sig) is None:
                swipe_to_far_end(stop_flag)
                wait_for_screen_stable(stop_flag)
                img = screenshot()
            if find_card_for_signature(img, sig) is None:
                log(f"DISMISS: order {no} is not on the board any more (served or gone) -- nothing deleted.")
                mark_dismiss(sig, "gone")
            elif delete_order(img, sig, stop_flag, why=why):
                done += 1
                mark_dismiss(sig, "gone")
                try:                                   # the game sends a new order ~30 min after a discard
                    import orders_view
                    orders_view.add_new_order_timer(orders_view.CLIPBOARD, time.time() + NEW_ORDER_AFTER_DISMISS_SEC)
                except Exception:                      # noqa: BLE001
                    pass
            else:
                mark_dismiss(sig, None)                # not deleted (a guard said No) -- show the card normally again
        except StopRequested:
            DISMISS_REQUESTS.insert(0, req)            # 10/23: Stop mid-dismiss -- finish it after the next Start
            raise
        except Exception as e:                         # noqa: BLE001
            log(f"DISMISS: failed ({e!r}) -- nothing more done.")
            mark_dismiss(sig, None)
        try:
            close_any_open_panel(quiet=True, thorough=True)
        except Exception:                              # noqa: BLE001
            pass
    return done


# ---------------------------------------------------------------------------------------------------------------
# pass 62: board memory -- know which page of the Orders board is on screen, number the orders, swipe only when needed
# ---------------------------------------------------------------------------------------------------------------
LOCK_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "orders_locked_slot.png"))
BOARD_START_CARD_X = 105             # first icon column of order 1 when the board is at its start (19 of 47 saved boards; the end page starts at 257)
BOARD_SLOT_PITCH = 365.5             # distance between two order slots
BOARD_CARD_CENTER_DX = 70            # a card's centre is this far right of its first icon column
BOARD_TOTAL_SLOTS = 7                # 6 order slots + the locked one
_LAST_ORDER_NO = None
_LAST_ORDER_SIG = None               # 10/27: header signature of that order (the Orders tab numbers cards differently)


def board_lock_x(img):
    """x of the locked slot's padlock when it is on screen (= the far end of the board), else None."""
    if LOCK_TEMPLATE is None or img is None or img.shape[:2] != (900, 1600):
        return None
    region = img[300:700, 1100:1600]
    if region.shape[0] < LOCK_TEMPLATE.shape[0] or region.shape[1] < LOCK_TEMPLATE.shape[1]:
        return None
    res = cv2.matchTemplate(region, LOCK_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, v, _, loc = cv2.minMaxLoc(res)
    if float(v) < 0.8:
        return None
    return int(loc[0] + 1100 + LOCK_TEMPLATE.shape[1] // 2)


def _on_start_grid(x):
    """10/27: True when a card sits on the start page's slot grid (105, 470, 836, 1201). Before, only a card at the very
    left edge counted -- a dismissed order leaves slot 1 EMPTY ("New Order In"), the first card then sits at 470 and
    every look said "position unknown" and reset the board (11 -> 52 -> 65x per Muse window). End-page cards sit at
    257 + n*365.5, ~150 px off this grid."""
    r = (x - BOARD_START_CARD_X) / BOARD_SLOT_PITCH
    return round(r) >= 0 and abs(r - round(r)) * BOARD_SLOT_PITCH <= 14


def classify_board_page(img):
    """Which part of the Orders board is on screen: {cards, lock_x, at_start, at_end}. Both true = the whole board fits on one page."""
    cards = find_cards(img)
    lock_x = board_lock_x(img)
    first = cards[0]["icon_col1_x"] if cards else None
    return {"cards": cards, "lock_x": lock_x,
            "at_start": first is not None and _on_start_grid(first),
            "at_end": lock_x is not None}


def board_order_number(cx, view):
    """1-based number of the order whose first icon column is cx, or None when the position is not anchored."""
    try:
        if view["at_start"]:
            return int(round((cx - BOARD_START_CARD_X) / BOARD_SLOT_PITCH)) + 1
        if view["lock_x"] is not None:
            return BOARD_TOTAL_SLOTS - int(round((view["lock_x"] - (cx + BOARD_CARD_CENTER_DX)) / BOARD_SLOT_PITCH))
    except Exception:                                  # noqa: BLE001
        pass
    return None


def _end_page_only(view, stop_flag, who):
    """10/26 Muse 13:08: "no order cards" 13x/h while orders WERE on the board -- after dismissals the board sits on its
    far end, where only empty "New Order In" slots + the locked slot show. The locked slot proves the board is open, so
    one drag back to the start is safe there. -> (img, view) after the drag, or None when it does not apply."""
    if view["cards"] or view["lock_x"] is None:
        return None
    log(f"{who}: only empty slots on the end page (locked slot in view) -- dragging back to the start once.")
    reset_orders_scroll(stop_flag)
    img = screenshot()
    return img, classify_board_page(img)


def open_board_smart(stop_flag=None):
    """Tap the Orders icon and look. The board keeps its scroll position, so when it is already on the start or the end page nothing is
    swiped; only an unknown position gets the old reset drag. Returns (screenshot, view)."""
    global _LAST_ORDER_NO, _LAST_ORDER_SIG
    _LAST_ORDER_NO = _LAST_ORDER_SIG = None
    tap(*ORDERS_ICON_LOC)
    interruptible_sleep(1.2, stop_flag)
    img = screenshot()
    view = classify_board_page(img)
    if not view["cards"]:                              # still opening
        interruptible_sleep(1.0, stop_flag)
        img = screenshot()
        view = classify_board_page(img)
    _e = _end_page_only(view, stop_flag, "BOARD")
    if _e:
        img, view = _e
    if not view["cards"]:                              # pass 83: nothing to read at all -- picture, one clean retry, never swipe
        log("BOARD: no order cards are visible after opening the board -- saving a picture, clearing any popup/panel and opening it once more.")
        try:
            import run_trace
            run_trace.fail_picture("board_no_cards", "the Orders board showed no order cards")
        except Exception:                              # noqa: BLE001
            pass
        try:
            import find_and_center as _fac
            _fac.dismiss_error_dialog()
            close_any_open_panel(quiet=True, thorough=True)
        except StopRequested:
            raise
        except Exception as e:                         # noqa: BLE001
            log(f"(board recovery step failed, ignored: {e!r})")
        interruptible_sleep(0.8, stop_flag)
        tap(*ORDERS_ICON_LOC)
        interruptible_sleep(1.5, stop_flag)
        img = screenshot()
        view = classify_board_page(img)
        if not view["cards"]:
            log("BOARD: still no order cards -- not swiping (nothing to scroll); giving up this look.")
            return img, view
    if view["at_start"] or view["at_end"]:
        log("BOARD: the board is already on the " + ("whole-board page" if (view["at_start"] and view["at_end"]) else
                                                      "start page" if view["at_start"] else "end page") + " -- no swipe needed.")
        return img, view
    log("BOARD: position unknown (neither the first order at the left edge nor the locked slot in view) -- resetting to the start once.")
    reset_orders_scroll(stop_flag)
    img = screenshot()
    return img, classify_board_page(img)


# ---------------------------------------------------------------------------------------------------------------
# pass 69: learn an unknown icon from the game's own tooltip
# ---------------------------------------------------------------------------------------------------------------
import re as _re
import difflib as _difflib
TOOLTIP_PARSE = _re.compile(r"^\s*(?:get|grow|make|gather|find|buy)\s+(.+?)\s+(?:fr\w{1,3}|on|at|by|in)\b", _re.I)
_RECIPE_NAMES = None


def _recipe_names():
    """{normalised name: (key, kind)} from recipes.json."""
    global _RECIPE_NAMES
    if _RECIPE_NAMES is None:
        try:
            d = json.load(open(os.path.join(BASE_DIR, "recipes.json"), encoding="utf-8"))
            items = dict(d.get("items", d))
            try:                                       # 10/28: dishes the bot learned by itself
                with open(os.path.join(BASE_DIR, "recipes_learned.json"), encoding="utf-8") as fh:
                    for k, v in json.load(fh).get("items", {}).items():
                        items.setdefault(k, v)
            except (OSError, ValueError):
                pass
            _RECIPE_NAMES = {_re.sub(r"[^a-z0-9]", "", str(v.get("name", k)).lower()): (k, v.get("kind"))
                             for k, v in items.items() if isinstance(v, dict)}
            for k, v in items.items():                 # pass 72: "Cabbage / Greens", "Ham / Pork" -- the game uses either word
                if isinstance(v, dict) and "/" in str(v.get("name", "")):
                    for part in str(v["name"]).split("/"):
                        _RECIPE_NAMES.setdefault(_re.sub(r"[^a-z0-9]", "", part.lower()), (k, v.get("kind")))
            for al in (d.get("aliases") or {}):        # seaweed / fish / chicken / sugar: the game names them, the recipe book files them under another item
                _RECIPE_NAMES.setdefault(_re.sub(r"[^a-z0-9]", "", al.lower()), (al, "alias"))
        except Exception:                              # noqa: BLE001
            _RECIPE_NAMES = {}
    return _RECIPE_NAMES


def parse_tooltip_item(text):
    """'Get Salad Nicoise from the Salad Station' -> ('salad_nicoise', 'dish'); None when it cannot be matched."""
    m = TOOLTIP_PARSE.search((text or "").replace("\n", " "))
    if not m:
        return None
    norm = _re.sub(r"[^a-z0-9]", "", m.group(1).lower())
    names = _recipe_names()
    if norm in names:
        return names[norm]
    close = _difflib.get_close_matches(norm, list(names), n=1, cutoff=0.82)
    return names[close[0]] if close else None


# 10/25 (owner: "I just want to see the name of the dish in the orders screen"): every tooltip the bot reads
# ("Get Chicken Enchiladas from the Taqueria") names the item's PICTURE -- kept in templates/tooltip_names/ so an
# item the bot cannot make still shows its real name on the Orders tab (and in [plan] lines) instead of
# "name not learned yet". Display only.
TOOLTIP_NAMES_DIR = os.path.join(BASE_DIR, "templates", "tooltip_names")
TOOLTIP_NAMES_FILE = os.path.join(TOOLTIP_NAMES_DIR, "names.json")
TOOLTIP_NAME_MIN = 0.85
_TT_NAMES = None


def _tt_vec(icon):
    g = cv2.resize(icon, (48, 48), interpolation=cv2.INTER_AREA).astype(np.float32)
    g = (g - g.mean()) / (g.std() + 1e-6)
    return g.ravel() / (np.linalg.norm(g) + 1e-6)


def _tt_names():
    global _TT_NAMES
    if _TT_NAMES is None:
        _TT_NAMES = []
        try:
            with open(TOOLTIP_NAMES_FILE, encoding="utf-8") as fh:
                meta = json.load(fh)
        except (OSError, ValueError):
            meta = {}
        for f, m in meta.items():
            im = cv2.imread(os.path.join(TOOLTIP_NAMES_DIR, f))
            if im is not None:
                _TT_NAMES.append((f, m, _tt_vec(im)))
    return _TT_NAMES


def tooltip_name(icon):
    """{"name", "note"} the game's tooltip gave for a picture like this one, or None."""
    if icon is None or icon.size == 0:
        return None
    v = _tt_vec(icon)
    best, bs = None, 0.0
    for _f, m, t in _tt_names():
        sc = float(v @ t)
        if sc > bs:
            best, bs = m, sc
    return best if bs >= TOOLTIP_NAME_MIN else None


def remember_tooltip_name(icon, name, note=""):
    """Save this picture under the name its tooltip gave (updates the note when the picture is already known)."""
    try:
        if icon is None or icon.size == 0 or not name:
            return
        names = _tt_names()
        v = _tt_vec(icon)
        for f, m, t in names:
            if float(v @ t) >= TOOLTIP_NAME_MIN:
                if m.get("name") == name and (not note or m.get("note") == note):
                    return
                m.update(name=name, note=note or m.get("note", ""))
                break
        else:
            os.makedirs(TOOLTIP_NAMES_DIR, exist_ok=True)
            f = f"{_re.sub(r'[^a-z0-9]+', '_', name.lower()).strip('_')}__{int(time.time())}.png"
            cv2.imwrite(os.path.join(TOOLTIP_NAMES_DIR, f), icon)
            names.append((f, {"name": name, "note": note}, v))
            log(f"[names] learned the name '{name}' for a board picture from its tooltip" + (f" ({note})" if note else "") + ".")
        with open(TOOLTIP_NAMES_FILE, "w", encoding="utf-8") as fh:
            json.dump({f: m for f, m, _t in names}, fh, indent=1)
    except Exception as e:                             # noqa: BLE001 -- display only
        log(f"[names] could not save a tooltip name (ignored): {e!r}")


def _unbuilt_check(text, item, q_loc, stop_flag):
    """10/25 (owner): an unknown dish from a station the owner has not built ("Get Chicken Enchiladas from the
    Taqueria") -- its '?' opens the SHOP instead of travelling. Shop -> close it (red X), learn the dish as unbuilt
    and return ('unbuilt', name); the caller dismisses the order. Board still open = the tap missed -> None (old flow).
    Travelled = the station exists, the dish is just not trained -> ('travelled', name)."""
    try:
        import unbuilt
        ds = unbuilt.parse_tooltip(text)
        if not ds:
            return None
        remember_tooltip_name(item.get("icon"), ds[0], f"from the {ds[1]} -- not trained")
        # 10/25 live: reading the text takes a few seconds and the tooltip closes meanwhile -- the "?" tap landed on
        # the bare board twice. Re-open the tooltip and tap its fresh "?" at once (2 tries).
        after = None
        for _try in range(2):
            tap(*item["tap_loc"])
            interruptible_sleep(0.35, stop_flag)
            q2, _q2 = find_question_button(screenshot(), retry=1)
            tap(*(q2 or q_loc))
            interruptible_sleep(1.5, stop_flag)
            after = screenshot()
            if not find_cards(after):
                break
        if unbuilt.is_shop(after):
            tap(*unbuilt.SHOP_CLOSE_X)                     # the shop's red X -- never a buy button
            interruptible_sleep(1.2, stop_flag)
            unbuilt.learn(ds[0], ds[1], item.get("icon"))
            remember_tooltip_name(item.get("icon"), ds[0], f"needs the {ds[1]} -- not built")
            return "unbuilt", ds[0]
        if find_cards(after):
            log(f"TOOLTIP: the '?' for '{ds[0]}' did not land (the board is still open) -- trying again next pass.")
            return None
        log(f"TOOLTIP: '{ds[0]}' -- its '?' travelled instead of opening the shop, so the {ds[1]} is built; the dish "
            "just is not trained yet.")
        try:                                           # 10/28 (owner): learn it right here, on its own station menu
            import recipe_learner
            lk = recipe_learner.learn_here(ds[0], ds[1], item.get("icon"), stop_flag)
        except StopRequested:
            raise
        except Exception as e:                         # noqa: BLE001
            lk = None
            log(f"(learning '{ds[0]}' failed, ignored: {e!r})")
        close_any_open_panel(quiet=True, thorough=True)
        if lk:                                         # learned -> the caller re-reads the board and cooks it now
            return "dish", lk
        return "travelled", ds[0]
    except StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001
        log(f"(unbuilt check failed, ignored: {e!r})")
        return None


def learn_icon_from_tooltip(item, stop_flag=None):
    """Tap the item, read its tooltip, and (when the name is a dish / raw item we know) save the icon as an added match.
    Returns ('dish'|'raw'|'known', key) or None."""
    import popup_ocr
    tap(*item["tap_loc"])
    interruptible_sleep(0.35, stop_flag)
    img = screenshot()
    q_loc, _q = find_question_button(img, retry=1)
    if q_loc is None:
        no_loc, _nc = find_no_button(img)
        if no_loc is not None:
            log("TOOLTIP: tapping the unknown item raised a gem-buy dialog -- declining (No).")
            tap(*no_loc)
        return None
    qx, qy = q_loc
    text = (popup_ocr.read_text(img, (max(0, qx - 420), max(0, qy - 60), max(1, qx - 15), qy + 60)) or "").strip()
    hit = parse_tooltip_item(text)
    log(f"TOOLTIP: '{text}' -> {hit if hit else 'no match in the recipe book'}")
    if not hit:
        return _unbuilt_check(text, item, (qx, qy), stop_flag)
    key, kind = hit
    stamp = int(time.time())
    try:
        lib = _load_dish_library()
    except Exception:                                  # noqa: BLE001
        lib = {}
    if key in lib:
        os.makedirs(DISH_LIBRARY_DIR, exist_ok=True)
        path = os.path.join(DISH_LIBRARY_DIR, f"{key}__a{stamp}.png")
        cv2.imwrite(path, item["icon"])
        chk = identify_dish(item["icon"])
        if not chk or chk["name"] != key:                 # a saved icon must recognise itself, otherwise it would be re-saved on every loop
            os.remove(path)
            log(f"TOOLTIP: saved icon for '{key}' did not recognise itself -- removed it, leaving the order alone.")
            return "known", key
        log(f"SELF-TRAINED: the tooltip names this icon '{key}' -- saved it as an added match ({os.path.basename(path)}).")
        return "dish", key
    if kind in ("crop", "fruit", "animal"):
        os.makedirs(BOARD_ITEMS_DIR, exist_ok=True)
        path = os.path.join(BOARD_ITEMS_DIR, f"{key}__a{stamp}.png")
        cv2.imwrite(path, item["icon"])
        log(f"SELF-TRAINED: the tooltip names this icon '{key}' (a raw item) -- saved it to the board items ({os.path.basename(path)}).")
        return "raw", key
    return "known", key


# ---------------------------------------------------------------------------------------------------------------
# pass 74: skip-until-ready for crops that are still growing
# ---------------------------------------------------------------------------------------------------------------
GROWING_FILE = os.path.join(BASE_DIR, ".growing_items.json")
GROWING_MAX_SEC = 8 * 3600


def _parse_grow_time(text):
    """'lh 14m 24s' / '1h 14m' / '23m 53s' / '48s' -> seconds, else None."""
    import re
    t = (text or "").lower().replace("\n", " ")
    t = re.sub(r"\b[l|i]h", "1h", t)
    h = re.search(r"(\d+)\s*h", t)
    m = re.search(r"(\d+)\s*m", t)
    s = re.search(r"(\d+)\s*s", t)
    if not (h or m or s):
        return None
    return (int(h.group(1)) * 3600 if h else 0) + (int(m.group(1)) * 60 if m else 0) + (int(s.group(1)) if s else 0)


def read_grow_card_seconds(img):
    """Seconds left on a crop's grow-timer card (strip y585-655, x640-960); None when it cannot be read reliably."""
    import popup_ocr
    roi = cv2.cvtColor(img[585:655, 640:960], cv2.COLOR_BGR2GRAY)
    votes = []
    for scale, binary in ((2, False), (3, True), (4, True), (2, True), (3, False)):
        big = cv2.resize(roi, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        if binary:
            _, big = cv2.threshold(big, 120, 255, cv2.THRESH_BINARY)
        big = cv2.copyMakeBorder(big, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)
        try:
            val = _parse_grow_time(popup_ocr.read_text(cv2.cvtColor(big, cv2.COLOR_GRAY2BGR), (0, 0, big.shape[1], big.shape[0])))
        except Exception:                              # noqa: BLE001
            val = None
        if val is not None:
            votes.append(val)
    if not votes:
        return None
    best = max(set(votes), key=lambda v: (votes.count(v), v))
    return best if 0 < best <= GROWING_MAX_SEC else None


def _growing_load():
    try:
        data = json.load(open(GROWING_FILE, encoding="utf-8"))
    except Exception:                                  # noqa: BLE001
        return []
    now = time.time()
    return [e for e in data if e.get("ready_at", 0) > now and e.get("ready_at", 0) - now <= GROWING_MAX_SEC]


def _growing_same(e, sig, dx, row):
    try:
        return e["dx"] == dx and e["row"] == row and same_sig(sig, e["sig"])
    except Exception:                                  # noqa: BLE001
        return False


def growing_add(slot_key, seconds):
    sig = slot_key.get("sig") if isinstance(slot_key, dict) else None
    if sig is None or not seconds:
        return
    entries = [e for e in _growing_load() if not _growing_same(e, sig, slot_key["dx"], slot_key["row"])]
    entries.append({"sig": [int(v) for v in sig.reshape(-1)], "dx": slot_key["dx"], "row": slot_key["row"],
                    "ready_at": time.time() + seconds})
    try:
        with open(GROWING_FILE, "w", encoding="utf-8") as fh:
            json.dump(entries, fh)
    except OSError:
        pass


def growing_remaining(slot_key):
    """Seconds until this order slot's crop is ready (0 = not remembered / already due)."""
    sig = slot_key.get("sig") if isinstance(slot_key, dict) else None
    if sig is None:
        return 0
    for e in _growing_load():
        if _growing_same(e, sig, slot_key["dx"], slot_key["row"]):
            return max(0, int(e["ready_at"] - time.time()))
    return 0


# 10/22 (owner: "quickest orders first, on by default") -- Settings > Clipboard Orders. Among the red items on the board
# page, work the one whose ORDER finishes soonest (LAST_ORDER_PLAN wall time from the recipe book) instead of the first
# one on the board; orders without a time come last. One look at the other page per pass when a quicker order sits there.
QUICK_FIRST = True
_OTHER_PAGE_LOOKED = False                          # reset by process_all_visible


RANK_BY_COINS = False                # 10/27 (owner: yes): "Best coins/hour" -- Settings "Which order first" = 2


def _order_rate_for_sig(sig):
    """coins per hour of the plan order whose header matches sig (coins / still-missing wall time), or None."""
    if sig is None:
        return None
    for s, o in zip(LAST_ORDER_PLAN.get("sigs") or [], LAST_ORDER_PLAN.get("orders") or []):
        if s is None or not o.get("priced") or o.get("ready") or not o.get("wall") or not o.get("coins"):
            continue
        try:
            if same_sig(sig, s):
                return o["coins"] * 3600.0 / max(60, o["wall"])          # a few-second order is not "infinite"
        except Exception:                           # noqa: BLE001
            continue
    return None


def _order_time_for_sig(sig):
    """(wall seconds, order number) of the plan order whose header matches sig, or (None, None)."""
    if sig is None:
        return None, None
    for s, o in zip(LAST_ORDER_PLAN.get("sigs") or [], LAST_ORDER_PLAN.get("orders") or []):
        if s is None or not o.get("priced") or o.get("ready") or not o.get("wall"):
            continue
        try:
            if same_sig(sig, s):
                return o["wall"], o.get("n")
        except Exception:                           # noqa: BLE001
            continue
    return None, None


def find_missing_item(img, skip_slots=None, quiet=True):
    """QUICK_FIRST: the red item of the quickest order on this page (see above); otherwise the first red item.
    quiet=False (main() only) logs the pick -- other callers (the plot route, Prep) scan the board too."""
    if not QUICK_FIRST:
        return _find_missing_item_first(img, skip_slots)
    cands = _find_missing_items_all(img, skip_slots)
    if not cands:
        return None
    for c in cands:
        c["_wall"] = _order_time_for_sig(c["slot_key"]["sig"])[0]
        try:                                    # 10/26 (owner: enchiladas never dismissed): an item whose tooltip said
            lb = tooltip_name(c.get("icon"))    # "not built" has no time, so it always came LAST and was never checked;
            c["_unbuilt"] = bool(lb and "not built" in (lb.get("note") or ""))   # go FIRST -> '?' check -> dismiss
        except Exception:                       # noqa: BLE001
            c["_unbuilt"] = False
    if RANK_BY_COINS:                           # 10/27: best coins per hour first; unknown rate -> after, quickest
        for c in cands:
            c["_rate"] = _order_rate_for_sig(c["slot_key"]["sig"])
        best = min(cands, key=lambda c: (not c["_unbuilt"], c["_rate"] is None, -(c["_rate"] or 0),
                                          c["_wall"] is None, c["_wall"] or 0))
        if best is not cands[0] and best.get("_rate") and not quiet:
            log(f"[order pick] best coins/hour first: this order (~{best['_rate']:.0f} coins/h) before the first "
                f"one on the board" + (f" (~{cands[0]['_rate']:.0f}/h)" if cands[0].get("_rate") else " (rate unknown)") + ".")
        return best
    best = min(cands, key=lambda c: (not c["_unbuilt"], c["_wall"] is None, c["_wall"] or 0))
    if best.get("_unbuilt") and not quiet:
        log("[order pick] a dish whose station was not built last time goes first -- one '?' check, then dismissed "
            "if the shop opens.")
    if best is not cands[0] and best["_wall"] is not None and not quiet:
        try:
            import recipe_book as _rb
            log(f"[order pick] quickest first: this order (~{_rb.fmt(best['_wall'])} left) before the first one on "
                f"the board" + (f" (~{_rb.fmt(cands[0]['_wall'])})" if cands[0]["_wall"] else " (time unknown)") + ".")
        except Exception:                           # noqa: BLE001
            pass
    return best


def _find_missing_items_all(img, skip_slots=None):
    out, skip = [], list(skip_slots or [])
    for _ in range(40):
        it = _find_missing_item_first(img, skip)
        if it is None or it["slot_key"]["sig"] is None or any(o["tap_loc"] == it["tap_loc"] for o in out):
            if it is not None and not out:
                out.append(it)                     # a card cut off at the edge (no header) -- still workable
            break
        out.append(it)
        skip.append(it["slot_key"])
    return out


def quicker_order_elsewhere(img, wall, rate=None):
    """A priced, unfinished plan order quicker than `wall` whose card is NOT on this page (so it is on the other one).
    10/27: with RANK_BY_COINS, "better" = more coins per hour than `rate` instead."""
    on_page = [_card_signature(img, cx) for cx in find_card_positions(img)]
    for s, o in zip(LAST_ORDER_PLAN.get("sigs") or [], LAST_ORDER_PLAN.get("orders") or []):
        if s is None or not o.get("priced") or o.get("ready") or not o.get("wall"):
            continue
        if RANK_BY_COINS:
            if not o.get("coins") or (rate is not None and o["coins"] * 3600.0 / max(60, o["wall"]) <= rate):
                continue
        elif o["wall"] >= wall:
            continue
        try:
            if any(p is not None and float(np.mean(np.abs(s.astype(np.int16) - p.astype(np.int16))))
                   < SIGNATURE_MATCH_THRESHOLD for p in on_page):
                continue
        except Exception:                           # noqa: BLE001
            continue
        return o
    return None


def _find_missing_item_first(img, skip_slots=None):
    """Scans the visible Orders cards for the first red (missing) item.
    Returns a dict {tap_loc, icon, slot_key} for the first one found, or
    None if everything visible is green/empty. `icon` is a small crop of
    the dish's own icon, used later to identify the matching recipe card
    at the destination station. `slot_key` is {sig, dx, row} -- the
    card's own content fingerprint plus which slot on it -- and is what
    `skip_slots` (a list of the same shape) should be built from, NOT the
    screen position: see _slot_already_skipped for why position-keyed
    skipping is fragile across scroll drift. Lets a caller pass over
    slots it already knows are blocked this session, so repeated runs
    can make progress on OTHER missing items instead of re-discovering
    the same stuck one every time."""
    skip_slots = skip_slots or []
    for cx in find_card_positions(img):
        card_sig = _card_signature(img, cx)
        if KEEP_LINK and _LINK["sig"] is not None and (sig_distance(img, cx, _LINK["sig"]) or 99) < SIGNATURE_MATCH_THRESHOLD:
            continue                                    # 10/25: the Sell Apple Juice link order is not worked
        for row_idx, (dx, (icon_y, text_y)) in enumerate(
                (dx, row) for dx in SLOT_DX for row in SLOT_ROWS):
            x = cx + dx
            if x - 45 < 0 or x + 45 > img.shape[1]:
                continue  # card is cut off at the screen edge -- not readable
            if _slot_already_skipped(card_sig, dx, row_idx, skip_slots, img=img, cx=cx):
                continue
            color = _sample_color(img, x, text_y)
            if color == "red":
                icon = img[icon_y - ICON_CROP_TOP:icon_y + ICON_CROP_BOTTOM, x - 45:x + 45]
                deficit = None
                try:                                    # pass 55: how many are still missing (need - have) from the board's own digits
                    import event_digits
                    ri = row_idx % len(SLOT_ROWS)
                    rc = event_digits.read_count(img, x, BOARD_TEXT_Y[ri], save_unknown=False,
                                                 half_w=BOARD_DIGIT_BOX[0], half_h=BOARD_DIGIT_BOX[1])
                    if rc:
                        deficit = max(0, rc["need"] - rc["have"])
                except Exception:                       # noqa: BLE001
                    deficit = None
                return {"tap_loc": (x, icon_y), "icon": icon, "deficit": deficit,
                        "slot_key": {"sig": card_sig, "dx": dx, "row": row_idx, "cx": cx}}
    return None


# 10/25 (owner) "Sell Apple Juice": while the switch is on, ONE clipboard order whose items lead to the Smoothie Bar
# (prep_route) is kept on the board as the way there -- not worked, not served, not dismissed. The other orders run
# as usual. KEEP_LINK = the item the link must reach (afsd_core._apply_settings), None = off.
KEEP_LINK = None
_LINK = {"sig": None, "order": None, "note": None}


def _sig_same(a, b):
    try:
        return a is not None and b is not None and float(np.mean(np.abs(a.astype(np.int16) - b.astype(np.int16)))) \
            < SIGNATURE_MATCH_THRESHOLD
    except Exception:                                      # noqa: BLE001
        return False


def link_order():
    """Pick (or keep) the clipboard order that leads to KEEP_LINK's station. -> its header sig or None."""
    if not KEEP_LINK:
        _LINK.update(sig=None, order=None)
        return None
    try:
        import prep_route
        sigs = LAST_ORDER_PLAN.get("sigs") or []
        items = LAST_ORDER_PLAN.get("items") or []
        best = None
        for n, (sg, its) in enumerate(zip(sigs, items), start=1):
            names = [it["name"] for it in its if it.get("name")]
            r = prep_route.find_route(KEEP_LINK, names) if names and sg is not None else None
            if not r:
                continue
            score = (not _sig_same(sg, _LINK["sig"]), len(r))     # the one already held first, then fewest hops
            if best is None or score < best[0]:
                best = (score, sg, n, prep_route.describe(KEEP_LINK, r))
        if best is None:
            if _LINK["sig"] is not None:
                log(f"[keep link] no clipboard order leads to {KEEP_LINK} any more -- nothing held.")
            _LINK.update(sig=None, order=None, note=None)
            return None
        if not _sig_same(best[1], _LINK["sig"]) or _LINK["note"] != best[3]:
            log(f"[keep link] holding Order {best[2]} as the way to {KEEP_LINK} ({best[3]}) -- not working, serving "
                "or dismissing it; the other orders run as usual.")
        _LINK.update(sig=best[1], order=best[2], note=best[3])
        return best[1]
    except Exception as ex:                                # noqa: BLE001
        log(f"[keep link] could not pick the link order: {ex!r}")
        return _LINK["sig"]


# 10/26 (owner: "auto dismiss orders that will take longer than a number") -- Settings > Clipboard Orders "Dismiss
# orders that take longer than" (long_order_min, 0 = off). Uses the plan's recipe-book wall time of what is still
# missing (the ⏱ on each card). The Sell Apple Juice link order is never dismissed. Each order is queued once.
LONG_ORDER_MIN = 0


def long_order_dismissals():
    """Queue a dismiss for every plan order whose remaining wall time is over LONG_ORDER_MIN. -> how many queued."""
    if LONG_ORDER_MIN <= 0:
        return 0
    import recipe_book as rb
    n_q = 0
    for sg, o in zip(LAST_ORDER_PLAN.get("sigs") or [], LAST_ORDER_PLAN.get("orders") or []):
        try:
            if sg is None or not o.get("priced") or o.get("ready") or not o.get("wall"):
                continue
            if o["wall"] <= LONG_ORDER_MIN * 60 or dismiss_state(sg) is not None:
                continue
            if _LINK["sig"] is not None and _sig_same(sg, _LINK["sig"]):
                continue
            if any(_sig_same(sg, r[1]) for r in DISMISS_REQUESTS if len(r) > 1):
                continue
            why = (f"takes about {rb.fmt(o['wall'])} (over the {LONG_ORDER_MIN} min limit in Settings) -- "
                   "dismissed by the bot")
            DISMISS_REQUESTS.append((o.get("n") or "?", sg, why))
            mark_dismiss(sg, "queued")
            log(f"[long order] Order {o.get('n')} {why}.")
            SET_ASIDE_NOTES.append(f"Dismissing Order {o.get('n')}: it takes about {rb.fmt(o['wall'])}.")
            n_q += 1
        except Exception as ex:                            # noqa: BLE001
            log(f"[long order] check failed for one order (ignored): {ex!r}")
    return n_q


def is_link_card(img, cx):
    return bool(KEEP_LINK) and _LINK["sig"] is not None and _sig_same(_card_signature(img, cx), _LINK["sig"])


def is_card_ready_to_serve(img, cx):
    """A card is ready to serve once every occupied item slot shows green
    and none show red. Deliberately reuses the already-proven per-item
    color classification instead of trying to detect the card's outline
    changing color (the user's own description of the visual cue) --
    that would need a new, unvalidated detector for something we can
    already determine reliably from data we're already reading."""
    any_item = False
    for dx in SLOT_DX:
        for icon_y, text_y in SLOT_ROWS:
            x = cx + dx
            if x - 45 < 0 or x + 45 > img.shape[1]:
                return False      # 10/28: card cut off at the screen edge (x=4) -- its hidden items may be red
            color = _sample_color(img, x, text_y)
            if color == "red":
                return False
            if color == "green":
                any_item = True
    return any_item


def _ready_by_counts(img, cx):
    """10/25 live: Order 3 (sushi boat, 271 coins) read READY TO SERVE in the plan (every count have >= need) for
    25+ min while is_card_ready_to_serve said no and nothing was served. Same test as the plan: every item slot that
    shows a count reads have >= need and none is red."""
    try:
        import event_digits
        n = 0
        for ri, (_iy, _ty) in enumerate(SLOT_ROWS):
            for dx in SLOT_DX:
                x = cx + dx
                if x - 45 < 0 or x + 45 > img.shape[1]:
                    return False
                color, glyphs = event_digits.glyphs(img, x, BOARD_TEXT_Y[ri], BOARD_DIGIT_BOX[0], BOARD_DIGIT_BOX[1])
                if not glyphs:
                    continue
                rc = event_digits.read_count(img, x, BOARD_TEXT_Y[ri], save_unknown=False,
                                             half_w=BOARD_DIGIT_BOX[0], half_h=BOARD_DIGIT_BOX[1])
                if color == "red" or not rc or rc.get("need") is None or (rc.get("have") or 0) < rc["need"]:
                    return False
                n += 1
        return n > 0
    except Exception:                                      # noqa: BLE001
        return False


def card_ready(img, cx):
    """Ready to serve by colour OR by its counts (the Serve tap's gem-dialog guard catches a wrong guess)."""
    if is_link_card(img, cx):                              # 10/25: the Sell Apple Juice link stays on the board
        return False
    if serve_refused(img, cx):                             # 10/28: the game asked for gems on this card already
        return False
    ready = is_card_ready_to_serve(img, cx) or _ready_by_counts(img, cx)
    if ready and truck_hold(img, cx):                      # 11/9 O.R.D.E.R.: the food truck needs those dishes
        return False
    return ready


# --- O.R.D.E.R. (Order Ranks, Decides Every Run), owner 11/9 -------------------------------------------------------
# "hold back clipboard orders from submitting anything that would interfere with a food truck order, if the food truck
# job is listed higher in the jobs list". afsd_core sets TRUCK_FIRST each cycle (Food Truck ticked AND above Clipboard
# Orders AND the Settings switch on). A READY clipboard card is not served while serving it would leave storage short
# of a dish the truck still wants (every open truck slot of that dish counts). The hold ends by itself when the truck
# leaves, its panel read is over TRUCK_STATE_MAX_SEC old, or the truck job skipped that dish (it can't cook in time).
TRUCK_FIRST = False
TRUCK_STATE_MAX_SEC = 3 * 3600
TRUCK_HOLD_LOG_SEC = 300
_TRUCK_HELD = []                                           # {"sig", "t"} -- cards held for the truck (dismiss clock)
_TRUCK_HOLD_LOGGED = {}


def _dish_key(name):
    return _re.sub(r"[^a-z]", "", (name or "").lower().replace("and", ""))


def truck_reserved(state, now=None):
    """Pure: {dish key: (truck name, how many the truck still wants, storage have it last saw)} from the saved Food
    Truck state. Empty when the read is stale, the truck has left, or nothing is open."""
    now = now or time.time()
    t = state.get("t") or 0
    if not t or now - t > TRUCK_STATE_MAX_SEC:
        return {}
    left = state.get("leaving_sec")
    if left is not None and left - (now - t) <= 0:
        return {}
    skipped = {_dish_key(n) for n in (state.get("skipped") or [])}
    out = {}
    for s in state.get("slots") or []:
        name = s.get("name")
        need = s.get("need") or s.get("want")
        if s.get("state") != "order" or not name or not need or _dish_key(name) in skipped:
            continue
        k = _dish_key(name)
        nm, tot, have = out.get(k, (name, 0, s.get("have")))
        out[k] = (nm, tot + need, have if have is not None else s.get("have"))
    return out


def _match_reserved(item_name, reserved):
    k = _dish_key(item_name)
    if not k:
        return None
    if k in reserved:
        return k
    import difflib
    best = max(reserved, key=lambda r: difflib.SequenceMatcher(None, k, r).ratio(), default=None)
    if best and difflib.SequenceMatcher(None, k, best).ratio() >= 0.85:
        return best
    return None


def truck_conflicts(items, reserved):
    """Pure: [(truck name, clipboard need, storage have, truck wants)] for the card's items that serving would take
    away from the truck -- i.e. storage after serving would be below what the truck still wants."""
    out = []
    for it in items or []:
        k = _match_reserved(it.get("name"), reserved)
        if not k:
            continue
        name, wants, t_have = reserved[k]
        need = it.get("need") or 1
        have = it.get("have") if it.get("have") is not None else t_have
        if have is None or have - need < wants:
            out.append((name, need, have, wants))
    return out


def truck_hold(img, cx):
    """True when this ready clipboard card must wait for a job higher in the jobs list (O.R.D.E.R.). Never raises."""
    try:
        import job_order as jo
        reserved = jo.reserved_for(jo.CURRENT[0] or jo.CLIP)
        if not reserved:
            return False
        best = min(read_orders_page(img), key=lambda o: abs(o["cx"] - cx), default=None)
        if best is None or abs(best["cx"] - cx) > 80:
            return False
        hits = []
        for it in best["items"]:
            c = jo.conflict(it.get("name"), it.get("have"), it.get("need") or 1, reserved)
            if c:
                hits.append((it.get("name"), it.get("need") or 1, it.get("have"), c[0], c[1]))
                jo.note_hold(jo.CURRENT[0] or jo.CLIP, c[1], f"serving {it.get('name')}")
        if not hits:
            return False
        now = time.time()
        sig = best.get("sig")
        _TRUCK_HELD[:] = [e for e in _TRUCK_HELD if now - e["t"] < 600 and not _sig_same(e["sig"], sig)]
        _TRUCK_HELD.append({"sig": sig, "t": now})
        key = (round(cx / 40), tuple(h[0] for h in hits))
        if now - _TRUCK_HOLD_LOGGED.get(key, 0) >= TRUCK_HOLD_LOG_SEC:
            _TRUCK_HOLD_LOGGED[key] = now
            what = "; ".join(f"{n} (this order takes {need}, storage {'?' if have is None else have}, "
                             f"{jo.short_name(o)} still needs {w})" for n, need, have, w, o in hits)
            log(f"[o.r.d.e.r.] holding the ready order at x={cx} -- a job higher in the list needs {what}.")
        return True
    except Exception as e:                                 # noqa: BLE001
        log(f"[o.r.d.e.r.] check failed (serving as usual): {e!r}")
        return False


# 11/9 (owner): "whatever is in the number one slot is the number one priority ... cabbage to make milk to make cheese
# to make mac and cheese -- don't take one for a clipboard order until the truck has what it needs ... just in case
# other stations are sitting empty, that's why both are on". So while TRUCK_FIRST, a CLIPBOARD cook (never the truck's
# own, Prep's or Chef's -- CLIPBOARD_TURN is set only inside process_all_visible) is held when one of its ingredients
# is anywhere in the truck's chain and taking it would leave less than the chain still needs. Stations the chain does
# not use stay free for the clipboard.
CLIPBOARD_TURN = [False]
TRUCK_CHAIN_LOG_SEC = 300
_TRUCK_CHAIN_LOGGED = {}


def _book_key(name):
    import recipe_book as rb
    for n in (name, (name or "").lower().replace(" & ", " and ").replace(" ", "_"), (name or "").lower().replace(" ", "_")):
        try:
            return rb.resolve(n)
        except Exception:                                  # noqa: BLE001
            continue
    return None


def truck_chain(state, stock=None, now=None):
    """{recipe-book key: units the truck's still-short dishes will use} -- the dishes themselves plus everything below
    them (cheese, milk, cabbage ...). stock = {key: n} known in storage (skips what is already made). {} = nothing."""
    import recipe_book as rb
    order, have = {}, dict(stock or {})
    for _k, (name, wants, t_have) in truck_reserved(state, now).items():
        key = _book_key(name)
        if not key:
            continue
        short = wants - (t_have or 0)
        if short > 0:
            order[key] = order.get(key, 0) + short
        if t_have is not None:
            have.setdefault(key, 0)
    if not order:
        return {}
    try:
        detail = rb.cost(order, stock=have)["detail"]
    except Exception:                                      # noqa: BLE001
        return {k: q for k, q in order.items()}
    return {k: d["needed"] for k, d in detail.items() if d.get("needed")}


def chain_conflict(ing_key, have, need, chain):
    """Pure: True when this cook's use of ing_key would eat into what the truck chain still needs."""
    if not ing_key or ing_key not in chain:
        return False
    if have is None or need is None:
        return True                                        # can't tell -> the truck comes first
    return have - need < chain[ing_key]


def _known_stock():
    """{key: n} the bot has seen recently (Prep's stock memory) -- lets the chain skip what is already made."""
    try:
        import prep_engine as pe
        order = pe._load()
        out = {}
        for k in (order.get("stock") or {}):
            n = pe._stock_known(order, k)
            if n is not None:
                out[k] = n
        return out
    except Exception:                                      # noqa: BLE001
        return {}


def _truck_chain_hold(img, ingredients, dish):
    """(name, have, need, units, owner job) of an ingredient this cook must leave for a job higher in the jobs list
    (O.R.D.E.R., every job -- job_order.py), or None. The top job is never held."""
    try:
        import job_order as jo
        job = jo.CURRENT[0]
        reserved = jo.reserved_for(job)
        if not reserved:
            return None
        import event_digits
        for color, x, y, name in ingredients:
            nm = PAGE2_CROP_ALIASES.get(name, name)
            if not jo.key_of(nm) or jo.key_of(nm) not in reserved:
                continue
            try:
                c = event_digits.read_count(img, x, INGREDIENT_TEXT_Y, save_unknown=False)
            except Exception:                              # noqa: BLE001
                c = None
            have, need = (c or {}).get("have"), (c or {}).get("need")
            hit = jo.conflict(nm, have, need, reserved)
            if hit:
                jo.note_hold(job, hit[1], nm)
                now = time.time()
                if now - _TRUCK_CHAIN_LOGGED.get((dish, nm), 0) >= TRUCK_CHAIN_LOG_SEC:
                    _TRUCK_CHAIN_LOGGED[(dish, nm)] = now
                    log(f"[o.r.d.e.r.] {jo.short_name(job)}: not cooking '{dish}' -- it takes {need or '?'} {name} "
                        f"(storage {'?' if have is None else have}) and {jo.short_name(hit[1])} (higher in the jobs "
                        f"list) still needs {hit[0]} of it.")
                return (name, have, need, hit[0], hit[1])
    except Exception as e:                                 # noqa: BLE001
        log(f"[o.r.d.e.r.] chain check failed (cooking as usual): {e!r}")
    return None


def truck_held_sig(sig):
    now = time.time()
    return any(now - e["t"] < 600 and _sig_same(e["sig"], sig) for e in _TRUCK_HELD)


# 10/28 live: Serve on the card at x=4 asked for gems, the guard said No, and the bot tapped Serve again every 3 s
# for 2+ min (the owner stopped it). A card whose Serve asked for gems is not tried again for SERVE_REFUSED_SEC.
SERVE_REFUSED_SEC = 600
_SERVE_REFUSED = []                                        # {"sig", "x", "t"}


def served_again(img, cx, just_served):
    """11/12 (Muse: 7 gem dialogs in 4 sends): right after a serve the pass re-read the board while the served card was
    still there and tapped Serve on it again -> 'Buy missing dishes?' gem dialog. True when the card at cx is one served
    in this pass (same header picture; unreadable header = same spot within 40 px)."""
    if not just_served:
        return False
    try:
        sig = _card_signature(img, cx)
    except Exception:                                      # noqa: BLE001
        sig = None
    for x, s0 in just_served:
        if sig is not None and s0 is not None:
            # 11/17: shift-tolerant like Dismiss -- under FLASH the same card can sit 1-2 px off, and a plain compare
            # then said "another card" and the second Serve tap went through (-> gem dialog)
            d = sig_distance(img, cx, s0)
            if d is not None and d < SIGNATURE_MATCH_THRESHOLD:
                return True
        elif abs(x - cx) <= 40:
            return True
    return False


def note_serve_refused(img, cx):
    _SERVE_REFUSED.append({"sig": _card_signature(img, cx), "x": cx, "t": time.time()})


def serve_refused(img, cx):
    now = time.time()
    _SERVE_REFUSED[:] = [e for e in _SERVE_REFUSED if now - e["t"] < SERVE_REFUSED_SEC]
    sig = _card_signature(img, cx)
    for e in _SERVE_REFUSED:
        if sig is not None and e["sig"] is not None:
            if _signature_seen(sig, [e["sig"]]):
                return True
        elif abs(e["x"] - cx) <= 40:
            return True
    return False


def wait_for_screen_stable(stop_flag=None, max_wait=8.0, check_interval=0.3, diff_threshold=4.0):
    """Waits until two consecutive screenshots are nearly identical, i.e.
    the camera/board has genuinely stopped moving -- rather than trusting
    a fixed sleep duration to always be long enough. Built 9/27 after the
    user caught a real live bug: the Orders board's fling-physics
    animation after a long swipe doesn't always finish within the fixed
    LONG_SWIPE_SETTLE_SEC (1.5s) sleep, so a Serve tap could fire while
    cards were still sliding into place and miss or hit the wrong one.
    Same 'verify against a real frame, don't guess a delay' philosophy as
    find_and_center's self-verifying zoom-out.

    max_wait defaults to 8s, not the originally-planned 3s -- measured
    live 9/27 that a single screenshot() call itself takes ~2.2-2.4s in
    this environment (ADB round-trip + image decode), so a 3s budget
    barely covered ONE real comparison. Gives up and returns False after
    max_wait so this never blocks forever -- caller proceeds regardless,
    same as before this existed, just with a better-informed screenshot
    when it does."""
    start = time.time()
    prev = screenshot()
    while time.time() - start < max_wait:
        check_stop(stop_flag)
        interruptible_sleep(check_interval, stop_flag)
        cur = screenshot()
        if frame_diff(prev, cur) < diff_threshold:
            return True
        prev = cur
    return False


# ---------------------------------------------------------------------------
# ORDER PLAN (10/4): during serve_ready_orders' first look at each Orders page, read every order's
# items + have/need counts and price the whole board with the recipe book (recipe_book.py). Logs
# "[plan]" lines, keeps the text in LAST_ORDER_PLAN for the AFSD window, and lists anything it could
# not identify or price so those can be checked/trained later. Read-only: it never taps anything.
# ---------------------------------------------------------------------------
BOARD_ITEMS_DIR = os.path.join(BASE_DIR, "templates", "board_items")
PLAN_UNKNOWN_DIR = os.path.join(BASE_DIR, "templates", "plan_unknown_items")
BOARD_TEXT_Y = (476, 616)          # centre y of the have/need text under row 1 / row 2 icons
BOARD_DIGIT_BOX = (34, 18)         # half width / half height of the digit search box
LAST_ORDER_PLAN = {"time": None, "text": "", "orders": [], "unknown": []}


def identify_board_item(icon):
    """Raw things that appear on orders but are not dishes (a plain carrot ...): match against
    templates/board_items/<name>.png (variants <name>__2.png). Returns a name or None."""
    if icon.size == 0 or not os.path.isdir(BOARD_ITEMS_DIR):
        return None
    best, best_name = 0.0, None
    for path in glob.glob(os.path.join(BOARD_ITEMS_DIR, "*.png")):
        name = os.path.basename(path)[:-4].split("__")[0]
        tmpl = cv2.imread(path)
        if tmpl is None:
            continue
        if tmpl.shape[:2] != icon.shape[:2]:
            tmpl = cv2.resize(tmpl, (icon.shape[1], icon.shape[0]))
        v = float(cv2.matchTemplate(icon, tmpl, cv2.TM_CCOEFF_NORMED).max())
        if v > best:
            best, best_name = v, name
    return best_name if best >= DISH_MATCH_THRESHOLD else None


def read_orders_page(img):
    """-> list of orders visible on this page: {cx, sig, items:[{name,need,have,color,icon,row,col}]}.
    Cards cut off at the screen edge are skipped (they are read on the other page)."""
    import event_digits
    orders = []
    for card in find_cards(img):
        cx = card["icon_col1_x"]
        sig = _card_signature(img, cx)
        if sig is None or cx - 45 < 0 or cx + SLOT_DX[-1] + 45 > img.shape[1]:
            continue
        items = []
        for ri, (icon_y, _text_y) in enumerate(SLOT_ROWS):
            for ci, dx in enumerate(SLOT_DX):
                x = cx + dx
                color, glyphs = event_digits.glyphs(img, x, BOARD_TEXT_Y[ri], BOARD_DIGIT_BOX[0], BOARD_DIGIT_BOX[1])
                if not glyphs:
                    continue                      # empty slot
                rc = event_digits.read_count(img, x, BOARD_TEXT_Y[ri], save_unknown=False,
                                             half_w=BOARD_DIGIT_BOX[0], half_h=BOARD_DIGIT_BOX[1])
                icon = img[icon_y - ICON_CROP_TOP:icon_y + ICON_CROP_BOTTOM, x - 45:x + 45]
                ident = identify_dish(icon)
                name = ident["name"] if ident else identify_board_item(icon)
                label = None if name else tooltip_name(icon)              # 10/25: the game's name for an unknown item
                items.append({"name": name, "need": rc["need"] if rc else None, "have": rc["have"] if rc else None,
                              "color": color, "icon": icon, "row": ri, "col": ci, "label": label})
        y1, y2 = REWARD_REGION_Y
        orders.append({"cx": cx, "sig": sig, "items": items,
                       "reward_img": img[y1:y2, cx + REWARD_REGION_DX[0]:cx + REWARD_REGION_DX[1]].copy()})
    return orders


def _items_on_card(img, card_x):
    """[{name, need}] of the order card at card_x (for the History tab). Never raises."""
    try:
        best = min(read_orders_page(img), key=lambda o: abs(o["cx"] - card_x), default=None)
        if best is None or abs(best["cx"] - card_x) > 80:
            return []
        return [{"name": (it["name"] or "").replace("_", " ").title() or None, "need": it["need"]} for it in best["items"]]
    except Exception:                              # noqa: BLE001
        return []


def _record_orders_page(img, seen_orders):
    """Adds the orders on this page that have not been recorded yet (dedupe by header signature)."""
    page = []
    try:
        sigs = [o["sig"] for o in seen_orders]
        page = read_orders_page(img)
        for o in page:
            if not _signature_seen(o["sig"], sigs):
                seen_orders.append(o)
                sigs.append(o["sig"])
    except Exception as e:                        # noqa: BLE001 -- planning must never break serving
        log(f"[plan] could not read this page: {e}")
    _read_new_order_wait(img, page)


# 10/26 (backlog #27): an empty clipboard slot says "New Order In 21 Minutes" (next to a Skip [gem] button -- never
# tapped). Read it (Windows OCR, at most once per page per NEW_ORDER_READ_GAP_SEC) so the Orders tab counts down the
# game's real time instead of the 30-min guess after a dismiss. Display only.
NEW_ORDER_READ_GAP_SEC = 120
_NEW_ORDER_READ_AT = {}
_NEW_ORDER_RE = _re.compile(r"new\s*order\s*in\s*:?\s*(\d{1,3})\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\b"
                           r"(?:\s*(\d{1,2})\s*(minutes?|mins?|m|seconds?|secs?|s)\b)?", _re.I)


def parse_new_order_waits(text):
    """'New Order In 21 Minutes New Order In 1 Hour 5 Minutes' -> [1260, 3900] (seconds)."""
    unit = lambda u: 3600 if u[0].lower() == "h" else 60 if u[0].lower() == "m" else 1   # noqa: E731
    out = []
    for m in _NEW_ORDER_RE.finditer(text or ""):
        sec = int(m.group(1)) * unit(m.group(2))
        if m.group(3):
            sec += int(m.group(3)) * unit(m.group(4))
        out.append(sec)
    return out


def _read_new_order_wait(img, page_orders):
    try:
        key = "left" if not page_orders or min(o["cx"] for o in page_orders) < img.shape[1] / 2 else "right"
        key += f"{len(page_orders)}"
        now = time.time()
        if now - _NEW_ORDER_READ_AT.get(key, 0) < NEW_ORDER_READ_GAP_SEC:
            return
        _NEW_ORDER_READ_AT[key] = now
        crop = img[150:min(img.shape[0], 870)].copy()
        import threading
        threading.Thread(target=_new_order_ocr, args=(crop, key, now), daemon=True).start()   # OCR takes 1-2 s
    except Exception as e:                        # noqa: BLE001 -- display only, never breaks the board read
        log(f"[new order] could not read the countdown: {e!r}")


def _new_order_ocr(crop, key, t):
    try:
        import popup_ocr
        text = popup_ocr.read_text(crop)
        waits = parse_new_order_waits(text)
        if not waits and "order in" not in (text or "").lower():
            return
        import orders_view
        orders_view.set_read_new_orders(orders_view.CLIPBOARD, [t + w for w in waits], key)
        if waits:
            log(f"[new order] the board says a new order comes in "
                + ", ".join(f"{w // 60} min" if w >= 60 else f"{w} s" for w in waits) + ".")
    except Exception as e:                        # noqa: BLE001
        log(f"[new order] could not read the countdown: {e!r}")


def _plan_coins(order):
    """10/27: the order card's coin reward (coin_digits, proven live 10/23-27), or None."""
    try:
        import coin_digits
        rimg = order.get("reward_img")
        return coin_digits.read_reward(rimg)["coins"] if rimg is not None and rimg.size else None
    except Exception:                                  # noqa: BLE001
        return None


def build_order_plan(orders):
    """Price every recorded order with the recipe book. Returns the text to show/log."""
    import recipe_book as rb
    from datetime import datetime
    lines, unknown, plan_orders = [], [], []
    combined = {}
    for n, o in enumerate(orders, start=1):
        names, missing, problems = [], {}, []
        all_green = bool(o["items"])
        for it in o["items"]:
            nm = it["name"]
            if nm is None:
                problems.append("an item I could not recognise")
                os.makedirs(PLAN_UNKNOWN_DIR, exist_ok=True)
                path = os.path.join(PLAN_UNKNOWN_DIR, f"{int(time.time())}_order{n}_r{it['row']}c{it['col']}.png")
                cv2.imwrite(path, it["icon"])
                unknown.append(f"Order {n}: unrecognised icon saved to {path}")
                lb = it.get("label")
                names.append(f"{it['need'] if it['need'] is not None else '?'} "
                             + (f"{lb['name']} ({lb.get('note') or 'not trained'})" if lb else "(unrecognised item)"))
                all_green = False
                continue
            try:
                key = rb.resolve(nm)
            except KeyError:
                problems.append(f"{nm} is not in the recipe book")
                unknown.append(f"{nm} is not in the recipe book (recipes.json)")
                key = None
            disp = nm.replace("_", " ")
            if it["need"] is None:
                problems.append(f"could not read the count for {disp}")
                names.append(f"{disp} ?")
                all_green = False
                continue
            names.append(f"{it['need']} {disp}")
            gap = max(0, it["need"] - (it["have"] or 0))
            if gap:
                all_green = False
                if key:
                    missing[key] = missing.get(key, 0) + gap
        head = f"Order {n}: " + (", ".join(names) if names else "(nothing readable)")
        if all_green and not problems:
            lines.append(head + "   READY TO SERVE")
            plan_orders.append({"n": n, "ready": True})
            continue
        lines.append(head)
        if problems:
            lines.append("   ! " + "; ".join(sorted(set(problems))) + " -- not priced")
            plan_orders.append({"n": n, "ready": False, "priced": False})
            continue
        r = rb.cost(missing)
        star = ">= " if r["unknown"] else ""
        still = ", ".join(f"{q} {k.replace('_', ' ')}" for k, q in missing.items()) or "nothing"
        lines.append(f"   still to do: {still}")
        lines.append(f"   total machine time ({star}{rb.fmt(r['work'])}), finished in about {star}{rb.fmt(r['wall'])}")
        if r["unknown"]:
            unknown.append(f"Order {n}: time not recorded for " + ", ".join(r["unknown"]))
        for k, q in missing.items():
            combined[k] = combined.get(k, 0) + q
        plan_orders.append({"n": n, "ready": False, "priced": True, "work": r["work"], "wall": r["wall"],
                            "busy": r["busy"], "coins": _plan_coins(o)})
    if combined:
        rc = rb.cost(combined)
        star = ">= " if rc["unknown"] else ""
        lines.append(f"All orders together: total machine time ({star}{rb.fmt(rc['work'])}), "
                     f"everything finished in about {star}{rb.fmt(rc['wall'])}")
    if unknown:
        lines.append("To check later:")
        lines += [f"   - {u}" for u in sorted(set(unknown))]
    text = "\n".join(lines) if lines else "No orders were read."
    LAST_ORDER_PLAN.update({"time": datetime.now().strftime("%H:%M:%S"), "text": text,
                            "orders": plan_orders, "unknown": sorted(set(unknown))})
    try:                                                       # pass 89: the raw items, for fishing_topup's needs sum
        def _known(nm):
            try:
                rb.resolve(nm)
                return True
            except KeyError:
                return False
        LAST_ORDER_PLAN["items"] = [[{"name": it["name"], "need": it["need"], "have": it["have"],
                                      "label": it.get("label")} for it in o["items"]]
                                    for o in orders]
        LAST_ORDER_PLAN["reliable"] = bool(orders) and all(
            it["name"] and it["need"] is not None and _known(it["name"]) for o in orders for it in o["items"])
    except Exception:                                          # noqa: BLE001 -- planning must never break serving
        LAST_ORDER_PLAN["items"], LAST_ORDER_PLAN["reliable"] = [], False
    for ln in text.splitlines():
        log("[plan] " + ln)
    try:                                                       # 10/21: header signature per order, for Dismiss
        LAST_ORDER_PLAN["sigs"] = [o.get("sig") for o in orders]
    except Exception:                                          # noqa: BLE001
        LAST_ORDER_PLAN["sigs"] = []
    _rank_test(orders, plan_orders)
    return text


# --- Order ranking test (10/19, owner: watch-only first) -----------------------------------------------------
# Is an order worth its station time? A 45-coin order needing an ice cream holds the Dairy 3 h and blocks every
# Cheese / Cream / Whipped Cream behind it. In a background thread (at most every RANK_TEST_SEC) each card's
# reward header is read by Windows OCR, and the orders are logged best-first by coins per hour of the slowest
# chain, with the stations each one would tie up. One header picture per new card goes to
# templates/reward_headers/ (Send logs) so the coin/star layout can be checked. Taps nothing.
RANK_TEST_SEC = 300
REWARD_PIC_DIR = os.path.join(BASE_DIR, "templates", "reward_headers")
_rank = {"t": 0.0, "busy": False}


def _rank_test(orders, plan_orders):
    if _rank["busy"] or time.time() - _rank["t"] < RANK_TEST_SEC or not orders:
        return
    _rank.update(t=time.time(), busy=True)
    jobs = [(p, orders[p["n"] - 1].get("reward_img")) for p in plan_orders if p["n"] - 1 < len(orders)]

    def work():
        import re
        import recipe_book as rb
        try:
            import coin_digits                            # 10/23: the game's own digit shapes (Windows OCR read '')
            os.makedirs(REWARD_PIC_DIR, exist_ok=True)
            old = sorted(os.listdir(REWARD_PIC_DIR))
            for f in old[:max(0, len(old) - 20 + len(jobs))]:
                os.remove(os.path.join(REWARD_PIC_DIR, f))
            rows = []
            for p, rimg in jobs:
                if rimg is None or rimg.size == 0:
                    continue
                cv2.imwrite(os.path.join(REWARD_PIC_DIR, f"{int(time.time())}_order{p['n']}.png"), rimg)
                rr = coin_digits.read_reward(rimg)
                coins = rr["coins"]
                raw = f"{coins}/{rr['stars']}"
                log(f"[coin test] Order {p['n']}: {coins if coins is not None else '?'} coins, "
                    f"{rr['stars'] if rr['stars'] is not None else '?'} stars"
                    + ("" if coins is not None else " -- coins unreadable, picture kept in templates/reward_headers"))
                if p.get("ready"):
                    rows.append((float("inf"), f"Order {p['n']}: ready to serve ({raw!r})"))
                    continue
                if not p.get("priced") or not p.get("wall"):
                    rows.append((-1, f"Order {p['n']}: not priced ({raw!r})"))
                    continue
                hrs = p["wall"] / 3600
                rate = coins / hrs if coins else None
                long_st = ", ".join(f"{st} {rb.fmt(sec)}" for st, sec in sorted(p["busy"].items(), key=lambda kv: -kv[1])
                                    if sec >= 1800)
                rows.append((rate if rate is not None else -1,
                             f"Order {p['n']}: {coins if coins is not None else '?'} coins (read {raw!r}), "
                             f"about {rb.fmt(p['wall'])} -> "
                             + (f"{rate:.0f} coins/h" if rate is not None else "? coins/h")
                             + (f"; ties up {long_st}" if long_st else "")))
            for _r, line in sorted(rows, key=lambda t: -t[0]):
                log("[rank test] " + line)
        except Exception as e:                        # noqa: BLE001 -- a test must never break the run
            log(f"[rank test] skipped: {e!r}")
        finally:
            _rank["busy"] = False
    import threading
    threading.Thread(target=work, daemon=True).start()



# pass 76: what does each served order pay?
SERVE_CSV = os.path.join(BASE_DIR, "served_orders.csv")


def _hud_coins(img):
    try:
        import currency_log
        return currency_log.read_hud(img).get("coins")
    except Exception:                                  # noqa: BLE001
        return None


def note_serve_reward(before, after_img):
    """Log + CSV one served order: coins before the Serve tap, coins now, and the difference when both reads are sane."""
    after = _hud_coins(after_img)
    delta = None
    if before is not None and after is not None and 0 < after - before < 5000:
        delta = after - before
    log(f"[serve] SERVED order: coins {before} -> {after}" + (f" (+{delta})" if delta else " (reward not readable)"))
    try:
        new = not os.path.exists(SERVE_CSV)
        with open(SERVE_CSV, "a", encoding="utf-8") as fh:
            if new:
                fh.write("time,coins_before,coins_after,reward\n")
            fh.write(f"{datetime.datetime.now().isoformat(timespec='seconds')},{before if before is not None else ''},"
                     f"{after if after is not None else ''},{delta if delta else ''}\n")
    except OSError:
        pass
    return delta


def _serve_page(stop_flag=None, seen_orders=None, settle_first=False):
    """Serve every ready card on the page that is on screen (the board must be open). Returns how many.
    10/25 (owner): also called from main() at every board look -- order 3 sat ready for 10 min while the bot
    chased other orders, then storage filled up."""
    served = 0
    first = True
    record_pending = True
    just_served = []                          # 11/12: (x, header sig) of cards served in this pass
    while True:
        check_stop(stop_flag)
        dismiss_second_device_dialog()
        if just_served:                       # 11/12: let the board finish moving after a serve before reading it
            first, settle_first = True, True
        # Only wait-for-stable on the FIRST screenshot of a pass, and
        # only when the caller just did a big swipe (settle_first) --
        # the fixed 1s sleep after each individual Serve tap below is
        # plenty for that small a reflow; calling the (multi-second,
        # multi-screenshot) stability check on every single served
        # item would needlessly slow down a page with several ready
        # orders. This is specifically for the swipe-then-serve
        # moment the user caught live: fling-physics animation from
        # reset_orders_scroll/swipe_to_far_end doesn't always finish
        # within the fixed LONG_SWIPE_SETTLE_SEC sleep.
        if first and settle_first:
            wait_for_screen_stable(stop_flag)
        first = False
        img = screenshot()
        if record_pending and seen_orders is not None:                       # first look at this page: read every order BEFORE serving
            record_pending = False
            _record_orders_page(img, seen_orders)
        # Real bug found 9/28: a Serve tap on a card that JUST reflowed
        # into position (right after the previous Serve) can be read as
        # ready from a stale/mid-animation screenshot when it actually
        # isn't -- that pops the real "Buy missing dishes?" gem dialog
        # instead of a genuine serve. This function used to have no
        # code anywhere to notice or decline that dialog (only the
        # ingredient-recursion paths ever called find_no_button), so it
        # sat open indefinitely -- confirmed live: stuck for 3+ hours
        # straight, every later cycle's close_any_open_panel matching
        # something at the fixed panel-corner X position (0.99) and
        # tapping it uselessly, since this dialog's real No button
        # lives elsewhere. Checked first, every iteration, before
        # trusting any card read.
        no_loc, no_conf = find_no_button(img)
        if no_loc is not None:
            log(f"A gem-buy dialog appeared during serving (confidence {no_conf:.2f}, most "
                "likely 'Buy missing dishes?' from a stale ready-read on a just-reflowed "
                "card) -- declining, never spending gems.")
            tap(*no_loc)
            interruptible_sleep(1, stop_flag)
            continue
        served_this_pass = False
        for card in find_cards(img):
            if card_ready(img, card["icon_col1_x"]):
                if served_again(img, card["icon_col1_x"], just_served):
                    log(f"Card at x={card['icon_col1_x']} looks like the order just served (still on the board "
                        "after the serve) -- not tapping it again.")
                    continue
                log(f"Order ready to serve at card x={card['icon_col1_x']} -- tapping Serve.")
                hud0 = _hud_coins(img)                                  # pass 76: coins before this serve
                served_items = _items_on_card(img, card["icon_col1_x"])   # History tab (10/16)
                tap(*card["serve_button"])
                interruptible_sleep(1, stop_flag)
                post = screenshot()
                no_loc, no_conf = find_no_button(post)
                if no_loc is not None:
                    log(f"Serve tap at x={card['icon_col1_x']} triggered a gem-buy dialog "
                        f"instead of a real serve (confidence {no_conf:.2f}) -- the card "
                        "wasn't actually fully ready. Declining, not counting it as served.")
                    tap(*no_loc)
                    note_serve_refused(img, card["icon_col1_x"])
                    interruptible_sleep(1, stop_flag)
                else:
                    served += 1
                    just_served.append((card["icon_col1_x"], _card_signature(img, card["icon_col1_x"])))
                    reward = None
                    try:                                                # pass 76: what did it pay?
                        interruptible_sleep(1.2, stop_flag)
                        reward = note_serve_reward(hud0, screenshot())
                    except StopRequested:
                        raise
                    except Exception as e:                              # noqa: BLE001
                        log(f"(serve reward note failed, ignored: {e!r})")
                    try:
                        import orders_view
                        orders_view.add_history(orders_view.CLIPBOARD, served_items, reward)
                    except Exception:                                   # noqa: BLE001
                        pass
                served_this_pass = True
                break  # positions may have shifted -- rescan fresh
        if not served_this_pass:
            break
    return served


def refresh_plan_counts(img):
    """10/25 (owner: the Orders screen did not show corn / the salad as done): the plan is built once per turn by
    the serve pass; every later board look now copies the fresh have/need of the orders on this page into it."""
    try:
        sigs = LAST_ORDER_PLAN.get("sigs") or []
        items = LAST_ORDER_PLAN.get("items") or []
        changed = 0
        for o in read_orders_page(img):
            for n, s0 in enumerate(sigs):
                if s0 is None or n >= len(items) or not _signature_seen(o["sig"], [s0]):
                    continue
                if len(items[n]) == len(o["items"]):
                    for old, new in zip(items[n], o["items"]):
                        if new["need"] is not None and (old.get("have"), old.get("need")) != (new["have"], new["need"]):
                            old["have"], old["need"] = new["have"], new["need"]
                            changed += 1
                break
        if changed:
            LAST_ORDER_PLAN["counts_time"] = time.time()
    except Exception as e:                                # noqa: BLE001 -- display only
        log(f"(plan count refresh failed, ignored: {e!r})")


ON_PLAN_CHANGE = None          # 10/25: afsd_core sets this to _publish_clipboard -- the Orders tab redraws at once


def _rebuild_plan_after_serve(stop_flag, served):
    """10/25 (owner: "when it submits an order expect a new order and update the bot to reflect that"): read both
    pages again right after a mid-turn serve, so the served order leaves the Orders tab and the new one shows up."""
    before = len(LAST_ORDER_PLAN.get("sigs") or [])
    seen = []
    reset_orders_scroll(stop_flag)
    wait_for_screen_stable(stop_flag)
    _record_orders_page(screenshot(), seen)
    swipe_to_far_end(stop_flag)
    wait_for_screen_stable(stop_flag)
    _record_orders_page(screenshot(), seen)
    build_order_plan(seen)
    log(f"SERVE: board read again after serving -- {len(seen)} order(s) on it now (was {before}).")
    if len(seen) < before:                         # the new order has not arrived yet -- show when it should
        try:
            import orders_view
            orders_view.add_new_order_timer(orders_view.CLIPBOARD, time.time() + NEW_ORDER_AFTER_DISMISS_SEC)
        except Exception:                          # noqa: BLE001
            pass
    if ON_PLAN_CHANGE is not None:
        try:
            ON_PLAN_CHANGE(served=served)
        except Exception as e:                     # noqa: BLE001
            log(f"(Orders tab refresh after serving failed, ignored: {e!r})")


def _serve_and_refresh(img, stop_flag):
    """At every board look: serve the ready cards on this page first (frees storage), then refresh the counts."""
    try:
        if any(card_ready(img, c["icon_col1_x"]) for c in find_cards(img)):
            n = _serve_page(stop_flag)
            if n:
                log(f"SERVE: served {n} ready order(s) on this page before working the next item.")
                _rebuild_plan_after_serve(stop_flag, n)
                return screenshot()
            img = screenshot()
    except StopRequested:
        raise
    except Exception as e:                                # noqa: BLE001
        log(f"(serve-on-look failed, ignored: {e!r})")
    refresh_plan_counts(img)
    try:                                                  # 10/27: a new order that arrived mid-turn was never priced,
        if _new_order_on_page(img) and time.time() - _NEW_ORDER_REPLAN["t"] > NEW_ORDER_REPLAN_GAP_SEC:
            _NEW_ORDER_REPLAN["t"] = time.time()          # so the long-order limit never saw it (Very Berry Smoothie
            log("[plan] a new order showed up during this turn -- reading the board again to time it.")  # -> 3 h ice cream)
            _rebuild_plan_after_serve(stop_flag, 0)
            if long_order_dismissals():
                log("[plan] the new order is over the long-order limit -- it will be dismissed after this item.")
            return screenshot()
    except StopRequested:
        raise
    except Exception as e:                                # noqa: BLE001
        log(f"(new-order re-plan failed, ignored: {e!r})")
    return img


NEW_ORDER_REPLAN_GAP_SEC = 120
_NEW_ORDER_REPLAN = {"t": 0.0}


def _new_order_on_page(img):
    """True when an order card on this page is not in the turn's plan (it arrived after the plan was built)."""
    if not LAST_ORDER_PLAN.get("time"):
        return False
    sigs = [s for s in (LAST_ORDER_PLAN.get("sigs") or []) if s is not None]
    return any(o["sig"] is not None and not _signature_seen(o["sig"], sigs) for o in read_orders_page(img))


def serve_ready_orders(stop_flag=None):
    """Taps Serve on every card that's fully ready (all items green, none
    red) across the WHOLE Orders board -- reset to the start, serve
    everything reachable there, one long slow swipe to the far end, serve
    everything there too. Two looks cover the whole board (see
    LONG_SWIPE_ENDPOINTS), so no scan loop is needed. Re-screenshots after
    each Serve tap rather than trusting stale positions, since serving a
    card can make the remaining cards on that page reflow. Returns how
    many were served."""
    close_any_open_panel()
    tap(*ORDERS_ICON_LOC)
    interruptible_sleep(1, stop_flag)
    _v = classify_board_page(screenshot())                    # pass 83: no cards = no board; never swipe blindly
    if not _v["cards"]:
        interruptible_sleep(1.0, stop_flag)
        _v = classify_board_page(screenshot())
    _e = _end_page_only(_v, stop_flag, "SERVE")
    if _e:
        _v = _e[1]
    if not _v["cards"]:
        log("SERVE: no order cards are visible after opening the board -- saving a picture, clearing any popup/panel and opening it once more.")
        try:
            import run_trace
            run_trace.fail_picture("board_no_cards", "the Orders board showed no order cards (serve pass)")
        except Exception:                              # noqa: BLE001
            pass
        try:
            import find_and_center as _fac
            _fac.dismiss_error_dialog()
            close_any_open_panel(quiet=True, thorough=True)
        except StopRequested:
            raise
        except Exception as e:                         # noqa: BLE001
            log(f"(board recovery step failed, ignored: {e!r})")
        interruptible_sleep(0.8, stop_flag)
        tap(*ORDERS_ICON_LOC)
        interruptible_sleep(1.5, stop_flag)
        _v = classify_board_page(screenshot())
        if not _v["cards"]:
            log("SERVE: still no order cards -- skipping this serve pass (nothing to serve, nothing to swipe).")
            close_any_open_panel(quiet=True, thorough=True)
            return 0
    reset_orders_scroll(stop_flag)

    served = 0
    seen_orders = []                # orders recorded for the plan (both pages)

    def serve_visible_ready_cards(settle_first=False):
        nonlocal served
        served += _serve_page(stop_flag, seen_orders, settle_first)

    serve_visible_ready_cards(settle_first=True)
    check_stop(stop_flag)
    dismiss_second_device_dialog()
    swipe_to_far_end(stop_flag)
    serve_visible_ready_cards(settle_first=True)

    try:
        build_order_plan(seen_orders)
    except Exception as e:                           # noqa: BLE001
        log(f"[plan] could not build the plan: {e}")
    # Close whatever's left open (the Orders board panel itself, normally --
    # but check first rather than blind-tapping CLOSE_X_LOC, in case a gem
    # dialog somehow survived the checks above and sits at a different X).
    close_any_open_panel(quiet=True, thorough=True)
    log(f"=== serve pass complete -- served {served} order(s) ===")
    return served


def find_question_button(img, retry=0):
    """Template-matches the blue quick-travel '?' button. Returns
    (loc, confidence); loc is None if not found (confidence still
    reported so callers can distinguish 'nothing there' from 'a dialog
    with no travel option appeared instead', e.g. a gem-buy prompt).
    pass 70: retry=N takes up to N fresh screenshots (0.4 s apart) when the first look misses -- the tooltip fades in.
    Only pass retry on LIVE screenshots."""
    loc, conf = _find_question_button_once(img)
    for _ in range(int(retry)):
        if loc is not None:
            break
        time.sleep(0.4)
        loc, conf = _find_question_button_once(screenshot())
    return loc, conf


def _find_question_button_once(img):
    res = cv2.matchTemplate(img, QUESTION_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)
    if max_val < QUESTION_MATCH_THRESHOLD:
        return None, max_val
    th, tw = QUESTION_TEMPLATE.shape[:2]
    return (max_loc[0] + tw // 2, max_loc[1] + th // 2), max_val


def panel_is_open(img):
    """Reuses the same close-X detection find_and_center.py's
    close_any_open_panel relies on, just as a read-only check here."""
    close_x = cv2.imread(os.path.join(BASE_DIR, "templates", "close_x.png"))
    x1, y1, x2, y2 = CLOSE_X_REGION
    region = img[y1:y2, x1:x2]
    if region.shape[0] < close_x.shape[0] or region.shape[1] < close_x.shape[1]:
        return False
    res = cv2.matchTemplate(region, close_x, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    return max_val >= 0.7


def _load_dish_library():
    if not os.path.exists(DISH_LIBRARY_FILE):
        return {}
    with open(DISH_LIBRARY_FILE) as f:
        return json.load(f)


def identify_dish(icon):
    """Matches a freshly-cropped Orders-board icon against the trained
    dish library (icon-to-icon, same art style -- unlike matching against
    a station panel's big illustration, this should self-match with high
    confidence). Returns {'name', 'card_index', 'confidence'} or None if
    this dish hasn't been trained yet."""
    if icon.size == 0:
        return None
    lib = _load_dish_library()
    best_name, best_val = None, 0.0
    for name in lib:
        # `{name}.png` plus optional `{name}__2.png`, `{name}__3.png`...
        # variants: the same dish can render on a different card background
        # (e.g. veggie_juice on grey vs cream cards), which a single 1:1
        # template can't cover (added 9/28).
        tmpl_paths = [os.path.join(DISH_LIBRARY_DIR, f"{name}.png")]
        tmpl_paths += sorted(glob.glob(os.path.join(DISH_LIBRARY_DIR, f"{name}__*.png")))
        for tmpl_path in tmpl_paths:
            if not os.path.exists(tmpl_path):
                continue
            tmpl = cv2.imread(tmpl_path)
            if tmpl.shape[:2] != icon.shape[:2]:
                tmpl = cv2.resize(tmpl, (icon.shape[1], icon.shape[0]))
            res = cv2.matchTemplate(icon, tmpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, _ = cv2.minMaxLoc(res)
            if max_val > best_val:
                best_val = max_val
                best_name = name
    if best_val >= DISH_MATCH_THRESHOLD:
        return {"name": best_name, "card_index": lib[best_name]["card_index"], "confidence": best_val}
    return None


def _panel_dish_crop(img, cx):
    y1, y2 = PANEL_DISH_IMAGE_REGION
    x1, x2 = cx - PANEL_DISH_IMAGE_HALF_WIDTH, cx + PANEL_DISH_IMAGE_HALF_WIDTH
    if x1 < 0 or x2 > img.shape[1]:
        return None  # too close to the screen edge to crop cleanly
    return img[y1:y2, x1:x2]


def find_dish_in_panel(img, name):
    """Locates a trained dish's recipe card in the CURRENT panel view by
    matching its own big illustration, instead of assuming a fixed
    card_index/RECIPE_CARD_X position -- works regardless of how many
    cards a station has or which position this dish happens to be sitting
    at. Returns (cx, confidence); cx is None if not found in this view or
    if this dish has no panel illustration trained yet."""
    tmpl_path = os.path.join(DISH_PANEL_LIBRARY_DIR, f"{name}.png")
    if not os.path.exists(tmpl_path):
        return None, 0.0
    tmpl = cv2.imread(tmpl_path)
    y1, y2 = PANEL_DISH_IMAGE_REGION
    strip = img[y1:y2, :]
    if strip.shape[0] != tmpl.shape[0]:
        return None, 0.0
    res = cv2.matchTemplate(strip, tmpl, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)
    if max_val < DISH_PANEL_MATCH_THRESHOLD:
        return None, max_val
    tw = tmpl.shape[1]
    return max_loc[0] + tw // 2, max_val


def locate_dish_card(name, stop_flag=None, max_swipes=2):
    """Finds which x-position a trained dish's card is sitting at within
    an already-open station panel, swiping the card row (same long slow
    swipe proven on both the Orders board and this panel's own row) if
    it's not visible yet. A station's card row is small (Soup Station's
    full range needed only one swipe), so max_swipes=2 gives real margin
    without risking an endless search. Returns (cx, confidence) --
    cx is None if still not found after swiping."""
    img = screenshot()
    cx, conf = find_dish_in_panel(img, name)
    if cx is not None:
        return cx, conf
    best = conf
    # 11/12 (owner: "Tomato Soup was too far left on the menu and didn't know to swipe left"): the row can open
    # scrolled toward its right end, so a card off the LEFT edge was never seen (best 0.79-0.81 = half a card at
    # the edge). Look right first (as before), then swipe back left past the start. A swipe that leaves the card
    # row unchanged = that end of the row is reached (the row lets you pull into empty space, then springs back).
    for x1, x2, n, left in ((1400, 200, max_swipes, False), (200, 1400, max_swipes * 2 + 1, True)):
        prev = _row_strip(img)
        for _ in range(n):
            check_stop(stop_flag)
            swipe(x1, PANEL_SWIPE_Y, x2, PANEL_SWIPE_Y, LONG_SWIPE_DURATION_MS)
            interruptible_sleep(LONG_SWIPE_SETTLE_SEC, stop_flag)
            img = screenshot()
            cx, conf = find_dish_in_panel(img, name)
            best = max(best, conf)
            if cx is not None:
                if left:
                    log(f"'{name}' was off the LEFT end of the card row -- found it after swiping back (x={cx}).")
                return cx, conf
            now = _row_strip(img)
            if prev is not None and now is not None and _row_same(prev, now):
                break                                       # this end of the row reached
            prev = now
    return None, best


def _row_strip(img):
    """Small grey copy of the card-picture row, to tell whether a swipe moved it."""
    try:
        y1, y2 = PANEL_DISH_IMAGE_REGION
        g = cv2.cvtColor(img[y1:y2, :], cv2.COLOR_BGR2GRAY)
        return cv2.resize(g, (160, max(4, (y2 - y1) // 10)))
    except Exception:                                       # noqa: BLE001
        return None


def _row_same(a, b):
    return a.shape == b.shape and float(np.mean(cv2.absdiff(a, b))) < 3.0


NAME_LOOK_GAP_SEC = 30 * 60      # 11/12: a dish whose name was not on any card is not looked up by name again for this long
_NAME_MISS = {}


def locate_card_by_name(name, stop_flag=None, swipes=3):
    """11/12: the station menu is open but the dish's card picture no longer matches (Tomato Soup best 0.79-0.81
    every cycle all night -> dish_card_not_found ~15x per send). Read the cards' NAME bubbles (picture taps only,
    never a button -- the recipe learner's way), swiping back left while it is not in view, and refresh the
    panel picture so the next look finds it by sight. Returns the card's cx, or None."""
    if _NAME_MISS.get(name, 0) > time.time():
        return None
    try:
        import event_orders as eo
        import recipe_book as rb
        try:
            want = rb.load()["items"][rb.resolve(name)]["name"]
        except Exception:                                   # noqa: BLE001
            want = name.replace("_", " ")
        seen_names = None
        for i in range(swipes + 1):
            check_stop(stop_flag)
            if i:
                swipe(200, PANEL_SWIPE_Y, 1400, PANEL_SWIPE_Y, LONG_SWIPE_DURATION_MS)   # back toward the row start
                interruptible_sleep(LONG_SWIPE_SETTLE_SEC, stop_flag)
            img = screenshot()
            if not panel_is_open(img):
                break
            btns = eo.station_buttons(img)
            names = eo.read_card_names(img, btns, stop_flag) if btns else None
            if not names or names == seen_names:
                break                                       # end of the row (or the panel changed)
            seen_names = names
            hits = [k for k, n in enumerate(names) if eo.same_name(n, want)]
            if len(hits) == 1:
                cx = btns[hits[0]][0]
                img = screenshot()                          # the name bubble may still be on the first one
                crop = _panel_dish_crop(img, cx)
                if crop is not None:
                    os.makedirs(DISH_PANEL_LIBRARY_DIR, exist_ok=True)
                    cv2.imwrite(os.path.join(DISH_PANEL_LIBRARY_DIR, f"{name}.png"), crop)
                return cx
        log(f"'{want}': no card of that name on this station menu -- not looking it up by name for 30 min.")
        _NAME_MISS[name] = time.time() + NAME_LOOK_GAP_SEC
    except StopRequested:
        raise
    except Exception as e:                                  # noqa: BLE001
        log(f"(finding '{name}' by its name failed, ignored: {e!r})")
    return None


def train_dish(icon, name, card_index=None, panel_img=None, panel_cx=None):
    """Adds a new dish to the small-icon library (used to NAME a missing
    item from its Orders-board icon) -- called once a human has looked at
    a pending icon and identified it (matches the user's own "we can
    train it" framing for handling stations/dishes we haven't seen
    before). If panel_img/panel_cx are given, also captures the dish's
    own big station-panel illustration into the second library, so future
    lookups can find its card by sight (see find_dish_in_panel) instead
    of trusting card_index -- the only thing that still works on a
    station shaped differently than 3 fixed cards (Soup Station,
    Breakfast Stove). card_index alone is kept for backward compatibility
    with dishes trained before this existed."""
    os.makedirs(DISH_LIBRARY_DIR, exist_ok=True)
    cv2.imwrite(os.path.join(DISH_LIBRARY_DIR, f"{name}.png"), icon)
    lib = _load_dish_library()
    lib[name] = {"card_index": card_index}
    with open(DISH_LIBRARY_FILE, "w") as f:
        json.dump(lib, f, indent=2)
    log(f"Trained new dish '{name}' -> card_index {card_index} (legacy fixed-position fallback).")

    if panel_img is not None and panel_cx is not None:
        crop = _panel_dish_crop(panel_img, panel_cx)
        if crop is not None:
            os.makedirs(DISH_PANEL_LIBRARY_DIR, exist_ok=True)
            cv2.imwrite(os.path.join(DISH_PANEL_LIBRARY_DIR, f"{name}.png"), crop)
            log(f"Also captured '{name}' panel illustration at cx={panel_cx} -- future lookups "
                "will find its card by sight instead of trusting card_index.")
        else:
            log(f"Couldn't crop '{name}' panel illustration at cx={panel_cx} (too close to the "
                "screen edge) -- only the legacy card_index fallback will work until retrained.")


# Trainable ingredient library -- same pattern as the dish library above,
# but for the small ingredient icons under a recipe card (Milk, Carrot,
# Cabbage, Wheat, Egg, ...). Built 9/27 in response to the user asking
# "can the code tell why it can't make each item" -- until now, a blocked
# ingredient only got special-cased identification for Wheat (see
# is_ingredient_wheat), and every other block just logged "isn't Wheat"
# without ever naming what it actually was. This does NOT replace
# is_ingredient_wheat (still the live trigger for Garden Plot recursion,
# proven and unchanged) -- it's a parallel, purely-informational layer so
# the log can say "blocked on Cabbage" instead of a bare position.
INGREDIENT_LIBRARY_DIR = os.path.join(BASE_DIR, "templates", "ingredients")
INGREDIENT_LIBRARY_FILE = os.path.join(INGREDIENT_LIBRARY_DIR, "library.json")
INGREDIENT_MATCH_THRESHOLD = 0.85  # raised from 0.8 live 9/27 -- a real
# false positive was caught end-to-end (Coffee Bean vs Seaweed scored
# 0.8176, just above the old threshold, before Coffee Bean was even
# trained). Every genuine cross-card match measured tonight scored
# 0.90-1.00, safely clear of this new bar.
INGREDIENT_ICON_HALF_W = 25
# Asymmetric vertical crop -- the icon art sits ABOVE its stock-count text
# (INGREDIENT_TEXT_Y, sampled +/-8px), so a naive symmetric crop around
# INGREDIENT_ICON_Y bleeds the green digits into the bottom of every icon
# (caught live 9/27 via a visual preview montage before any training --
# every candidate crop showed a green "2/1"-style overlay baked in).
# Extend further up than down to stay clear of the text baseline.
INGREDIENT_ICON_TOP_MARGIN = 22
INGREDIENT_ICON_BOTTOM_MARGIN = 6
# Extra slack around the expected icon position for a SLIDING search
# rather than a rigid 1:1 pixel compare -- a direct crop-vs-crop match
# (like the dish-icon library uses) turned out to be far too sensitive to
# a couple pixels of position drift between different cards/stations:
# measured live 9/27, genuinely-identical ingredients (e.g. Milk seen on
# two different panels) scored only 0.49-0.78 against each other,
# nowhere close to a usable threshold. Same fix already proven by
# is_ingredient_wheat's own margin-padded region. The trained template
# stays a TIGHT crop; only the region being SEARCHED gets the margin.
INGREDIENT_SEARCH_MARGIN = 10


def crop_ingredient_icon(img, x, y):
    return img[y - INGREDIENT_ICON_TOP_MARGIN:y + INGREDIENT_ICON_BOTTOM_MARGIN,
               x - INGREDIENT_ICON_HALF_W:x + INGREDIENT_ICON_HALF_W]


def _ingredient_search_region(img, x, y):
    return img[y - INGREDIENT_ICON_TOP_MARGIN - INGREDIENT_SEARCH_MARGIN:
               y + INGREDIENT_ICON_BOTTOM_MARGIN + INGREDIENT_SEARCH_MARGIN,
               x - INGREDIENT_ICON_HALF_W - INGREDIENT_SEARCH_MARGIN:
               x + INGREDIENT_ICON_HALF_W + INGREDIENT_SEARCH_MARGIN]


def _load_ingredient_library():
    if not os.path.exists(INGREDIENT_LIBRARY_FILE):
        return []
    with open(INGREDIENT_LIBRARY_FILE) as f:
        return json.load(f)


def identify_ingredient(search_region):
    """Slides each trained (tight-crop) ingredient template across a
    margin-padded search region and takes the best alignment anywhere
    within it -- NOT a rigid 1:1 compare, see INGREDIENT_SEARCH_MARGIN.
    Returns {'name', 'confidence'} or None if unidentified -- never
    guesses."""
    if search_region.size == 0:
        return None
    names = _load_ingredient_library()
    best_name, best_val = None, 0.0
    for name in names:
        tmpl_path = os.path.join(INGREDIENT_LIBRARY_DIR, f"{name}.png")
        if not os.path.exists(tmpl_path):
            continue
        tmpl = cv2.imread(tmpl_path)
        if tmpl.shape[0] > search_region.shape[0] or tmpl.shape[1] > search_region.shape[1]:
            continue
        res = cv2.matchTemplate(search_region, tmpl, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, _ = cv2.minMaxLoc(res)
        if max_val > best_val:
            best_val = max_val
            best_name = name
    if best_val >= INGREDIENT_MATCH_THRESHOLD:
        return {"name": best_name, "confidence": best_val}
    return None


def train_ingredient(icon, name):
    os.makedirs(INGREDIENT_LIBRARY_DIR, exist_ok=True)
    cv2.imwrite(os.path.join(INGREDIENT_LIBRARY_DIR, f"{name}.png"), icon)
    names = _load_ingredient_library()
    if name not in names:
        names.append(name)
    with open(INGREDIENT_LIBRARY_FILE, "w") as f:
        json.dump(names, f, indent=2)
    log(f"Trained new ingredient '{name}'.")


# Real blank card background, measured live 9/27 from Cheese's two
# genuinely-unused ingredient slots (a single-ingredient dish): std=12.5,
# rgb=(219,233,249). Distinguishes "no ingredient here at all" (dish
# genuinely has fewer than 3 ingredients -- Cheese, Whipped Cream, Butter,
# Apple Juice, Tomato Soup, Espresso, and any other 1-ingredient card) from
# "something IS here but the color read failed" (the real wrong-position
# bug has_none was built to catch) -- a wrong cx samples scrambled real
# game content, not the plain card background, so this is a safe,
# specific discriminator, not a loosening of the original safety check.
BLANK_SLOT_STD_MAX = 18.0
BLANK_SLOT_RGB = (219, 233, 249)  # (r, g, b)
BLANK_SLOT_RGB_TOLERANCE = 12


def is_blank_ingredient_slot(img, x, y):
    region = crop_ingredient_icon(img, x, y)
    if region.size == 0:
        return False
    if region.std() > BLANK_SLOT_STD_MAX:
        return False
    b, g, r = region[:, :, 0].mean(), region[:, :, 1].mean(), region[:, :, 2].mean()
    tr, tg, tb = BLANK_SLOT_RGB
    return (abs(r - tr) < BLANK_SLOT_RGB_TOLERANCE and
            abs(g - tg) < BLANK_SLOT_RGB_TOLERANCE and
            abs(b - tb) < BLANK_SLOT_RGB_TOLERANCE)


# Per-dish ingredient-offset overrides for cards that don't fit the
# standard fixed 3-slot spacing (INGREDIENT_DX). Found live 9/27: a
# 2-ingredient or 4-ingredient card's icons are NOT reliably at a subset
# of the -72/0/72 positions -- e.g. cream_of_mushroom's real Cook run
# failed live in production (both ingredients green in-game, but read as
# unclassifiable because the code sampled the standard 3-slot positions
# instead of the card's real, narrower spacing), the exact same class of
# bug already seen for cornbread/pastry/miso_soup/blueberry_pie during
# training. Each entry here was measured empirically (sliding-window
# search for the card's own trained ingredient icons) -- there is NO
# single formula that covers every case (cornbread's offsets are
# asymmetric while most others are roughly symmetric ~+/-35), so this is
# a per-dish table, not a general rule. Keyed by dish name; falls back to
# INGREDIENT_DX when a dish isn't listed.
INGREDIENT_DX_OVERRIDES = {
    "cornbread": [-38, 34],                       # pass 64: measured on 4 saved Bread Oven panels (was [-36, 72], which hit empty background)
    "pastry": [-34, 36],
    "miso_soup": [-35, 37],
    "blueberry_pie": [-36, 36],
    "cream_of_mushroom": [-35, 35],
    # 4-ingredient card, measured 9/28 from a live Breakfast Stove panel
    # (egg/mushroom/tomato found by sliding-window at -105/-35/+107, bacon
    # by elimination at +35 -- colors at all four spots matched the panel).
    "full_english": [-105, -35, 35, 107],
    # 2-ingredient card (wheat + egg), measured 9/28 -- was silently being
    # read at the default -72/0/72 positions before this.
    "pancakes": [-35, 34],
    # 4-ingredient card (cabbage/fish/egg/tomato), measured 9/28 from a live
    # Salad Station panel.
    "salad_nicoise": [-106, -34, 35, 106],
    # Barista Coffee 2-ingredient cards, measured 9/28 from a live panel
    # (latte: coffee_bean -37 / milk +36; affogato: espresso -34 / ice
    # cream +36 -- both made dishes used as ingredients).
    "coffee_latte": [-37, 36],
    "affogato": [-34, 36],
}


# ---------------------------------------------------------------------------------------------------------------
# pass 75: an unnamed red ingredient teaches itself from the game's own tooltip
# ---------------------------------------------------------------------------------------------------------------
_INGR_LEARN_TRIED = set()


def learn_ingredient_from_tooltip(panel_img, x, y, stop_flag=None):
    """Tap the ingredient icon at (x, y) on an open station panel, read its tooltip, save the icon under its real name.
    Returns ('trained', key) / ('known', key) / None."""
    import popup_ocr
    tap(x, y)
    interruptible_sleep(0.35, stop_flag)
    img = screenshot()
    q_loc, _q = find_question_button(img, retry=1)
    if q_loc is None:
        no_loc, _nc = find_no_button(img)
        if no_loc is not None:
            log("INGREDIENT TOOLTIP: tapping the icon raised a gem-buy dialog -- declining (No).")
            tap(*no_loc)
        return None
    qx, qy = q_loc
    text = (popup_ocr.read_text(img, (max(0, qx - 420), max(0, qy - 60), max(1, qx - 15), qy + 60)) or "").strip()
    hit = parse_tooltip_item(text)
    log(f"INGREDIENT TOOLTIP: '{text}' -> {hit if hit else 'no match in the recipe book'}")
    if not hit:
        return None
    key = hit[0]
    if key in _load_ingredient_library():
        log(f"INGREDIENT TOOLTIP: '{key}' is already in the ingredient library -- not overwriting it.")
        return "known", key
    crop = crop_ingredient_icon(panel_img, x, y)
    if crop is None or crop.size == 0:
        return None
    train_ingredient(crop, key)
    chk = identify_ingredient(_ingredient_search_region(panel_img, x, y))
    if not chk or chk["name"] != key:
        names = [n for n in _load_ingredient_library() if n != key]
        try:
            os.remove(os.path.join(INGREDIENT_LIBRARY_DIR, f"{key}.png"))
        except OSError:
            pass
        with open(INGREDIENT_LIBRARY_FILE, "w") as f:
            json.dump(names, f, indent=2)
        log(f"INGREDIENT TOOLTIP: the new '{key}' template did not recognise its own icon -- removed it again.")
        return None
    log(f"SELF-TRAINED: the tooltip names this ingredient icon '{key}' -- saved it to the ingredient library.")
    return "trained", key


def read_ingredients(panel_img, cx, dish_name=None):
    """Returns a list of ('red'/'green'/None, x, y, name) for each
    ingredient slot under the recipe card centered at cx (3 slots by
    default, or a per-dish override count/spacing -- see
    INGREDIENT_DX_OVERRIDES for cards that aren't the standard 3-slot
    layout). `name` is the identified ingredient (via the trained
    ingredient library) or None if unidentified/untrained -- purely
    informational, does not gate any action."""
    result = []
    dx_list = INGREDIENT_DX_OVERRIDES.get(dish_name, INGREDIENT_DX)
    for dx in dx_list:
        x = cx + dx
        color = _sample_color(panel_img, x, INGREDIENT_TEXT_Y)
        region = _ingredient_search_region(panel_img, x, INGREDIENT_ICON_Y)
        ident = identify_ingredient(region)
        name = ident["name"] if ident else None
        result.append((color, x, INGREDIENT_ICON_Y, name))
    return result


NO_BUTTON_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "dialog_no_button.png"))
NO_BUTTON_MATCH_THRESHOLD = 0.75

WHEAT_INGREDIENT_ICON_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "wheat_ingredient_icon.png"))
WHEAT_ICON_MATCH_THRESHOLD = 0.75

WHEAT_READY_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "wheat_ready.png"))
WHEAT_READY_SCALES = [0.6, 0.75, 0.9, 1.0, 1.15, 1.3]
WHEAT_READY_THRESHOLD = 0.6

PLANT_BAR_HEADER_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "plant_bar_header.png"))
PLANT_BAR_HEADER_REGION = (640, 95, 960, 120)
PLANT_BAR_MATCH_THRESHOLD = 0.75
PLANT_BAR_WHEAT_LOC = (140, 270)  # same fixed overlay position validated in garden_check.py


def find_no_button(img):
    """Template-matches the 'No' button on a gem-buy dialog (e.g. 'Buy
    missing dishes?'). Used to safely decline when an ingredient tap
    triggers a purchase prompt instead of a travel tooltip."""
    res = cv2.matchTemplate(img, NO_BUTTON_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)
    if max_val < NO_BUTTON_MATCH_THRESHOLD:
        return None, max_val
    th, tw = NO_BUTTON_TEMPLATE.shape[:2]
    return (max_loc[0] + tw // 2, max_loc[1] + th // 2), max_val


def is_ingredient_wheat(img, x, y):
    """Checks whether the ingredient icon at (x, y) (an icon-row position
    from read_ingredients) is Wheat, by matching against a small trained
    icon crop -- not guessed from position, since ingredient order isn't
    guaranteed to be identical across every station. Logs the raw match
    score on every near-miss: confirmed live 9/25 that this check can
    false-negative on a genuine Wheat icon (scored just under threshold),
    and with no logged score at all there was no way to tell "confidently
    not Wheat" apart from "Wheat, but a bad match" after the fact."""
    th, tw = WHEAT_INGREDIENT_ICON_TEMPLATE.shape[:2]
    region = img[y - th // 2 - 5:y + th // 2 + 5, x - tw // 2 - 5:x + tw // 2 + 5]
    if region.shape[0] < th or region.shape[1] < tw:
        log(f"is_ingredient_wheat at ({x},{y}): region cropped out of bounds -- can't check.")
        return False
    res = cv2.matchTemplate(region, WHEAT_INGREDIENT_ICON_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    is_wheat = max_val >= WHEAT_ICON_MATCH_THRESHOLD
    if not is_wheat and max_val >= WHEAT_ICON_MATCH_THRESHOLD - 0.15:
        # Close enough to the threshold that it's worth a record -- this
        # is exactly the band a real false negative would land in.
        log(f"is_ingredient_wheat at ({x},{y}): near-miss, scored {max_val:.2f} "
            f"(threshold {WHEAT_ICON_MATCH_THRESHOLD}) -- classified as NOT Wheat.")
    return is_wheat


def find_ready_wheat(img):
    """Mature wheat (tall golden stalks) at the Garden Plot -- same
    whole-screen multi-scale search pattern as every other ready-to-
    collect icon in this project."""
    best_loc, best_val = None, 0.0
    th, tw = WHEAT_READY_TEMPLATE.shape[:2]
    for scale in WHEAT_READY_SCALES:
        w, h = int(tw * scale), int(th * scale)
        if w < 10 or h < 10 or w > img.shape[1] or h > img.shape[0]:
            continue
        resized = cv2.resize(WHEAT_READY_TEMPLATE, (w, h))
        res = cv2.matchTemplate(img, resized, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val > best_val:
            best_val = max_val
            best_loc = (max_loc[0] + w // 2, max_loc[1] + h // 2)
    if best_val >= WHEAT_READY_THRESHOLD:
        return best_loc, best_val
    return None, best_val


def plant_bar_is_open(img):
    x1, y1, x2, y2 = PLANT_BAR_HEADER_REGION
    region = img[y1:y2, x1:x2]
    if region.shape[0] < PLANT_BAR_HEADER_TEMPLATE.shape[0] or \
            region.shape[1] < PLANT_BAR_HEADER_TEMPLATE.shape[1]:
        return False
    res = cv2.matchTemplate(region, PLANT_BAR_HEADER_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    return max_val >= PLANT_BAR_MATCH_THRESHOLD


def recurse_wheat_ingredient(ingredient_loc, stop_flag=None):
    """Chases down a missing Wheat ingredient: taps it for the quick-
    travel tooltip (declining any gem-buy dialog that appears instead,
    same precision issue documented for main()'s ingredient taps),
    harvests any ready wheat at the Garden Plot, and replants if the
    plant-crops bar happens to auto-open afterward (observed sometimes,
    not guaranteed -- this does NOT go hunting for an empty plot to tap,
    same gap noted in garden_check.py).

    Scoped specifically to Wheat for v1: proven manually multiple times
    tonight, and the single biggest shared bottleneck found so far (was
    blocking 4+ different dishes at once). Returns True if real progress
    was made (something harvested and/or replanted), False otherwise."""
    tap(*ingredient_loc)
    interruptible_sleep(0.3, stop_flag)
    img = screenshot()

    q_loc, q_conf = find_question_button(img, retry=1)
    if q_loc is None:
        no_loc, no_conf = find_no_button(img)
        if no_loc is not None:
            log(f"Ingredient tap triggered a gem-buy dialog instead of a travel tooltip "
                f"(confidence {no_conf:.2f}) -- declining, never spending gems.")
            tap(*no_loc)
        else:
            log(f"No quick-travel tooltip or gem dialog found after tapping the Wheat ingredient "
                f"(best '?' match {q_conf:.2f}) -- giving up on this ingredient for now.")
        return False

    tap(*q_loc)
    interruptible_sleep(1, stop_flag)
    img = screenshot()

    harvested = 0
    for _ in range(10):
        check_stop(stop_flag)
        dismiss_second_device_dialog()
        loc, conf = find_ready_wheat(img)
        if loc is None:
            break
        log(f"Ready wheat found at {loc} (confidence {conf:.2f}) -- harvesting.")
        tap(*loc)
        harvested += 1
        interruptible_sleep(1, stop_flag)
        img = screenshot()
    if harvested:
        log(f"Harvested {harvested} ready wheat plant(s).")

    replanted = False
    if plant_bar_is_open(img):
        log("Plant-crops bar is open -- planting Wheat.")
        tap(*PLANT_BAR_WHEAT_LOC)
        interruptible_sleep(1, stop_flag)
        replanted = True

    return harvested > 0 or replanted


# Generalized ingredient recursion -- built 9/27 after proving the
# mechanism manually live (Tomato Soup -> Tomato -> Garden Plot, and
# Croissant -> Butter -> Milk -> Greens, all the way down). Wheat keeps
# its own separate, already-proven `recurse_wheat_ingredient` above
# untouched; these cover the NEXT set of ingredients proven live tonight,
# via the same two underlying mechanisms Wheat already used:
#   - a RAW CROP (harvest a ready plant at the Garden Plot, then replant
#     from whatever's now in stock) -- see garden_check.harvest_ready_crop
#   - a PRODUCED DISH (quick-travel to its own station, locate ITS recipe
#     card by sight, and either cook it if its own ingredients are
#     sufficient, or recurse one level deeper if not)
# Deliberately a small, explicit whitelist rather than "try to handle any
# ingredient" -- an ingredient outside this set still falls through to
# the existing safe "not automated yet" decline in main(), same as every
# ingredient did before tonight.
GENERIC_CROP_INGREDIENTS = {"wheat", "tomato", "cabbage", "carrot", "corn"}     # pass 43: + corn
# pass 44: crops on PAGE 2 of the plant bar (x after a long swipe to the far end); "sugar" is the sugar-cane crop
PAGE2_CROP_COLUMNS = {"mushroom": 85, "onion": 330, "sugar_cane": 605, "garlic": 890, "rice": 1175}
PAGE2_CROP_ALIASES = {"sugar": "sugar_cane"}
GENERIC_CROP_INGREDIENTS |= set(PAGE2_CROP_COLUMNS) | set(PAGE2_CROP_ALIASES)
# 10/23 (owner: "on, and 2 by default") CROP RESERVE for clipboard cooking -- Settings > Clipboard Orders "Crops kept
# for replanting" (0 = off). The 8-h run 10/22 hit "crop at 0 while some are still growing" 76x (rice 50): the bot
# cooked every crop it harvested, so the pool never grew (1 rice plot, 9 of 10 plots empty). Now a dish is not cooked
# when it would leave a raw crop below CROP_RESERVE; that crop is planted instead (each seed comes back as 2).
CROP_RESERVE = 2
GROWING_WAIT = {"name": None, "t": 0.0}   # 11/11: last 'at 0 while growing' (street_truck reads it)


def _crop_reserve_hold(img, ingredients):
    """(crop, have, need, x, y) of a raw crop this cook would take below CROP_RESERVE, or None. Unreadable = no hold."""
    if CROP_RESERVE <= 0:
        return None
    try:
        import event_digits
    except Exception:                                # noqa: BLE001
        return None
    for color, x, y, name in ingredients:
        crop = PAGE2_CROP_ALIASES.get(name, name)
        if color != "green" or crop not in GENERIC_CROP_INGREDIENTS:
            continue
        try:
            c = event_digits.read_count(img, x, INGREDIENT_TEXT_Y, save_unknown=False)
        except Exception:                            # noqa: BLE001
            c = None
        if c and c.get("have") is not None and c.get("need") and c["have"] - c["need"] < CROP_RESERVE:
            return name, c["have"], c["need"], x, y
    return None


def _open_missing():
    """{recipe-book key: units} the open clipboard orders still miss (from the last board read)."""
    import recipe_book as rb
    missing = {}
    for its in LAST_ORDER_PLAN.get("items") or []:
        for it in its:
            if not it.get("name") or it.get("need") is None:
                continue
            gap = it["need"] - (it.get("have") or 0)
            if gap > 0:
                try:
                    k = rb.resolve(it["name"])
                except KeyError:
                    continue
                missing[k] = missing.get(k, 0) + gap
    return missing


# 10/24 JAM TEST (freetime, log-only; idea #1 "stop the bot jamming its own stations"): night 10/23-24 the bot queued a
# 3 h ice cream in FRONT of the Dairy at 03:42 and butter/cheese sat "Waiting..." behind it until morning (croissant
# starved, 06-07 zero coins). Each long cook (>= JAM_LONG_SEC) queued logs whether open orders still need a SHORTER
# item from that same station (a jam guard WOULD queue those first); a later "queue full" there while such a jam is
# in front is logged with how long it has been blocking. Taps nothing, changes nothing.
JAM_LONG_SEC = 1800
_JAM = {"long": 0, "would": 0, "hits": 0, "front": {}}


def _jam_test(name, n):
    try:
        import recipe_book as rb
        items = rb.load()["items"]
        key = rb.resolve(name)
        it = items[key]
        cook = it.get("cook_sec") or 0
        if cook < JAM_LONG_SEC:
            return
        st = it["station"]
        _JAM["long"] += 1
        miss = _open_missing()
        others = {}
        if miss:
            for k, v in rb.cost(miss)["to_make"].items():
                if k != key and v["station"] == st and (v["cook_sec"] or 0) < cook:
                    others[k] = v
        if others:
            _JAM["would"] += 1
            _JAM["front"][st] = (it["name"], time.time(), time.time() + cook)
            what = ", ".join(f"{items[k]['name']} x{v['batches']} ({rb.fmt(v['cook_sec'] or 0)})" for k, v in others.items())
            log(f"[jam test] queued {n}x {it['name']} ({rb.fmt(cook)}) at {st} while open orders still need {what} "
                f"there -- a jam guard WOULD queue those first ({_JAM['would']} of {_JAM['long']} long cooks so far).")
        else:
            log(f"[jam test] queued {n}x {it['name']} ({rb.fmt(cook)}) at {st}; nothing shorter is needed there -- fine "
                f"({_JAM['would']} of {_JAM['long']} long cooks would have been held).")
    except Exception as e:                           # noqa: BLE001 -- a test must never break play
        log(f"[jam test] failed (ignored): {e!r}")


def _jam_hit(station, waiting):
    j = _JAM["front"].get(station)
    if not j or time.time() > j[2]:
        return
    _JAM["hits"] += 1
    log(f"[jam test] {station} full while '{waiting}' waits -- {j[0]} queued at "
        f"{time.strftime('%H:%M', time.localtime(j[1]))} is in front ({int((time.time() - j[1]) // 60)} min so far, "
        f"{_JAM['hits']} blocked visits this run).")


def crop_targets(reserve):
    """10/23: how many of each raw crop the plot round plants up to -- the reserve PLUS what the open clipboard orders
    still need of it (recipe book, through every ingredient). Live 10/23 the round used the reserve alone (2), every
    readable crop was already >= 2, and it planted nothing on empty plots ("harvested 2, planted 0")."""
    import recipe_book as rb
    missing = dict(_open_missing())
    try:                                             # 11/9 (Muse): the truck's corn was never planted -- its trips say
        import job_order as jo                       # "a crop, the Garden Plot grows those" and no plot round planted
        if jo.TRUCK in jo.ORDER:                     # for it. The plot round now also plants what the truck is short.
            for name, q in jo.claim_truck().items():
                k = jo.book_key(name)
                if k:
                    missing[k] = missing.get(k, 0) + q
    except Exception:                                # noqa: BLE001
        pass
    need = {}
    if missing:
        try:
            need = rb.cost(missing)["to_get"]
        except Exception:                            # noqa: BLE001
            need = {}
    out = {}
    for crop in set(PAGE2_CROP_COLUMNS) | {"wheat", "tomato", "cabbage", "carrot", "corn"}:
        n = need.get(crop, 0) + sum(v for a, v in need.items() if PAGE2_CROP_ALIASES.get(a) == crop)
        out[crop] = reserve + n
    return out


def _plant_reserve(hold, dish, stop_flag):
    """Plant the held crop instead of cooking. True = something was planted / harvested."""
    name, have, need, x, y = hold
    log(f"[crop reserve] not cooking '{dish}': it needs {need} {name}, we have {have}, and {CROP_RESERVE} are kept "
        f"for replanting -- planting {name} instead (each seed comes back as 2).")
    try:
        import run_trace
        run_trace.stat("crop reserve", name, 1)
    except Exception:                                # noqa: BLE001
        pass
    try:
        return bool(recurse_ingredient(name, (x, y), stop_flag))
    except StopRequested:
        raise
    except Exception as e:                           # noqa: BLE001
        log(f"[crop reserve] planting {name} failed (ignored): {e!r}")
        return False


# Added 9/28: espresso (Barista Coffee), ice_cream (Dairy), bacon (Pig Pen).
# Each needs a trained dish-library entry WITH a panel illustration under
# the same name so locate_dish_card() can find its card by sight. Their own
# sub-ingredients recurse through this same dispatcher (bacon -> carrot is a
# crop; ice_cream -> whipped_cream/egg/sugar_cane; espresso -> coffee_bean,
# which isn't automated yet and simply stops there).
PRODUCED_DISH_INGREDIENTS = {"butter", "milk", "espresso", "ice_cream", "bacon", "whipped_cream",
                             "seaweed", "fish"}
# Some ingredients are made by a DIFFERENT dish card than their own name.
# Fisherman's Boat (seen 9/28): its first card is a mystery catch (Fishing
# Hook only) that yields EITHER fish or seaweed, while the fish/seaweed
# cards each burn a rarer item (Fish Bait / Seaweed Rake, both crafted at
# the Fisherman's Lighthouse). Per the user: for both fish and seaweed, only
# ever press the mystery card, so the bait and rake are never spent.
PRODUCED_DISH_ALIASES = {"seaweed": "mystery_catch", "fish": "mystery_catch",
                        "chicken": "chicken_drumstick"}                     # pass 43: the ingredient "chicken" is the Chicken Coop drumstick card
PRODUCED_DISH_INGREDIENTS.add("chicken")
# Fishing Hook is crafted at the Fisherman's Lighthouse for 50 COINS (its
# "ingredient" is a coin price, not a stock count).
PRODUCED_DISH_INGREDIENTS.add("fishing_hook")
PRODUCED_DISH_INGREDIENTS.add("egg")          # pass 40: Chicken Coop egg card (panel art trained 9/27)
PRODUCED_DISH_INGREDIENTS.update({"beef", "bread", "cheese", "pastry"})     # pass 58: trained with panel art, were missing from the fetch list
PRODUCED_DISH_INGREDIENTS.add("ham")           # pass 75: Pig Pen pork card trained (panel art cx=620)
COIN_COST_DISHES = {"fishing_hook"}
# How many batches to queue per visit, one per free slot: two mystery catches
# always, and two hooks to replace what they use (user's rule, 9/28).
MULTI_QUEUE_DISHES = {"mystery_catch": 2, "fishing_hook": 2}
_QUEUE_COUNT_THIS_RUN = {}
MAX_INGREDIENT_RECURSION_DEPTH = 2
# Real overproduction bug found live 9/27: process_all_visible() re-checks
# the WHOLE board every iteration, and a dish still waiting on a
# multi-step chain (e.g. Croissant -> Butter -> Milk) gets rediscovered
# and re-walked every single time, since 'recursed_ingredient' is
# deliberately excluded from the skip list so genuinely-blocked items get
# a fresh look. That's correct for the crop-harvest path (harvesting/
# replanting naturally stops mattering once nothing's ready or no plot is
# empty) but WRONG for a produced dish's action button: re-tapping "Make"
# on Milk every ~50s with no memory of "I already queued this" filled 3
# of Cow Shed's 4 queue slots with redundant Milk batches in about 5
# minutes, when the Butter recipe only needed 2 total. Not a gem-safety
# issue (Milk/Greens are coin-cheap and renewable), but a real, confirmed
# resource-waste bug. Fixed with a simple per-process guard: once a
# produced ingredient's action button has been tapped during THIS
# process_all_visible() run, don't tap it again until a genuinely new
# run starts (a fuller fix would read each station's actual queue-slot
# occupancy before acting, but that needs per-station slot-position
# calibration this project doesn't have for every station yet).
_ALREADY_QUEUED_THIS_RUN = set()
# Ingredients whose chase made no progress earlier in the CURRENT
# process_all_visible() pass (e.g. espresso -> coffee_bean, which isn't
# automated) -- skipped for the rest of that pass so the same dead end
# isn't re-walked and a dish's OTHER missing ingredients get tried.
_DEAD_END_INGREDIENTS = set()


def _at_crop_plots(img):
    """pass 80: the screen shows the Garden Plot area (crop plots, a grow-timer card or the plant bar)."""
    try:
        import event_orders
        import garden_check
        return bool(garden_check.is_grow_timer_card(img) or event_orders.bar_is_open(img) or len(event_orders.plot_points(img)) >= 2)
    except Exception:                                  # noqa: BLE001
        return False


def _plants_wanted(deficit):
    """pass 81: each planting returns 2 at harvest -> ceil(deficit / 2), at least 1 (unknown deficit = 1)."""
    try:
        return max(1, (int(deficit) + 1) // 2)
    except (TypeError, ValueError):
        return 1


LAST_CROP_STOCK = {}           # 10/31: the plant-bar stock _work_crop_plots last read {name, n, t}


def _work_crop_plots(ingredient_name, stop_flag=None, want=1, stop_at=None):
    """pass 80: everything that happens once the camera is at the Garden Plot: close a grow card, harvest, sweep the plots,
    plant from stock (declining any gem dialog). Moved unchanged out of recurse_generic_crop_ingredient. True = real progress."""
    import garden_check as gc
    try:                                           # pass 67: the game opens the grow-timer card by itself when the trip lands on a growing plot
        gc._close_grow_card_if_open(screenshot(), stop_flag)
    except StopRequested:
        raise
    except Exception:                              # noqa: BLE001
        pass

    progressed = False
    harvested = gc.harvest_ready_crop(ingredient_name, stop_flag=stop_flag, max_harvests=5)
    if harvested:
        progressed = True
    if not harvested:       # pass 66: the picture harvest found nothing (or the crop has no picture) -> go around the plots: tap each, silence = harvested
        try:
            import event_orders as _eo
            kind, found_any = _eo.sweep_plots(stop_flag)
            log(f"Plot sweep for '{ingredient_name}': {kind}, plots found: {found_any}.")
            if getattr(_eo, "LAST_SWEEP_HARVESTED", 0) > 0:          # pass 68: only real harvests count; an empty plot being found is not progress
                progressed = True
        except StopRequested:
            raise
        except Exception as e:                                     # noqa: BLE001
            log(f"Plot sweep for '{ingredient_name}' failed (ignored): {e}")

    img = screenshot()
    if not plant_bar_is_open(img):
        tap(*SCREEN_CENTER)
        interruptible_sleep(1, stop_flag)
        img = screenshot()
    if not plant_bar_is_open(img):
        # Found live 9/28: the screen-center tap that's supposed to open the
        # plant bar lands on whatever plot is centered -- when that plot is
        # still GROWING, it opens its grow-timer info card ("Tomato, 1m25s,
        # Skip [1 gem]") instead. Returning without closing it left that card
        # (and its gem-cost Skip button) sitting on screen, blocking the
        # game until the user cleared it by hand. Clean up before giving up;
        # a still-growing crop just means "wait", not a failure to hide.
        log(f"Couldn't get the plant-crops bar open for '{ingredient_name}' after quick-travel "
            "(most likely the centered plot is still growing) -- closing any grow-timer card "
            "and stopping here for this run.")
        close_any_open_panel(quiet=True, thorough=True)
        return progressed

    plant_bar_key = PAGE2_CROP_ALIASES.get(ingredient_name, gc.INGREDIENT_TO_PLANT_BAR_KEY.get(ingredient_name, ingredient_name))
    if plant_bar_key in PAGE2_CROP_COLUMNS:                           # pass 44: page-2 crop -> swipe the bar to its far end first
        for _ in range(2):
            check_stop(stop_flag)
            swipe(1400, gc.PLANT_BAR_ROW_Y, 200, gc.PLANT_BAR_ROW_Y, 2000)
            interruptible_sleep(1.5, stop_flag)
        x = PAGE2_CROP_COLUMNS[plant_bar_key]
    elif plant_bar_key in gc.PLANT_BAR_COLUMNS:
        x = gc.PLANT_BAR_COLUMNS[plant_bar_key]
    else:
        log(f"'{ingredient_name}' isn't in the known plant-bar column list -- can't plant it.")
        gc.close_plant_bar(stop_flag=stop_flag)
        return progressed
    try:                                              # pass 68: read the card's stock first -- 0 while some are still growing would only raise the gem question
        import plant_stock
        _stock_now = plant_stock.read_stock(screenshot(), x)
    except Exception:                                 # noqa: BLE001
        _stock_now = None
    LAST_CROP_STOCK.update(name=ingredient_name, n=(0 if _stock_now == "free" else _stock_now), t=time.time())
    if stop_at is not None and isinstance(_stock_now, int) and _stock_now >= stop_at:
        # 10/31 (owner): Prep planted every seed it harvested, so its crop count never reached the list's number
        log(f"'{ingredient_name}': {_stock_now} in stock, {stop_at} wanted -- enough, not planting.")
        gc.close_plant_bar(stop_flag=stop_flag)
        return progressed
    if _stock_now == 0:
        log(f"'{ingredient_name}' is at 0 while some are still growing -- planting more would ask for gems; not tapping, waiting for the harvest.")
        GROWING_WAIT.update(name=ingredient_name, t=time.time())   # 11/11: the truck pauses that dish instead of re-chasing
        gc.close_plant_bar(stop_flag=stop_flag)
        return progressed
    try:                                              # pass 49: debug pictures
        import run_trace
        run_trace.dbg(img, f"plant_{ingredient_name}_before")
    except Exception:                                 # noqa: BLE001
        pass
    tap(x, gc.PLANT_BAR_ROW_Y)
    interruptible_sleep(0.5, stop_flag)
    try:
        run_trace.dbg_after(f"plant_{ingredient_name}_after")
    except Exception:                                 # noqa: BLE001
        pass
    img = screenshot()
    no_loc, no_conf = find_no_button(img)
    if no_loc is not None:
        log(f"'{ingredient_name}' is out of stock with nothing to replant with (gem-buy dialog, "
            f"confidence {no_conf:.2f}) -- declining, never spending gems.")
        tap(*no_loc)
    else:
        log(f"Planted '{ingredient_name}' from current stock.")
        progressed = True
        extra = max(0, min(4, int(want or 1)) - 1)                        # pass 81: the order needs more than one plant
        for _i in range(extra):
            check_stop(stop_flag)
            interruptible_sleep(0.5, stop_flag)
            img = screenshot()
            if not plant_bar_is_open(img):
                break
            try:
                import plant_stock
                left = plant_stock.read_stock(img, x)
            except Exception:                                             # noqa: BLE001
                left = None
            if not isinstance(left, int) or left <= 0:                    # unreadable / none left: never guess (0 would raise the gem question)
                break
            tap(x, gc.PLANT_BAR_ROW_Y)
            interruptible_sleep(0.5, stop_flag)
            no_loc, no_conf = find_no_button(screenshot())
            if no_loc is not None:
                log("An extra planting raised a gem-buy dialog -- declining, never spending gems.")
                tap(*no_loc)
                break
            log(f"Planted another '{ingredient_name}' ({_i + 2} of {extra + 1}).")

    gc.close_plant_bar(stop_flag=stop_flag)
    return progressed


def recurse_generic_crop_ingredient(ingredient_name, ingredient_loc, stop_flag=None):
    """Generalizes recurse_wheat_ingredient's crop-chasing mechanism to
    any crop in GENERIC_CROP_INGREDIENTS. Taps the ingredient for its
    quick-travel tooltip (declining any gem-buy dialog instead, same as
    every other ingredient tap), harvests any ready specimen of that
    exact crop at the Garden Plot, opens the plant-crops bar if it didn't
    auto-open, and replants from whatever's now in stock -- declining the
    'out of X, buy for N gems?' dialog if stock is still 0. Returns True
    if real progress was made (harvested and/or replanted)."""
    import garden_check as gc

    tap(*ingredient_loc)
    interruptible_sleep(0.3, stop_flag)
    img = screenshot()

    q_loc, q_conf = find_question_button(img, retry=1)
    if q_loc is None:
        no_loc, no_conf = find_no_button(img)
        if no_loc is not None:
            log(f"Ingredient tap for '{ingredient_name}' triggered a gem-buy dialog instead of "
                f"a travel tooltip (confidence {no_conf:.2f}) -- declining, never spending gems.")
            tap(*no_loc)
        else:
            log(f"No quick-travel tooltip or gem dialog found after tapping '{ingredient_name}' "
                f"(best '?' match {q_conf:.2f}) -- giving up on this ingredient for now.")
        return False

    tap(*q_loc)
    interruptible_sleep(1, stop_flag)
    check_stop(stop_flag)
    return _work_crop_plots(ingredient_name, stop_flag, want=_plants_wanted(_DEFICIT.get(ingredient_name)))


QUEUE_EMPTY_LABEL_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "queue_empty_label.png"))
QUEUE_SLOT_REGION = (340, 630, 1070, 830)   # widened 10/4 pass 3: slot-1 label sits at x=440 on 3-slot stations  # (x1, y1, x2, y2): the row of queue slots under the cards
QUEUE_EMPTY_MATCH_THRESHOLD = 0.8


def queue_has_free_slot(img):
    """True if at least one queue slot on the open station panel shows the
    white 'EMPTY' label (template-matched, so it works for any station and
    any slot count -- validated 9/28 on 2-slot panels, a partly full Cow
    Shed and an all-busy one). Built so recursion never taps Make/Brew/
    Produce into a full queue; the per-run _ALREADY_QUEUED_THIS_RUN guard
    still separately limits repeat batches within one run."""
    x1, y1, x2, y2 = QUEUE_SLOT_REGION
    res = cv2.matchTemplate(img[y1:y2, x1:x2], QUEUE_EMPTY_LABEL_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    return float(res.max()) >= QUEUE_EMPTY_MATCH_THRESHOLD


CARD_STOCK_DIGIT_TEMPLATES = {
    d: cv2.imread(os.path.join(BASE_DIR, "templates", "card_stock_digits", f"{d}.png"))
    for d in "01"
}
CARD_STOCK_MATCH_THRESHOLD = 0.85
HOOKS_TO_KEEP = 2   # per the user, 9/28: only ever hold 2 hooks in stock (pantry space)


def read_card_stock_low(img, cx):
    """The stock count in the white box under a recipe card centred at cx, or None when it can't be read (callers
    treat None as "2+ = enough", so an unreadable box never makes the bot cook more).
    10/20: now the full number from stock_digits (the game's own digit shapes, 616/640 boxes on saved station
    panels; the rest are covered by a tooltip or have no box). Before, only 0 and 1 were known and everything else
    -- including unreadable -- was "2+": during expresses 10/19 it said "stock is 2+, not cooking more" 8 times.
    The old 0/1 pictures stay as a backup where they exist."""
    try:
        import stock_digits
        n = stock_digits.read_stock(img, cx)
        if n is not None:
            return n
    except Exception:                                  # noqa: BLE001
        pass
    if any(t is None for t in CARD_STOCK_DIGIT_TEMPLATES.values()):
        return None
    region = img[405:465, cx + 111 - 25:cx + 111 + 25]
    best_digit, best = None, 0.0
    for d, t in CARD_STOCK_DIGIT_TEMPLATES.items():
        score = float(cv2.matchTemplate(region, t, cv2.TM_CCOEFF_NORMED).max())
        if score > best:
            best_digit, best = int(d), score
    return best_digit if best >= CARD_STOCK_MATCH_THRESHOLD else None


def _chase_sub_missing(sub_missing, dish_name, cx, depth, stop_flag):
    """pass 79: chase the red sub-ingredients of a card one by one -- but never tap a stale position after a chase left the card.
    Returns (progressed_any, more_to_try)."""
    progressed_any = False
    names = [n for n, _x, _y in sub_missing]
    for i, (name, x, y) in enumerate(sub_missing):
        if name is None or name in _DEAD_END_INGREDIENTS:
            continue
        result = recurse_ingredient(name, (x, y), stop_flag, depth=depth + 1)
        if result:
            progressed_any = True
        else:
            _DEAD_END_INGREDIENTS.add(name)
        if result is None:
            continue                                   # not automated: nothing was tapped, this panel is still showing
        still_here = False
        try:
            img2 = screenshot()
            if panel_is_open(img2):
                cx2, _c2 = find_dish_in_panel(img2, dish_name)
                still_here = bool(cx2) and abs(cx2 - cx) <= 40
        except StopRequested:
            raise
        except Exception:                              # noqa: BLE001
            still_here = False
        if still_here:
            continue
        rest = [n for n in names[i + 1:] if n and n not in _DEAD_END_INGREDIENTS
                and (n in GENERIC_CROP_INGREDIENTS or n in PRODUCED_DISH_INGREDIENTS or n in BUSH_INGREDIENTS)]
        if rest:
            log(f"The chase for '{name}' left this card -- its old screen positions are stale, so {rest} are NOT tapped now; "
                "the order is re-examined next and they get their turn.")
            return progressed_any, True
        break
    return progressed_any, False


# 10/24 (skip pointless trips, owner YES 10/21): night 10/23-24 the Dairy's 3 slots were ice cream (3 h, in front)
# + butter + cheese "Waiting..." and the bot travelled there ~60x in 3 h for butter, finding it full every time.
# A station seen full is not travelled to for a produced ingredient for FULL_STATION_HOLD_SEC.
FULL_STATION_HOLD_SEC = 600
_FULL_STATIONS = {}


def _station_of(name):
    try:
        import recipe_book as rb
        return rb.load()["items"][rb.resolve(name)]["station"]
    except Exception:                                  # noqa: BLE001
        return None


def recurse_produced_ingredient(ingredient_name, ingredient_loc, stop_flag=None, depth=0):
    """Generalizes the 'go make the sub-ingredient' mechanism proven
    manually for Butter->Milk tonight. Quick-travels to the missing
    ingredient's own station, locates ITS recipe card by sight (the same
    dish-library/panel-illustration system every trained dish already
    uses -- an ingredient name like 'butter' or 'milk' IS a trained dish
    name), and either cooks it if its own ingredients are sufficient, or
    recurses ONE level deeper (up to MAX_INGREDIENT_RECURSION_DEPTH) if
    it's ALSO missing something -- e.g. Butter missing Milk missing
    Greens. Returns True if real progress was made (something cooked or
    a deeper recursion made progress)."""
    st = _station_of(ingredient_name)
    if st and _FULL_STATIONS.get(st, 0) > time.time():                # 10/24: skip the pointless trip
        log(f"[full station] not travelling for '{ingredient_name}': every {st} slot was busy "
            f"{int((time.time() - _FULL_STATIONS[st] + FULL_STATION_HOLD_SEC) // 60)} min ago -- looking again after "
            f"{time.strftime('%H:%M', time.localtime(_FULL_STATIONS[st]))}.")
        return False
    tap(*ingredient_loc)
    interruptible_sleep(0.3, stop_flag)
    img = screenshot()

    q_loc, q_conf = find_question_button(img, retry=1)
    if q_loc is None:
        no_loc, no_conf = find_no_button(img)
        if no_loc is not None:
            log(f"Ingredient tap for '{ingredient_name}' triggered a gem-buy dialog instead of "
                f"a travel tooltip (confidence {no_conf:.2f}) -- declining, never spending gems.")
            tap(*no_loc)
        else:
            log(f"No quick-travel tooltip or gem dialog found after tapping '{ingredient_name}' "
                f"(best '?' match {q_conf:.2f}) -- giving up on this ingredient for now.")
        return False

    tap(*q_loc)
    interruptible_sleep(1, stop_flag)
    check_stop(stop_flag)

    img = screenshot()
    opened = panel_is_open(img)
    if not opened:
        for _ in range(3):
            interruptible_sleep(0.7, stop_flag)
            img = screenshot()
            if panel_is_open(img):
                opened = True
                break
    if not opened:
        # up to 4 centre taps: each one collects a finished item sitting on the
        # station before the panel itself opens (the Fisherman's Lighthouse had
        # 2 hooks waiting on 9/28, so it took 3 taps)
        log(f"COLLECTION BLOCKER active at the '{ingredient_name}' station: panel did not open -- tapping the centre to collect, up to 4 tries.")
        for _try in range(4):
            log(f"COLLECTION BLOCKER: centre tap, try {_try + 1} of 4")
            tap(*SCREEN_CENTER)
            interruptible_sleep(1.3, stop_flag)
            img = screenshot()
            if panel_is_open(img):
                opened = True
                break
        if not opened:
            log("COLLECTION BLOCKER still active after 4 tries.")
    if not opened:
        log(f"'{ingredient_name}''s station panel never auto-opened after quick-travel -- "
            "giving up on this ingredient for now.")
        return False

    dish_name = PRODUCED_DISH_ALIASES.get(ingredient_name, ingredient_name)
    if dish_name != ingredient_name:
        log(f"'{ingredient_name}' is made by the '{dish_name}' card (alias) -- using that one only.")
    if dish_name == "mystery_catch":
        # pick up any finished fish/seaweed floating on the boat first (see
        # collect_boat_ready_items), then bring the panel back
        tap(*CLOSE_X_LOC)
        interruptible_sleep(1.5, stop_flag)
        collected = collect_boat_ready_items(stop_flag)
        log(f"Collected {collected} finished catch(es) from the boat.")
        if not reopen_boat_panel(stop_flag):
            log("Couldn't reopen the Fisherman's Boat panel after collecting -- stopping here.")
            return collected > 0
    cx, conf = locate_dish_card(dish_name, stop_flag)
    if cx is None:
        log(f"Could not locate '{dish_name}''s own recipe card by sight (best {conf:.2f}) "
            "-- closing without guessing.")
        tap(*CLOSE_X_LOC)
        return False

    img = screenshot()
    _prep_hook("seen_card", dish_name, img, cx)                     # 11/13: Prep re-checks its stock on every visit
    if dish_name in COIN_COST_DISHES:
        # the "ingredient" is a coin price (white number on a coin bag), not a
        # red/green stock count -- coins are fine to spend, nothing to chase
        sub_ingredients = []
        log(f"'{ingredient_name}' costs coins, not an ingredient -- no stock check needed.")
    else:
        sub_ingredients = read_ingredients(img, cx, dish_name=dish_name)
        log(f"'{ingredient_name}' (a sub-ingredient) ingredients at x={cx}: {sub_ingredients}")
        try:                                          # pass 49
            import run_trace
            run_trace.arrived(img, dish_name, f"ingredient {ingredient_name}")
            run_trace.log_counts(dish_name, img, sub_ingredients)
        except Exception:                             # noqa: BLE001
            pass
    unreadable = [(x, y) for color, x, y, name in sub_ingredients
                  if color is None and not is_blank_ingredient_slot(img, x, y)]
    if unreadable:
        log(f"'{ingredient_name}' ingredient slot(s) at {unreadable} unreadable -- the read "
            "position is probably wrong. Closing without acting.")
        tap(*CLOSE_X_LOC)
        return False

    has_red = any(color == "red" for color, x, y, name in sub_ingredients)
    if has_red:
        sub_missing = [(name, x, y) for color, x, y, name in sub_ingredients if color == "red"]
        if depth >= MAX_INGREDIENT_RECURSION_DEPTH:
            log(f"'{ingredient_name}' is itself missing {sub_missing}, but max recursion depth "
                f"({MAX_INGREDIENT_RECURSION_DEPTH}) reached -- stopping here.")
            tap(*CLOSE_X_LOC)
            return False
        log(f"'{ingredient_name}' is itself missing {sub_missing} -- recursing one level deeper.")
        progressed_any, more_to_try = _chase_sub_missing(sub_missing, dish_name, cx, depth, stop_flag)      # pass 79
        close_panel_if_open()
        return progressed_any or more_to_try

    limit = MULTI_QUEUE_DISHES.get(dish_name, 1)
    if dish_name == "fishing_hook":
        # only top up to HOOKS_TO_KEEP in stock -- pantry space is limited
        stock = read_card_stock_low(img, cx)
        limit = (HOOKS_TO_KEEP - stock) if stock is not None else 0
        if limit <= 0:
            log(f"Fishing Hook stock is already {HOOKS_TO_KEEP}+ -- not crafting more "
                "(keeping pantry space free).")
            tap(*CLOSE_X_LOC)
            return False
        log(f"Fishing Hook stock is {stock} -- crafting {limit} to reach {HOOKS_TO_KEEP}.")
    elif dish_name not in MULTI_QUEUE_DISHES:
        up = _prep_hook("topup", dish_name, _DEFICIT.get(ingredient_name))   # 11/13: also cover the Prep list
        if up:
            limit = max(limit, up)
    already = _QUEUE_COUNT_THIS_RUN.get(dish_name, 0)
    if already >= limit:
        log(f"'{ingredient_name}' ingredients are sufficient, but this pass already queued "
            f"{already} batch(es) of '{dish_name}' (limit {limit}) -- waiting for a fresh run.")
        _topup_hooks_if_boat(dish_name, cx, stop_flag, depth)                    # pass 89
        close_panel_if_open()
        return False

    if dish_name not in MULTI_QUEUE_DISHES and covered_by_cooking(dish_name, _DEFICIT.get(ingredient_name)):    # pass 55
        log(f"ALREADY COOKING: {in_progress(dish_name)} batch(es) of '{dish_name}' were queued earlier and are still cooking "
            f"(short by {_DEFICIT.get(ingredient_name) or '?'}) -- not queuing another.")
        tap(*CLOSE_X_LOC)
        return False
    if not queue_has_free_slot(img):
        log(f"'{ingredient_name}' ingredients are sufficient, but no free (EMPTY) queue slot is "
            "showing on its station -- every slot is already busy, so not tapping. Its batches "
            "will finish on their own; a later run will pick it up.")
        if st:
            _FULL_STATIONS[st] = time.time() + FULL_STATION_HOLD_SEC
            _jam_hit(st, ingredient_name)
        _topup_hooks_if_boat(dish_name, cx, stop_flag, depth)                    # pass 89
        close_panel_if_open()
        return False

    if _truck_chain_hold(img, sub_ingredients, dish_name):       # 11/9 O.R.D.E.R.: the truck's chain first
        close_panel_if_open()
        return False
    hold = _crop_reserve_hold(img, sub_ingredients)             # 10/23: keep seeds to replant
    if hold:
        planted = _plant_reserve(hold, dish_name, stop_flag)
        close_panel_if_open()
        return planted
    # Queue up to `limit` batches this visit, one per free slot, re-checking the
    # panel between taps (a slot may fill up, or the ingredient -- e.g. the
    # Fishing Hook for a mystery catch -- may run out after the first batch).
    why = long_cook_blocked(ingredient_name)
    if why:
        log(f"[long cooks] {why}")
        close_panel_if_open()
        return False
    action_loc = (cx, ACTION_BUTTON_Y)
    queued_now = 0
    while already + queued_now < limit:
        log(f"'{ingredient_name}' ingredients all sufficient -- tapping its action button at "
            f"{action_loc} (batch {already + queued_now + 1} of up to {limit}).")
        try:                                          # pass 49: debug pictures
            import run_trace
            run_trace.dbg(img, f"make_{ingredient_name}_before")
        except Exception:                             # noqa: BLE001
            pass
        if not _action_card_is_expected(img, dish_name, cx):                      # pass 88
            log(f"REFUSING to tap at {action_loc}: the card there is not clearly '{dish_name}' "
                "(the rake / bait cards next to it burn a Helping Hand) -- closing without crafting.")
            close_panel_if_open()
            return queued_now > 0
        tap(*action_loc)
        interruptible_sleep(1.2, stop_flag)
        try:
            run_trace.dbg_after(f"make_{ingredient_name}_after")
        except Exception:                             # noqa: BLE001
            pass
        queued_now += 1
        if already + queued_now >= limit:
            break
        img = screenshot()
        if not queue_has_free_slot(img):
            break
        if dish_name not in COIN_COST_DISHES:
            recheck = read_ingredients(img, cx, dish_name=dish_name)
            if any(color == "red" for color, _x, _y, _n in recheck):
                log(f"'{dish_name}' ran out of an ingredient after {queued_now} batch(es) -- "
                    "stopping here.")
                break
    _QUEUE_COUNT_THIS_RUN[dish_name] = already + queued_now
    _ALREADY_QUEUED_THIS_RUN.add(dish_name)
    if queued_now and dish_name not in MULTI_QUEUE_DISHES:
        try:
            note_queued(dish_name, queued_now)                  # pass 55
        except Exception:                             # noqa: BLE001
            pass

    # Each mystery catch burns a Fishing Hook, so after queuing catches, make
    # two more hooks (per the user: "two hooks for every time you harvest fish
    # and seaweed"). The hook icon on this same card is the way to the Lighthouse.
    if dish_name == "mystery_catch" and queued_now:
        log("Queued mystery catch(es) -- now making 2 more Fishing Hooks at the Lighthouse.")
        recurse_produced_ingredient("fishing_hook", (cx, INGREDIENT_ICON_Y), stop_flag, depth=depth + 1)
    close_panel_if_open()
    return True


def _topup_hooks_if_boat(dish_name, cx, stop_flag, depth):
    """pass 89: 'always be fishing' -- at the Fisherman's Boat keep 2 Fishing Hooks in stock even when no catch
    could be queued right now (slots busy / already queued this pass). Hook icon -> '?' -> Lighthouse -> Craft the
    HOOK card only (pass 88 guards the card). Never raises."""
    if dish_name != "mystery_catch":
        return
    try:
        recurse_produced_ingredient("fishing_hook", (cx, INGREDIENT_ICON_Y), stop_flag, depth=depth + 1)
    except StopRequested:
        raise
    except Exception as e:                                    # noqa: BLE001
        log(f"hook top-up failed: {e}")


def close_panel_if_open():
    """Taps the panel's close-X ONLY if a panel is actually showing.
    Found live 9/28: after a quick-travel moved the camera away (e.g. to
    the Coffee Bush grove), the old unconditional `tap(*CLOSE_X_LOC)` hit
    the bare map at that spot and opened the 'Expand your Land' panel (which
    carries a 110-gem button). No gems were touched, but a blind tap
    there is a real hazard."""
    if panel_is_open(screenshot()):
        tap(*CLOSE_X_LOC)


# Fisherman's Boat finished catches (found live 9/28, user watching): a finished
# batch shows up as a fish / seaweed icon floating on the boat's cabin roof. After
# a quick-travel the boat's panel opens by itself WITHOUT touching those icons
# (the old "tap screen centre" only hits the water there), so finished catches
# just sat on the roof and were never collected. Each icon needs its own tap
# (fish first, then the seaweed it was covering). The panel hides the map, so
# we close it, tap the icons, then reopen the panel by tapping the boat deck.
BOAT_ITEM_TEMPLATES = [
    cv2.imread(os.path.join(BASE_DIR, "templates", "boat_fish_ready.png")),
    cv2.imread(os.path.join(BASE_DIR, "templates", "boat_seaweed_ready.png")),
]
BOAT_ITEM_THRESHOLD = 0.75
BOAT_DECK_TAPS = [(720, 585), (700, 560), (765, 605)]


def find_boat_ready_items(img):
    """[(confidence, x, y)] of floating finished-catch icons, best first."""
    found = []
    for t in BOAT_ITEM_TEMPLATES:
        res = cv2.matchTemplate(img, t, cv2.TM_CCOEFF_NORMED)
        _, mv, _, ml = cv2.minMaxLoc(res)
        if mv >= BOAT_ITEM_THRESHOLD:
            found.append((float(mv), ml[0] + t.shape[1] // 2, ml[1] + t.shape[0] // 2))
    return sorted(found, reverse=True)


def collect_boat_ready_items(stop_flag=None, max_taps=6):
    """Taps floating finished-catch icons on the boat until none are left.
    Re-detects after every tap (one may have been hiding another) and waits
    long enough for the fly-away animation to finish. Returns how many taps."""
    taps = 0
    for _ in range(max_taps):
        items = find_boat_ready_items(screenshot())
        if not items:
            break
        conf, x, y = items[0]
        log(f"Finished catch icon on the boat at ({x},{y}) (confidence {conf:.2f}) -- collecting.")
        tap(x, y)
        interruptible_sleep(2.0, stop_flag)
        taps += 1
    return taps


NEVER_CRAFT_DISHES = {"seaweed_rake", "fish_bait"}      # pass 88: they burn a Helping Hand glove -- never craft them
FISHING_GUARDED_DISHES = {"fishing_hook", "mystery_catch"}


def _action_card_is_expected(img, dish_name, cx):
    """pass 88: a fresh look right before an action-button tap -- on the fishing stations the card under the tap
    must really be the dish we mean (hook / mystery catch), because the neighbouring cards craft a rake / bait."""
    if dish_name in NEVER_CRAFT_DISHES:
        return False
    if dish_name not in FISHING_GUARDED_DISHES:
        return True
    fcx, _conf = find_dish_in_panel(img, dish_name)
    return fcx is not None and abs(fcx - cx) <= 30


def _is_boat_panel(img):
    fcx, _conf = find_dish_in_panel(img, "mystery_catch")
    return fcx is not None


def reopen_boat_panel(stop_flag=None):
    """Taps the boat's deck until its station panel is showing again.
    pass 88: LOOKS FIRST. A panel that is already open must never be tapped through -- the deck spot (720,585)
    is the Seaweed Rake's Craft button on the Lighthouse panel and the Fish Catch button on the Boat panel."""
    for loc in BOAT_DECK_TAPS:
        for _try in range(3):
            img = screenshot()
            if not panel_is_open(img):
                break
            if _is_boat_panel(img):
                return True
            log("reopen_boat_panel: another station panel is open -- closing it, not tapping the deck through it.")
            tap(*CLOSE_X_LOC)
            interruptible_sleep(1.2, stop_flag)
        else:
            log("reopen_boat_panel: a panel will not close -- not tapping the deck.")
            return False
        tap(*loc)
        interruptible_sleep(1.6, stop_flag)
        img = screenshot()
        if panel_is_open(img):
            if _is_boat_panel(img):
                return True
            tap(*CLOSE_X_LOC)                                  # something else opened: close it, try the next spot
            interruptible_sleep(1.2, stop_flag)
    return False


# Bush-type ingredients: harvested by tapping ripe fruit clusters on the
# bushes the quick-travel lands next to (no plant bar, no replanting).
# Coffee Bush trained by hand 9/28: tapping the coffee_bean ingredient's
# red icon shows "Get Coffee Bean by planting Coffee Bush" + a "?"; the "?"
# jumps the camera straight to the fruit grove. Each tap on a ripe red
# cluster harvests one; a bush shows up to 3 clusters. The camera may
# center on an already-picked bush while another nearby still has fruit,
# so we look for ripe clusters anywhere on screen instead of tapping center.
BUSH_INGREDIENTS = {"coffee_bean", "apple", "lemon"}                          # pass 45: + apple tree; pass 48: + lemon tree
COFFEE_CLUSTER_TEMPLATES = [
    cv2.imread(os.path.join(BASE_DIR, "templates", f"coffee_bean_cluster_{k}.png"))
    for k in ("top", "left", "right")
]
COFFEE_CLUSTER_THRESHOLD = 0.75   # false positives on non-grove screens topped out at 0.71
COFFEE_SEARCH_REGION = (0, 90, 1400, 900)   # x1,y1,x2,y2 -- skips the top HUD and right-side event badges


def find_ripe_coffee_clusters(img):
    """Returns [(confidence, x, y)] for ripe coffee-bean clusters, best
    first, de-duplicated. Uses three cluster templates (top/left/right of
    a full bush) since clusters differ in shape by position."""
    x1, y1, x2, y2 = COFFEE_SEARCH_REGION
    region = img[y1:y2, x1:x2]
    pts = []
    for t in COFFEE_CLUSTER_TEMPLATES:
        res = cv2.matchTemplate(region, t, cv2.TM_CCOEFF_NORMED)
        while True:
            _, mv, _, ml = cv2.minMaxLoc(res)
            if mv < COFFEE_CLUSTER_THRESHOLD:
                break
            pts.append((float(mv), ml[0] + t.shape[1] // 2 + x1, ml[1] + t.shape[0] // 2 + y1))
            res[max(0, ml[1] - 35):ml[1] + 35, max(0, ml[0] - 40):ml[0] + 40] = -1
    out = []
    for p in sorted(pts, reverse=True):
        if all(abs(p[1] - q[1]) > 45 or abs(p[2] - q[2]) > 45 for q in out):
            out.append(p)
    return out


APPLE_MIN_AREA = 450                                  # pass 45: a ripe apple is ~700-790 px at the owner's zoom; berries/strawberries < 100
APPLE_MAX_AREA = 3200                                 # 10/20: at a closer zoom ripe apples are ~1800-2200 px (bush_misses 10/19)
APPLE_TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")
APPLE_MATCH_MIN = 0.65
_apple_templates = None


def _apple_shape_score(img, x, y):
    global _apple_templates
    if _apple_templates is None:
        _apple_templates = [t for t in (cv2.imread(os.path.join(APPLE_TEMPLATE_DIR, f"apple_ripe_{i}.png")) for i in range(4)) if t is not None]
    reg = img[max(0, y - 80):y + 80, max(0, x - 90):x + 90]
    best = 0.0
    for t in _apple_templates:
        for s in (0.8, 0.9, 1.0, 1.1, 1.25, 1.45, 1.7):                 # 10/20: + closer zooms
            tt = cv2.resize(t, None, fx=s, fy=s)
            if reg.shape[0] >= tt.shape[0] and reg.shape[1] >= tt.shape[1]:
                best = max(best, float(cv2.matchTemplate(reg, tt, cv2.TM_CCOEFF_NORMED).max()))
    return best


def find_ripe_apples(img):
    """[(area, x, y)] of ripe (bright red, apple-sized) blobs, biggest first. Excludes the top HUD, the right-hand
    event badges, the bottom-right nav bar and the bottom-left build brush (all red / busy)."""
    if img is None or img.shape[:2] != (900, 1600):
        return []
    b, g, r = [img[:, :, i].astype(np.int16) for i in range(3)]
    m = ((r > 215) & (g < 100) & (b < 100)).astype(np.uint8)
    m[:90, :] = 0
    m[:, 1400:] = 0
    m[760:, 980:] = 0
    m[740:, :300] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    n, _lab, st, cen = cv2.connectedComponentsWithStats(m, 8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if (APPLE_MIN_AREA <= a <= APPLE_MAX_AREA and 28 <= w <= 100 and 20 <= h <= 70
                and _apple_shape_score(img, int(cen[i][0]), int(cen[i][1])) >= APPLE_MATCH_MIN):
            out.append((int(a), int(cen[i][0]), int(cen[i][1])))
    return sorted(out, reverse=True)


LEMON_MIN_AREA = 700                                  # pass 48: a ripe lemon is ~900-1300 px at the owner's zoom
LEMON_MAX_AREA = 1700
LEMON_MATCH_MIN = 0.8                                    # real lemons score >= 0.93; a yellow pig-pen wall scored 0.67
_lemon_templates = None


def _lemon_shape_score(img, x, y):
    global _lemon_templates
    if _lemon_templates is None:
        _lemon_templates = [t for t in (cv2.imread(os.path.join(APPLE_TEMPLATE_DIR, f"lemon_ripe_{i}.png")) for i in range(4)) if t is not None]
    reg = img[max(0, y - 65):y + 65, max(0, x - 60):x + 60]
    best = 0.0
    for t in _lemon_templates:
        for s in (0.8, 0.9, 1.0, 1.1, 1.25):
            tt = cv2.resize(t, None, fx=s, fy=s)
            if reg.shape[0] >= tt.shape[0] and reg.shape[1] >= tt.shape[1]:
                best = max(best, float(cv2.matchTemplate(reg, tt, cv2.TM_CCOEFF_NORMED).max()))
    return best


def find_ripe_lemons(img):
    """[(area, x, y)] of ripe lemons (saturated yellow, lemon-shaped), biggest first."""
    if img is None or img.shape[:2] != (900, 1600):
        return []
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = ((hsv[:, :, 0] >= 22) & (hsv[:, :, 0] <= 36) & (hsv[:, :, 1] >= 110) & (hsv[:, :, 2] >= 225)).astype(np.uint8)
    m[:90, :] = 0
    m[:, 1400:] = 0
    m[760:, 980:] = 0
    m[740:, :300] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    n, _lab, st, cen = cv2.connectedComponentsWithStats(m, 8)
    out = []
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if (LEMON_MIN_AREA <= a <= LEMON_MAX_AREA and 26 <= w <= 44 and 38 <= h <= 56
                and _lemon_shape_score(img, int(cen[i][0]), int(cen[i][1])) >= LEMON_MATCH_MIN):
            out.append((int(a), int(cen[i][0]), int(cen[i][1])))
    return sorted(out, reverse=True)


COFFEE_COLOUR_MIN_AREA = 150                          # pass 53: scale-free coffee-cluster finder (cluster ~1100-1750 px zoomed in, ~220-300 px zoomed out)


def find_ripe_coffee_by_colour(img):
    """[(area/1000, x, y)] of ripe coffee-bean clusters found by colour (works at any camera zoom), biggest first."""
    if img is None or img.shape[:2] != (900, 1600):
        return []
    b, g, r = [img[:, :, i].astype(np.int16) for i in range(3)]
    m = ((r >= 120) & (r <= 200) & (g <= 60) & (b <= 80) & (r - g >= 90) & (r - b >= 70)).astype(np.uint8)
    m[:90, :] = 0
    m[:, 1400:] = 0
    m[740:, :300] = 0
    m[760:, 980:] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m, 8)
    out = []
    for i in range(1, n):
        a = int(st[i][4])
        if a < COFFEE_COLOUR_MIN_AREA or a > 4000:
            continue
        mb, mg, mr = img[lab == i].mean(0)
        if 38 <= mb <= 55 and 20 <= mg <= 31 and 145 <= mr <= 165:
            out.append((a / 1000.0, int(cen[i][0]), int(cen[i][1])))
    return sorted(out, reverse=True)


def _find_ripe(ingredient_name, img):
    """The ripe-fruit finder for a bush/tree ingredient: (confidence-like, x, y) best first."""
    if ingredient_name == "apple":
        return [(a / 1000.0, x, y) for a, x, y in find_ripe_apples(img)]
    if ingredient_name == "lemon":                                    # pass 48
        return [(a / 1000.0, x, y) for a, x, y in find_ripe_lemons(img)]
    found = find_ripe_coffee_clusters(img)
    return found if found else find_ripe_coffee_by_colour(img)          # pass 53: colour fallback (works at any zoom)


_bush_miss_last = 0.0


def _save_bush_miss(img, ingredient_name, tag):
    """pass 46: a picture of what the bush chase saw when it found nothing ripe (max one per tag per 20 s)."""
    global _bush_miss_last
    try:
        if tag == "pre" and time.time() - _bush_miss_last < 20:
            return None
        if tag == "pre":
            _bush_miss_last = time.time()
        d = os.path.join(BASE_DIR, "templates", "bush_misses")
        os.makedirs(d, exist_ok=True)
        path = os.path.join(d, f"{int(_bush_miss_last)}_{ingredient_name}_{tag}.png")
        cv2.imwrite(path, img)
        log(f"No-ripe-fruit picture saved: {os.path.relpath(path, BASE_DIR)}")
        return path
    except Exception:                                  # noqa: BLE001
        return None


def _fruit_resting(name):
    """10/25 Picked Tree Problem: True (and one log line) while `name` rests after a picked / empty trip."""
    try:
        import picked_trees
        left = picked_trees.resting(name)
    except Exception:                                  # noqa: BLE001
        return False
    if left:
        log(f"[picked trees] not travelling for '{name}': its trees were picked on the last trip -- looking again in "
            f"{left // 60 + 1} min.")
        _DEAD_END_INGREDIENTS.add(name)
    return bool(left)


def recurse_bush_ingredient(ingredient_name, ingredient_loc, stop_flag=None, max_harvests=3):
    """Quick-travels to a bush ingredient's grove (see BUSH_INGREDIENTS) and
    taps ripe fruit clusters, up to max_harvests. Returns True if at least
    one harvest was made. The "?" is tapped right after the ingredient tap
    (the tooltip auto-dismisses in ~4s -- a late tap silently does nothing)."""
    if _fruit_resting(ingredient_name):
        return False
    tap(*ingredient_loc)
    interruptible_sleep(0.3, stop_flag)
    img = screenshot()
    q_loc, q_conf = find_question_button(img, retry=1)
    if q_loc is None:
        no_loc, no_conf = find_no_button(img)
        if no_loc is not None:
            log(f"Ingredient tap for '{ingredient_name}' triggered a gem-buy dialog instead of "
                f"a travel tooltip (confidence {no_conf:.2f}) -- declining, never spending gems.")
            tap(*no_loc)
        else:
            log(f"No quick-travel tooltip found after tapping '{ingredient_name}' "
                f"(best '?' match {q_conf:.2f}) -- giving up on this ingredient for now.")
        return False
    tap(*q_loc)
    interruptible_sleep(1.5, stop_flag)
    check_stop(stop_flag)
    return harvest_fruit_here(ingredient_name, stop_flag, max_harvests)


# 10/22 (owner): 8-h run lost 7 h to ONE picked coffee bush -- "Ripe 'coffee_bean' cluster at (300,624)" tapped 527
# times, stock stayed 1/2, every trip counted as progress. A harvest only counts if it is real: the same spot found
# again after its tap in the same run = no harvest; a "progress" chase after which the card's stock did not rise
# (run_trace CHECK) = the spots it tapped are fake. Fake spots are ignored for FAKE_SPOT_SEC and the ingredient is a
# dead end for the rest of the pass, so the bot moves on to other orders.
FAKE_SPOT_SEC = 3600
FAKE_SPOT_PX = 30
_FAKE_BUSH_SPOTS = {}                                # ingredient -> [(x, y, until)]
_LAST_HARVEST_SPOTS = {}                             # ingredient -> [(x, y)] tapped by the last harvest_fruit_here


def _is_fake_spot(name, x, y):
    now = time.time()
    spots = [s for s in _FAKE_BUSH_SPOTS.get(name, []) if s[2] > now]
    _FAKE_BUSH_SPOTS[name] = spots
    return any(abs(x - sx) <= FAKE_SPOT_PX and abs(y - sy) <= FAKE_SPOT_PX for sx, sy, _u in spots)


def _mark_fake_spots(name, spots, why):
    for x, y in spots:
        if not _is_fake_spot(name, x, y):
            _FAKE_BUSH_SPOTS.setdefault(name, []).append((x, y, time.time() + FAKE_SPOT_SEC))
    if spots:
        log(f"[harvest check] '{name}' at {spots}: {why} -- not a harvest; ignoring that spot for "
            f"{FAKE_SPOT_SEC // 60} min.")


def harvest_no_rise(name):
    """Called by run_trace when a chase reported progress but the card's stock did not rise."""
    if name not in BUSH_INGREDIENTS:
        return
    _mark_fake_spots(name, _LAST_HARVEST_SPOTS.pop(name, []), "the stock did not rise after harvesting")
    _DEAD_END_INGREDIENTS.add(name)
    log(f"[harvest check] '{name}' counts as no progress -- skipping it for the rest of this pass.")


def _find_real_ripe(name, img):
    return [c for c in (_find_ripe(name, img) or []) if not _is_fake_spot(name, c[1], c[2])]


# 10/25: OFF -- owner: groves are organized now, fruit should be in view; "idk that i want the bot to start moving
# around to find them". The drags stay here (put them back in APPLE_PANS to switch the search on again).
APPLE_PANS_SEARCH = (((800, 300, 800, 650), "above (map dragged down 350 px)"),
                     ((500, 400, 900, 400), "up-left (map dragged right 400 px)"))
APPLE_PANS = ()


def apple_tree_census(img):
    """10/25 (owner: "harvested trees are a darker green, trees that are sprouting flowers are about to fruit"):
    (ripe, blossoming, harvested) apple-tree counts in view. Harvested canopy = olive (hue 24-37, dim), growing canopy =
    bright green (hue 42-70); a green tree with >= 800 pink-white flower pixels and no ripe apple = blossoming (trees
    with apples have white highlights too). Canopies < 15000 px are ignored (a small white-flowered tree on the right
    of the grove is in every picture). Checked on the 10/19-21 bush_misses: 3 harvested + 0-1 blossoming per miss."""
    try:
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        h, sat, v = (hsv[..., i].astype(np.int16) for i in range(3))
        b, r = img[..., 0].astype(np.int16), img[..., 2].astype(np.int16)

        def blobs(m):
            m = m.astype(np.uint8)
            m[:90] = 0
            m[:, 1400:] = 0
            m[760:, 980:] = 0
            m[740:, :300] = 0
            m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
            m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
            n, _lab, st, _cen = cv2.connectedComponentsWithStats(m, 8)
            return [st[i] for i in range(1, n) if st[i][4] >= 15000]
        harvested = len(blobs((h >= 24) & (h <= 37) & (sat >= 100) & (v >= 55) & (v <= 115)))
        flower = ((v >= 200) & (sat <= 90) & (r - b >= 12)).astype(np.uint8)
        apples = find_ripe_apples(img)
        ripe = bloom = 0
        for bx, by, bw, bh, _a in blobs((h >= 42) & (h <= 70) & (sat >= 120) & (v >= 95)):
            if any(bx <= x <= bx + bw and by <= y <= by + bh for _a2, x, y in apples):
                ripe += 1
            elif int(flower[by:by + bh, bx:bx + bw].sum()) >= 800:
                bloom += 1
        return ripe, bloom, harvested
    except Exception:                                  # noqa: BLE001 -- log-only helper
        return None


def _log_census(img, where):
    c = apple_tree_census(img)
    if c:
        log(f"[apples] trees {where}: {c[0]} with ripe apples, {c[1]} blossoming (fruit soon), {c[2]} harvested "
            f"(dark green).")


def harvest_fruit_here(ingredient_name, stop_flag=None, max_harvests=3):
    """10/20: the picking part of recurse_bush_ingredient (the camera is already at the trees) -- also used by
    Prep work when apples are on its list. True = at least one harvest."""
    try:
        import find_and_center as _fac
        if _fac.pantry_full_recent():                          # 10/25: picking only brings the popup back
            log(f"[pantry full] not picking {ingredient_name} -- the Pantry is full.")
            return False
    except Exception:                                          # noqa: BLE001
        pass
    harvested = 0
    picked_menu = 0                                  # 10/25: picked-tree menus met (Ask for Help tapped / spent)
    tapped = []                                      # 10/22: spots tapped this run (a real harvest makes its cluster go away)
    for attempt in range(max_harvests + 2):
        img = screenshot()
        clusters = _find_real_ripe(ingredient_name, img)
        again = [c for c in clusters if any(abs(c[1] - tx) <= FAKE_SPOT_PX and abs(c[2] - ty) <= FAKE_SPOT_PX
                                            for tx, ty in tapped)]
        if again:
            for _c, x0, y0 in again:
                _mark_fake_spots(ingredient_name, [(x0, y0)], "still looks ripe after it was tapped")
                hit = [t for t in tapped if abs(x0 - t[0]) <= FAKE_SPOT_PX and abs(y0 - t[1]) <= FAKE_SPOT_PX]
                for t in hit:
                    tapped.remove(t)
                    harvested = max(0, harvested - 1)
            clusters = _find_real_ripe(ingredient_name, img)
        if attempt == 0 and ingredient_name == "apple":
            _log_census(img, "where it landed")
        if not clusters:
            _save_bush_miss(img, ingredient_name, "pre")
            if attempt == 0:
                # the grove may sit partly off-screen -- one zoom-out for a wider look
                from adb_helper import pinch
                pinch(800, 450, *((100, 300) if ingredient_name in ("apple", "lemon") else (250, 100)))
                interruptible_sleep(1.5, stop_flag)
                img = screenshot()
                clusters = _find_real_ripe(ingredient_name, img)
            if not clusters and attempt == 0 and ingredient_name == "apple":
                # 10/25 (owner 10/20: "look for ripe apples on nearby trees"): 126 of 154 apple trips since 10/19
                # found nothing. Fast travel always parks the camera on the SAME picked tree, the other apple trees
                # sit just above the screen (one ripe apple hidden under the top HUD in the 10/21 misses), and the
                # zoom step leaves the view unchanged. Drag the map so the trees above / to the left come into view
                # (a drag never taps anything) and look again; taps only land on ripe apples the detector confirms.
                for (x1, y1, x2, y2), where in APPLE_PANS:
                    swipe(x1, y1, x2, y2, 600)
                    interruptible_sleep(1.2, stop_flag)
                    img = screenshot()
                    clusters = _find_real_ripe(ingredient_name, img)
                    log(f"[apples] looked {where}: {len(clusters)} ripe apple(s) in view.")
                    _log_census(img, where.split(" (")[0])
                    if clusters:
                        break
            if not clusters:
                _save_bush_miss(img, ingredient_name, "post_zoom")
                log(f"No ripe '{ingredient_name}' clusters visible after travel "
                    f"(harvested {harvested} so far) -- the bushes are probably all picked/growing.")
                break
        conf, x, y = clusters[0]
        log(f"Ripe '{ingredient_name}' cluster at ({x},{y}) (confidence {conf:.2f}) -- harvesting.")
        try:                                          # pass 49: debug pictures
            import run_trace
            run_trace.dbg(img, f"harvest_{ingredient_name}_before")
        except Exception:                             # noqa: BLE001
            pass
        tap(x, y)
        interruptible_sleep(1.2, stop_flag)
        try:
            run_trace.dbg_after(f"harvest_{ingredient_name}_after")
        except Exception:                             # noqa: BLE001
            pass
        try:                                          # 10/25: a picked tree/bush opens its menu instead of harvesting
            import picked_trees
            if picked_trees.handle(screenshot(), f"harvest tap at ({x},{y})", fruit=ingredient_name, tap=tap,
                                   sleep=lambda s: interruptible_sleep(s, stop_flag), screenshot=screenshot,
                                   before=img, tap_xy=(x, y)):
                _mark_fake_spots(ingredient_name, [(x, y)], "that tree is picked (its menu opened)")
                picked_menu += 1
                continue
        except Exception as e:                        # noqa: BLE001
            if type(e).__name__ == "StopRequested":
                raise
            log(f"[picked trees] check failed (ignored): {e!r}")
        harvested += 1
        tapped.append((x, y))
        if harvested >= max_harvests:
            break
    _LAST_HARVEST_SPOTS[ingredient_name] = list(tapped)
    # a tap on a still-growing bush opens its grow-timer card (with a gem Skip)
    # -- clear anything left over, never touching that button
    close_any_open_panel(quiet=True, thorough=True)
    log(f"Harvested {harvested} '{ingredient_name}' cluster(s) this run.")
    if harvested == 0 and not picked_menu:          # 10/25: nothing ripe -- don't come straight back
        try:
            import picked_trees
            picked_trees.rest(ingredient_name, picked_trees.REST_EMPTY_SEC, "no ripe fruit where the bot landed")
        except Exception:                             # noqa: BLE001
            pass
    return harvested > 0


def recurse_ingredient(ingredient_name, ingredient_loc, stop_flag=None, depth=0):
    """Dispatches a missing ingredient to the right recursion strategy, or
    returns None if it's outside the known-automated set (caller should
    fall back to the existing safe 'not automated yet' decline in that
    case -- this function never guesses)."""
    if ingredient_name in BUSH_INGREDIENTS:
        result = recurse_bush_ingredient(ingredient_name, ingredient_loc, stop_flag)
    elif ingredient_name in GENERIC_CROP_INGREDIENTS:
        result = recurse_generic_crop_ingredient(ingredient_name, ingredient_loc, stop_flag)
    elif ingredient_name in PRODUCED_DISH_INGREDIENTS:
        result = recurse_produced_ingredient(ingredient_name, ingredient_loc, stop_flag, depth=depth)
    else:
        return None
    try:                                              # pass 49: remember the chase so the next stock read can check it
        import run_trace
        run_trace.note_chase(ingredient_name, result)
    except Exception:                                 # noqa: BLE001
        pass
    return result


def travel_to_missing_item(item, stop_flag=None):
    """Taps the missing item and, if the quick-travel tooltip appears,
    taps its '?' button. Returns True if travel was triggered, False if
    the tooltip never showed up (timing miss, or a different dialog like
    a gem-buy prompt appeared instead -- either way, doesn't guess)."""
    tap(*item["tap_loc"])
    interruptible_sleep(0.25, stop_flag)
    img = screenshot()
    loc, conf = find_question_button(img, retry=1)
    if loc is None:
        log(f"No quick-travel '?' found after tapping the missing item (best match {conf:.2f}) -- "
            "either the tooltip timing was missed or a different dialog appeared. Not guessing further.")
        return False
    tap(*loc)
    interruptible_sleep(1, stop_flag)
    return True


LONG_SWIPE_ENDPOINTS = ((1400, 200), (200, 200))
LONG_SWIPE_DURATION_MS = 2000
LONG_SWIPE_SETTLE_SEC = 1.5
# Real fix found live 9/26, replacing the whole fast-swipe/retry-loop
# design below (kept only in spirit in this comment; the old machinery --
# scroll_orders_next's 400ms flick, reset_orders_scroll's 8-swipe
# stability-count loop, _confirm_end_of_list's retry-the-swipe safety
# net -- is gone). The old fast swipe had genuinely unpredictable fling
# physics: sometimes advanced one card, sometimes jumped 2.6 card-widths,
# sometimes did nothing at all, which is why this project spent all of
# 9/25-9/26 building layers of retry/stability-check logic around it.
# A single SLOW 2-second drag across the same endpoints has none of that
# -- it tracks the finger the whole distance with no fling, and the
# carousel just settles naturally at its real edge. Confirmed live: 4/4
# trials (two each direction) landed pixel-exact on the true boundary
# every time, whether starting from the true start, the true end, or
# mid-board. The Orders board's entire scrollable range (6 order slots +
# 1 locked placeholder) fits inside ONE such swipe in either direction --
# so reading the whole board is now "read what's visible, one slow swipe,
# read what's visible again," not a scan loop.


def swipe_to_far_end(stop_flag=None):
    """One long slow drag toward the far/last-order end of the board."""
    (x1, y1), (x2, y2) = LONG_SWIPE_ENDPOINTS
    swipe(x1, y1, x2, y2, LONG_SWIPE_DURATION_MS)
    interruptible_sleep(LONG_SWIPE_SETTLE_SEC, stop_flag)


def reset_orders_scroll(stop_flag=None):
    """Scrolls the Orders board all the way back to its first card in one
    slow drag. Confirmed live 9/25 that the board does NOT reset its
    scroll position when reopened -- it stays wherever a previous session
    left it, which silently breaks every card-reading assumption if not
    corrected first. See LONG_SWIPE_ENDPOINTS above for why one swipe is
    now trusted to reach the true start unconditionally."""
    (x1, y1), (x2, y2) = LONG_SWIPE_ENDPOINTS
    swipe(x2, y1, x1, y1, LONG_SWIPE_DURATION_MS)  # reverse direction
    interruptible_sleep(LONG_SWIPE_SETTLE_SEC, stop_flag)


def _scan_page_for_missing(img, page_label, seen_signatures):
    """Reads every visible card on one screenshot, recording each card's
    signature (so the OTHER page's scan won't double-count a card visible
    on both) and returning a finding for every red (missing) slot."""
    page_findings = []
    for card in find_cards(img):
        cx = card["icon_col1_x"]
        sig = _card_signature(img, cx)
        if sig is not None and _signature_seen(sig, seen_signatures):
            continue  # already recorded from the other page
        if sig is not None:
            seen_signatures.append(sig)
        for dx in SLOT_DX:
            for icon_y, text_y in SLOT_ROWS:
                x = cx + dx
                if x - 45 < 0 or x + 45 > img.shape[1]:
                    continue  # cut off at the screen edge
                color = _sample_color(img, x, text_y)
                if color == "red":
                    icon = img[icon_y - ICON_CROP_TOP:icon_y + ICON_CROP_BOTTOM, x - 45:x + 45]
                    dish = identify_dish(icon)
                    finding = {
                        "page": page_label, "loc": (x, icon_y),
                        "name": dish["name"] if dish else "unidentified",
                    }
                    if dish is None:
                        os.makedirs(PENDING_DIR, exist_ok=True)
                        pending_path = os.path.join(
                            PENDING_DIR, f"{page_label}_{x}_{icon_y}.png")
                        cv2.imwrite(pending_path, icon)
                        finding["pending_path"] = pending_path
                    page_findings.append(finding)
    log(f"{page_label}: {len(page_findings)} missing item(s) visible: "
        f"{[f['name'] for f in page_findings]}")
    return page_findings


def scan_full_orders_board(stop_flag=None):
    """Reads the WHOLE Orders board in exactly two looks -- reset to the
    start, read what's visible, one long slow swipe to the far end, read
    what's visible there. Confirmed live 9/26 that a single long swipe
    spans the board's entire scrollable range (6 order slots + 1 locked
    placeholder) in one motion (see LONG_SWIPE_ENDPOINTS), so no scan
    loop/retry logic is needed anymore -- two pages is the whole board.
    This is a discovery/coverage scan, not a fulfill run -- it doesn't
    travel anywhere."""
    close_any_open_panel()
    tap(*ORDERS_ICON_LOC)
    interruptible_sleep(1, stop_flag)
    reset_orders_scroll(stop_flag)

    seen_signatures = []
    findings = _scan_page_for_missing(screenshot(), "page_start", seen_signatures)
    check_stop(stop_flag)
    dismiss_second_device_dialog()
    swipe_to_far_end(stop_flag)
    findings += _scan_page_for_missing(screenshot(), "page_end", seen_signatures)

    tap(*CLOSE_X_LOC)
    return findings


def main(stop_flag=None, skip_slots=None):
    """Returns a dict {status, item_loc, slot_key} so a caller can run
    repeated cycles and build up a skip set across runs -- status is one
    of 'nothing_to_do', 'travel_failed', 'panel_not_opened', 'not_trained',
    'blocked_on_ingredient', 'queued'. `slot_key` identifies the item by
    its order card's content signature (see find_missing_item), not by
    screen position, so it stays valid across scroll drift -- pass the
    accumulated slot_key list back in as `skip_slots` to skip it next call."""
    log("=== order fulfill run start ===")
    try:
        close_any_open_panel()
        check_stop(stop_flag)

        # pass 62 (board memory): look first, swipe only when the board is somewhere unknown; scan the page that is
        # on screen before swiping to the other one (the whole board is two pages -- see LONG_SWIPE_ENDPOINTS).
        img, view = open_board_smart(stop_flag)
        img = _serve_and_refresh(img, stop_flag)
        if DISMISS_REQUESTS:                          # 10/27: e.g. a new order just found over the long-order limit
            log("Orders are waiting to be dismissed -- ending this item so the dismiss goes first.")
            tap(*CLOSE_X_LOC)
            return {"status": "dismiss_pending", "item_loc": None, "slot_key": None}
        view = classify_board_page(img)
        item = find_missing_item(img, skip_slots=skip_slots, quiet=False)
        if item is None and not (view["at_start"] and view["at_end"]):
            check_stop(stop_flag)
            dismiss_second_device_dialog()
            if view["at_end"]:
                log("BOARD: nothing missing on the end page -- swiping back to the start page.")
                reset_orders_scroll(stop_flag)
            else:
                swipe_to_far_end(stop_flag)
            img = _serve_and_refresh(screenshot(), stop_flag)
            view = classify_board_page(img)
            item = find_missing_item(img, skip_slots=skip_slots)
        global _OTHER_PAGE_LOOKED
        if (item is not None and QUICK_FIRST and not _OTHER_PAGE_LOOKED and not (view["at_start"] and view["at_end"])
                and item.get("_wall")):
            other = quicker_order_elsewhere(img, item["_wall"], item.get("_rate"))
            if other is not None:                   # 10/22: a quicker order is on the other page -- one look per pass
                _OTHER_PAGE_LOOKED = True
                log(f"[order pick] Order {other.get('n')} is " + ("better paid per hour" if RANK_BY_COINS else "quicker")
                    + " and on the other page -- looking there.")
                check_stop(stop_flag)
                if view["at_end"]:
                    reset_orders_scroll(stop_flag)
                else:
                    swipe_to_far_end(stop_flag)
                img2 = screenshot()
                item2 = find_missing_item(img2, skip_slots=skip_slots)
                better = (item2 is not None and ((item2.get("_rate") or 0) > (item.get("_rate") or 0)) if RANK_BY_COINS
                          else item2 is not None and item2.get("_wall") and item2["_wall"] < item["_wall"])
                if better:
                    img, item, view = img2, item2, classify_board_page(img2)
                else:
                    log("[order pick] nothing better to work there (set aside / skipped / waiting) -- back to the first page.")
                    if view["at_end"]:
                        swipe_to_far_end(stop_flag)
                    else:
                        reset_orders_scroll(stop_flag)
                    img = screenshot()
                    view = classify_board_page(img)
                    item = find_missing_item(img, skip_slots=skip_slots)
        if item is not None:
            global _LAST_ORDER_NO, _LAST_ORDER_SIG
            _LAST_ORDER_NO = board_order_number(item["tap_loc"][0] - item["slot_key"]["dx"], view)
            _LAST_ORDER_SIG = item["slot_key"].get("sig")
            item["order"] = _LAST_ORDER_NO
            log(f"BOARD: missing item on order #{_LAST_ORDER_NO if _LAST_ORDER_NO else '?'} (page: "
                f"{'whole board' if (view['at_start'] and view['at_end']) else 'end' if view['at_end'] else 'start' if view['at_start'] else 'middle'}).")

        if item is None:
            log("No missing (red) items found anywhere on the Orders board -- nothing to do this run.")
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (nothing to do) ===")
            return {"status": "nothing_to_do", "item_loc": None}

        try:
            import run_trace
            run_trace.mark("board")                         # pass 49: timing
        except Exception:                             # noqa: BLE001
            pass
        try:                                              # pass 55: a batch of this dish is already cooking -> do not make (or chase ingredients for) another
            pre = identify_dish(item["icon"])
            if pre is None and identify_board_item(item["icon"]) is None:       # pass 60: nobody knows this item -- count it, maybe delete the order, never travel
                ub_sig = item["slot_key"]["sig"] if isinstance(item.get("slot_key"), dict) else None
                try:                                                              # 10/25: a dish whose station is not built
                    import unbuilt
                    ub = unbuilt.match_icon(item["icon"])
                except Exception:                                                 # noqa: BLE001
                    ub = None
                if ub is not None:
                    unbuilt.seen(ub)
                    log(f"[unbuilt] Order #{item.get('order') or '?'} wants {ub['name']} -- the {ub['station']} is not "
                        "built: dismissing the order right away.")
                    if ub_sig is not None and delete_order(img, ub_sig, stop_flag, why=f"needs {ub['name']} from the "
                                                           f"{ub['station']}, which is not built"):
                        tap(*CLOSE_X_LOC)
                        log("=== order fulfill run end (order for an unbuilt station dismissed) ===")
                        return {"status": "discarded_unbuilt", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}
                    tap(*CLOSE_X_LOC)
                    log("=== order fulfill run end (unbuilt station, order not dismissed -- see above) ===")
                    return {"status": "not_trained", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}
                try:                                                              # pass 69: ask the game what it is (tooltip) before counting anything
                    learned = learn_icon_from_tooltip(item, stop_flag)
                except StopRequested:
                    raise
                except Exception as e:                                        # noqa: BLE001
                    learned = None
                    log(f"(tooltip learning failed, ignored: {e!r})")
                if learned and learned[0] in ("dish", "raw"):
                    tap(*CLOSE_X_LOC)
                    log("=== order fulfill run end (icon learned from its tooltip) ===")
                    return {"status": "learned_icon", "item_loc": item["tap_loc"], "slot_key": item["slot_key"], "dish": learned[1]}
                if learned and learned[0] == "unbuilt":                           # 10/25: shop opened -> dismiss now
                    if ub_sig is not None:
                        DISMISS_REQUESTS.append((item.get("order"), ub_sig,
                                                 f"needs {learned[1]}, whose station is not built"))
                    log(f"[unbuilt] Order #{item.get('order') or '?'} wants {learned[1]} -- station not built: "
                        "dismissing the order (queued).")
                    log("=== order fulfill run end (order for an unbuilt station) ===")
                    return {"status": "discarded_unbuilt", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}
                if learned and learned[0] == "travelled":
                    log("=== order fulfill run end (dish not trained -- its station exists) ===")
                    return {"status": "not_trained", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}
                if learned and learned[0] == "known":
                    tap(*CLOSE_X_LOC)
                    log(f"UNTRAINED: the game calls it '{learned[1]}', which this bot cannot make from the Orders board -- leaving the order alone, not counting it towards deletion.")
                    log("=== order fulfill run end (dish not trained) ===")
                    return {"status": "not_trained", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}
                sig = item["slot_key"]["sig"] if isinstance(item.get("slot_key"), dict) else None
                pending_path = None
                os.makedirs(PENDING_DIR, exist_ok=True)
                pending_path = _pending_duplicate(item["icon"])
                if pending_path is None:
                    pending_path = os.path.join(PENDING_DIR, f"unidentified_{int(time.time())}.png")
                    cv2.imwrite(pending_path, item["icon"])
                n_seen = untrained_count_add(sig) if sig is not None else 0
                log(f"UNTRAINED ORDER {n_seen} of {UNTRAINED_DELETE_AFTER}: an item on the board is not a known dish or raw item (picture: {pending_path})."
                    + (" The order will be deleted after this many sightings." if DELETE_UNTRAINED_ORDERS else " (deleting is switched off)"))
                global _DELETES_THIS_RUN
                if (DELETE_UNTRAINED_ORDERS and sig is not None and n_seen >= UNTRAINED_DELETE_AFTER
                        and _DELETES_THIS_RUN < UNTRAINED_MAX_DELETES_PER_RUN):
                    if delete_order(img, sig, stop_flag):
                        _DELETES_THIS_RUN += 1
                        untrained_count_clear(sig)
                        tap(*CLOSE_X_LOC)
                        log("=== order fulfill run end (untrained order deleted) ===")
                        return {"status": "discarded_untrained", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}
                tap(*CLOSE_X_LOC)
                log("=== order fulfill run end (dish not trained) ===")
                return {"status": "not_trained", "item_loc": item["tap_loc"], "slot_key": item["slot_key"], "pending_path": pending_path}
            if pre is not None and covered_by_cooking(pre["name"], item.get("deficit")):
                log(f"ALREADY COOKING: {in_progress(pre['name'])} batch(es) of '{pre['name']}' were queued earlier and are still cooking; the board "
                    f"is short {item.get('deficit') or '?'} -- not travelling, not making another.")
                tap(*CLOSE_X_LOC)
                log("=== order fulfill run end (already cooking) ===")
                return {"status": "already_cooking", "item_loc": item["tap_loc"], "slot_key": item["slot_key"], "dish": pre["name"]}
        except StopRequested:
            raise
        except Exception as e:                            # noqa: BLE001
            log(f"(cooking check failed, ignored: {e!r})")
        try:                                              # pass 74: a crop that is still growing is not worth a trip yet
            wait = growing_remaining(item["slot_key"])
            if wait > 0:
                log(f"SKIP-UNTIL-READY: this order slot's crop is still growing (about {wait // 60}m {wait % 60}s left) -- not travelling.")
                tap(*CLOSE_X_LOC)
                log("=== order fulfill run end (crop still growing, skipped) ===")
                return {"status": "crop_growing", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}
        except StopRequested:
            raise
        except Exception as e:                            # noqa: BLE001
            log(f"(growing check failed, ignored: {e!r})")
        log(f"Missing item found at {item['tap_loc']} -- attempting quick-travel.")
        if not travel_to_missing_item(item, stop_flag):
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (travel failed) ===")
            return {"status": "travel_failed", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}

        return cook_after_travel(item, stop_flag)
    except StopRequested:
        log("=== order fulfill run stopped early by user ===")
        raise


def dish_by_name(name):
    """A dish-library entry by its in-game name ('Beef Burger' -> beef_burger), or None."""
    import difflib
    lib = _load_dish_library()
    key = "_".join("".join(ch if ch.isalnum() else " " for ch in str(name or "").lower()).split())
    if key not in lib:
        close = difflib.get_close_matches(key, list(lib), n=1, cutoff=0.85)
        if not close:
            return None
        key = close[0]
    return {"name": key, "card_index": lib[key].get("card_index"), "confidence": 1.0}


# 10/19 (owner, Settings tab): while Food Club is ticked, no dish that cooks longer than the limit goes on a
# station Food Club uses -- 4 ice creams (3 h each) at the Dairy blocked a Food Club Cream for hours.
# afsd_core fills this before each Auto Fulfill turn; limit_sec None = off.
LONG_COOK_GUARD = {"limit_sec": None, "stations": set()}


def long_cook_blocked(dish_name):
    """A reason text when this dish must not be queued now, else None."""
    lim = LONG_COOK_GUARD.get("limit_sec")
    if not lim or not dish_name:
        return None
    try:
        import recipe_book as rb
        it = rb.load()["items"][rb.resolve(dish_name)]
    except Exception:                                 # noqa: BLE001
        return None
    cook, st = it.get("cook_sec") or 0, it.get("station")
    if cook <= lim or st not in LONG_COOK_GUARD.get("stations", ()):
        return None
    return (f"{dish_name.replace('_', ' ')} cooks {cook // 60} min at the {st}, which Food Club uses -- over the "
            f"{lim // 60}-min limit in Settings, so not queueing it while Food Club runs.")


def _item_name(item, dish_name=None):
    """11/8: the name of the board item a trip was for (for log lines), or None."""
    try:
        if dish_name:
            return dish_name
        icon = item.get("icon") if isinstance(item, dict) else None
        if icon is not None and getattr(icon, "size", 0):
            ident = identify_dish(icon)
            return (ident["name"] if ident else None) or identify_board_item(icon) or tooltip_name(icon)
    except Exception:                                 # noqa: BLE001
        pass
    return None


def _item_where(item, dish_name=None):
    """11/8 (Muse: "the blocker lines never name the station"): ' for Bacon (Pig Pen)' or '' when unknown."""
    name = _item_name(item, dish_name)
    if not name:
        return ""
    st = None
    try:
        import recipe_book as rb
        st = rb.load()["items"][rb.resolve(name)].get("station")
    except Exception:                                 # noqa: BLE001
        pass
    return f" for {str(name).replace('_', ' ')}" + (f" ({st})" if st else "")


def _fruit_item(item, dish_name=None):
    """11/8: the BUSH_INGREDIENTS name of a board item that is raw fruit (apple, coffee bean, lemon), else None."""
    try:
        names = [dish_name]
        icon = item.get("icon") if isinstance(item, dict) else None
        if icon is not None and getattr(icon, "size", 0):
            ident = identify_dish(icon)
            names += [ident["name"] if ident else None, identify_board_item(icon)]
        import recipe_book as rb
        for n in names:
            if not n:
                continue
            try:
                k = rb.resolve(n)
            except KeyError:                          # resolve raises on unknown names ("Coffee Beans")
                k = str(n).strip().lower().replace(" ", "_")
            k = {"coffee_beans": "coffee_bean", "apples": "apple", "lemons": "lemon"}.get(k, k)
            if k in BUSH_INGREDIENTS:
                return k
    except Exception:                                 # noqa: BLE001
        return None
    return None


def cook_after_travel(item, stop_flag=None, still_open=None, dish_name=None):
    """Everything after a quick-travel '?' tap: open the station panel (clearing a collection blocker),
    find the dish card, chase a missing ingredient or queue the batches. Split out of main() on 10/17 so
    the street Food Truck can use the very same, live-tested path. item = {tap_loc, icon, slot_key,
    deficit}; still_open(img) -> True when the panel we came from is still showing (travel failed)."""
    try:
        try:
            import run_trace
            run_trace.mark("travel")
        except Exception:                             # noqa: BLE001
            pass
        img = screenshot()
        opened = panel_is_open(img)
        if opened and still_open is None and find_cards(img) and item.get("tap_loc"):
            # 10/24: live 10/23 the travel tooltip vanished before the '?' tap landed whenever the emulator was slow
            # (failed trips took 6-13 s, good ones 3-5 s; 10 failures in 2 h, none in the 27 logs before). The board is
            # still open on the same item, so try the trip once more right away.
            log("The board is still open after the '?' tap (the tooltip timed out?) -- trying this trip once more.")
            if travel_to_missing_item(item, stop_flag):
                img = screenshot()
                opened = panel_is_open(img)
        if opened and (find_cards(img) or (still_open and still_open(img))):   # pass 54: the Orders board (or the truck panel) has the same close X as a station panel
            log("The panel we travelled from is still open after the '?' tap (quick-travel did not happen) -- treating this as a failed travel.")
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (travel failed) ===")
            return {"status": "travel_failed", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}
        cleared_blocker = False
        if not opened:
            # Confirmed live 9/25: a single check right after travel can be
            # a false negative purely from timing (the panel hadn't
            # finished rendering yet), not a real "didn't open" case --
            # give it a couple more chances before concluding that.
            for _ in range(3):
                interruptible_sleep(0.7, stop_flag)
                img = screenshot()
                if panel_is_open(img):
                    opened = True
                    break
        fruit = _fruit_item(item, dish_name) if not opened else None
        if fruit:
            # 11/8: a board item that IS a fruit (Order "8 apple") travels to the TREES, not a station. The blind
            # centre taps below opened a spent tree's menu instead (97 spent-tree menus in 3 days, read later by the
            # popup check with no map picture, so they could never be cut) and every trip ended panel_not_opened.
            # Pick it like any fruit ingredient: ripe fruit only, picked-tree menus handled (Ask for Help / cut).
            want = item.get("deficit") or 3
            log(f"[fruit item] the order wants {fruit.replace('_', ' ')} itself -- the trip landed at the trees, "
                f"picking instead of looking for a station.")
            ok = harvest_fruit_here(fruit, stop_flag, max_harvests=max(1, min(int(want), 8)))
            log("=== order fulfill run end (fruit item) ===")
            return {"status": "harvested_fruit" if ok else "blocked_on_ingredient", "item_loc": item.get("tap_loc"),
                    "slot_key": item.get("slot_key"), "ingredient": fruit}
        if not opened:
            # A ready-to-collect item sitting on/near the destination
            # station can block its panel from opening at all -- confirmed
            # live 9/25 (a ready Funghi Pizza had to be collected before
            # the Pizza Oven panel would open). Quick-travel reliably
            # centers the destination on screen, so tap there to collect
            # whatever's in the way, then recheck -- rather than a whole
            # new per-dish "ready icon" template library, this reuses the
            # one thing we already know is true about every quick-travel
            # destination: it's centered.
            _what = _item_where(item, dish_name)
            log(f"COLLECTION BLOCKER active{_what}: the station panel did not open (a finished item is probably sitting "
                "on it) -- tapping the centre to collect it, up to 2 tries.")
            for attempt in range(2):
                check_stop(stop_flag)
                log(f"COLLECTION BLOCKER: centre tap, try {attempt + 1} of 2")
                tap(*SCREEN_CENTER)
                interruptible_sleep(1, stop_flag)
                img = screenshot()
                if panel_is_open(img):
                    opened = True
                    cleared_blocker = True
                    log(f"Panel opened after tapping screen-center (attempt {attempt + 1}) -- "
                        "likely cleared a ready-to-collect item that was blocking it.")
                    break
        if not opened:
            try:                                                   # pass 80: a raw crop on the board -- we are at the plots, so work them
                raw_crop = identify_board_item(item["icon"]) if identify_dish(item["icon"]) is None else None
                if raw_crop in GENERIC_CROP_INGREDIENTS and _at_crop_plots(img):
                    log(f"The missing item is the raw crop '{raw_crop}' and the trip landed at the plots -- harvesting / planting it here.")
                    did = _work_crop_plots(raw_crop, stop_flag, want=_plants_wanted(item.get("deficit")))
                    close_any_open_panel(quiet=True, thorough=True)
                    log("=== order fulfill run end (raw crop worked at the plots) ===")
                    return {"status": "recursed_ingredient" if did else "crop_growing", "item_loc": item["tap_loc"],
                            "slot_key": item["slot_key"], "dish": raw_crop, "recursed": raw_crop}
            except StopRequested:
                raise
            except Exception as e:                                 # noqa: BLE001
                log(f"(raw-crop handling failed, ignored: {e!r})")
            try:                                                   # pass 73: a growing crop opens its grow-timer card, not a station panel
                import garden_check
                if garden_check.is_grow_timer_card(img):
                    log("The missing item is a crop that is still growing (its grow-timer card opened at the plot) -- closing the card with its X (never Skip) and waiting for the harvest.")
                    secs = read_grow_card_seconds(img)                     # pass 74: remember when it is ready
                    garden_check._close_grow_card_if_open(img, stop_flag)
                    if secs:
                        growing_add(item["slot_key"], secs)
                        log(f"SKIP-UNTIL-READY: the grow timer says {secs // 3600}h {secs % 3600 // 60}m {secs % 60}s left -- this order slot will not be travelled to again until then.")
                    else:
                        log("(the grow timer could not be read reliably -- not remembering it)")
                    log("=== order fulfill run end (crop still growing) ===")
                    return {"status": "crop_growing", "item_loc": item["tap_loc"], "slot_key": item["slot_key"]}
            except StopRequested:
                raise
            except Exception as e:                                 # noqa: BLE001
                log(f"(grow-card check failed, ignored: {e!r})")
            log("COLLECTION BLOCKER still active after 2 tries (or this was not a blocker) -- giving up on this item for now.")
            log("Travel completed but no station panel auto-opened -- landed on the map instead, "
                "and tapping screen-center didn't clear it either. Not guessing further (real "
                "mistakes happened doing this manually tonight -- Fridge, Chicken Coop). Stopping "
                "here for this run.")
            log(f"=== order fulfill run end (panel didn't auto-open{_item_where(item, dish_name)}) ===")
            return {"status": "panel_not_opened", "item_loc": item["tap_loc"], "slot_key": item["slot_key"],
                    "dish": _item_name(item, dish_name)}

        if cleared_blocker:
            # Real bug flagged by the user 9/27: the ready-to-collect item
            # just cleared via the screen-center tap could easily BE the
            # exact dish this order needed -- collecting it may have
            # already satisfied the order (its stock just went up by 1).
            # Continuing straight into "check ingredients -> cook another
            # batch" without rechecking the Orders board first risks
            # cooking one MORE than actually needed, every single time a
            # finished batch happens to be sitting on the station when we
            # arrive -- a real, silent ingredient-wasting bug, not just a
            # theoretical one. Stop here and let the next main() call
            # re-scan the Orders board fresh: if the order is now
            # satisfied, this item simply won't show up as missing
            # anymore; if it's still short, this same item gets
            # rediscovered and a real cook decision happens then, backed
            # by a fresh read instead of a stale assumption.
            log("Collected a ready-to-collect item to open this panel -- that alone may have "
                "already satisfied the order. Closing without cooking and ending this run so the "
                "Orders board gets rechecked fresh, rather than risking an unneeded extra batch.")
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (collected blocker, recheck needed) ===")
            return {"status": "collected_blocker", "item_loc": item["tap_loc"],
                    "slot_key": item["slot_key"]}

        try:
            import run_trace
            run_trace.mark("panel")
        except Exception:                             # noqa: BLE001
            pass
        dish = dish_by_name(dish_name) if dish_name else None    # 10/17: the truck read the name from the game's tooltip
        if dish is not None:
            log(f"Dish '{dish_name}' found in the library by name as '{dish['name']}'.")
        elif not dish_name:
            dish = identify_dish(item["icon"])
        if dish is None and item.get("icon") is None:     # 11/16 (Muse): a by-name trip ("Ham / Pork") has no icon
            log(f"Dish '{dish_name}' is not in the trained library by that name -- closing (nothing to save).")
            tap(*CLOSE_X_LOC)
            return {"status": "not_trained", "item_loc": item.get("tap_loc"), "slot_key": item.get("slot_key"),
                    "dish": dish_name}
        if dish is None:
            os.makedirs(PENDING_DIR, exist_ok=True)
            pending_path = _pending_duplicate(item["icon"])                  # pass 59: do not save the same picture every cycle
            if pending_path is None:
                pending_path = os.path.join(PENDING_DIR, f"unidentified_{int(time.time())}.png")
                cv2.imwrite(pending_path, item["icon"])
            log(f"Dish not yet in the trained library -- saved its icon to {pending_path} for "
                "training (see order_fulfill.train_dish). Closing without guessing.")
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (dish not trained) ===")
            return {"status": "not_trained", "item_loc": item["tap_loc"], "slot_key": item["slot_key"],
                    "pending_path": pending_path}
        log(f"Identified dish '{dish['name']}' (confidence {dish['confidence']:.2f}) -- "
            "locating its card by sight.")
        cx, panel_conf = locate_dish_card(dish["name"], stop_flag)
        if cx is not None:
            log(f"Located '{dish['name']}' card at x={cx} (confidence {panel_conf:.2f}).")
        elif dish["card_index"] is not None:
            cx = RECIPE_CARD_X[dish["card_index"]]
            log(f"'{dish['name']}' not found by sight (best {panel_conf:.2f}) -- falling back to "
                f"legacy card_index {dish['card_index']} (x={cx}).")
        else:
            cx = locate_card_by_name(dish["name"], stop_flag)     # 11/12: tomato_soup 0.79-0.81 all night
            if cx is not None:
                log(f"'{dish['name']}' not found by sight (best {panel_conf:.2f}) -- found it by its NAME at x={cx}; "
                    "its card picture was refreshed for next time.")
        if cx is None:
            log(f"'{dish['name']}' not found by sight (best {panel_conf:.2f}) and has no legacy "
                "card_index -- can't locate its card. Closing without guessing.")
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (dish card not found) ===")
            return {"status": "dish_card_not_found", "item_loc": item["tap_loc"],
                    "slot_key": item["slot_key"], "dish": dish["name"]}

        img = screenshot()  # refresh -- locate_dish_card may have swiped the panel
        _prep_hook("seen_card", dish["name"], img, cx)            # 11/13: Prep re-checks its stock on every visit
        if dish["name"] in COIN_COST_DISHES:
            # 10/25 (Muse, from the 10/24 Lighthouse pictures): the Fishing Hook card has NO ingredient icons, only a
            # coin price -- reading slots there gave 'ingredients_unreadable' every Prep turn. Same rule as the
            # sub-ingredient path: coins are fine to spend, nothing to read or chase.
            ingredients = []
            log(f"'{dish['name']}' costs coins, not ingredients -- no stock check needed.")
        else:
            ingredients = read_ingredients(img, cx, dish_name=dish["name"])
        log(f"'{dish['name']}' ingredients at x={cx}: {ingredients}")
        try:                                          # pass 49: where did the trip land + what are the counts
            import run_trace
            run_trace.arrived(img, dish["name"], "order")
            run_trace.log_counts(dish["name"], img, ingredients)
            run_trace.mark("read")
        except Exception:                             # noqa: BLE001
            pass
        try:
            _set_deficits(img, ingredients)                # pass 55
        except Exception:                             # noqa: BLE001
            pass

        has_red = any(color == "red" for color, x, y, name in ingredients)
        # Real bug found live 9/27, in three stages. First: an all-None
        # read (nothing classified at all) fell through the old "no red
        # found -> must be sufficient" check and tapped Cook on a dish
        # with zero confirmed ingredients (veggie_stirfry "queued
        # successfully" twice with nothing actually queued). Second: a
        # read of [None, None, 'green'] still slipped through a
        # first-draft fix requiring only "at least one confirmed green" --
        # fixed by refusing to act on ANY unclassifiable slot, on the
        # assumption every dish has exactly 3 populated ingredient slots.
        # Third bug, found live 9/27 running the freshly-trained dish
        # library: that assumption is FALSE for every single-ingredient
        # dish (Cheese, Whipped Cream, Butter, Apple Juice, Tomato Soup,
        # Espresso, ...) -- Cheese correctly read Milk as green but its
        # two genuinely-unused slots came back None, and the safety check
        # refused to cook a fully-available dish. Fixed by distinguishing
        # a GENUINELY EMPTY slot (plain card background, see
        # is_blank_ingredient_slot) from an unreadable one (real content,
        # ambiguous color -- still refused, unchanged).
        unreadable = [(x, y) for color, x, y, name in ingredients
                      if color is None and not is_blank_ingredient_slot(img, x, y)]
        if unreadable:
            log(f"Ingredient slot(s) at {unreadable} read as unclassifiable (not blank background, "
                f"not red/green) out of {ingredients} -- the read position itself is probably wrong "
                "(wrong panel scroll state, wrong cx, etc.). Refusing to act on a partial read.")
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (ingredients unreadable) ===")
            return {"status": "ingredients_unreadable", "item_loc": item["tap_loc"],
                    "slot_key": item["slot_key"], "dish": dish["name"]}

        if has_red:
            missing = [(name or "unidentified", x, y) for color, x, y, name in ingredients if color == "red"]
            log(f"Ingredient(s) still missing: {missing}.")

            # Real bug found live 9/27 (user watching): Wheat used to be
            # special-cased HERE, ahead of the generalized dispatcher
            # below, and routed to the older `recurse_wheat_ingredient`
            # -- which taps the plant-bar icon to replant but never
            # checks whether that tap actually triggered the "you're out
            # of Wheat, buy for gems?" dialog instead of really planting.
            # It would blindly report success either way. The newer
            # `recurse_generic_crop_ingredient` (built the same night for
            # Tomato/Cabbage) already checks for exactly that dialog and
            # declines it -- Wheat now goes through the SAME path via
            # GENERIC_CROP_INGREDIENTS below, instead of a separate,
            # less-safe special case. `is_ingredient_wheat`/
            # `recurse_wheat_ingredient` are kept only as unused-but-
            # documented history of the original v1 approach.

            # Generalized ingredient recursion, built 9/27 after proving it
            # manually live (Tomato Soup->Tomato->Garden Plot, and
            # Croissant->Butter->Milk->Greens). Tries the first named
            # missing ingredient that's in the known-automated set
            # (GENERIC_CROP_INGREDIENTS / PRODUCED_DISH_INGREDIENTS);
            # anything outside that set (or unidentified) falls through
            # to the same safe decline every ingredient got before tonight.
            # Dead-end memory (9/28): found live that Affogato (espresso AND
            # ice_cream both missing) only ever chased espresso -- it hit
            # the un-automated coffee_bean dead end, returned "no progress",
            # and the run stopped, so ice_cream was never even tried (and
            # would never be, on any later run, since espresso always comes
            # first). Now an ingredient whose chase makes no progress is
            # remembered for the rest of this process_all_visible() pass and
            # skipped, and the item is re-examined fresh (status
            # 'retry_next_ingredient', not added to the skip list) so the
            # remaining missing ingredients each get their turn.
            all_names = [n for n, _x, _y in missing]
            for name, x, y in missing:
                if name == "unidentified" and (dish["name"], x) not in _INGR_LEARN_TRIED:    # pass 75: ask the game what this icon is
                    _INGR_LEARN_TRIED.add((dish["name"], x))
                    try:
                        learned = learn_ingredient_from_tooltip(img, x, y, stop_flag)
                    except StopRequested:
                        raise
                    except Exception as e:                        # noqa: BLE001
                        learned = None
                        log(f"(ingredient tooltip learning failed, ignored: {e!r})")
                    if learned and learned[0] == "trained":
                        tap(*CLOSE_X_LOC)
                        log("=== order fulfill run end (ingredient icon learned from its tooltip) ===")
                        return {"status": "learned_icon", "item_loc": item["tap_loc"], "slot_key": item["slot_key"], "dish": dish["name"]}
                if name == "unidentified" or name in _DEAD_END_INGREDIENTS:
                    continue
                result = recurse_ingredient(name, (x, y), stop_flag)
                if result is None:
                    continue  # not in the automated set yet -- try the next one
                close_panel_if_open()
                if result:
                    log(f"=== order fulfill run end (recursed into {name}, made progress) ===")
                    return {"status": "recursed_ingredient", "item_loc": item["tap_loc"],
                            "slot_key": item["slot_key"], "dish": dish["name"], "recursed": name}
                _DEAD_END_INGREDIENTS.add(name)
                untried = [n for n in all_names
                           if n != "unidentified" and n not in _DEAD_END_INGREDIENTS
                           and (n in GENERIC_CROP_INGREDIENTS or n in PRODUCED_DISH_INGREDIENTS
                                or n in BUSH_INGREDIENTS)]
                if untried:
                    log(f"Chasing '{name}' made no progress -- will re-check this order and try "
                        f"{untried} next.")
                    log(f"=== order fulfill run end (no progress on {name}, retrying with another "
                        "ingredient) ===")
                    return {"status": "retry_next_ingredient", "item_loc": item["tap_loc"],
                            "slot_key": item["slot_key"], "dish": dish["name"]}
                log(f"=== order fulfill run end (blocked on {name}, recursion made no progress) ===")
                return {"status": "blocked_on_ingredient", "item_loc": item["tap_loc"],
                        "slot_key": item["slot_key"], "dish": dish["name"],
                        "missing_ingredients": all_names}

            log(f"Missing ingredient(s) {missing} have no automated way forward this pass (not in "
                "the recursion set yet, or already tried without progress). "
                "Stopping here rather than guessing or buying with gems.")
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (blocked on an ingredient) ===")
            return {"status": "blocked_on_ingredient", "item_loc": item["tap_loc"],
                    "slot_key": item["slot_key"], "dish": dish["name"],
                    "missing_ingredients": [name for name, x, y in missing]}

        if _truck_chain_hold(img, ingredients, dish["name"]):     # 11/9 O.R.D.E.R.: the truck's chain first
            tap(*CLOSE_X_LOC)
            _TRUCK_HELD.append({"sig": (item.get("slot_key") or {}).get("sig"), "t": time.time()})
            log("=== order fulfill run end (left for the food truck) ===")
            return {"status": "truck_held", "item_loc": item["tap_loc"], "slot_key": item["slot_key"],
                    "dish": dish["name"]}
        hold = _crop_reserve_hold(img, ingredients)              # 10/23: keep seeds to replant
        if hold:
            _plant_reserve(hold, dish["name"], stop_flag)
            close_panel_if_open()
            log("=== order fulfill run end (crop kept for replanting) ===")
            return {"status": "crop_reserve_held", "item_loc": item["tap_loc"], "slot_key": item["slot_key"],
                    "dish": dish["name"]}
        action_loc = (cx, ACTION_BUTTON_Y)
        why = long_cook_blocked(dish["name"])
        if why:
            log(f"[long cooks] {why}")
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (long cook kept off a Food Club station) ===")
            return {"status": "long_cook_held", "item_loc": item["tap_loc"], "slot_key": item["slot_key"],
                    "dish": dish["name"]}
        if (dish["name"] in FISHING_GUARDED_DISHES | NEVER_CRAFT_DISHES        # pass 88 guard, main path too
                and not _action_card_is_expected(screenshot(), dish["name"], cx)):
            log(f"The card under the button is not '{dish['name']}' (or it is a never-craft item) -- not tapping.")
            tap(*CLOSE_X_LOC)
            log("=== order fulfill run end (card check failed) ===")
            return {"status": "dish_card_not_found", "item_loc": item["tap_loc"], "slot_key": item["slot_key"],
                    "dish": dish["name"]}
        log(f"All ingredients sufficient -- tapping the action button at {action_loc}.")
        try:                                          # pass 49: debug pictures (only when the file .debug_pictures exists)
            import run_trace
            run_trace.dbg(img, f"queue_{dish['name']}_before")
        except Exception:                             # noqa: BLE001
            pass
        tap(*action_loc)
        interruptible_sleep(1, stop_flag)
        try:
            run_trace.dbg_after(f"queue_{dish['name']}_after")
        except Exception:                             # noqa: BLE001
            pass

        extra_done = 0
        try:                                          # pass 82: queue the other batches this order needs while we are here
            n_total = _batches_wanted(item.get("deficit"), in_progress(dish["name"]))
            up = _prep_hook("topup", dish["name"], item.get("deficit"))      # 11/13: also cover the Prep list
            if up:
                n_total = max(n_total, up)
            if n_total > 1:
                extra_done = _queue_extra_batches(dish["name"], cx, action_loc, n_total - 1, stop_flag)
        except StopRequested:
            raise
        except Exception as e:                        # noqa: BLE001
            log(f"(extra batches skipped: {e!r})")
        try:
            note_queued(dish["name"], 1 + extra_done)      # pass 55 / 82
        except Exception:                             # noqa: BLE001
            pass
        tap(*CLOSE_X_LOC)
        log("=== order fulfill run end (queued successfully) ===")
        return {"status": "queued", "item_loc": item["tap_loc"], "slot_key": item["slot_key"],
                "dish": dish["name"]}
    except StopRequested:
        log("=== order fulfill run stopped early by user ===")
        raise


MAIN_MULTI_QUEUE_MAX = 3


def _batches_wanted(deficit, cooking):
    """pass 82: how many batches this visit should queue = board deficit minus what is already cooking, clamped to 1..MAIN_MULTI_QUEUE_MAX."""
    try:
        need = int(deficit) - int(cooking or 0)
    except (TypeError, ValueError):
        return 1
    return max(1, min(MAIN_MULTI_QUEUE_MAX, need))


def _queue_extra_batches(dish_name, cx, action_loc, n_extra, stop_flag=None):
    """pass 82: after the first action tap, queue up to n_extra more batches while it is provably safe. Returns how many were queued."""
    done = 0
    for _ in range(max(0, n_extra)):
        check_stop(stop_flag)
        img2 = screenshot()
        if not panel_is_open(img2):
            break
        no_loc, _nc = find_no_button(img2)
        if no_loc is not None:
            log("An extra batch raised a gem-buy dialog -- declining, never spending gems.")
            tap(*no_loc)
            break
        if not queue_has_free_slot(img2):
            break
        ing2 = read_ingredients(img2, cx, dish_name=dish_name)
        if any((c != "green") and not (c is None and is_blank_ingredient_slot(img2, x, y)) for c, x, y, _n in ing2):
            break
        log(f"'{dish_name}': more batches are needed and everything is still green with a free slot -- queuing another ({done + 2}).")
        tap(*action_loc)
        interruptible_sleep(1, stop_flag)
        done += 1
    return done


# 10/22 (owner): "set aside" -- an order item with no REAL progress for SET_ASIDE_MIN minutes (Settings > Clipboard
# Orders, 0 = off) is skipped for SET_ASIDE_FOR_SEC so the other orders get the bot's time. Real progress = queued /
# collected / already cooking, or a stock rise of one of its ingredients (run_trace). An item the bot did not look at
# for SET_ASIDE_GAP_SEC starts a fresh clock (not tried = not stuck). Same 8-h run: espresso 527 tries, sushi 123,
# while Onion Soup (makeable) got nothing for 5 h.
SET_ASIDE_MIN = 30
SET_ASIDE_FOR_SEC = 3600
SET_ASIDE_GAP_SEC = 900
SET_ASIDE_REAL = ("queued", "collected_blocker", "already_cooking")
SET_ASIDE_NOTES = []                                 # texts for the window (afsd_core shows them)
DISMISS_MIN = 30                                     # 10/22 (owner): Settings "Dismiss stuck orders after" (0 = off)
_STUCK = []                                          # [{"key", "dish", "order", "since", "seen", "aside_until"}]


def _stuck_entry(key):
    for e in _STUCK:
        if _slot_already_skipped(key.get("sig"), key["dx"], key["row"], [e["key"]]):
            return e
    return None


def _dismiss_due(e, now):
    """10/22 (owner): "dismiss stuck orders after N min" -- its own clock, independent of the set-aside time."""
    if DISMISS_MIN <= 0 or e.get("dismissed") or now - e["since"] < DISMISS_MIN * 60:
        return
    if KEEP_LINK and _sig_same(e["key"].get("sig"), _LINK["sig"]):   # 10/25: the Sell Apple Juice link is kept
        e["since"] = now
        return
    if truck_held_sig(e["key"].get("sig")):                    # 11/9 O.R.D.E.R.: waiting for the food truck
        e["since"] = now
        return
    try:                                                         # 10/25: Pantry full = no harvest could happen;
        import find_and_center as _fac                           # not the order's fault -- restart its clock
        if _fac.pantry_full_recent():
            e["since"] = now
            return
    except Exception:                                            # noqa: BLE001
        pass
    e["dismissed"] = True
    e["aside_until"] = now + SET_ASIDE_FOR_SEC                 # never worked again before it is gone
    DISMISS_REQUESTS.append((e.get("order") or "?", e["key"]["sig"],
                             f"no real progress on {e['dish'] or 'it'} for {DISMISS_MIN} min -- dismissed by the bot"))
    text = (f"Dismissed: Order {e.get('order') or '?'} ({e['dish'] or 'unknown dish'}) -- nothing it could make or "
            f"do for {DISMISS_MIN} min. A new order comes in about 30 min.")
    log(f"[set aside] {text}")
    SET_ASIDE_NOTES.append(text)


# 10/27 (owner: yes) WAIT IT OUT: logs 09-14 -- ~60 "progress" trips whose stock had not risen yet: the bot planted
# mushrooms (19-33 min) or queued egg / whipped cream, then came back for the same dish 30 s later, every pass.
# After a trip that planted / queued an ingredient (or found it missing), that order item is not worked again until the
# ingredient's recipe-book time has passed (WAIT_MIN_SEC..WAIT_MAX_SEC). WAIT_MAX stays under SET_ASIDE_GAP_SEC so the
# give-up clock keeps running for orders that never move.
WAIT_OUT = True
WAIT_MIN_SEC = 90                    # quick things (wheat 45 s, bread 45 s) are not worth a wait
WAIT_MAX_SEC = 12 * 60
_WAITING = []                        # [{"key": slot_key, "until": t, "ing": name, "dish": name}]


def _ready_secs(ing):
    try:
        import recipe_book as _rb
        return int(_rb.load()["items"][_rb.resolve(ing)].get("cook_sec") or 0)
    except Exception:                                            # noqa: BLE001
        return 0


ALREADY_COOKING_MIN_SEC = 30    # 11/6: a batch finishing sooner is simply looked at again next pass


TRUCK_HELD_WAIT_SEC = 10 * 60


def note_wait(result):
    """After one item: start a wait for it when its trip planted/queued (or was blocked on) something slow. -> key or None."""
    if not WAIT_OUT or not isinstance(result, dict):
        return None
    key = result.get("slot_key")
    st = result.get("status")
    if not isinstance(key, dict) or (key.get("sig") is None and not (st == "truck_held" and key.get("cx") is not None)):
        return None
    if st in ("recursed_ingredient", "crop_growing"):
        ing = result.get("recursed")
    elif st == "blocked_on_ingredient":
        ing = next((n for n in (result.get("missing_ingredients") or []) if n and n != "unidentified"), None)
    elif st == "truck_held":
        # 11/10 (Muse): a held order was re-tried every pass (caprese 15x in one send, ~30 s each, whole clipboard
        # stalled). Leave it alone for TRUCK_HELD_WAIT_SEC -- the other orders get worked meanwhile.
        ing = result.get("dish")
    elif st == "already_cooking":
        # 11/6 (Muse): the same cooking dishes were re-checked 42-93x per half hour (board open + read, ~9 s each).
        # The bot knows when its batch finishes -- leave the item alone until then.
        ing = result.get("dish")
    else:
        return None
    if st == "truck_held":
        secs = TRUCK_HELD_WAIT_SEC
    elif st == "already_cooking":
        left = [t - time.time() for t in _cooking_state().get(ing, [])]
        secs = int(min(left)) if left else 0
        if secs < ALREADY_COOKING_MIN_SEC:
            return None
    else:
        secs = _ready_secs(ing) if ing else 0
        if secs < WAIT_MIN_SEC:
            return None
    secs = min(secs, WAIT_MAX_SEC)
    now = time.time()
    _WAITING[:] = [w for w in _WAITING if w["until"] > now and not (
        _sig_same(w["key"].get("sig"), key.get("sig")) and w["key"].get("dx") == key.get("dx")
        and w["key"].get("row") == key.get("row"))]
    _WAITING.append({"key": key, "until": now + secs, "ing": ing, "dish": result.get("dish")})
    if st == "truck_held":
        log(f"[wait out] {result.get('dish') or 'that order item'}: held for a higher job -- not trying it again "
            f"before {time.strftime('%H:%M', time.localtime(now + secs))}.")
        return key
    log(f"[wait out] {result.get('dish') or 'that order item'}: {ing} takes ~{secs // 60} min "
        f"(status {st}) -- not working it again before {time.strftime('%H:%M', time.localtime(now + secs))}.")
    return key


def waiting_keys():
    now = time.time()
    _WAITING[:] = [w for w in _WAITING if w["until"] > now]
    for w in _WAITING:                                           # waiting is not "unseen": keep the give-up clock
        e = _stuck_entry(w["key"])                               # running (a 15-min gap would restart it)
        if e is not None:
            e["seen"] = now
    return [w["key"] for w in _WAITING]


def set_aside_keys():
    now = time.time()
    _STUCK[:] = [e for e in _STUCK if now - e["seen"] < 6 * 3600 or e.get("aside_until", 0) > now]
    for e in _STUCK:                                           # an order set aside still runs out its dismiss clock
        if e.get("aside_until", 0) > now:
            _dismiss_due(e, now)
    return [e["key"] for e in _STUCK if e.get("aside_until", 0) > now]


def _note_stuck(result):
    key = result.get("slot_key")
    if (SET_ASIDE_MIN <= 0 and DISMISS_MIN <= 0) or not isinstance(key, dict) or key.get("sig") is None:
        return
    now = time.time()
    e = _stuck_entry(key)
    if e is None or (now - e["seen"] > SET_ASIDE_GAP_SEC and not e.get("aside_until")):
        if e is not None:                            # by identity: == on entries compares numpy pictures (ValueError
            _STUCK[:] = [x for x in _STUCK if x is not e]   # live 10/23, 8x -- the stuck clock silently stopped)
        e = {"key": key, "dish": result.get("dish"), "order": result.get("order"), "since": now, "seen": now}
        _STUCK.append(e)
    e["seen"] = now
    e["dish"] = result.get("dish") or e["dish"]
    rose = False
    try:
        import run_trace
        rose = run_trace.dish_rose_since(e["dish"], e["since"])
    except Exception:                                # noqa: BLE001
        pass
    real = result["status"] in SET_ASIDE_REAL or rose
    if result["status"] == "already_cooking" and not rose:   # 10/22 (owner): long cooks count as stuck too
        try:
            import recipe_book as _rb
            cook = _rb.load()["items"][_rb.resolve(e["dish"])].get("cook_sec") or 0
        except Exception:                            # noqa: BLE001
            cook = 0
        real = DISMISS_MIN <= 0 or cook <= 2 * DISMISS_MIN * 60    # long = over twice the dismiss time (soup 35 m ok)
    if real:
        e["since"] = now
        e.pop("aside_until", None)
        return
    _dismiss_due(e, now)
    if e.get("dismissed"):
        return
    if SET_ASIDE_MIN > 0 and now - e["since"] >= SET_ASIDE_MIN * 60 and e.get("aside_until", 0) <= now:
        e["aside_until"] = now + SET_ASIDE_FOR_SEC
        text = (f"Set aside: Order {e.get('order') or '?'} ({e['dish'] or 'unknown dish'}) -- no real progress "
                f"for {int(now - e['since']) // 60} min, skipped for {SET_ASIDE_FOR_SEC // 60} min"
                + (f" (dismissed at {DISMISS_MIN} min with no progress)." if DISMISS_MIN > 0 else
                   ". Dismiss it on the Orders tab if it should go."))
        log(f"[set aside] {text}")
        SET_ASIDE_NOTES.append(text)


def process_all_visible(stop_flag=None, max_items=15, on_item=None, should_stop=None):
    """The clipboard turn. CLIPBOARD_TURN marks its cooks for O.R.D.E.R. (11/9); the work is in _process_all_visible."""
    CLIPBOARD_TURN[0] = True
    try:
        return _process_all_visible(stop_flag, max_items, on_item, should_stop)
    finally:
        CLIPBOARD_TURN[0] = False


def _process_all_visible(stop_flag=None, max_items=15, on_item=None, should_stop=None):
    """Runs main() repeatedly, accumulating a skip set so each cycle makes
    progress on a DIFFERENT item instead of getting stuck re-discovering
    the same blocked one. Each main() call already checks the WHOLE board
    (start page + one long swipe to the end page, see LONG_SWIPE_ENDPOINTS)
    on its own, not just page 0. Skip identity is keyed by each order
    card's own content signature
    (see find_missing_item/_slot_already_skipped), not screen position --
    fixed 9/26 after the user watched a live run's reset-scroll logs and
    suspected orders near the end of the board might be getting missed.
    Root cause was never fully isolated (that specific run happened to
    overlap a second ADB session touching the same emulator, which can by
    itself produce misleading "no change" scroll readings -- see
    CLAUDE.md), but position-keyed skipping was already a known fragility
    in this function's own prior comment, so fixing it was worth doing
    regardless: a scrolled page's exact pixel position can drift a few px
    between separate main() calls, which risked an already-handled item
    not being recognized as such (or, worse, a different item at a
    drifted position being wrongly treated as already-skipped). Content-
    signature keying makes "have I already dealt with this exact order"
    a real identity check instead of a coordinate guess. Returns the full
    list of per-item results, so this can answer "can it do the whole
    list unattended" with real evidence instead of a guess.

    `on_item(results_so_far)`, if given, is called after EVERY item (not
    just at the end) -- built 9/29 so the GUI's Stats overlay can show live
    progress instead of only updating once the whole batch finishes, which
    can take several minutes on a long board (the user watched Cheese and
    Ice Cream actually get cooked while the overlay still said "no Orders
    check run yet," since the old behavior only pushed a report after
    process_all_visible fully returned). Never lets a callback exception
    kill a real run -- logged and swallowed instead.

    Resets _ALREADY_QUEUED_THIS_RUN at the start of every call -- that
    guard exists to stop a produced ingredient (Milk, Butter) from being
    re-queued over and over within a single rapid-fire batch (see its own
    comment for the real overproduction bug this fixed), not to block a
    genuinely new need for it on a LATER call. AFSD keeps one long-lived
    Python process running for the whole session, so without this reset
    the guard would silently block Milk forever after its first use,
    hours into a real session."""
    global _DELETES_THIS_RUN, _OTHER_PAGE_LOOKED
    _DELETES_THIS_RUN = 0                                   # pass 60
    _OTHER_PAGE_LOOKED = False                              # 10/22 quickest-first
    _ALREADY_QUEUED_THIS_RUN.clear()
    _QUEUE_COUNT_THIS_RUN.clear()
    _DEAD_END_INGREDIENTS.clear()
    _INGR_LEARN_TRIED.clear()
    skip = set_aside_keys()                                 # 10/22: orders set aside stay skipped
    _w = waiting_keys()                                     # 10/27: items waiting for a slow ingredient
    if _w:
        log(f"[wait out] {len(_w)} order item(s) waiting for a slow ingredient -- not working them this pass.")
        skip += [k for k in _w if not any(k is x for x in skip)]
    link_order()                                            # 10/25: Sell Apple Juice -- which order to keep
    if long_order_dismissals():                             # 10/26: too-long orders go first, then this turn ends
        return []
    if skip:
        log(f"[set aside] {len(skip)} order item(s) set aside -- not working them this pass.")
    results = []
    for _ in range(max_items):
        _t_order = time.time()
        try:                                          # pass 49: reset the per-order reasons + timers
            import run_trace
            run_trace.reset_order()
        except Exception:                             # noqa: BLE001
            run_trace = None
        result = main(stop_flag=stop_flag, skip_slots=skip)
        try:
            result.setdefault("order", _LAST_ORDER_NO)                   # pass 62: which board order it was
        except Exception:                             # noqa: BLE001
            pass
        results.append(result)
        try:
            _note_stuck(result)
            _k = result.get("slot_key")
            _e = _stuck_entry(_k) if isinstance(_k, dict) and _k.get("sig") is not None else None
            if _e is not None and _e.get("aside_until", 0) > time.time() and not any(x is _k for x in skip):
                skip.append(_k)
            _wk = note_wait(result)                                      # 10/27: wait out slow ingredients
            if _wk is not None and not any(x is _wk for x in skip):
                skip.append(_wk)
        except Exception as e:                        # noqa: BLE001
            import traceback as _tb
            log(f"(set-aside bookkeeping failed, ignored: {e!r} at {_tb.extract_tb(e.__traceback__)[-1].lineno})")
        try:
            run_trace.order_result(len(results), result, time.time() - _t_order)
        except Exception:                             # noqa: BLE001
            pass
        if on_item is not None:
            try:
                on_item(results)
            except Exception as e:
                log(f"process_all_visible on_item callback raised {e!r} -- ignoring, run continues.")
        if result["status"] == "nothing_to_do":
            break
        if should_stop is not None:                   # 10/19: an express appeared -- hand the bot to it now
            try:
                why = should_stop()
                if why:                                # True = express; a text = another reason (10/19 time cap)
                    log("process_all_visible: " + (why if isinstance(why, str) else
                        "an EXPRESS order is on the Food Club board -- stopping the clipboard work so the "
                        "express goes first."))
                    break
            except Exception:                         # noqa: BLE001
                pass
        # A successful recursion (e.g. Wheat harvested/replanted) isn't
        # added to skip -- the same item should be re-discovered and
        # rechecked next cycle now that its ingredient may be sufficient,
        # rather than being permanently written off. Same reasoning for
        # collected_blocker (9/27): the ready-to-collect item just
        # collected to open the panel may have already satisfied the
        # order, so this item needs a fresh Orders-board look on the very
        # next iteration of THIS loop, not a skip that would delay
        # noticing that until the next whole GUI cycle a minute later.
        if result.get("slot_key") and result["status"] not in ("recursed_ingredient", "collected_blocker",
                                                                  "retry_next_ingredient", "learned_icon"):
            skip.append(result["slot_key"])
    status_counts = {}
    for r in results:
        status_counts[r["status"]] = status_counts.get(r["status"], 0) + 1
    not_trained_total = len(os.listdir(PENDING_DIR)) if os.path.isdir(PENDING_DIR) else 0
    log(f"=== process_all_visible complete -- {len(results)} item(s) processed, "
        f"breakdown {status_counts} -- {not_trained_total} icon(s) currently sitting in "
        f"the pending-training backlog ===")
    for line in format_run_report(results).split("\n"):
        log(line)
    return results


def summarize_missing(results):
    """Aggregates a process_all_visible() results list into a shopping-
    list-style summary -- how many of each ingredient is currently
    blocking progress, and which dishes still need something -- so a
    human (or the GUI) can see "what do I need to be making" at a
    glance instead of reading through every individual item's log line.
    Purely a reporting aggregation built from data main() already
    collects (missing_ingredients on a blocked_on_ingredient result);
    does not change any decision/action logic. 'unidentified' covers a
    red slot whose ingredient isn't in the trained ingredient library yet
    (see identify_ingredient) -- still worth surfacing as "something is
    needed here," just not nameable yet."""
    ingredient_counts = {}
    dish_counts = {}
    for r in results:
        status = r["status"]
        if status in ("blocked_on_ingredient", "ingredients_unreadable", "recursed_ingredient"):
            dish_name = r.get("dish") or "unidentified dish"
            dish_counts[dish_name] = dish_counts.get(dish_name, 0) + 1
            for ing in r.get("missing_ingredients", []):
                ing = ing or "unidentified"
                ingredient_counts[ing] = ingredient_counts.get(ing, 0) + 1
        elif status == "not_trained":
            dish_counts["(untrained dish)"] = dish_counts.get("(untrained dish)", 0) + 1
    return {"ingredient_counts": ingredient_counts, "dish_counts": dish_counts}


def format_run_report(results, served=0):
    """Human-readable, multi-line summary of a process_all_visible() run
    -- built 9/27 per user request for 'a nice readable report after
    every run', instead of having to parse a raw status-count dict or
    scroll back through every individual item's log lines. Purely a
    presentation layer on top of data process_all_visible()/
    summarize_missing() already collect -- changes no decision logic."""
    lines = []
    lines.append("===== Auto Fulfill Orders — run report =====")
    lines.append(f"Served: {served}    Items checked: {len(results)}")

    cooked = [r["dish"] for r in results if r["status"] == "queued" and r.get("dish")]
    if cooked:
        lines.append(f"Cooked/queued: {', '.join(cooked)}")

    recursed = [r["dish"] for r in results if r["status"] == "recursed_ingredient" and r.get("dish")]
    if recursed:
        lines.append(f"Chased down an ingredient for: {', '.join(recursed)}")

    collected = sum(1 for r in results if r["status"] == "collected_blocker")
    if collected:
        lines.append(f"Cleared a ready-to-collect blocker (rechecking fresh): {collected}")

    blocked = [(r.get("dish") or "unidentified", r.get("missing_ingredients") or [])
               for r in results if r["status"] == "blocked_on_ingredient"]
    if blocked:
        parts = [f"{d} (needs {', '.join(m) if m else 'something unidentified'})" for d, m in blocked]
        lines.append(f"Still blocked: {'; '.join(parts)}")

    unreadable = sum(1 for r in results if r["status"] == "ingredients_unreadable")
    if unreadable:
        lines.append(f"Ingredient read looked wrong, skipped rather than guess: {unreadable}")

    not_trained = sum(1 for r in results if r["status"] == "not_trained")
    if not_trained:
        lines.append(f"New dish(es) found, saved for training: {not_trained}")

    not_trained_total = len(os.listdir(PENDING_DIR)) if os.path.isdir(PENDING_DIR) else 0
    if not_trained_total:
        lines.append(f"Pending-training backlog now: {not_trained_total} icon(s)")

    panel_issues = sum(1 for r in results if r["status"] in ("panel_not_opened", "travel_failed", "dish_card_not_found"))
    if panel_issues:
        lines.append(f"Navigation hiccup (panel/travel didn't open as expected): {panel_issues}")

    summary = summarize_missing(results)
    if summary["ingredient_counts"]:
        ing_line = ", ".join(f"{k} x{v}" for k, v in
                              sorted(summary["ingredient_counts"].items(), key=lambda kv: -kv[1]))
        lines.append(f"Ingredients currently needed: {ing_line}")

    if len(results) == 1 and results[0]["status"] == "nothing_to_do":
        lines.append("Nothing to do -- the whole board is either satisfied or already blocked.")

    lines.append("=============================================")
    return "\n".join(lines)


if __name__ == "__main__":
    main()
