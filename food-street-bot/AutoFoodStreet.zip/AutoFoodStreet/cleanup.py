"""11/14 (owner: "help me delete the old photos we don't need, my PC is filling up"): free disk space on the PC.

Two parts, both from Settings > Updates and logs > "Free up space":
1. old DEBUG pictures -- the screens the bot saves for Claude to look at (fail pictures, unknown screens, test shots,
   ad / Let Me Play recordings ...). They are already on GitHub or no longer needed. Files older than KEEP_DAYS are
   deleted; the newest KEEP_NEWEST of every folder always stay. Never touches anything the bot reads to play
   (dish pictures, digit shapes, trained icons, plant-bar library, dishes_pending ...).
2. git's copy of the whole history (.git, several GB): `fetch --depth 1` + gc keeps only the newest version.
   Update and Send logs work the same afterwards.
Also at every Start (setting "Delete old debug pictures at Start", default on): part 1 with AUTO_DAYS.
"""
import os
import shutil
import time

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATES = os.path.join(HERE, "templates")
# folders the bot only WRITES (pictures for Claude / Muse); nothing reads them to play
DEBUG_DIRS = ("tests", "fail_pictures", "unknown_screens", "event_tapfail", "event_pending", "recover_debug",
              "let_me_play", "bush_misses", "unstuck", "ad_training", "training_shots", "reward_headers",
              "count_unknown", "time_labels_unknown", "chef_pending", "street_truck_debug", "busy_prices",
              "learned", "orchard/seen", "picked_trees/seen", "food_truck/seen", "event_digits_pending")
# NOT here (read while playing): recipe_test (its ingredients/ pictures name items), dishes_pending (training queue),
# dishes, plant_bar_library, crop_cards, tooltip_names, stock_digits, ... and every path in afsd_tools.UPDATE_PATHS
PIC_EXT = (".png", ".jpg", ".jpeg")
KEEP_DAYS = 3          # "Free up space" button
AUTO_DAYS = 7          # automatic at Start
KEEP_NEWEST = 10       # per folder, always kept


def _pictures(folder):
    out = []
    for root, _dirs, files in os.walk(folder):
        for f in files:
            if f.lower().endswith(PIC_EXT):
                p = os.path.join(root, f)
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                out.append((p, st.st_mtime, st.st_size))
    return out


def plan(base=TEMPLATES, days=KEEP_DAYS, now=None, keep_newest=KEEP_NEWEST):
    """Pictures to delete: in DEBUG_DIRS, older than `days`, not among the newest `keep_newest` of their folder.
    Returns (paths, bytes)."""
    now = time.time() if now is None else now
    paths, total = [], 0
    for d in DEBUG_DIRS:
        pics = sorted(_pictures(os.path.join(base, d)), key=lambda t: -t[1])
        for p, mt, size in pics[keep_newest:]:
            if now - mt > days * 86400:
                paths.append(p)
                total += size
    return paths, total


def delete(paths):
    gone, freed = 0, 0
    for p in paths:
        try:
            size = os.path.getsize(p)
            os.remove(p)
            gone += 1
            freed += size
        except OSError:
            pass
    for d in DEBUG_DIRS:                                  # empty recording folders (let_me_play/play_*, ad live_*)
        for root, dirs, files in os.walk(os.path.join(TEMPLATES, d), topdown=False):
            if root != os.path.join(TEMPLATES, d) and not os.listdir(root):
                try:
                    os.rmdir(root)
                except OSError:
                    pass
    return gone, freed


def folder_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def gb(n):
    return f"{n / 1e9:.1f} GB" if n >= 1e9 else f"{n / 1e6:.0f} MB"


def shrink_git(git, progress=lambda *a: None, base=HERE):
    """Keep only the newest version in .git. `git(*args, timeout=...)` -> (rc, out) (afsd_tools._git).
    Returns (ok, message, bytes freed)."""
    gitdir = os.path.join(base, ".git")
    before = folder_size(gitdir)
    progress("Free up space: getting only the newest version from GitHub...", 0.2)
    rc, out = git("fetch", "-q", "--depth", "1", "origin", "main", timeout=600)
    if rc != 0:
        return False, f"could not reach GitHub ({out.strip()[-120:]})", 0
    git("reset", "-q", "origin/main")                    # keeps every file on disk; only moves git's pointer
    rc, refs = git("for-each-ref", "--format=%(refname)", "refs/remotes/origin")
    for r in (refs or "").split():
        if r.strip() not in ("refs/remotes/origin/main", "refs/remotes/origin/HEAD"):
            git("update-ref", "-d", r.strip())          # old branch copies keep old pictures alive
    progress("Free up space: throwing away old history (can take a few minutes)...", 0.5)
    git("reflog", "expire", "--expire=now", "--all")
    rc, out = git("gc", "-q", "--prune=now", timeout=1800)
    after = folder_size(gitdir)
    if rc != 0:
        return False, f"git clean-up stopped: {out.strip()[-120:]}", max(0, before - after)
    return True, f"git history {gb(before)} -> {gb(after)}", max(0, before - after)


def free_space(git=None, progress=lambda *a: None, days=KEEP_DAYS, shrink=True):
    """The button: old pictures, then git. Returns (ok, message)."""
    paths, size = plan(days=days)
    progress(f"Free up space: deleting {len(paths)} old pictures ({gb(size)})...", 0.05)
    gone, freed = delete(paths)
    msg = f"Free up space: deleted {gone} old pictures ({gb(freed)})"
    ok = True
    if shrink and git is not None:
        ok, gmsg, gfreed = shrink_git(git, progress)
        freed += gfreed
        msg += f"; {gmsg}"
    try:
        free = shutil.disk_usage(HERE).free
        msg += f". {gb(freed)} freed in all -- {gb(free)} free on the disk now."
    except OSError:
        msg += f". {gb(freed)} freed in all."
    return ok, msg
