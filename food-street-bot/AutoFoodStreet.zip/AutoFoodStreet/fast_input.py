"""FLASH step 3 (11/1): taps, swipes and the Back key through ONE adb shell that stays open.

Every tap used to start a new adb.exe (Windows process start + adb handshake), ~0.3-0.5 s each, ~1,000+ an hour.
Here one `adb -s <device> shell` stays open; each action is written to it as a line followed by an echo marker,
and we wait for the marker (so the action has FINISHED, exactly like before). Any problem -> the shell is closed,
the caller falls back to the old one-adb-per-tap way, and fast taps rest REST_SEC before trying again.
Settings > Speed > "FLASH fast taps" (off by default) sets ON."""
import os
import queue
import subprocess
import threading
import time

ON = False
TIMEOUT_SEC = 8.0           # one tap/swipe/key; a swipe of N ms takes N ms plus a little
REST_SEC = 300              # after a failure, old taps for 5 min
NOTE_SEC = 300

_st = {"p": None, "dev": None, "q": None, "n": 0, "rest_until": 0.0, "fails": 0, "ok": 0, "sec": 0.0,
       "noted": 0.0}
_lock = threading.Lock()
LOG = None


def _log(msg):
    try:
        if LOG:
            LOG(msg)
    except Exception:                                   # noqa: BLE001
        pass


def marker(n):
    """Pure: the echo line that tells us action n finished."""
    return f"__AFSD_OK_{n}__"


def command_line(args, n):
    """Pure: ['shell', 'input', 'tap', '5', '6'] -> 'input tap 5 6; echo __AFSD_OK_n__'. None = not a shell action."""
    if not args or args[0] != "shell" or len(args) < 2:
        return None
    safe = all(str(a).replace("_", "").replace("-", "").replace("/", "").replace(".", "").isalnum() for a in args[1:])
    if not safe:
        return None
    return " ".join(str(a) for a in args[1:]) + f"; echo {marker(n)}"


def _reader(p, q):
    try:
        for line in iter(p.stdout.readline, b""):
            q.put(line)
    except Exception:                                   # noqa: BLE001
        pass
    q.put(None)


def _close():
    p = _st["p"]
    _st.update({"p": None, "dev": None, "q": None})
    if p is not None:
        try:
            p.kill()                                    # never wait on its pipes (the 10/19 hang)
        except Exception:                               # noqa: BLE001
            pass


def _open(adb, dev):
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    p = subprocess.Popen([adb, "-s", dev, "shell"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, creationflags=flags)
    q = queue.Queue()
    threading.Thread(target=_reader, args=(p, q), daemon=True).start()
    _st.update({"p": p, "dev": dev, "q": q})


def _fail(why):
    _close()
    _st["fails"] += 1
    _st["rest_until"] = time.time() + REST_SEC
    if time.time() - _st["noted"] > NOTE_SEC:
        _st["noted"] = time.time()
        _log(f"[flash] fast taps: {why} -- using the old taps for {REST_SEC // 60} min "
             f"({_st['fails']} failures, {_st['ok']} fast taps this run).")


def send(args, adb, dev, timeout=TIMEOUT_SEC):
    """True when the action went to the open shell; False = nothing was sent, the caller uses the old way.
    Once the line is written we never report False: a second tap from the fallback could land on a dialog the
    first tap opened (a gem Yes in the same spot). A tap that did not happen shows on the next look, as before."""
    if not ON or time.time() < _st["rest_until"]:
        return False
    with _lock:
        _st["n"] += 1
        n = _st["n"]
        line = command_line(args, n)
        if line is None:
            return False
        t0 = time.time()
        sent = False
        try:
            if _st["p"] is None or _st["p"].poll() is not None or _st["dev"] != dev:
                _close()
                _open(adb, dev)
            _st["p"].stdin.write((line + "\n").encode())
            _st["p"].stdin.flush()
            sent = True
            want = marker(n).encode()
            end = t0 + timeout
            while True:
                left = end - time.time()
                if left <= 0:
                    _fail("no answer in time")
                    return True                         # sent: never tap twice
                try:
                    got = _st["q"].get(timeout=left)
                except queue.Empty:
                    continue
                if got is None:
                    _fail("the adb shell closed")
                    return True
                if want in got:
                    break
        except Exception as e:                          # noqa: BLE001
            _fail(f"error {e!r}"[:120])
            return sent
        _st["ok"] += 1
        _st["sec"] += time.time() - t0
        return True


def stats():
    return {"ok": _st["ok"], "sec": _st["sec"], "fails": _st["fails"]}


def reset():
    with _lock:
        _close()
        _st.update({"n": 0, "rest_until": 0.0, "fails": 0, "ok": 0, "sec": 0.0, "noted": 0.0})
