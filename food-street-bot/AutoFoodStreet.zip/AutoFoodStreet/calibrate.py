"""One-off calibration: measure how far the camera actually pans for a
given swipe, by template-matching a patch of world content (not UI chrome)
from the before-screenshot against the after-screenshot.
"""
import sys
import time
import cv2
from adb_helper import screenshot, swipe

x1, y1, x2, y2, duration = (int(v) for v in sys.argv[1:6])

before = screenshot()
# Patch from the middle of the screen, well clear of the top/bottom HUD bars.
px, py, pw, ph = 700, 350, 160, 160
patch = before[py:py + ph, px:px + pw]

swipe(x1, y1, x2, y2, duration)
time.sleep(1)
after = screenshot()

res = cv2.matchTemplate(after, patch, cv2.TM_CCOEFF_NORMED)
_, max_val, _, max_loc = cv2.minMaxLoc(res)

dx = max_loc[0] - px
dy = max_loc[1] - py
print(f"swipe({x1},{y1} -> {x2},{y2}, {duration}ms)")
print(f"match confidence: {max_val:.3f}")
print(f"camera shift: dx={dx} dy={dy}  (world content moved by -dx,-dy on screen)")
