"""Unstuck ladder. 10/20 log-only test; LIVE since 10/22 for covered screens (see LIVE below).

Why: night 10/19-20 one screen with a red X at (1540,122) sat on top of the game for 7 hours; the bot tapped that
same X 599 times and never tried anything else. The plan: notice being stuck, try a ladder of safe escapes (Android
Back key, other X spots, empty space, restart game, restart LDPlayer), remember which escape cleared each screen
(a small fingerprint), and use it straight away next time. Never a gem / buy / Unlock / Open / Skip / trash button.

This first step only WATCHES: once a minute (from the run loop) it takes one screenshot; when the same covered
screen (map dimmed by something), or a frozen identical frame, lasts STUCK_MIN_SEC, it logs `[unstuck test] ...
WOULD press Back` with the screen's fingerprint, keeps one picture per new screen in templates/unstuck/ (in Send
logs), and counts how often each screen came back in .unstuck.json. Taps nothing.
"""
import json
import os
import time

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PIC_DIR = os.path.join(BASE_DIR, "templates", "unstuck")
LIB_FILE = os.path.join(BASE_DIR, ".unstuck.json")
SAMPLE_SEC = 60
STUCK_MIN_SEC = 300
SAME_MAX_DIFF = 6.0          # mean grey difference of two 64x36 thumbnails that still counts as "the same screen"
LADDER = ("Android Back key", "red X (other spots)", "tap empty space", "restart the game", "restart LDPlayer")
# 10/22 (owner: "lets switch it on ... logs tell when it was used, which one, and what worked"): LIVE for COVERED
# screens (the map dimmed by a popup/panel for STUCK_MIN_SEC). A FROZEN plain map stays log-only: the bot may just be
# idle there, and Back on the plain map can open the game's exit question (adb freezes are the watchdog's job).
LIVE = True
RETRY_SEC = 15 * 60                  # a ladder that cleared nothing is climbed again after this
GAME_RESTART_GAP_SEC = 30 * 60       # rung 4 at most this often
EMPTY_SPOT = (60, 420)               # far from the plots / buttons (garden_check.CLOSE_BAR_CANDIDATES)
_stats = {"used": 0, "worked": {}, "failed": {}}

_st = {"t": 0.0, "thumb": None, "since": None, "kind": None, "logged": False, "moved": False,
       "next_try": 0.0, "game_restart": 0.0}


def _moved_observer(img):
    """10/20 live: during an express the bot shuttled Deli <-> Snack Stand, so two samples a minute apart showed the
    same map and it was called "frozen" for 5 min. Every screenshot the bot takes itself is compared too: if any of
    them differs from the last sample, the screen is not stuck. Only runs while a stuck candidate is open."""
    if _st["since"] and not _st["moved"] and _st["thumb"] is not None and img is not None \
            and img.shape[:2] == (900, 1600):
        if float(np.abs(_thumb(img) - _st["thumb"]).mean()) > SAME_MAX_DIFF:
            _st["moved"] = True


def _thumb(img):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    g[:90, :] = 0                                   # top HUD (coins, gems, timers) changes on its own
    return cv2.resize(g, (64, 36), interpolation=cv2.INTER_AREA).astype(np.float32)


def fingerprint(img):
    """Short id of a screen: 8x8 average hash of the screen below the HUD, as 16 hex digits."""
    g = cv2.resize(cv2.cvtColor(img[90:, :], cv2.COLOR_BGR2GRAY), (8, 8), interpolation=cv2.INTER_AREA)
    bits = (g > g.mean()).flatten()
    return "%016x" % int("".join("1" if b else "0" for b in bits), 2)


def _red_x(img):
    try:
        import find_and_center as fac
        res = cv2.matchTemplate(img[50:250, 1150:1580], fac.CLOSE_X_TEMPLATE, cv2.TM_CCOEFF_NORMED)
        _mn, mx, _l, loc = cv2.minMaxLoc(res)
        th, tw = fac.CLOSE_X_TEMPLATE.shape[:2]
        return (loc[0] + 1150 + tw // 2, loc[1] + 50 + th // 2, round(float(mx), 2)) if mx >= 0.7 else None
    except Exception:                                # noqa: BLE001
        return None


def _library():
    try:
        with open(LIB_FILE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _remember(fp, kind, img, mins, xinfo):
    lib = _library()
    e = lib.setdefault(fp, {"first": time.strftime("%Y-%m-%d %H:%M"), "times": 0, "kind": kind, "escape": None})
    e["times"] += 1
    e["last"] = time.strftime("%Y-%m-%d %H:%M")
    e["longest_min"] = max(e.get("longest_min", 0), mins)
    if xinfo:
        e["red_x"] = list(xinfo[:2])
    try:
        with open(LIB_FILE, "w", encoding="utf-8") as fh:
            json.dump(lib, fh, indent=1)
    except OSError:
        pass
    if e["times"] == 1:
        try:
            os.makedirs(PIC_DIR, exist_ok=True)
            cv2.imwrite(os.path.join(PIC_DIR, f"{fp}.png"), img)
        except Exception:                            # noqa: BLE001
            pass
    return e


def _save_escape(fp, rung, ok):
    lib = _library()
    e = lib.setdefault(fp, {"first": time.strftime("%Y-%m-%d %H:%M"), "times": 0, "escape": None})
    tries = e.setdefault("tries", {})
    t = tries.setdefault(rung, {"worked": 0, "failed": 0})
    t["worked" if ok else "failed"] += 1
    if ok:
        e["escape"] = rung
        e["escape_when"] = time.strftime("%Y-%m-%d %H:%M")
    try:
        with open(LIB_FILE, "w", encoding="utf-8") as fh:
            json.dump(lib, fh, indent=1)
    except OSError:
        pass


def _do_rung(rung, img, act, log):
    """Performs one rung. Returns False when it was skipped (not allowed right now)."""
    import adb_helper
    if rung == LADDER[0]:
        adb_helper.back()
    elif rung == LADDER[1]:
        import find_and_center as fac
        if fac.dismiss_error_dialog():                 # a known popup's own safe button (Okay / X)
            return True
        x = _red_x(img)
        if not x:
            log("[unstuck]   no red X on screen -- rung skipped.")
            return False
        adb_helper.tap(x[0], x[1])
    elif rung == LADDER[2]:
        adb_helper.tap(*EMPTY_SPOT)
    elif rung == LADDER[3]:
        if time.time() - _st["game_restart"] < GAME_RESTART_GAP_SEC or not act.get("restart_game"):
            log("[unstuck]   the game was restarted less than 30 min ago -- rung skipped.")
            return False
        _st["game_restart"] = time.time()
        act["restart_game"]()
    elif rung == LADDER[4]:
        if not act.get("restart_ldplayer"):
            return False
        act["restart_ldplayer"]()
    return True


def _climb(fp, mins, img, act, log):
    """The live ladder: each rung, then a fresh look. Logs every step; remembers what worked per screen."""
    import adb_helper
    import event_orders as eo
    known = (_library().get(fp) or {}).get("escape")
    order = ([known] if known in LADDER else []) + [r for r in LADDER if r != known]
    _stats["used"] += 1
    log(f"[unstuck] USED: screen #{fp} covered for {mins} min -- climbing the ladder"
        + (f" (remembered escape first: {known})" if known else "") + ".")
    for i, rung in enumerate(order, 1):
        log(f"[unstuck]   try {i}: {rung}")
        if not _do_rung(rung, img, act, log):
            continue
        time.sleep(20 if rung in LADDER[3:] else 3)
        after = adb_helper.screenshot()
        if after is not None and after.shape[:2] == (900, 1600) and eo.hud_is_bright(after):
            log(f"[unstuck]   WORKED: {rung} cleared screen #{fp} (map is clear again). Remembered for next time.")
            _save_escape(fp, rung, True)
            _stats["worked"][rung] = _stats["worked"].get(rung, 0) + 1
            _summary(log)
            return True
        fp2 = fingerprint(after) if after is not None else "?"
        log(f"[unstuck]   {rung} did NOT clear it -- still covered"
            + (" (same screen)." if fp2 == fp else f" (now screen #{fp2})."))
        _save_escape(fp, rung, False)
        _stats["failed"][rung] = _stats["failed"].get(rung, 0) + 1
        if after is not None:
            img = after
    log(f"[unstuck] nothing on the ladder cleared screen #{fp} -- trying again in {RETRY_SEC // 60} min.")
    _summary(log)
    return False


def _summary(log):
    w = ", ".join(f"{k} {v}" for k, v in _stats["worked"].items()) or "none"
    f = ", ".join(f"{k} {v}" for k, v in _stats["failed"].items()) or "none"
    log(f"[unstuck] this run: ladder used {_stats['used']}x; worked: {w}; did not work: {f}.")


def tick(log, running_job=True, act=None):
    """Call once per cycle; does real work at most every SAMPLE_SEC. Never raises. With act (callbacks
    restart_game / restart_ldplayer from afsd_core) and LIVE, a COVERED screen gets the ladder."""
    now = time.time()
    if now - _st["t"] < SAMPLE_SEC:
        return
    _st["t"] = now
    try:
        import adb_helper
        import event_orders as eo
        img = adb_helper.screenshot()
        if img is None or img.shape[:2] != (900, 1600):
            return
        th = _thumb(img)
        covered = not eo.hud_is_bright(img)
        if covered and eo.board_is_open(img):
            covered = False                          # 10/31: the Food Club board is the bot's own screen (17 of 41 "stuck")
        same = _st["thumb"] is not None and float(np.abs(th - _st["thumb"]).mean()) <= SAME_MAX_DIFF
        kind = "covered" if covered else ("frozen" if same else None)
        # stuck = the same covered screen, or an identical frame, sample after sample
        if kind and same and _st["kind"] == kind and not _st["moved"]:
            pass
        elif kind:
            if _st["since"] and _st["logged"]:
                log(f"[unstuck test] the stuck screen went away after {int((now - _st['since']) // 60)} min "
                    "(by itself / by the bot's normal steps).")
            _st.update(since=now, kind=kind, logged=False, next_try=0.0)
        else:
            if _st["since"] and _st["logged"]:
                log(f"[unstuck test] the stuck screen went away after {int((now - _st['since']) // 60)} min "
                    "(by itself / by the bot's normal steps).")
            _st.update(since=None, kind=None, logged=False)
        _st["thumb"] = th
        _st["moved"] = False
        if not _st["since"] or now - _st["since"] < STUCK_MIN_SEC:
            return
        mins = int((now - _st["since"]) // 60)
        if LIVE and act is not None and _st["kind"] == "covered" and now >= _st["next_try"]:
            fp = fingerprint(img)
            _remember(fp, "covered", img, mins, _red_x(img))
            _st["logged"] = True
            if _climb(fp, mins, img, act, log):
                _st.update(since=None, kind=None, logged=False, thumb=None, next_try=0.0)
            else:
                _st["next_try"] = time.time() + RETRY_SEC
            _st["t"] = time.time()
            return
        if _st["logged"] and mins % 15:              # first time, then every 15 min while it lasts
            return
        _st["logged"] = True
        fp = fingerprint(img)
        xinfo = _red_x(img)
        e = _remember(fp, _st["kind"], img, mins, xinfo)
        what = ("the map is covered by something" if _st["kind"] == "covered"
                else "the picture has not changed at all (frozen?)")
        log(f"[unstuck test] stuck {mins} min on screen #{fp} -- {what}"
            + (f"; red X at ({xinfo[0]},{xinfo[1]}) {xinfo[2]}" if xinfo else "; no red X found")
            + f". Seen {e['times']}x so far (longest {e.get('longest_min', mins)} min). "
            f"WOULD try: {LADDER[0]} first, then {', '.join(LADDER[1:])}."
            + (" Picture saved: templates/unstuck/" + fp + ".png" if e["times"] == 1 else ""))
    except Exception as ex:                          # noqa: BLE001 -- a test must never break the run
        try:
            log(f"[unstuck test] skipped: {ex!r}")
        except Exception:                            # noqa: BLE001
            pass


try:
    import adb_helper as _ah
    _ah.SCREENSHOT_OBSERVERS[:] = [f for f in _ah.SCREENSHOT_OBSERVERS
                                   if getattr(f, "__name__", "") != "_moved_observer"] + [_moved_observer]
except Exception:                                    # noqa: BLE001
    pass
