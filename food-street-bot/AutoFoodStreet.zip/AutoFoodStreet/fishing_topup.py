"""fishing_topup.py -- "always be fishing" (owner's rule, 10/14). Runs as the LAST step of each Auto Fulfill Orders pass.

1. Reach the Fisherman's Boat by fast travel: the Orders board item of a fish/seaweed dish (sushi boat, miso soup, tamago sushi, grilled fish,
   salad nicoise) -> its station -> the fish/seaweed ingredient icon -> '?' -> boat. (No such order on the board = no route yet; see NOTE.)
2. At the boat order_fulfill.recurse_produced_ingredient does the work: collect finished catches, queue Mystery Catches into EMPTY slots, then keep
   2 Fishing Hooks (Lighthouse, HOOK card only -- pass 88 guards against the rake / bait cards).
3. Work out how much fish and seaweed the board still needs; sell the extras (trade_sell, max price) keeping 2 spare.
NOTE: a route without any board order needs a picture of the Boat / Sushi Bar on the map (not captured yet).
"""
import datetime
import json
import os
import time

import order_fulfill as of
import recipe_book as rb
import trade_sell
from adb_helper import screenshot
from find_and_center import close_any_open_panel, interruptible_sleep, StopRequested

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(BASE_DIR, "run_log.txt")
STATE = os.path.join(BASE_DIR, ".fishing_state.json")
VISIT_GAP_SEC = 15 * 60          # a catch takes 30 min, so once per ~15 min is plenty
SELL_GAP_SEC = 60 * 60
KEEP_SPARE = 2                   # sell only what is above (orders' need + 2)
FISH_DISHES = {"sushi_boat", "miso_soup", "tamago_egg_sushi", "grilled_fish", "salad_nicoise"}
RAW = {"fish", "seaweed"}


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] [fishing] {msg}\n")
    except OSError:
        pass
    try:
        print(f"[{ts}] [fishing] {msg}")
    except (AttributeError, OSError):
        pass


def _state():
    try:
        return json.load(open(STATE, encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(st):
    try:
        json.dump(st, open(STATE, "w", encoding="utf-8"))
    except OSError:
        pass


def needs_from_plan(plan=None):
    """-> {"fish": n, "seaweed": m} still needed by the orders on the board (dishes already in stock not counted), or None if the plan is not reliable."""
    plan = plan if plan is not None else of.LAST_ORDER_PLAN
    if not plan.get("reliable") or not plan.get("items"):
        return None
    items = rb.load()["items"]
    out = {"fish": 0, "seaweed": 0}

    def walk(name, qty):
        if name in RAW:
            out[name] += qty
            return
        try:
            key = rb.resolve(name)
        except KeyError:
            return
        it = items.get(key)
        for ing, cnt in (it["ingredients"] if it else []):
            walk(ing, qty * int(cnt))

    for order in plan["items"]:
        for it in order:
            gap = max(0, int(it["need"]) - int(it["have"] or 0))
            if gap:
                walk(it["name"], gap)
    return out


def _page_candidates(img):
    """[(name, x, y)] fish/seaweed items on this board page (tap points)."""
    out = []
    for o in of.read_orders_page(img):
        for it in o["items"]:
            if it["name"] in FISH_DISHES or it["name"] in RAW:
                x = o["cx"] + of.SLOT_DX[it["col"]]
                y = of.SLOT_ROWS[it["row"]][0]
                out.append((it["name"], x, y))
    return out


def _wait_panel(stop_flag, tries=4):
    for _ in range(tries):
        interruptible_sleep(1.0, stop_flag)
        if of.panel_is_open(screenshot()):
            return True
    return False


def visit_boat(stop_flag=None):
    """Board -> fish/seaweed item -> boat; then recurse_produced_ingredient queues catches + tops up hooks. True if the boat was reached."""
    close_any_open_panel(quiet=True)
    of.open_board_smart(stop_flag)
    of.reset_orders_scroll(stop_flag)
    for page in (0, 1):
        img = screenshot()
        cands = _page_candidates(img)
        if cands:
            name, x, y = cands[0]
            log(f"route: board item '{name}' at ({x},{y}) (page {page + 1})")
            if name in RAW:
                of.recurse_produced_ingredient(name, (x, y), stop_flag, depth=0)
                return True
            if not of.travel_to_missing_item({"tap_loc": (x, y)}, stop_flag):
                log("route: the quick-travel '?' did not show -- will try again next time.")
                of.close_panel_if_open()
                return False
            if not _wait_panel(stop_flag):
                log("route: the station panel did not open.")
                return False
            cx, _conf = of.locate_dish_card(name, stop_flag)
            if cx is None:
                log(f"route: could not find the '{name}' card by sight.")
                of.close_panel_if_open()
                return False
            ings = of.read_ingredients(screenshot(), cx, dish_name=name)
            pick = next(((n, x2, y2) for _c, x2, y2, n in ings if n in RAW), None)
            if pick is None:
                log(f"route: no fish/seaweed icon read on the '{name}' card: {ings}")
                of.close_panel_if_open()
                return False
            of.recurse_produced_ingredient(pick[0], (pick[1], pick[2]), stop_flag, depth=0)
            return True
        if page == 0:
            of.swipe_to_far_end(stop_flag)
    log("route: no fish/seaweed order on the board -- no way to the boat this time (see NOTE in fishing_topup.py).")
    return False


def run(stop_flag=None, force=False, keep=None, use_orders=True):
    """Called once per cycle when "Keep fishing (sell extras)" is ticked. Never raises (except a Stop request).
    keep = fish / seaweed to hold back (None -> KEEP_SPARE). use_orders=True (Auto Fulfill Orders ticked): keep the
    orders' need + keep, and skip selling if the plan was not read reliably. use_orders=False: keep just `keep` of
    each, so storage does not fill up with catches nobody is using (owner, 10/15)."""
    keep = KEEP_SPARE if keep is None else int(keep)
    st = _state()
    now = time.time()
    try:
        if force or now - st.get("visit", 0) >= VISIT_GAP_SEC:
            st["visit"] = now
            _save(st)
            log("always-fishing visit starting.")
            try:
                reached = visit_boat(stop_flag)
            finally:
                close_any_open_panel(quiet=True)
            log(f"always-fishing visit done (boat reached: {reached}).")
        if force or now - st.get("sell", 0) >= SELL_GAP_SEC:
            needs = needs_from_plan() if use_orders else {"fish": 0, "seaweed": 0}
            if not use_orders:
                log(f"Auto Fulfill Orders is off -- keeping {keep} of each, selling the rest.")
            if needs is None:
                log("sell check skipped: the orders were not all read reliably this pass (nothing is sold on a guess).")
            else:
                st["sell"] = now
                _save(st)
                res = trade_sell.sell_extras(needs, keep=keep, stop_flag=stop_flag)
                log(f"sell check done: {res}")
    except StopRequested:
        raise
    except Exception as e:                                      # noqa: BLE001
        log(f"fishing step failed (ignored): {e!r}")
        try:
            close_any_open_panel(quiet=True)
        except Exception:                                       # noqa: BLE001
            pass
