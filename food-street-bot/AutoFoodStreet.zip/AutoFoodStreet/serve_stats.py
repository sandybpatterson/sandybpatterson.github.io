"""Orders and coins per hour from served_orders.csv (written by order_fulfill.note_serve_reward). Usage: python serve_stats.py"""
import collections
import csv
import os

PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "served_orders.csv")


def main():
    if not os.path.exists(PATH):
        print("no served_orders.csv yet")
        return
    hours = collections.OrderedDict()
    total_n = total_c = unread = 0
    for row in csv.DictReader(open(PATH, encoding="utf-8")):
        key = row["time"][:13]
        n, c = hours.get(key, (0, 0))
        reward = int(row["reward"]) if row["reward"] else 0
        hours[key] = (n + 1, c + reward)
        total_n += 1
        total_c += reward
        unread += 0 if row["reward"] else 1
    for k, (n, c) in hours.items():
        print(f"{k}:00  orders {n:3d}  coins +{c}")
    print(f"TOTAL orders {total_n}, coins +{total_c} ({unread} serve(s) with an unreadable reward)")


if __name__ == "__main__":
    main()
