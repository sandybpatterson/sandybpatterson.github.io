"""O.R.D.E.R. -- Order Ranks, Decides Every Run (owner 11/9: "whatever is in the number one slot should be the number
one priority ... project order should help us work this out for all jobs").

The jobs list is a priority list. Every job that has needs CLAIMS what it is still short of:
  Food Truck (street)  -> its open truck orders (.food_truck.json)
  Food Club Event      -> its board cards' short items + one level of their event recipes (milk for a Scareshake)
  Auto Fulfill Orders  -> what the open clipboard orders still miss
  Prep work            -> the placed Prep list minus the stock it has seen
  Chef Challenge       -> unfinished "produce this dish" tasks (.chef_claim.json, saved when its screen is read)
A job LOWER in the list may not cook or serve with anything a higher job's chain still needs (the claim expanded
through the recipe book: mac & cheese -> cheese -> milk -> cabbage; stock already seen is subtracted, so made milk
frees the cabbage). Everything outside those chains stays free, so idle stoves keep working. Expresses still beat
everything (afsd_core runs only Food Club then).

afsd_core sets ORDER (the ticked jobs, top first) and ON (Settings) each cycle, and CURRENT while a job runs.
order_fulfill asks `reserved_for(CURRENT)` before every cook and serve.
"""
import time

ON = True
ORDER = []                    # ticked job keys, top of the list first
CURRENT = [None]              # the job running right now
TRUCK, CLUB, CLIP, PREP, CHEF = ("Food Truck (street)", "Food Club Event", "Auto Fulfill Orders", "Prep work",
                                 "Chef Challenge")
CACHE_SEC = 20
_cache = {}
# 11/9 STARVATION GUARD (Muse: the clipboard held 14x for a truck whose corn the truck job never grows and whose cream
# is untrained -- 0 hand-ins all morning, 0 clipboard serves). A higher job's claim counts only while it is moving:
# if its total still-short count has not gone DOWN for STALL_SEC, the lower jobs stop holding for it (log once) until
# it moves again (or grows: new orders = a fresh clock). Truck claims also need a panel read in the last TRUCK_SEEN_SEC.
STALL_SEC = 30 * 60
TRUCK_SEEN_SEC = 45 * 60
_moving = {}                  # job -> [lowest total seen, time it last went down / was set, logged?]
LOG = [None]                  # afsd_core sets the log function (tick)


def moving(job, total, now=None):
    """Pure-ish: True while `job`'s claim total keeps going down (or is fresh)."""
    now = now or time.time()
    st = _moving.get(job)
    if st is None or total > st[0]:
        _moving[job] = [total, now, False]
        return True
    if total < st[0]:
        st[0], st[1], st[2] = total, now, False
        return True
    if now - st[1] < STALL_SEC:
        return True
    if not st[2] and LOG[0]:
        st[2] = True
        LOG[0](f"[o.r.d.e.r.] {short_name(job)}'s needs have not moved in {int((now - st[1]) // 60)} min -- the jobs "
               f"below it stop holding for it until it makes progress again.")
    return False


def _norm(name):
    return "".join(ch for ch in (name or "").lower() if ch.isalnum())


def book_key(name):
    """Recipe-book key for a name, or None (event items are not in the book)."""
    import recipe_book as rb
    n = (name or "").strip()
    for cand in (n, n.lower().replace(" & ", " and ").replace(" ", "_"), n.lower().replace(" ", "_")):
        try:
            return rb.resolve(cand)
        except Exception:                                  # noqa: BLE001
            continue
    return None


def key_of(name):
    """One key space for both worlds: recipe-book key, else 'n:<letters>' for event items."""
    return book_key(name) or ("n:" + _norm(name) if _norm(name) else None)


def higher(job, order=None):
    """Ticked jobs above `job` in the list (empty when job is unknown / on top)."""
    order = ORDER if order is None else order
    if job not in order:
        return []
    return order[:order.index(job)]


# --- what each job claims: {name: units still short} ---------------------------------------------------------------
def claim_truck(now=None):
    try:
        import order_fulfill as of
        import truck_panel
        out = {}
        st = truck_panel.load()
        if (now or time.time()) - (st.get("t") or 0) > TRUCK_SEEN_SEC:
            return {}                                      # 11/9 (Muse): no recent sighting -> no claim
        for _k, (name, wants, have) in of.truck_reserved(st, now).items():
            short = wants - (have or 0)
            if short > 0:
                out[name] = out.get(name, 0) + short
        return out
    except Exception:                                      # noqa: BLE001
        return {}


def club_claim(cards, book):
    """Pure: Food Club claim from the board. cards = [{name, have, need}] short items; book = {norm dish:
    [(ingredient, need)]} (event recipes the bot has read). The item itself plus one level of its ingredients."""
    out = {}
    for it in cards:
        short = (it.get("need") or 1) - (it.get("have") or 0)
        if short <= 0 or not it.get("name"):
            continue
        out[it["name"]] = out.get(it["name"], 0) + short
        for ing, q in book.get(_norm(it["name"]), []):
            out[ing] = out.get(ing, 0) + short * int(q or 1)
    return out


def claim_club():
    try:
        import event_orders as eo
        import orders_view
        _v, st = orders_view.snapshot()
        cards = [it for o in (st.get("Food Club Event") or {}).get("orders", []) for it in o["items"]
                 if it.get("name") and it.get("kind") != "done"]
        return club_claim(cards, eo._recipe_book())
    except Exception:                                      # noqa: BLE001
        return {}


def claim_clip():
    try:
        import order_fulfill as of
        return dict(of._open_missing())
    except Exception:                                      # noqa: BLE001
        return {}


def claim_prep():
    try:
        import prep_engine as pe
        order = pe._load()
        if not order.get("placed"):
            return {}
        out = {}
        for k, q in (order.get("items") or {}).items():
            have = pe._stock_known(order, k) or 0
            if int(q) - have > 0:
                out[k] = int(q) - have
        return out
    except Exception:                                      # noqa: BLE001
        return {}


def claim_chef():
    try:
        import chef_tasks
        return chef_tasks.load_claim()
    except Exception:                                      # noqa: BLE001
        return {}


CLAIMS = {TRUCK: claim_truck, CLUB: claim_club, CLIP: claim_clip, PREP: claim_prep, CHEF: claim_chef}


def known_stock():
    """{book key: n} seen recently (Prep's stock memory) -- lets a chain skip what is already made."""
    try:
        import prep_engine as pe
        order = pe._load()
        out = {}
        for k in (order.get("stock") or {}):
            n = pe._stock_known(order, k)
            if n is not None:
                out[k] = n
        return out
    except Exception:                                      # noqa: BLE001
        return {}


def expand(claim, stock=None):
    """Pure-ish: {key: units} for a claim {name: short} -- book items through the recipe book (every level),
    event items as 'n:' keys as they are."""
    import recipe_book as rb
    order, out = {}, {}
    for name, q in claim.items():
        bk = book_key(name)
        if bk:
            order[bk] = order.get(bk, 0) + q
        else:
            k = key_of(name)
            if k:
                out[k] = out.get(k, 0) + q
    if order:
        try:
            for k, d in rb.cost(order, stock=dict(stock or {}))["detail"].items():
                if d.get("needed"):
                    out[k] = out.get(k, 0) + d["needed"]
        except Exception:                                  # noqa: BLE001
            for k, q in order.items():
                out[k] = out.get(k, 0) + q
    return out


def reserved_for(job, now=None, claims=None, stock=None):
    """{key: (units, owner job)} that `job` must leave alone -- the chains of every ticked job above it."""
    if not ON or not job:
        return {}
    above = [j for j in higher(job) if j in CLAIMS]
    if not above:
        return {}
    now = now or time.time()
    ck = (job, tuple(above))
    if claims is None and stock is None and ck in _cache and now - _cache[ck][0] < CACHE_SEC:
        return _cache[ck][1]
    stock = known_stock() if stock is None else stock
    out = {}
    for j in above:
        c = (claims or {}).get(j) if claims is not None else CLAIMS[j]()
        if claims is None and c and not moving(j, sum(c.values()), now):
            continue
        for k, q in expand(c or {}, stock).items():
            u, owner = out.get(k, (0, j))
            out[k] = (u + q, owner)
    if claims is None:
        _cache[ck] = (now, out)
    return out


def conflict(name, have, need, reserved):
    """(units, owner) when using `need` of `name` (with `have` in storage) eats into a higher job's claim, else None.
    Unreadable counts -> the higher job wins."""
    k = key_of(name)
    if not k or k not in reserved:
        return None
    units, owner = reserved[k]
    if have is None or need is None or have - need < units:
        return units, owner
    return None


def short_name(job):
    return {TRUCK: "Food Truck", CLUB: "Food Club", CLIP: "Clipboard Orders", PREP: "Prep",
            CHEF: "Chef Challenge"}.get(job, job)


# --- tally for the logs: how often a lower job held back for a higher one -----------------------------------------
TALLY_SEC = 30 * 60
_tally = {}
_tally_t = [0.0]


def note_hold(job, owner, what):
    k = (short_name(job or CLIP), short_name(owner), what)
    _tally[k] = _tally.get(k, 0) + 1


def tally_line(now=None):
    """'[o.r.d.e.r.] last 30 min: Clipboard Orders held 4x for Food Truck (cabbage 3, milk 1); ...' or None."""
    now = now or time.time()
    if now - _tally_t[0] < TALLY_SEC:
        return None
    _tally_t[0] = now
    if not _tally:
        return None
    by = {}
    for (job, owner, what), n in _tally.items():
        d = by.setdefault((job, owner), {})
        d[what] = d.get(what, 0) + n
    _tally.clear()
    parts = [f"{job} held {sum(d.values())}x for {owner} (" + ", ".join(f"{w} {n}" for w, n in d.items()) + ")"
             for (job, owner), d in by.items()]
    return "[o.r.d.e.r.] last 30 min: " + "; ".join(parts)


def tick(log):
    """From the run loop: the tally line once per TALLY_SEC. Never raises."""
    LOG[0] = log
    try:
        line = tally_line()
        if line:
            log(line)
    except Exception:                                      # noqa: BLE001
        pass
