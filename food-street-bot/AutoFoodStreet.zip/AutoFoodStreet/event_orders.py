"""Auto Fulfill Orders for time-limited EVENTS (first built 10/2 for the
Storybook Cafe event). Designed so a different event with different art
still works: nothing here depends on event-specific templates.

Generic anchors used instead of per-event art:
  * the lime-green action buttons (Complete / Make / Gather / ...) -- found
    by colour + shape, never by their label text;
  * red/green count-text blobs for ingredient rows (a card with N
    ingredients shows N coloured blobs, wherever they sit);
  * SIFT feature matching to link a small board/ingredient icon to the big
    art on a station card (the two are different art assets at different
    scales, so plain template matching never works -- see CLAUDE.md);
  * the game's own "?" quick-travel tooltip for routing.

Safety rules baked in: never tap trash buttons, the hearts "+" upgrade,
the queue "Unlock" button, or any gem button. Never spend gems.
"""
import json
import re
import os
import sys
import time
import datetime

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import adb_helper
import order_fulfill as of
import event_digits
import find_and_center as fac
from find_and_center import StopRequested

LOG = os.path.join(BASE_DIR, "run_log.txt")

# Where the event's "orders list" icon sits on the bottom nav (the shoes icon
# for Storybook Cafe). Per-event; update here (or a future profile file) when
# a new event starts. None-safe: open_board() fails soft if it is wrong.
BOARD_ICON_LOC = (1221, 829)   # Food Club cart icon, 10/15 (was (1055, 822) for the old event)

# Board geometry (1600x900), measured live 10/2 on the Storybook board.
CARD_BTN_Y = 830            # centre y of the Complete buttons
CARD_BTN_TO_CX = -46        # card centre x = button centre x + this
SLOT_DX = (-70, 70)         # icon column offsets from card centre
ROW_ICON_Y = (570, 710)     # icon centre y per row
ROW_TEXT_Y = (618, 758)     # count-text centre y per row

SIFT_MIN_INLIERS = 20
SIFT_MIN_RATIO = 3.0


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] [event] {msg}\n")
    try:
        print(f"[{ts}] [event] {msg}")
    except (AttributeError, OSError):
        pass


# --------------------------------------------------------------------------
# Generic vision helpers
# --------------------------------------------------------------------------

def find_green_buttons(img, y1=0, y2=900, min_w=150, max_w=330, min_h=40, max_h=95):
    """Finds lime-green rounded action buttons. Returns [(cx, cy, w, h)],
    left-to-right then top-to-bottom. Colour + shape only, so it works for
    any label (Make / Gather / Complete / Produce...)."""
    band = img[y1:y2]
    hsv = cv2.cvtColor(band, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (35, 150, 140), (60, 255, 255))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, _, stats, cents = cv2.connectedComponentsWithStats(mask)
    out = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if min_w <= w <= max_w and min_h <= h <= max_h and area > 0.45 * w * h:
            out.append((int(x + w / 2), int(y + h / 2) + y1, int(w), int(h)))
    out.sort(key=lambda b: (b[1] // 40, b[0]))
    return out


def sift_match_score(small_bgr, big_bgr):
    """RANSAC inlier count of SIFT matches between a small icon and a larger
    card art. Higher = more likely the same picture. 0 on any failure."""
    def prep(im):
        h, w = im.shape[:2]
        s = 240.0 / max(h, w)
        im = cv2.resize(im, (max(1, int(w * s)), max(1, int(h * s))),
                        interpolation=cv2.INTER_CUBIC)
        return cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    try:
        sift = cv2.SIFT_create()
        k1, d1 = sift.detectAndCompute(prep(small_bgr), None)
        k2, d2 = sift.detectAndCompute(prep(big_bgr), None)
        if d1 is None or d2 is None or len(k1) < 2 or len(k2) < 2:
            return 0
        bf = cv2.BFMatcher()
        good = []
        for pair in bf.knnMatch(d1, d2, k=2):
            if len(pair) == 2 and pair[0].distance < 0.8 * pair[1].distance:
                good.append(pair[0])
        if len(good) < 4:
            return 0
        src = np.float32([k1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst = np.float32([k2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
        _, inl = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC,
                                             ransacReprojThreshold=6)
        return int(inl.sum()) if inl is not None else 0
    except cv2.error:
        return 0


def _hs_hist(im):
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)
    h = cv2.calcHist([hsv], [0, 1], None, [18, 8], [0, 180, 0, 256]).flatten()
    return h / (h.sum() + 1e-9)


# Weaker-evidence tiers (found live 10/2: soft low-texture icons -- a Dairy
# "Whipped Cream" swirl gave SIFT 12 vs 4, a tiny smooth Cow Shed "Milk" bottle
# gave SIFT 5 vs 2 -- right card, under the 20-inlier bar):
#  tier 2: SIFT top >= 10 and >= 2.5x runner-up AND the colour-histogram vote
#          (HS intersection) picks the SAME card with >= 0.35 and >= 1.5x.
#  tier 3: colour alone, when it is decisive (>= 0.30 and >= 2x the runner-up)
#          AND SIFT does not contradict it (no other card with SIFT >= 8).
# Histograms use the top 70% of the icon so a count-text overlay at its bottom
# edge ("0/1") does not pollute the colours.
SIFT_WEAK_MIN = 10
SIFT_WEAK_RATIO = 2.5
HIST_MIN = 0.35
HIST_RATIO = 1.5
HIST_ONLY_MIN = 0.30
HIST_ONLY_RATIO = 2.0
SIFT_CONTRADICT = 8


def pick_best(small_bgr, candidates):
    """candidates = [(key, big_bgr)]. Returns (best_key_or_None, scores).
    Accepts on strong SIFT, or weaker SIFT + colour agreement, or decisive
    colour that SIFT does not contradict."""
    scores = [(k, sift_match_score(small_bgr, b)) for k, b in candidates]
    ranked = sorted(scores, key=lambda kv: kv[1], reverse=True)
    if not ranked:
        return None, scores
    best, bs = ranked[0]
    rs = ranked[1][1] if len(ranked) > 1 else 0
    if bs >= SIFT_MIN_INLIERS and bs >= SIFT_MIN_RATIO * max(rs, 1):
        return best, scores
    if len(candidates) < 2:
        return None, scores
    ih = _hs_hist(small_bgr[:max(1, int(small_bgr.shape[0] * 0.7))])
    hs = sorted(((k, float(np.minimum(ih, _hs_hist(b)).sum())) for k, b in candidates),
                key=lambda kv: kv[1], reverse=True)
    hk, hv = hs[0]
    hr = max(hs[1][1], 1e-9)
    if bs >= SIFT_WEAK_MIN and bs >= SIFT_WEAK_RATIO * max(rs, 1):
        if hk == best and hv >= HIST_MIN and hv >= HIST_RATIO * hr:
            log(f"weak SIFT ({bs} vs {rs}) accepted: colour histogram agrees ({hv:.2f} vs {hr:.2f}).")
            return best, scores
    if hv >= HIST_ONLY_MIN and hv >= HIST_ONLY_RATIO * hr:
        contradicted = any(k != hk and sc >= SIFT_CONTRADICT for k, sc in scores)
        if not contradicted:
            log(f"colour decisive ({hv:.2f} vs {hr:.2f}), SIFT weak ({bs}) but not contradicting -- accepted.")
            return hk, scores
    return None, scores


def count_blobs(img, y1, y2, x1, x2, merge_gap=24):
    """Finds the red/green count-text blobs ("0/1", "5/1") inside a box.
    The game draws these in PURE 255 red/green with a dark outline, which
    card art almost never contains, so strict channel thresholds separate
    them cleanly. Returns [(cx, 'red'|'green')] left-to-right; blobs of the
    same colour closer than merge_gap are one count."""
    box = img[y1:y2, x1:x2].astype(int)
    b, g, r = box[:, :, 0], box[:, :, 1], box[:, :, 2]
    masks = (("red", (r > 235) & (g < 45) & (b < 45)),
             ("green", (g > 235) & (r < 45) & (b < 45)))
    hits = []
    for color, m in masks:
        cols = np.where(m.sum(axis=0) >= 2)[0]
        for x in cols:
            hits.append((int(x1 + x), color))
    hits.sort()
    groups = []
    for x, color in hits:
        if groups and groups[-1]["color"] == color and x - groups[-1]["x2"] <= merge_gap:
            groups[-1]["x2"] = x
        else:
            groups.append({"color": color, "x1": x, "x2": x})
    return [((g["x1"] + g["x2"]) // 2, g["color"]) for g in groups if g["x2"] - g["x1"] >= 8]


# HUD corner holding the board's own blue "?" help button (matches the
# tooltip "?" template at 0.99 -- tapping it would be wrong). Masked out.
HELP_BUTTON_ZONE = (1250, 0, 1600, 220)   # x1, y1, x2, y2


def find_tooltip_question(img):
    """Like order_fulfill.find_question_button but ignores the board's own
    help button in the top-right corner. Returns (loc_or_None, confidence)."""
    res = cv2.matchTemplate(img, of.QUESTION_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    th, tw = of.QUESTION_TEMPLATE.shape[:2]
    x1, y1, x2, y2 = HELP_BUTTON_ZONE
    res[max(0, y1 - th):y2, max(0, x1 - tw):x2] = -1
    _, mv, _, ml = cv2.minMaxLoc(res)
    if mv < of.QUESTION_MATCH_THRESHOLD:
        return None, float(mv)
    return (ml[0] + tw // 2, ml[1] + th // 2), float(mv)


def tap_item_and_travel(tap_xy, label, stop_flag=None):
    """Taps an item, then (same script, within the ~4s tooltip window) taps
    the tooltip's "?" so the camera travels to its source. Declines any
    gem-buy dialog. Returns True if travel was triggered."""
    adb_helper.tap(*tap_xy)
    # 10/17: back to 0.3 s. A 0.8 s wait plus slow screenshots (2.2 s) put the '?' tap past the ~4 s tooltip:
    # 13 "travel did not start" in 2 h, every one with the '?' found at match 0.99-1.00 (right spot, too late).
    of.interruptible_sleep(0.3, stop_flag)
    img = adb_helper.screenshot()
    q, qc = find_tooltip_question(img)
    if q is None:
        no, nc = of.find_no_button(img)
        if no is not None:
            log(f"'{label}': tap opened a gem-buy dialog ({nc:.2f}) -- declining, never spending gems.")
            adb_helper.tap(*no)
        else:
            log(f"'{label}': no travel tooltip appeared (best '?' {qc:.2f}).")
        return False
    adb_helper.tap(*q)
    reader = _start_tooltip_read(img, q)                     # 10/16: the tooltip names the item and its source
    for attempt in (1, 2):
        # 11/1 FLASH step 4: was a fixed 2.0 s (31x = 62 s in 16 min) -- now look until the board has closed
        wait_for(lambda im: not board_is_open(im), 2.0, stop_flag)
        for _ in range(5 if attempt == 1 else 3):           # pass 34: wait until the camera has left the board
            if not board_is_open(adb_helper.screenshot()):
                break
            of.interruptible_sleep(1.5, stop_flag)
        else:                                                # pass 35: still on the board = the travel never started
            if attempt == 1:
                # 10/17: the '?' spot is known now -- tap the item and that spot straight away, no screenshot
                # in between, so the tap lands while the tooltip is surely still up.
                log(f"'{label}': the travel did not start (tapped '?' at {q} too late?) -- retrying once.")
                adb_helper.tap(*tap_xy)
                of.interruptible_sleep(0.3, stop_flag)
                img_r = adb_helper.screenshot()
                q2, _ = find_tooltip_question(img_r)
                if q2 is None or abs(q2[0] - q[0]) > 25 or abs(q2[1] - q[1]) > 25:
                    no, _ = of.find_no_button(img_r)
                    if no is not None:                       # never anything near a gem 'Yes'
                        adb_helper.tap(*no)
                    log(f"'{label}': the retry did not show the same '?' -- not tapping blind; next pass.")
                    return False
                adb_helper.tap(*q2)
                continue
            log(f"'{label}': the board is still open after the travel tap and a quick retry (tapped '?' at {q}, "
                f"match {qc:.2f}) -- the travel did not start; trying again next pass.")
            return False
        if attempt == 2:
            log(f"'{label}': the quick retry worked -- travelling.")
        break
    _finish_tooltip_read(reader, label)
    return True


# --------------------------------------------------------------------------
# Names from the game's own text (10/16, owner's idea)
# --------------------------------------------------------------------------
# The travel tooltip says what an item is and where it comes from: "Get Cherry Pie from the
# Supermarket Merchant" (a station) or "Grow Spices on your Event Plot" (a crop). Tapping a
# station card's PICTURE shows its name ("Cola", "Assorted Meats") in a bubble at the top of the
# card and starts nothing. So when the picture matchers are unsure, the bot can pick the card
# by name -- and it stores the icon + card in the item library so next time no tapping is needed.
_last_wanted = {"name": None, "where": None, "plot": None, "label": None}
PLOT_CROPS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".plot_crops.json")
try:                         # names the game said are "grown on your Event Plot" (seed reserve, 10/17);
    with open(PLOT_CROPS_FILE, encoding="utf-8") as _fh:       # kept on disk: a Start reloads this module
        _plot_crops = set(json.load(_fh))
except (OSError, ValueError):
    _plot_crops = set()
_plot_crops |= {"assortedberries", "spices", "newpotato", "greens"}   # Market Fresh event, from the 10/17 logs
_crop_ready = {}             # crop name -> when the last planted batch is ready
SEED_RESERVE = 2             # keep this many of a crop for replanting before cooking it into a dish
# 10/19 (owner: yes): an express at 02:30 was missed with berries at 0 -- expresses keep asking for American
# Pancakes (2 berries + 2 wheat each, often x5). Between expresses keep a bigger stock of those two crops; during an
# express the reserve is off, so all of it can be cooked at once.
EXPRESS_BUFFER = {}           # 10/30 (owner): removed from Settings -- every crop keeps SEED_RESERVE
PRESTOCK_EACH = 2             # 10/30 Settings "Prestock Food Club event storage": keep this many of every event item (0 = off)
ALARM_ON = True             # Settings tab (afsd_core._apply_settings sets these each cycle)


def _reserve(crop_name):
    # 10/31 (owner: prestock "the dishes, then the ingredients, then the crops"): event crops are kept at the
    # prestock number too, so an express does not find Twilight Root / Pumpkin at 0 with more still growing
    return max(SEED_RESERVE, PRESTOCK_EACH, EXPRESS_BUFFER.get(_norm(crop_name or ""), 0), prep_keep(crop_name))


def prep_targets():
    """11/13 (owner: event items on the Prep list): {event item name: keep} from the placed Prep list."""
    try:
        import prep_engine
        return prep_engine.event_targets()
    except Exception:                                  # noqa: BLE001
        return {}


def keep_for(name, targets):
    """Pure: the Prep list's keep number for this event item name (0 = not on the list)."""
    return max([q for nm, q in (targets or {}).items() if name and same_name(nm, name)] or [0])


def prep_keep(name):
    return keep_for(name, prep_targets())


CATALOG_MIN_SEEN = 5            # 11/13: low now -- the 6-day window drops old events; OCR near-copies still drop
CATALOG_RECENT_SEC = 6 * 86400   # 11/13 (owner): an event runs ~6 days -- items not seen for 6 days drop off


def event_catalog(book=None, crops=None, now=None):
    """11/13: [(name, kind, where)] of the Food Club event items for the Prep tab's Event button -- dishes and
    merchant items from recipe_test.json (made at an EVENT station), and event crops from their recipes.
    OCR slips are dropped (seen < CATALOG_MIN_SEEN, or a near-copy of a name seen more often). Only entries seen in
    the last CATALOG_RECENT_SEC (6 days, one event) are listed. Pure."""
    import difflib
    if book is None:
        try:
            import json
            with open(RECIPE_TEST_FILE, encoding="utf-8") as fh:
                book = json.load(fh)
        except (OSError, ValueError):
            book = {}
    crops = _plot_crops if crops is None else crops
    now = now or time.time()
    rows = [(nm, e) for nm, e in book.items() if isinstance(e, dict) and int(e.get("seen") or 0) >= CATALOG_MIN_SEEN]
    # 11/13 (owner: "it has all of the old event crops listed"): only items seen in the last 6 days; entries from
    # before the "last seen" time was kept (no "t") are old events and never listed
    rows = [(nm, e) for nm, e in rows if now - float(e.get("t") or 0) < CATALOG_RECENT_SEC]
    rows.sort(key=lambda r: -int(r[1].get("seen") or 0))
    out, names = [], []

    def dup(nm):
        return any(difflib.SequenceMatcher(None, _norm(nm), _norm(o)).ratio() >= 0.8 for o in names)
    for nm, e in rows:
        where = e.get("where")
        if not panel_prestock_allowed(where) or dup(nm):
            continue
        names.append(nm)
        out.append((nm, "merchant" if "merchant" in (where or "").lower() else "dish", where))
    for nm, e in rows:                                   # event crops = ingredients of those that grow on the plots
        for reading in (e.get("readings") or {}):
            for part in reading.split(","):
                ing = part.rsplit(" x", 1)[0].strip()
                if ing and _norm(ing) in crops and not dup(ing):
                    names.append(ing)
                    out.append((ing, "crop", "Event Plot"))
    return out
                             # (10/17: berries went into Cola / Cherry Pie, the plots stood empty, 2 orders/h;
                             # 4 held too much back: the plots were nearly always full -- planted 1 of 5-8 wanted)
_plots_full_until = {}       # crop -> until when its last planting found no free plot (holding seeds back is pointless)
TOOLTIP_BOX = (-370, -45, -40, 45)          # x1, y1, x2, y2 around the tooltip's "?" (measured 10/16)
CARD_NAME_BOX = (-170, -380, 170, -325)      # around a station card's green button: the name bubble
CARD_ART_TAP_DY = -205                       # card picture centre, above the button
NAME_MATCH_MIN = 0.80


def parse_tooltip(text):
    """'Get Cherry Pie from the Supermarket Merchant' -> {'name': 'Cherry Pie', 'where': 'Supermarket
    Merchant', 'plot': False}; 'Grow Spices on your Event Plot' -> plot True. None if unreadable.
    Tolerates OCR noise around the words (stray brackets, 'frn' / 'fran' / 'frorn' for 'from'; 10/17: 'fran' seen live)."""
    import re
    t = " ".join(re.sub(r"[^A-Za-z0-9' &-]", " ", text or "").split())
    t = re.sub(r"(?<=[A-Za-z]) 8 (?=[A-Za-z])", " & ", t)          # 'Bacon Eggs 8 Hash Browns': OCR reads & as 8
    m = re.search(r"\b(get|grow|pick|harvest|collect|catch|buy|make)\s+(.+?)\s+(f[rn][aoe0]?(?:m|rn|n)|on)\s+(?:the\s+|your\s+)?(.+)$", t, re.I)
    if not m:   # 10/17: 'frmn' seen live -- any short f-word, but only right before 'the' / 'your'
        m = re.search(r"\b(get|grow|pick|harvest|collect|catch|buy|make)\s+(.+?)\s+(f[rn][a-z0]{0,3})\s+(?:the|tne|your|uour)\s+(.+)$", t, re.I)
    if not m:   # 10/28 live: fruit says 'Get Lemon by planting a Lemon Tree' (OCR 'plantina')
        m = re.search(r"\b(get)\s+(.+?)\s+(by)\s+plant\w*\s+(?:an?\s+)?(.+)$", t, re.I)
    if not m:
        return None
    verb, name, prep, where = m.group(1).lower(), m.group(2).strip(), m.group(3).lower(), m.group(4).strip()
    plot = verb == "grow" or (prep == "on" and "plot" in where.lower())
    return {"name": name, "where": where, "plot": plot}


def _norm(name):
    return "".join(ch for ch in (name or "").lower() if ch.isalnum())


def same_name(a, b):
    import difflib
    a, b = _norm(a), _norm(b)
    return bool(a and b) and difflib.SequenceMatcher(None, a, b).ratio() >= NAME_MATCH_MIN


def _start_tooltip_read(img, q):
    import threading
    box = (q[0] + TOOLTIP_BOX[0], q[1] + TOOLTIP_BOX[1], q[0] + TOOLTIP_BOX[2], q[1] + TOOLTIP_BOX[3])
    out = {"img": img, "box": box}

    def work():
        try:
            import popup_ocr
            out["text"] = popup_ocr.read_text(img, box)
        except Exception:                                     # noqa: BLE001
            out["text"] = ""
    t = threading.Thread(target=work, daemon=True)
    t.start()
    return t, out


def _note_plot_crop(info):
    if info.get("plot") and _norm(info["name"]) not in _plot_crops:
        _plot_crops.add(_norm(info["name"]))
        try:
            with open(PLOT_CROPS_FILE, "w", encoding="utf-8") as fh:
                json.dump(sorted(_plot_crops), fh)
        except OSError:
            pass


# --- 11/13 (owner: "after it doesn't recognise an event dish, instead of letting it say name not learned yet" /
# "run the board and the stations as soon as I have trained a new event icon -- I need to learn the dishes to prep").
NAME_LOOKS_PER_PASS = 3          # unnamed board items whose tooltip is read per pass (~4 s each, once per item)
NAME_LOOK_GAP_SEC = 10 * 60      # an item whose tooltip could not be read is tried again after this
_name_looks = {}                 # (x, y) -> when last looked


def learn_board_names(img, cards, stop_flag=None):
    """Board items with no name yet: tap the item (NEVER the '?'), read the tooltip "Get X from the Y" / "Grow X on
    your Event Plot", remember the name with its picture, wait for the tooltip to go. Returns how many were named."""
    import popup_ocr
    now, done, looked = time.time(), 0, 0
    for c in cards:
        for sl in c["slots"]:
            if looked >= NAME_LOOKS_PER_PASS:
                return done
            icon = board_icon(img, *sl["icon"])
            key = tuple(sl["icon"])
            if item_name(icon) or now - _name_looks.get(key, 0) < NAME_LOOK_GAP_SEC:
                continue
            _name_looks[key] = now
            looked += 1
            of.check_stop(stop_flag)
            adb_helper.tap(*sl["icon"])
            of.interruptible_sleep(0.4, stop_flag)
            shot = adb_helper.screenshot()
            q, _qc = find_tooltip_question(shot)
            if q is None:
                no, _ = of.find_no_button(shot)
                if no is not None:
                    log("[names] tapping a board item opened a buy dialog -- declining.")
                    adb_helper.tap(*no)
                    return done
                continue
            box = (q[0] + TOOLTIP_BOX[0], q[1] + TOOLTIP_BOX[1], q[0] + TOOLTIP_BOX[2], q[1] + TOOLTIP_BOX[3])
            info = parse_tooltip(popup_ocr.read_text(shot, box))
            if info:
                _remember_name(icon, info["name"])
                _note_plot_crop(info)
                done += 1
                log(f"[names] board item at {key}: the game says {info['name']} -- "
                    f"{'grown on ' if info['plot'] else 'from '}{info['where']}.")
            wait_for(lambda im: find_tooltip_question(im)[0] is None, 5.0, stop_flag)
    return done


STATION_LEARN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".event_stations_learned.json")


def learn_station(label, stop_flag, ctx):
    """First visit to an EVENT station this event (6 days): read every card's name (picture taps only, never a
    button) and its ingredients into recipe_test.json, so the Prep tab's Event list has the whole menu."""
    import json
    if ctx.get("express"):
        return 0
    where = _last_wanted.get("where") if _last_wanted.get("label") == label else None
    if not panel_prestock_allowed(where):
        return 0
    try:
        with open(STATION_LEARN_FILE, encoding="utf-8") as fh:
            seen = json.load(fh)
    except (OSError, ValueError):
        seen = {}
    now = time.time()
    if now - float(seen.get(where, 0)) < CATALOG_RECENT_SEC:
        return 0
    img = adb_helper.screenshot()
    if img is None or not station_panel_open(img):
        return 0
    btns = station_buttons(img)
    names = read_card_names(img, btns, stop_flag) if btns else None
    if not names:
        return 0
    try:
        with open(RECIPE_TEST_FILE, encoding="utf-8") as fh:
            book = json.load(fh)
    except (OSError, ValueError):
        book = {}
    got = []
    for (bx, by, *_), nm in zip(btns, names):
        nm = (nm or "").strip(" .-")
        if len(nm) < 3:
            continue
        parts = []
        for k, (x, _color) in enumerate(count_blobs(img, by - 70, by - 40, bx - 175, bx + 175) or []):
            rc = event_digits.read_count(img, x, by - 55)
            ing = _ingredient_name(ingredient_icon(img, x, by)) or f"unknown #{k + 1}"
            parts.append(f"{ing} x{rc['need'] if rc else '?'}")
        e = book.setdefault(nm, {"seen": 0, "readings": {}})
        e["seen"] = max(int(e.get("seen") or 0), CATALOG_MIN_SEEN)
        e["t"], e["where"] = int(now), where
        if parts:
            txt = ", ".join(parts)
            e.setdefault("readings", {})[txt] = e["readings"].get(txt, 0) + 1
        got.append(nm)
    if not got:
        return 0
    try:
        os.makedirs(RECIPE_TEST_DIR, exist_ok=True)
        with open(RECIPE_TEST_FILE + ".tmp", "w", encoding="utf-8") as fh:
            json.dump(book, fh, indent=1)
        os.replace(RECIPE_TEST_FILE + ".tmp", RECIPE_TEST_FILE)
        seen[where] = now
        with open(STATION_LEARN_FILE, "w", encoding="utf-8") as fh:
            json.dump(seen, fh)
    except OSError:
        return 0
    log(f"[learn menu] {where}: {', '.join(got)} -- on the Prep tab's Event list now.")
    return len(got)


def _finish_tooltip_read(reader, label):
    t, out = reader
    t.join(timeout=20)
    info = parse_tooltip(out.get("text", ""))
    _last_wanted.update(name=None, where=None, plot=None, label=label)
    if info:
        _last_wanted.update(info)
        _note_plot_crop(info)
        log(f"'{label}': the game says: {info['name']} -- "
            f"{'grown on ' if info['plot'] else 'from '}{info['where']}.")
    else:
        log(f"'{label}': could not read the travel tooltip ('{out.get('text', '')}').")
        _save_tooltip_miss(out)


_tooltip_misses = [0]


def _save_tooltip_miss(out):
    """10/31: 148 unreadable tooltips 10/30-31 (134 on ingredient trips to the plots) and no picture to see why --
    keep the first 3 per run (whole screen with the read box drawn) in templates/fail_pictures (Send logs)."""
    if _tooltip_misses[0] >= 3 or out.get("img") is None:
        return
    _tooltip_misses[0] += 1
    try:
        pic = out["img"].copy()
        x1, y1, x2, y2 = out["box"]
        cv2.rectangle(pic, (x1, y1), (x2, y2), (0, 0, 255), 3)
        folder = os.path.join(BASE_DIR, "templates", "fail_pictures")
        os.makedirs(folder, exist_ok=True)
        cv2.imwrite(os.path.join(folder, f"{int(time.time())}_tooltip_unread.png"), pic)
    except Exception:                                         # noqa: BLE001
        pass


def _slug(name):
    import re
    return re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_")


def read_card_names(img, btns, stop_flag=None):
    """Taps each station card's PICTURE (never its button) and reads the name bubble. Returns a list
    of names ('' when unreadable), or None if a tap opened anything else (that is declined/closed)."""
    import popup_ocr
    names = []
    for bx, by, *_ in btns:
        of.check_stop(stop_flag)
        adb_helper.tap(bx, by + CARD_ART_TAP_DY)
        of.interruptible_sleep(0.7, stop_flag)
        shot = adb_helper.screenshot()
        no, _ = of.find_no_button(shot)
        if no is not None:                                    # never expected -- but never buy anything
            log("reading card names: a tap opened a buy dialog -- declining and giving up.")
            adb_helper.tap(*no)
            return None
        if len(station_buttons(shot)) != len(btns):
            log("reading card names: the panel changed after a picture tap -- giving up.")
            return None
        x1, y1, x2, y2 = CARD_NAME_BOX
        names.append(popup_ocr.read_text(shot, (bx + x1, by + y1, bx + x2, by + y2)).strip())
    return names


def learn_item(name, icon, card):
    """Stores icon + card art under the item's name in the item library (never overwrites)."""
    slug = _slug(name)
    if not slug or icon is None or card is None:
        return
    os.makedirs(PLANT_LIB_DIR, exist_ok=True)
    top = icon[:max(1, int(icon.shape[0] * 0.7))]
    for fn in os.listdir(PLANT_LIB_DIR):                      # already known (maybe by another name): no duplicate
        ref = cv2.imread(os.path.join(PLANT_LIB_DIR, fn)) if fn.startswith("icon_") else None
        if ref is not None and _inner_match(ref[:max(1, int(ref.shape[0] * 0.7))], top, 4) >= 0.95:
            log(f"item library: '{name}' looks like the stored {fn} already -- not saving a second copy.")
            return
    ip = os.path.join(PLANT_LIB_DIR, f"icon_{slug}.png")
    n = 1
    while os.path.exists(ip):
        n += 1
        ip = os.path.join(PLANT_LIB_DIR, f"icon_{slug}__{n}.png")
    cv2.imwrite(ip, icon)
    cp = os.path.join(PLANT_LIB_DIR, f"card_{slug}.png")
    if not os.path.exists(cp):
        cv2.imwrite(cp, card)
    log(f"[train] item library: learned '{name}' ({os.path.basename(ip)}) -- next time no tapping is needed.")


def pick_card_by_name(icon, img, btns, label, stop_flag=None):
    """Card index whose name matches the travel tooltip's item, or None."""
    want = _last_wanted.get("name")
    if not want or _last_wanted.get("label") != label:
        return None
    log(f"[train] '{label}': reading the {len(btns)} card names to find '{want}'...")
    names = read_card_names(img, btns, stop_flag)
    if names is None:
        log(f"[train] '{label}': could not read the card names (OCR or the name bubble did not show).")
        return None
    hits = [i for i, n in enumerate(names) if same_name(n, want)]
    log(f"'{label}': looking for '{want}' by name; the cards say {names} -> "
        f"{'card ' + str(hits[0]) if len(hits) == 1 else 'no single match'}")
    if len(hits) != 1:
        return None
    i = hits[0]
    learn_item(want, icon, card_art(img, btns[i][0], btns[i][1]))
    return i


# --------------------------------------------------------------------------
# Board
# --------------------------------------------------------------------------

def read_board(img):
    """Returns a list of cards: {cx, btn:(x,y), slots:[{row,col,icon:(x,y),color}]}.
    Slot colour comes from the count text under each icon; empty slots are
    omitted."""
    cards = []
    for bx, by, _, _ in find_green_buttons(img, y1=780, y2=890):
        cx = bx + CARD_BTN_TO_CX
        slots = []
        for row in (0, 1):
            for col, dx in enumerate(SLOT_DX):
                tx = cx + dx
                # Strict pure-255 text blobs, NOT of._sample_color: a ready
                # card turns tan, and the tan background of its EMPTY slots
                # read as "red" there (seen live 10/2).
                blobs = count_blobs(img, ROW_TEXT_Y[row] - 12, ROW_TEXT_Y[row] + 12,
                                    tx - 32, tx + 32)
                if not blobs:
                    continue
                color = "red" if any(c == "red" for _, c in blobs) else "green"
                slots.append({"row": row, "col": col,
                              "icon": (tx, ROW_ICON_Y[row]), "color": color})
        cards.append({"cx": cx, "btn": (bx, by), "slots": slots})
    return cards


def card_is_ready(card):
    return bool(card["slots"]) and all(s["color"] == "green" for s in card["slots"])


def board_is_open(img):
    if len(find_green_buttons(img, y1=780, y2=890)) < 1:
        return False
    # The board's own orange-brown background (BGR ~26,62,128); a lime-green
    # hedge on the map was mistaken for a Complete button on 10/2.
    b, g, r = img[600:700, 60:200].reshape(-1, 3).mean(0)
    return b < 70 and 40 < g < 95 and 100 < r < 165


BOARD_ICON_TEMPLATE = os.path.join(BASE_DIR, "templates", "event_board_icon.png")
# The template is only the LEFT part of the shoes (a ready-badge covers the right
# part). A tap lands at the template's top-left + this offset = the icon's middle
# (template origin (1005,795), icon middle (1055,822)).
BOARD_ICON_TAP_OFFSET = (35, 34)   # cart template 70x68 at (1186,795) -> middle (1221,829), 10/15
BOARD_ICON_REGION = (880, 720, 1450, 900)   # x1, y1, x2, y2 of the bottom event-icon bar (widened 10/15:
                                             # icons shift when an event adds one; stops short of the clipboard)
# A ready checkmark + number badge over the cart drops its match to ~0.52 (live 10/15); 402 older
# map screenshots with no cart never scored above 0.34. 0.45 sits in that gap.
BOARD_ICON_COVERED_MIN = 0.45


def hud_is_bright(img):
    """True when the screen is a PLAIN, undimmed map view (no popup / panel on top).
    Measured on the permanent bright-white Orders clipboard in the bottom-right nav:
    its 90th-percentile brightness reads 244-245 on every plain map (including dark
    or green crop-plot maps) and <= 234 under every popup/panel (most 50-62). The old
    whole-HUD-strip mean (>=155) wrongly rejected a green crop-plot map (153.7)."""
    v = cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2]
    return float(np.percentile(v, 90)) >= 240


_last_icon_score = None      # (best match, where) from the last find_board_icon -- for the open-board log (10/16)


def _save_board_try(img, tag):
    """Keeps a picture of what the screen showed when opening the board went wrong (newest 20 kept)."""
    try:
        folder = os.path.join(BASE_DIR, "templates", "event_tapfail")
        os.makedirs(folder, exist_ok=True)
        name = f"{int(time.time())}_{tag}.png"
        cv2.imwrite(os.path.join(folder, name), img)
        old = sorted(f for f in os.listdir(folder) if "_board_" in f)
        for f in old[:-20]:
            os.remove(os.path.join(folder, f))
        return name
    except Exception:                                  # noqa: BLE001
        return None


EVENT_ICON_DIR = os.path.join(BASE_DIR, "templates", "event_icons")   # 11/12: shipped icons of every event (Update)
_icon_cache = {}


def board_icon_templates():
    """11/12: the PC's own trained / learned icon (BOARD_ICON_TEMPLATE -- the 'New event icon' button and
    event_icon_search write it; it is NOT in the Update list, so an Update never undoes a learned icon) plus every
    70x68 icon shipped in templates/event_icons/ (one per event, so a returning event is known at once)."""
    paths = [BOARD_ICON_TEMPLATE]
    try:
        paths += sorted(os.path.join(EVENT_ICON_DIR, f) for f in os.listdir(EVENT_ICON_DIR) if f.endswith(".png"))
    except OSError:
        pass
    out = []
    for p in paths:
        try:
            mt = os.path.getmtime(p)
        except OSError:
            continue
        if _icon_cache.get(p, (None,))[0] != mt:
            _icon_cache[p] = (mt, cv2.imread(p))
        if _icon_cache[p][1] is not None:
            out.append(_icon_cache[p][1])
    return out


def find_board_icon(img):
    """Finds the event's orders icon (the shoes) in the bottom nav bar by image,
    not by a fixed coordinate. Returns (x, y) or None. Per-event template:
    templates/event_board_icon.png (crop of the icon art only: no timer text,
    no badge). If the template file is missing, falls back to BOARD_ICON_LOC."""
    # Never tap the nav bar while a modal/panel dims the HUD (the template matcher
    # ignores brightness, so it would "find" the icon under a dimmed popup).
    if not hud_is_bright(img):
        return None
    x1, y1, x2, y2 = BOARD_ICON_REGION
    v, l = -1.0, (0, 0)
    for tpl in board_icon_templates():
        try:
            r = cv2.matchTemplate(img[y1:y2, x1:x2], tpl, cv2.TM_CCOEFF_NORMED)
        except Exception:                                   # noqa: BLE001
            continue
        _, tv, _, tl = cv2.minMaxLoc(r)
        if tv > v:
            v, l = tv, tl
    if v < 0:
        return BOARD_ICON_LOC
    global _last_icon_score
    _last_icon_score = (round(float(v), 2), (x1 + l[0] + BOARD_ICON_TAP_OFFSET[0], y1 + l[1] + BOARD_ICON_TAP_OFFSET[1]))
    if v >= 0.6:
        return (x1 + l[0] + BOARD_ICON_TAP_OFFSET[0], y1 + l[1] + BOARD_ICON_TAP_OFFSET[1])
    # A green "ready" checkmark / number badge can cover part of the icon. Accept a
    # weaker match then, but never a fixed spot: the icons shift sideways when an event
    # adds an icon, and the old fixed spot (BOARD_ICON_LOC) landed on the Season globe
    # on 10/15 and opened the Season screen.
    if v >= BOARD_ICON_COVERED_MIN:
        if _quiet("icon_covered", 600, round(float(v), 1)):        # 11/28: was 2 lines per board open
            log(f"Board icon partly covered (match {v:.2f}) -- tapping it where the picture was found "
                "(said once per 10 min; press New event icon if this shows all the time).")
        return (x1 + l[0] + BOARD_ICON_TAP_OFFSET[0], y1 + l[1] + BOARD_ICON_TAP_OFFSET[1])
    return None


_QUIET = {}


def _quiet(key, gap, value=None):
    """11/28 log hygiene: True when a repeating line should be written now -- the first time, when `value`
    changed, or after `gap` seconds."""
    now = time.time()
    last = _QUIET.get(key)
    if last is None or last[1] != value or now - last[0] >= gap:
        _QUIET[key] = (now, value)
        return True
    return False


_last_unknown_save = 0.0


def save_unknown_screen(img):
    """An unrecognised screen is blocking the nav bar: keep a capture (at most
    one per 30s) in templates/unknown_screens/ so it can be trained as a
    popup. Never taps anything."""
    global _last_unknown_save
    if time.time() - _last_unknown_save < 30:
        return
    _last_unknown_save = time.time()
    d = os.path.join(BASE_DIR, "templates", "unknown_screens")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{int(time.time())}.png")
    cv2.imwrite(path, img)
    log(f"Saved the unrecognised screen to {path} -- send it to be trained as a popup.")


# When the event icon cannot be found, try these in order -- each rung is followed by
# a full re-check (dialogs, open panels, then the icon) before the next one (user, 10/2).
# Gestures are the project's proven ones (find_and_center's zoom pinch / hop drag).
RECOVERY_LADDER = ("zoom out", "swipe left")


def _recovery_gesture(name):
    if name == "zoom out":
        adb_helper.pinch(800, 450, 350, 80, steps=15)
    elif name == "swipe left":
        adb_helper.swipe(1000, 450, 600, 450, 600)        # drag left


SETTLE_DIFF = 2.0      # mean pixel change below which the map counts as still (prep_engine._wait_still uses the same)
SETTLE_MAX_SEC = 2.5


def _settle(img, stop_flag=None):
    """10/31: after a fast-travel the camera is often still gliding -- a tap then lands on a moving map and is lost.
    Wait (max SETTLE_MAX_SEC) until two screenshots 0.3 s apart below the HUD barely differ; returns the last one."""
    t0 = time.time()
    step, still = settle_params()
    while time.time() - t0 < SETTLE_MAX_SEC:
        of.interruptible_sleep(step, stop_flag)
        nxt = adb_helper.screenshot()
        if nxt is None or img is None or nxt.shape != img.shape:
            return nxt if nxt is not None else img
        diff = float(np.abs(nxt[100:700].astype(np.int16) - img[100:700].astype(np.int16)).mean())
        img = nxt
        if diff < still:
            break
    return img


SETTLE_FAST_STEP = 0.15   # 11/2 FLASH step 5 (owner: approved): look twice as often while FLASH looks are cheap
SETTLE_FAST_DIFF = 1.5    # frames 0.15 s apart move about half as much -- a slightly stricter "still" than 2.0


def settle_params():
    """Pure-ish (11/2): (seconds between looks, 'still' threshold) -- faster only while FLASH window looks work."""
    try:
        import flash
        if flash.ON and flash._grab.get("ok_t") and time.time() - flash._grab["ok_t"] < 30:
            return SETTLE_FAST_STEP, SETTLE_FAST_DIFF
    except Exception:                                   # noqa: BLE001
        pass
    return 0.3, SETTLE_DIFF


def wait_for(pred, max_sec, stop_flag=None, step=None, min_sec=0.0):
    """11/1 FLASH step 4: instead of a fixed pause, look every `step` s and stop as soon as pred(screenshot) is
    true (after at least min_sec). Returns (picture, True) when it came true, (last picture, False) after max_sec.
    With FLASH a look costs ~0.1 s; without it the adb look itself is the wait, so it is never slower than before."""
    t0 = time.time()
    img = None
    if step is None:                                   # 11/2 step 5: 0.15 s while FLASH looks work, else 0.25 s
        step = SETTLE_FAST_STEP if settle_params()[0] == SETTLE_FAST_STEP else 0.25
    while True:
        of.interruptible_sleep(step, stop_flag)
        img = adb_helper.screenshot()
        if time.time() - t0 >= min_sec and img is not None:
            try:
                if pred(img):
                    return img, True
            except Exception:                              # noqa: BLE001
                pass
        if time.time() - t0 >= max_sec:
            return img, False


def open_board(stop_flag=None):
    """11/12: open_board_core, and when it gives up because the icon is not on screen at all (a new event drew a
    new icon), event_icon_search tries every timed icon in the bottom bar once and learns the one that opens the
    board (owner pick; it rests on a dead event, see event_icon_search)."""
    board = _open_board_core(stop_flag)
    if board is not None:
        return board
    try:
        img = adb_helper.screenshot()
        if img is not None and hud_is_bright(img) and find_board_icon(img) is None:
            import event_icon_search
            return event_icon_search.search(stop_flag)
    except StopRequested:
        raise
    except Exception as e:                                  # noqa: BLE001
        log(f"[event icon] search failed ({e}).")
    return None


def _open_board_core(stop_flag=None):
    """Opens the event board and verifies it. SAFE ordering (a blind repeated
    tap at the icon spot once opened the Prize Tent, found live 10/2, and on an
    open board that same spot is card 3's TRASH button): look at the screen
    FIRST, never tap the icon while a board/panel is already up.
    If the icon cannot be found: zoom out and check again, then swipe left and check
    again (RECOVERY_LADDER) -- every rung starts with the dialog + open-panel checks.
    Any zoom-out is undone afterwards so later plot sweeps see the normal zoom."""
    rung = 0
    zoomed_out = False
    t0 = time.time()
    try:
        for attempt in range(1, 4 + len(RECOVERY_LADDER) * 2 + 1):
            of.check_stop(stop_flag)
            img = adb_helper.screenshot()
            if board_is_open(img):
                if attempt > 1:
                    log(f"Open board: open after {attempt - 1} step(s), {time.time() - t0:.0f} s.")
                return img
            if fac.dismiss_error_dialog():          # Whoops / ANR / reward / Prize Tent...
                log(f"Open board step {attempt}: closed an error/reward dialog first.")
                continue
            if station_panel_open(img) or of.panel_is_open(img):
                log(f"Open board step {attempt}: a {'station panel' if station_panel_open(img) else 'panel'} "
                    "is open -- closing it first.")
                fac.close_any_open_panel(quiet=True, thorough=True)
                continue
            loc = find_board_icon(img)
            if loc is None:
                sc = _last_icon_score
                log(f"Open board step {attempt}: board icon not found "
                    f"(best match {sc[0] if sc else '?'} at {sc[1] if sc else '?'}; "
                    f"screen {'plain' if hud_is_bright(img) else 'dimmed by something'}).")
                log("Board icon not found on screen -- not tapping blindly.")
                # A world-space info card (a crop's grow-timer card with its Skip [gem] button,
                # seen live 10/2) dims the HUD but its red X is nowhere near the corner:
                # search the whole screen for a red X and close it (never touching Skip).
                # Pass 2 (10/4): try this FIRST and only keep a picture of the screen when
                # nothing could be closed (it used to save every closable card as "unknown").
                if fac.close_any_open_panel(quiet=True, thorough=True):
                    log("Closed an open info card / panel (red X found) -- checking again.")
                    continue
                save_unknown_screen(img)
                if rung < len(RECOVERY_LADDER):
                    step = RECOVERY_LADDER[rung]
                    rung += 1
                    log(f"Recovery {rung}/{len(RECOVERY_LADDER)}: {step}, then checking panels and the icon again.")
                    _recovery_gesture(step)
                    zoomed_out = zoomed_out or step == "zoom out"
                    time.sleep(1.8)
                else:
                    time.sleep(1.5)
                    if rung >= len(RECOVERY_LADDER):
                        break
                continue
            if bar_is_open(img):
                # 10/31: most first taps that "did nothing" (434 of ~600 openings 10/30-31, ~16 s each) came right after
                # a trip to the plots: the plant bar was still open and the icon tap only closed it. Close it first.
                _stats["bar_closed_first"] = _stats.get("bar_closed_first", 0) + 1
                if _stats["bar_closed_first"] <= 3 or _stats["bar_closed_first"] % 20 == 0:
                    log(f"Open board step {attempt}: the plant bar is still open -- closing it before tapping the board "
                        f"(seen {_stats['bar_closed_first']}x this run).")
                try:
                    import garden_check
                    garden_check.close_plant_bar(stop_flag=stop_flag)
                except StopRequested:
                    raise
                except Exception as e:                      # noqa: BLE001
                    log(f"Open board: closing the plant bar failed ({e}).")
                continue
            img = _settle(img, stop_flag)
            loc = find_board_icon(img) or loc
            if attempt > 1:                                 # 10/17 log diet: step 1 is the normal case
                log(f"Open board step {attempt}: tapping the event icon at {loc} (match {_last_icon_score[0]}).")
            adb_helper.tap(*loc)
            time.sleep(1.5)
            img = adb_helper.screenshot()
            # 10/21 (owner: yes): half the openings "did nothing" on the first tap and needed a second (~16 s per
            # opening). The board is often just slow to appear -- look again a few times before tapping again.
            for _late in range(3):
                if board_is_open(img) or not hud_is_bright(img):
                    break
                time.sleep(0.7)
                img = adb_helper.screenshot()
            if board_is_open(img):
                if attempt > 1 or time.time() - t0 > 15:
                    log(f"Open board: open after {attempt} step(s), {time.time() - t0:.0f} s.")
                _stats["board_opens"] += 1
                return img
            what = ("a buy dialog (No button showing)" if of.find_no_button(img)[0] is not None else
                    "a station panel" if station_panel_open(img) else
                    "some other panel" if of.panel_is_open(img) else
                    "the plain map (tap did nothing yet?)" if hud_is_bright(img) else "something dimming the screen")
            pic = _save_board_try(img, f"board_try{attempt}")
            log(f"Open board step {attempt}: after the tap the screen shows {what}"
                f"{' -- picture templates/event_tapfail/' + pic if pic else ''}.")
        pic = _save_board_try(adb_helper.screenshot(), "board_gaveup")
        log(f"Board did not open (checked before every tap) -- gave up after {time.time() - t0:.0f} s"
            f"{', last screen saved as templates/event_tapfail/' + pic if pic else ''}.")
        return None
    finally:
        if zoomed_out:
            adb_helper.pinch(800, 450, 80, 300, steps=15)     # undo the zoom-out
            time.sleep(1.2)


# --------------------------------------------------------------------------
# Station panels (stoves / merchants): find the card for an item, read its
# ingredients, recurse on a red one or press the action button
# --------------------------------------------------------------------------

STATION_BTN_Y = (540, 640)
EVENT_QUEUE_SLOTS = 2        # event stoves show 2 queue slots + a locked "Unlock"
MAX_DEPTH = 4
PENDING_DIR = os.path.join(BASE_DIR, "templates", "event_pending")


def station_buttons(img):
    return [b for b in find_green_buttons(img, 150, 800)
            if STATION_BTN_Y[0] <= b[1] <= STATION_BTN_Y[1]]


def station_panel_open(img):
    # 10/16: a bright green hedge on the plain map sat exactly in the button band and was taken for a
    # Gather button, so the bot kept "closing a panel" and never tapped the event icon. A real panel
    # always dims the HUD behind it; the plain map never does.
    return len(station_buttons(img)) >= 1 and not hud_is_bright(img)


def queue_slot_total(img, n_empty=0):
    """Number of queue slots on an open station panel (2 on the Merchant / Oz Stove, 3 after the user's upgrade of the Emerald City
    Stove, 4 on the Cow Shed ...). Counts the white tile borders in the queue row; falls back to max(EMPTY, 2) when unsure."""
    counts = []
    for y in (692, 700, 708):
        row = img[y, 300:1150, :].min(axis=1) > 200
        runs, inside = 0, False
        for v in row:
            if v and not inside:
                inside = True
            elif not v and inside:
                runs += 1
                inside = False
        counts.append(runs)
    counts.sort()
    total = counts[1] // 2
    if 2 <= total <= 6 and total >= n_empty:
        return total
    return max(n_empty, EVENT_QUEUE_SLOTS)


def count_empty_slots(img):
    """Number of queue slots showing the white EMPTY label."""
    x1, y1, x2, y2 = of.QUEUE_SLOT_REGION
    res = cv2.matchTemplate(img[y1:y2, x1:x2], of.QUEUE_EMPTY_LABEL_TEMPLATE,
                            cv2.TM_CCOEFF_NORMED)
    xs = sorted(np.where(res >= 0.85)[1])
    clusters = []
    for x in xs:
        if not clusters or x - clusters[-1] > 40:
            clusters.append(int(x))
    return len(clusters)


def card_art(img, bx, by):
    return img[by - 298:by - 112, bx - 100:bx + 80]


def ingredient_icon(img, x, by):
    return img[by - 114:by - 60, x - 32:x + 32]


def board_icon(img, ix, iy):
    return img[iy - 62:iy + 28, ix - 55:ix + 55]


def _thumb(im):
    return cv2.resize(cv2.cvtColor(im, cv2.COLOR_BGR2GRAY), (24, 24)).astype(np.int16)


def _same(a, b, tol=14):
    return float(np.abs(_thumb(a) - _thumb(b)).mean()) < tol


def save_pending(icon, panel_img, why):
    os.makedirs(PENDING_DIR, exist_ok=True)
    stamp = int(time.time())
    cv2.imwrite(os.path.join(PENDING_DIR, f"{stamp}_icon.png"), icon)
    if panel_img is not None:
        cv2.imwrite(os.path.join(PENDING_DIR, f"{stamp}_panel.png"), panel_img)
    log(f"Saved unresolved capture to templates/event_pending/{stamp}_* ({why}).")


def _normal_library_card(icon, img, btns):
    """Fallback for ORDINARY items the image matcher cannot place (soft, low-detail
    icons such as an egg vs a drumstick, seen live 10/2 at the Chicken Coop): name the
    icon with the normal INGREDIENT library (sliding match, reliable), then find that
    dish's card on the panel by its trained PANEL art. Returns a button index or None."""
    try:
        r = of.identify_ingredient(icon)
        name = r.get("name") if isinstance(r, dict) else None
        if not name:
            return None
        cx, conf = of.find_dish_in_panel(img, name)
        if cx is None:
            return None
        i = min(range(len(btns)), key=lambda k: abs(btns[k][0] - cx))
        if abs(btns[i][0] - cx) > 60:
            return None
        log(f"normal-library fallback: icon is '{name}' (panel art match {conf:.2f}) -> card {i}")
        return i
    except Exception as e:                       # noqa: BLE001 -- a fallback must never break the run
        log(f"normal-library fallback failed: {e}")
        return None


# --- Recipe book TEST (10/17, watch-only: nothing here taps or changes what the bot does) ---------
# Every time a station card is read, write down "dish = ingredient x need, ..." in recipe_test.json and
# keep one picture of the card per dish in templates/recipe_test/. Later, Claude compares the notes with
# the pictures: are the dish and ingredient names right, and does the same dish read the same every time?
RECIPE_TEST_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "recipe_test")
RECIPE_TEST_FILE = os.path.join(RECIPE_TEST_DIR, "recipe_test.json")


ING_DIR = os.path.join(RECIPE_TEST_DIR, "ingredients")
_ing_cache = None                                       # [(picture, name)]


def _ing_load():
    global _ing_cache
    if _ing_cache is None:
        _ing_cache = []
        if os.path.isdir(ING_DIR):
            for fn in sorted(os.listdir(ING_DIR)):
                im = cv2.imread(os.path.join(ING_DIR, fn)) if fn.endswith(".png") else None
                if im is not None:
                    _ing_cache.append((im, fn[:-4].split("__")[0].replace("_", " ")))
    return _ing_cache


def _ingredient_name(icon):
    """Name of a station-card ingredient picture, from ingredient pictures learned on earlier chases."""
    best, best_s = None, 0.0
    for im, nm in _ing_load():
        sc = _icon_score(im, icon)
        if sc > best_s:
            best, best_s = nm, sc
    return best if best_s >= BOARD_NAME_MATCH else None


def _ingredient_learn(icon, name):
    """Watch-only (10/17): keep this ingredient picture under the name the game's tooltip just gave it.
    At most 4 pictures per name, and none that look the same as one already kept."""
    try:
        cache = _ing_load()
        mine = [im for im, nm in cache if same_name(nm, name)]
        if len(mine) >= 4 or any(_icon_score(im, icon) >= 0.95 for im in mine):
            return
        os.makedirs(ING_DIR, exist_ok=True)
        safe = "".join(ch if ch.isalnum() else "_" for ch in name)[:40]
        cv2.imwrite(os.path.join(ING_DIR, f"{safe}__{len(mine) + 1}.png"), icon)
        cache.append((icon.copy(), name))
        log(f"[recipe test] learned the ingredient picture for '{name}' ({len(mine) + 1} kept).")
    except Exception as e:                             # noqa: BLE001
        log(f"[recipe test] ingredient learn skipped: {e}")


def _recipe_test(label, icon, img, bx, by, ing):
    try:
        import json
        dish = _last_wanted.get("name") if _last_wanted.get("label") == label else None
        dish = dish or item_name(icon) or "?"
        parts = []
        for k, i in enumerate(ing):
            crop = ingredient_icon(img, i["x"], by)
            nm = _ingredient_name(crop) or item_name(crop) or f"unknown #{k + 1}"
            parts.append({"name": nm, "need": i["need"]})
            if i.get("have") is not None and not nm.startswith("unknown"):
                _stock_seen[_norm(nm)] = (i["have"], time.time(), nm)        # express planner test (10/17)
        text = ", ".join(f"{p['name']} x{p['need'] if p['need'] is not None else '?'}" for p in parts)
        os.makedirs(RECIPE_TEST_DIR, exist_ok=True)
        try:
            with open(RECIPE_TEST_FILE, encoding="utf-8") as fh:
                book = json.load(fh)
        except (OSError, ValueError):
            book = {}
        entry = book.setdefault(dish, {"seen": 0, "readings": {}})
        entry["seen"] += 1
        entry["t"] = int(time.time())                     # 11/13: when last seen (the Prep tab lists this event's items)
        if _last_wanted.get("label") == label and _last_wanted.get("where"):
            entry["where"] = _last_wanted["where"]           # 10/20 storage relief test: which station makes it
        entry["readings"][text] = entry["readings"].get(text, 0) + 1
        same = len(entry["readings"]) == 1
        if entry["readings"][text] == 1 or entry["seen"] % 20 == 0:   # 11/28: was every visit
            log(f"[recipe test] {dish} = {text}  (seen {entry['seen']}x, "
                f"{'same reading every time' if same else str(len(entry['readings'])) + ' DIFFERENT readings'})")
        safe = "".join(ch if ch.isalnum() else "_" for ch in dish)[:40] or "unknown"
        pic = os.path.join(RECIPE_TEST_DIR, f"{safe}.png" if same else f"{safe}_reading{len(entry['readings'])}.png")
        if not os.path.exists(pic):                    # 10/18: each picture saved ONCE (re-saves were re-uploaded)
            h, w = img.shape[:2]
            card = img[max(0, by - 330):min(h, by + 40), max(0, bx - 180):min(w, bx + 180)]
            cv2.imwrite(pic, card)
        tmp = RECIPE_TEST_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(book, fh, indent=1)
        os.replace(tmp, RECIPE_TEST_FILE)
    except Exception as e:                             # noqa: BLE001 -- a test must never break the run
        log(f"[recipe test] skipped: {e}")


# --- Express sprint (10/18) ------------------------------------------------------------------------------
# A station cooks one batch at a time (American Pancakes: 4 min each, 5 wanted = 20 min at the Deli). The
# express logs showed the bot cooking every last berry into a batch that would only START minutes later,
# then finding 0 seeds ("out of that crop") while the plots sat empty. So: during an express, when a batch
# of this dish is already cooking and the station is busy for longer than a crop takes to grow, plant the
# crop instead of queueing it -- every seed comes back as 2 before the station could use it anyway.
SPRINT_MARGIN_SEC = 60
_sprint_until = {}     # crop -> no new sprint planting before this time (one per grow time)


def _express_sprint(img, ing, by, label, icon, depth, stop_flag, ctx):
    _nm, where = _timer_name(label, icon)
    if not where:
        return None
    now = time.time()
    busy = _station_free_at.get(where, 0.0) - now
    for i in ing:
        if not i["have"] or not i["need"]:
            continue
        sub = ingredient_icon(img, i["x"], by)
        crop = _ingredient_name(sub)
        if not crop or _norm(crop) not in _plot_crops:
            continue
        k = _norm(crop)
        if _plots_full_until.get(k, 0.0) > now or _sprint_until.get(k, 0.0) > now:
            continue
        grow = _grow_secs.get(k, 180)
        if busy < grow + SPRINT_MARGIN_SEC:
            continue
        _sprint_until[k] = now + grow
        log(f"'{label}': [sprint] {where} is busy for {int(busy) // 60}m{int(busy) % 60:02d}s, {crop} grows in "
            f"{grow // 60}m{grow % 60:02d}s -- planting the {i['have']} in stock (they come back doubled) "
            "instead of queueing them.")
        _stats["sprint"] += 1
        r = chase(sub, (i["x"], by - 56), f"{label}>sprint", depth + 1, stop_flag, ctx, want=i["have"])
        log(f"'{label}': [sprint] result: {r}")
        if "planted" not in str(r):
            _plots_full_until[k] = time.time() + 180
        return f"recursed:{r}"
    return None


def relief_batches(ing, n_empty):
    """11/4 (owner: storage-full deadlock 11/3 16:32-18:00): batches of one panel card to cook only to MAKE ROOM.
    Ingredients leave storage when cooking STARTS and a finished batch is not in storage until collected, so any card
    whose recipe takes 2+ units frees room. 1 batch per card per visit, all ingredients green and readable, crops
    above the replant reserve (have_for_cooking). Pure, tested."""
    if n_empty <= 0 or not ing:
        return 0
    if any(i.get("color") == "red" or i.get("have") is None or not i.get("need") for i in ing):
        return 0
    can = min(i.get("have_for_cooking", i["have"]) // i["need"] for i in ing)
    if can < 1:
        return 0
    if sum(i["need"] for i in ing) >= 2:
        return 1                                       # 2+ in -> 1 out: frees room for good
    # 11/4 live: every Ghost Merchant card takes ONE ingredient (11/1, 4/1, 0/1) -> the 2+ rule found nothing for 3 h.
    # A 1-in card still moves units OUT of storage onto the station shelf until collected -- the room needed to
    # harvest the crops the cards are waiting on. Only when there is plenty of it (>= RELIEF_SINGLE_MIN).
    return 1 if min(i.get("have_for_cooking", i["have"]) for i in ing) >= RELIEF_SINGLE_MIN else 0


RELIEF_SINGLE_MIN = 3               # a 1-ingredient card is cooked for room only with this many of it in storage
RELIEF_PANEL_MAX = 3                # batches per station visit


def _panel_ingredients(img, bx, by):
    ing = []
    for x, color in count_blobs(img, by - 70, by - 40, bx - 175, bx + 175) or []:
        rc = event_digits.read_count(img, x, by - 55)
        i = {"x": x, "color": color, "have": rc["have"] if rc else None, "need": rc["need"] if rc else None}
        if i["have"] is not None:
            nm = _ingredient_name(ingredient_icon(img, x, by))
            if nm and _norm(nm) in _plot_crops:
                i["have_for_cooking"] = max(0, i["have"] - _reserve(nm))
        ing.append(i)
    return ing


def relief_panel(label, stop_flag, ctx):
    """11/4: storage FULL + an event station's menu open -> cook up to RELIEF_PANEL_MAX batches of any card here
    that uses 2+ ingredients, to make room. 11/3 16:32-18:00 every board card needed a crop (Pumpkin, Blood Orange,
    Ghostly Essence <- Blood Orange), crops cannot be harvested while storage is full, and the old relief only cooked
    the card's OWN dish -- 1.5 h at 30/30 with 0 points. Not during an express. Gem question -> No."""
    if ctx.get("express") or not storage_full_now():
        return 0
    where = _last_wanted.get("where") if _last_wanted.get("label") == label else None
    if not panel_prestock_allowed(where):
        return 0
    img = adb_helper.screenshot()
    if img is None or not station_panel_open(img):
        return 0
    total, tried = 0, []
    for bx, by, *_ in station_buttons(img):
        if total >= RELIEF_PANEL_MAX:
            break
        n_empty = count_empty_slots(img)
        if n_empty <= 0:
            break
        ing = _panel_ingredients(img, bx, by)
        if relief_batches(ing, n_empty) <= 0:
            tried.append(f"x={bx} " + (",".join(f"{i['have']}/{i['need']}{' red' if i['color'] == 'red' else ''}"
                                                for i in ing) or "unread"))
            continue
        adb_helper.tap(bx, by)
        of.interruptible_sleep(1.2, stop_flag)
        img = adb_helper.screenshot()
        no, _nc = of.find_no_button(img)
        if no is not None:
            log("[storage relief] a card's button asked for gems -- declining.")
            adb_helper.tap(*no)
            return total
        if count_empty_slots(img) < n_empty:
            total += 1
            _stg["relief"] = _stg.get("relief", 0) + 1
            log(f"[storage relief] storage full -- cooked 1 batch of the card at x={bx} at {where} to make room "
                f"(ingredients {','.join(str(i['have']) + '/' + str(i['need']) for i in ing)}).")
    if not total:
        log(f"[storage relief] storage full at {where}: nothing here frees room -- " + ("; ".join(tried) or "no cards"))
    return total


PRESTOCK_ROOM = 10                  # 11/14: 6 -> 10 (storage sat 20-25/30 on prestock); 11/4: prestock only while storage has at least this many spaces free


def prestock_room_ok():
    """11/4: prestock filled storage 25 -> 30 on 11/3 afternoon (the guard needs a FRESH reading of 27+). Prestock
    now stops PRESTOCK_ROOM spaces before full, using the last storage reading up to 30 min old (none = allowed)."""
    last, t = _storage.get("last"), _storage.get("last_t", 0)
    try:
        pop_t = fac.STORAGE_FULL_TIMES[-1] if fac.STORAGE_FULL_TIMES else 0
    except Exception:                                   # noqa: BLE001
        pop_t = 0
    if pop_t and time.time() - pop_t < 1800 and pop_t >= t:
        return False
    if not last or time.time() - t > 1800:
        return True
    return last[0] <= last[1] - PRESTOCK_ROOM


def work_station(icon, label, depth, stop_flag, ctx, want=1, after_collect=False):
    """Normal station work, then (pass 13) plant ahead for the batches that are still wanted."""
    ctx.pop("ahead", None)
    try:
        learn_station(label, stop_flag, ctx)              # 11/13: first visit this event -> learn the whole menu
    except StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001
        log(f"[learn menu] failed (ignored): {e!r}")
    try:
        relief_panel(label, stop_flag, ctx)              # 11/4: storage full -> cook here to make room first
    except StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001
        log(f"[storage relief] panel pass failed (ignored): {e}")
    r = _work_station_core(icon, label, depth, stop_flag, ctx, want=want, after_collect=after_collect)
    ah = ctx.pop("ahead", None)
    if PRESTOCK_EACH > 0 and (r in ("waiting", "already_made_this_run", "tap_unverified") or str(r).startswith("queued")):
        try:
            prestock_panel(label, stop_flag, ctx)
        except StopRequested:
            raise
        except Exception as e:                         # noqa: BLE001
            log(f"[prestock] failed (ignored): {e}")
    if not ah or depth >= MAX_DEPTH or not (r == "waiting" or str(r).startswith("queued") or r == "tap_unverified"):
        return r
    img, ing, n, by = ah
    short = []
    for i in ing:
        if i["color"] != "red" and i["have"] is not None and i["need"]:
            d = i["need"] * n - i["have"]
            if d > 0:
                short.append((d, i))
    if not short:
        return r
    d, i = max(short, key=lambda t: t[0])
    try:
        sub = ingredient_icon(img, i["x"], by)
        log(f"'{label}': plant-ahead -- {n} wanted, an ingredient is short by {d} for all of them; chasing it now.")
        r2 = chase(sub, (i["x"], by - 56), f"{label}>ahead", depth + 1, stop_flag, ctx, want=d)
        log(f"'{label}': plant-ahead result: {r2}")
    except StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001
        log(f"'{label}': plant-ahead failed (ignored): {e}")
    return r


_prestock_recent = []          # [(card art, time queued)] -- a prestocked card is left alone for PRESTOCK_GAP_SEC
PRESTOCK_GAP_SEC = 600


def prestock_batches(keep, stock, n_empty, ing, leave_free=1):
    """10/30 (owner: "stock 2 of all Food Club event items"): batches of one panel card to queue so `keep` are in
    storage. stock = its stock box; ing = [{color, have, need, have_for_cooking?}]; one slot stays free for the
    cards' own work. Pure, tested."""
    if stock is None or stock >= keep or not ing:
        return 0
    if any(i.get("color") == "red" or i.get("have") is None or not i.get("need") for i in ing):
        return 0
    can = min(i.get("have_for_cooking", i["have"]) // i["need"] for i in ing)
    return max(0, min(keep - stock, n_empty - leave_free, can))


PRESTOCK_MAX_COOK_SEC = 30 * 60      # 11/1: prestock never starts a cook longer than this (ice cream 3 h blocked
                                    # the Dairy for 6 h after two prestock batches 00:06 + 00:21)


def _regular_station(where):
    """11/1: a station from the recipe book (Dairy, Soup Station ...) -- not an event-only station."""
    try:
        import recipe_book as rb
        known = {it["station"] for it in rb.load()["items"].values() if it.get("station")}
    except Exception:                                   # noqa: BLE001
        return True
    return any(same_name(k, where) for k in known)


def panel_prestock_allowed(where):
    """11/1 (owner: "why did it make two ice creams that take 3 hours each"): the whole-panel prestock only runs at
    an EVENT station (Witch's Cauldron, Ghost Merchant ...). At a regular station (Dairy) every other card is a
    regular dish -- it stocked Ice Cream (3 h) twice -- and when the station name could not be read ("from the.")
    we cannot tell, so no. Pure, tested."""
    w = (where or "").strip(" .").lower()
    if len(w) < 4 or w in ("the", "from the"):
        return False
    return not _regular_station(where)


def prestock_quick_known(dish):
    """11/3 R.U.S.H. (owner: yes): an INGREDIENT of an event dish (Milk for the Scareshake, Egg for Cupcakes) gets
    prestock extras too -- but only when the recipe book knows it and it cooks in <= PRESTOCK_MAX_COOK_SEC (never
    an unknown card, never ice cream)."""
    try:
        import recipe_book as rb
        key = rb.resolve(dish) if dish else None
        sec = rb.load()["items"].get(key, {}).get("cook_sec") if key else None
    except Exception:                                   # noqa: BLE001
        return False
    return bool(sec) and sec <= PRESTOCK_MAX_COOK_SEC


def prestock_cook_ok(dish):
    """11/1: the card's own dish may get prestock extras only when the recipe book says it cooks in
    <= PRESTOCK_MAX_COOK_SEC (unknown = event dish, allowed)."""
    try:
        import recipe_book as rb
        key = rb.resolve(dish) if dish else None
        sec = rb.load()["items"].get(key, {}).get("cook_sec") if key else None
    except Exception:                                   # noqa: BLE001
        sec = None
    return not sec or sec <= PRESTOCK_MAX_COOK_SEC


def prestock_panel(label, stop_flag, ctx):
    """10/30: on an open Food Club station panel, queue every card whose dish has fewer than PRESTOCK_EACH in
    storage (all its ingredients green, crops above the replant reserve). Not during an express or the storage
    guard. Taps only the card's green button; a gem question is declined. 11/1: event stations only."""
    targets = prep_targets()
    if (PRESTOCK_EACH <= 0 and not targets) or ctx.get("express") or storage_guard_on(f"'{label}' prestock"):
        return 0
    where = _last_wanted.get("where") if _last_wanted.get("label") == label else None
    if not prestock_room_ok():
        _prestock_why(where, [f"storage has fewer than {PRESTOCK_ROOM} free spaces"])
        return 0
    why = []                                          # 11/2: prestock never fired for 20 h -- log the reasons
    if not panel_prestock_allowed(where):
        _prestock_why(where, [f"not an event station (read {where!r})"])
        return 0
    img = adb_helper.screenshot()
    if img is None or not station_panel_open(img):
        _prestock_why(where, ["the station menu was not open any more"])
        return 0
    now = time.time()
    _prestock_recent[:] = [(a, t) for a, t in _prestock_recent if now - t < PRESTOCK_GAP_SEC]
    total = 0
    # 11/3 R.U.S.H. (owner: yes): no free slot kept any more -- "one stays free: a board card needs this station"
    # blocked prestock 99x in a day (the cards nearly always need the event stations), so it stocked 13x and
    # expresses started from 0. Not during an express (checked above).
    leave = 0
    for bx, by, *_ in station_buttons(img):
        n_empty = count_empty_slots(img)
        if n_empty <= leave:
            why.append(f"{n_empty} free slot(s)" + (" -- one stays free: a board card needs this station" if leave
                                                     else ""))
            break
        art = card_art(img, bx, by)
        if any(_same(art, a) for a in ctx.get("made", [])) or any(_same(art, a) for a, _ in _prestock_recent):
            why.append(f"x={bx} done recently")
            continue
        stock = of.read_card_stock_low(img, bx)
        nm = item_name(art) if targets else None
        keep = max(PRESTOCK_EACH, keep_for(nm, targets))       # 11/13: the Prep list's own number for this item
        if stock is None or stock >= keep:
            why.append(f"x={bx} stock {'unread' if stock is None else stock}")
            continue
        ing = []
        for x, color in count_blobs(img, by - 70, by - 40, bx - 175, bx + 175) or []:
            rc = event_digits.read_count(img, x, by - 55)
            i = {"x": x, "color": color, "have": rc["have"] if rc else None, "need": rc["need"] if rc else None}
            if i["have"] is not None:
                nm = _ingredient_name(ingredient_icon(img, x, by))
                if nm and _norm(nm) in _plot_crops:
                    i["have_for_cooking"] = max(0, i["have"] - _reserve(nm))
            ing.append(i)
        want = prestock_batches(keep, stock, n_empty, ing, leave_free=leave)
        if want <= 0:
            why.append(f"x={bx} stock {stock}, ingredients " +
                       (",".join(f"{i['have']}/{i['need']}{' red' if i['color'] == 'red' else ''}" for i in ing) or "unread"))
            continue
        queued = 0
        for _ in range(want):
            adb_helper.tap(bx, by)
            of.interruptible_sleep(1.2, stop_flag)
            img = adb_helper.screenshot()
            no, _nc = of.find_no_button(img)
            if no is not None:
                log(f"[prestock] a card's button asked for gems -- declining.")
                adb_helper.tap(*no)
                return total
            if count_empty_slots(img) < n_empty:
                queued += 1
                n_empty -= 1
            else:
                break
        _prestock_recent.append((art, now))
        if queued:
            total += queued
            _stg["prestock"] = _stg.get("prestock", 0) + queued
            log(f"[prestock] card at x={bx}{' (' + nm + ')' if nm else ''} had {stock} in storage, keeping {keep}"
                f"{' (Prep list)' if keep > PRESTOCK_EACH else ''} -- queued {queued} batch(es).")
    if not total:
        _prestock_why(where, why or ["no cards on the panel"])
    return total


def station_needed(where, short_items, where_of, book):
    """11/2 (owner: "what do you think" -> option 2): does a short item on the Food Club board -- or one of its
    ingredients -- cook at `where`? A short item whose station is unknown counts as needed (safe). Pure, tested.
    short_items = [names]; where_of = {norm dish: station}; book = {norm dish: [(ingredient, need)]}."""
    for nm in short_items:
        names = [nm] + [ing for ing, _q in book.get(_norm(nm), [])]
        for k, n in enumerate(names):
            w = where_of.get(_norm(n))
            if not w:
                if k == 0:
                    return True                       # the card's own dish: station unknown -> keep the slot
                continue
            if same_name(w, where):
                return True
    return False


def board_needs_station(where):
    """Live wrapper: short Food Club items from orders_view + stations learned in recipe_test.json."""
    import json
    try:
        import orders_view
        _v, st = orders_view.snapshot()
        short = [it["name"] for o in (st.get("Food Club Event") or {}).get("orders", []) for it in o["items"]
                 if it.get("name") and it.get("kind") != "done"
                 and (it.get("have") or 0) < (it.get("need") or 1)]
        with open(RECIPE_TEST_FILE, encoding="utf-8") as fh:
            raw = json.load(fh)
    except Exception:                                   # noqa: BLE001
        return True                                     # can't tell -> keep the slot free
    where_of = {_norm(d): e.get("where") for d, e in raw.items() if e.get("where")}
    return station_needed(where, short, where_of, _recipe_book())


_prestock_why_t = {}


def _prestock_why(where, reasons):
    """Log-only (11/2): why the panel pass queued nothing -- once per station per 10 min."""
    k = (where or "?").lower()
    if time.time() - _prestock_why_t.get(k, 0) < 600:
        return
    _prestock_why_t[k] = time.time()
    log(f"[prestock] nothing stocked at {where or 'this station'}: " + "; ".join(reasons))


_express_chased = {}            # 11/2: (express item, ingredient spot) -> last time it was chased
EXPRESS_ROTATE_SEC = 120


def _express_key(label, i):
    return (label.split(">")[0], int(i["x"]) // 40)


def express_short_order(label, ing, n_left, reds, now=None):
    """11/2 live 13:32-13:52 (missed express, 2 Halloween Cupcakes): Egg read 1/1 GREEN, but 2 cupcakes need 2 eggs --
    the bot only chased the red Candy (busy Ghost Merchant) for 13 min and found the egg short at 13:45. During an
    express: green ingredients short for the wanted batches count too, and an ingredient chased in the last
    EXPRESS_ROTATE_SEC goes to the back, so every short ingredient gets started. Pure, tested."""
    now = time.time() if now is None else now

    def short(i):
        return i["have"] is not None and i["need"] and i["have"] < i["need"] * n_left

    out = list(reds) + [i for i in ing if i["color"] != "red" and short(i)]
    fresh = [i for i in out if now - _express_chased.get(_express_key(label, i), 0) >= EXPRESS_ROTATE_SEC]
    return fresh + [i for i in out if i not in fresh]


def prestock_extra(keep, n, cooking, n_empty, ing):
    """10/30: extra batches beyond the n wanted (n = what the card is still missing, so its stock goes to the
    card) so `keep` of the dish are left ready afterwards. cooking = batches of it cooking. Pure, tested."""
    need_slots = max(0, n - cooking)                       # slots the wanted batches still take
    can = min((i.get("have_for_cooking", i["have"]) // i["need"]
               for i in ing if i.get("have") is not None and i.get("need")), default=0)
    want = keep - max(0, cooking - n)                      # extra batches already cooking count as ready
    return max(0, min(want, n_empty - need_slots, can - need_slots))


_ORDER_LOGGED = {}


def _order_held(label, img, ing, by):
    """11/9 O.R.D.E.R.: True when cooking this card would take an ingredient a job higher in the jobs list still
    needs (job_order.reserved_for("Food Club Event")). Logs why, max every 5 min per card + ingredient."""
    try:
        import job_order as jo
        reserved = jo.reserved_for(jo.CLUB)
        if not reserved:
            return False
        for i in ing:
            nm = _ingredient_name(ingredient_icon(img, i["x"], by))
            hit = jo.conflict(nm, i.get("have"), i.get("need"), reserved) if nm else None
            if hit:
                jo.note_hold(jo.CLUB, hit[1], nm)
                k = (label, nm)
                if time.time() - _ORDER_LOGGED.get(k, 0) >= 300:
                    _ORDER_LOGGED[k] = time.time()
                    log(f"[o.r.d.e.r.] Food Club: not cooking '{label}' -- it takes {i.get('need') or '?'} {nm} "
                        f"(storage {'?' if i.get('have') is None else i['have']}) and {jo.short_name(hit[1])} "
                        f"(higher in the jobs list) still needs {hit[0]} of it.")
                return True
    except Exception as e:                                  # noqa: BLE001
        log(f"[o.r.d.e.r.] Food Club check failed (cooking as usual): {e!r}")
    return False


def _work_station_core(icon, label, depth, stop_flag, ctx, want=1, after_collect=False):
    """On an open event station panel: pick the card matching `icon`, read
    its ingredients (colour AND have/need counts), then either chase the ingredient that
    is short or press the green button (only if every queue slot is EMPTY).
    `want` = how many of this item are still needed (express orders count what to make):
    a short ingredient is chased for its real deficit (need*want - have), and when
    everything is available up to min(want, batches the stock allows, EMPTY slots)
    batches are queued in one visit."""
    img = adb_helper.screenshot()
    btns = station_buttons(img)
    if not btns:
        return "no_panel"
    best, scores = pick_best(icon, [(i, card_art(img, b[0], b[1])) for i, b in enumerate(btns)])
    log(f"'{label}': card SIFT inliers per card {[s for _, s in scores]} -> "
        f"{'card ' + str(best) if best is not None else 'NO CONFIDENT MATCH'}")
    if best is None:
        best = _normal_library_card(icon, img, btns)
        if best is not None:
            log(f"[train] '{label}': regular dish library knows it -> card {best}.")
    if best is None:
        best, item = library_pick(icon, [(i, card_art(img, b[0], b[1])) for i, b in enumerate(btns)])
        if best is not None:
            log(f"'{label}': item library says '{item}' -> card {best}.")
    if best is None:
        best = pick_card_by_name(icon, img, btns, label, stop_flag)
    if best is None:
        save_pending(icon, img, "card match not confident")
        want = _last_wanted.get("name") if _last_wanted.get("label") == label else None
        log(f"[train] '{label}': could not tell which of the {len(btns)} cards it is -- picture match, regular "
            f"library and item library all unsure; " + (f"looked for '{want}' by name, no single card matched"
            if want else "no name from the travel tooltip (OCR read nothing), so it could not pick the card by "
            "name") + ". Picture saved to templates/event_pending; it tries again next pass.")
        return "unsure"
    bx, by = btns[best][0], btns[best][1]
    if after_collect:
        # pass 5: a centre-tap collected something to open this panel. Wait for the count to update,
        # then look at THIS card's stock box (the real count; None = unreadable, treated as enough). Stock 0 = the collected batch was not
        # this item, so keep going now instead of waiting a whole pass; 1+ = it may be this item -> stop.
        of.interruptible_sleep(1.5, stop_flag)
        img = adb_helper.screenshot()
        btns = station_buttons(img) or btns
        stock_now = of.read_card_stock_low(img, bx)
        if stock_now is not None and 0 < stock_now < int(want or 1):
            log(f"'{label}': collected a finished batch; the card has {stock_now} but {int(want)} are still wanted -- "
                f"continuing for {int(want) - stock_now} more.")
            want = int(want) - stock_now
        elif stock_now != 0:
            log(f"'{label}': collected a finished batch and this card's stock is "
                f"{'2+' if stock_now is None else stock_now} -- it may be this item, so not cooking more (next pass re-reads the board).")
            return "collected_blocker"
        else:
            log(f"'{label}': collected a finished batch but this card's stock is 0 -- it was a different item; continuing now.")
    blobs = count_blobs(img, by - 70, by - 40, bx - 175, bx + 175)
    if not blobs:
        return "unreadable"
    n = max(1, int(want or 1))
    ing = []       # [{x, color, have, need}]  (have/need None when the digits are unreadable)
    for x, color in blobs:
        rc = event_digits.read_count(img, x, by - 55)
        ing.append({"x": x, "color": color,
                    "have": rc["have"] if rc else None, "need": rc["need"] if rc else None})
    shown = ", ".join((f"{i['have']}/{i['need']}" if i["have"] is not None else "?") + ("" if i["color"] == "green" else " red")
                      for i in ing)
    log(f"'{label}': have/need per ingredient [{shown}], wanting {n} of this item")
    _recipe_test(label, icon, img, bx, by, ing)
    # 10/20 (owner, live 12:49): Cherry Pie was queued at 12:45, which took its ice cream out of storage, so the
    # card showed the ice cream red again and the bot chased ice cream for a SECOND pie. Our own batches of this
    # dish that already cover what is wanted -> just wait for them, chase nothing.
    _mine0 = _batches_of_this_dish(label, icon)
    _relief_ok = not ctx.get("express") and storage_full_now() and all(i["color"] != "red" for i in ing)
    if _mine0 is not None and _mine0 >= n and not _relief_ok:
        log(f"'{label}': {_mine0} batch(es) of this dish already cooking for {n} wanted -- the red ingredient "
            "went into them; waiting, not chasing more.")
        _worth_cooking(label, icon, ctx)
        _slot_ad(label, icon, ctx, stop_flag)
        return "waiting"

    def deficit(i, batches):
        if i["have"] is None:
            return 1 if i["color"] == "red" else 0
        return max(0, i["need"] * batches - i["have"])

    # 1) an ingredient that is red (cannot make even ONE batch): chase it, biggest deficit first
    n_left = max(1, n - (_mine0 or 0))                     # batches still to start (ours already cooking excluded)
    reds = sorted((i for i in ing if i["color"] == "red"), key=lambda i: -deficit(i, n_left))
    if ctx.get("express"):
        reds = express_short_order(label, ing, n_left, reds)
    if reds:
        if depth >= MAX_DEPTH:
            return "too_deep"
        i = reds[0]
        if ctx.get("express"):
            _express_chased[_express_key(label, i)] = time.time()
        d = max(1, deficit(i, n_left))
        sub = ingredient_icon(img, i["x"], by)
        if not ctx.get("express") and not storage_guard_on(f"'{label}': red crop ingredient"):
            nm = _ingredient_name(sub)
            if nm and _norm(nm) in _plot_crops:
                d += _reserve(nm)                          # seed reserve: plant enough to replant next time too
        log(f"'{label}': short of an ingredient -- chasing {d} of it.")
        r = chase(sub, (i["x"], by - 56), f"{label}>ingredient", depth + 1, stop_flag, ctx, want=d)
        return f"recursed:{r}"
    # 1b) seed reserve (10/17): a crop ingredient is cooked only above SEED_RESERVE, so the plots get
    # replanted and the crop doubles. Below it: plant instead (every free plot). Not during an express.
    if not ctx.get("express") and depth < MAX_DEPTH and not storage_guard_on(f"'{label}'"):
        for i in ing:
            if i["have"] is None or not i["need"]:
                continue
            nm = _ingredient_name(ingredient_icon(img, i["x"], by))
            if not nm or _norm(nm) not in _plot_crops:
                continue
            if _plots_full_until.get(_norm(nm), 0.0) > time.time():
                continue                                   # no free plot: seeds cannot be planted anyway -- cook
            keep = _reserve(nm)
            can = (i["have"] - keep) // i["need"]
            if can >= 1:
                i["have_for_cooking"] = i["have"] - keep
                continue
            wait = _crop_ready.get(_norm(nm), 0.0) - time.time()
            if wait > 0:
                log(f"'{label}': seed reserve -- {nm} {i['have']} in stock (keeping {keep}); more is growing, ready in "
                    f"{int(wait) // 60}m{int(wait) % 60:02d}s; waiting for them.")
                return "waiting"
            log(f"'{label}': seed reserve -- {nm} {i['have']} in stock, keeping {keep}"
                + (" (express buffer)" if keep > SEED_RESERVE else "") + " to replant, "
                "so not cooking with it yet; planting it instead.")
            _storage_test_reserve(nm, i["have"], keep, i["need"] * n)
            sub = ingredient_icon(img, i["x"], by)
            r = chase(sub, (i["x"], by - 56), f"{label}>reserve", depth + 1, stop_flag, ctx,
                      want=keep + i["need"] * n)
            if "planted" not in str(r):                     # nowhere to plant: don't hold seeds back for 3 min
                _plots_full_until[_norm(nm)] = time.time() + 180
            return f"recursed:{r}"
    # 1c) O.R.D.E.R. (11/9): a job higher in the jobs list (e.g. the Food Truck above Food Club) still needs some of
    # these ingredients -> leave them. Never during an express (expresses beat everything).
    if not ctx.get("express") and _order_held(label, img, ing, by):
        return "waiting"
    # 2) one batch is possible; how many batches does the stock allow?
    k = n
    for i in ing:
        if i["have"] is not None and i["need"]:
            k = min(k, i.get("have_for_cooking", i["have"]) // i["need"])
    k = max(1, k)
    ctx["ahead"] = (img, ing, n, by)                      # pass 13: for plant-ahead after the queue work
    art = card_art(img, bx, by)
    if any(_same(art, a) for a in ctx["made"]):
        return "already_made_this_run"
    n_empty = count_empty_slots(img)
    slots_total = queue_slot_total(img, n_empty)            # pass 15: the real number of slots on this panel
    try:
        _nm, _wh = _timer_name(label, icon)
        if _wh:
            _station_slots[_wh] = slots_total                # skip test: how many slots this station has
            _note_fc_station(_wh)
    except Exception:                                       # noqa: BLE001
        pass
    cooking = max(0, slots_total - n_empty)                 # pass 12: occupied slots = batches already cooking
    try:                                                    # 10/20 simulator step 3: grade the "busy until" model
        import kitchen_model
        kitchen_model.station_seen(_timer_name(label, icon)[1], cooking, slots_total, log)
    except Exception:                                       # noqa: BLE001
        pass
    mine = _batches_of_this_dish(label, icon)               # 10/17: only batches of THIS dish count
    if mine is not None and mine < cooking:
        log(f"'{label}': {cooking} batch(es) cooking here, {mine} of them this dish -- the rest are other dishes.")
        cooking = mine
    if ctx.get("express") and cooking >= 1 and depth < MAX_DEPTH:
        r = _express_sprint(img, ing, by, label, icon, depth, stop_flag, ctx)
        if r:
            return r
    if n_empty > 0 and cooking >= n and _relief_ok:
        # 10/20 (owner: "try to make something, doesn't matter what"): storage full, purge off -> cook extra
        # batches into the free slots. Ingredients leave storage when cooking STARTS (tested live), so a 3->1
        # recipe frees 2 spaces per batch; the extra dish serves a later card.
        extra = min(k, n_empty)
        log(f"[storage relief] storage full -- cooking {extra} extra batch(es) of this dish to make room "
            f"({cooking} already cooking for {n} wanted).")
        _stg["relief"] = _stg.get("relief", 0) + extra
        n = cooking + extra
    elif ((PRESTOCK_EACH > 0 or prep_keep(_last_wanted.get("name") if _last_wanted.get("label") == label else None) > 0)
          and not ctx.get("express") and n_empty > 0
          and (prestock_cook_ok(_last_wanted.get("name") if _last_wanted.get("label") == label else None)
               if depth == 0 else
               prestock_quick_known(_last_wanted.get("name") if _last_wanted.get("label") == label else None))
          and not storage_guard_on(f"'{label}' no prestock extras") and prestock_room_ok()):
        # 10/30 (owner: new setting "Prestock Food Club event storage"): while cooking a card's dish, fill free
        # slots with extra batches so the next card asking for it is served at once. Keeps PRESTOCK_EACH of the
        # dish ready after the card (extra batches cooking count); never eats the crop reserve.
        keep = max(PRESTOCK_EACH, prep_keep(_last_wanted.get("name") if _last_wanted.get("label") == label else None))
        extra = prestock_extra(keep, n, cooking, n_empty, ing)
        if extra <= 0:
            _prestock_why("extras:" + str(_last_wanted.get("name")), [
                f"no extra batches of {_last_wanted.get('name')}: {n_empty} free slot(s), {n} wanted, {cooking} cooking, "
                "ingredients " + (",".join(f"{i.get('have')}/{i.get('need')}" for i in ing) or "unread")])
        if extra > 0:
            log(f"[prestock] '{label}': keeping {keep} ready after this card -- cooking {extra} extra "
                f"batch(es) besides the {n} wanted.")
            _stg["prestock"] = _stg.get("prestock", 0) + extra
            n = max(n, cooking) + extra
            k = max(k, n - cooking)
    if n_empty == 0 or cooking >= n:
        log(f"'{label}': queue not empty ({n_empty}/{slots_total} EMPTY, {cooking} cooking, {n} wanted) "
            "-- already cooking enough, not queueing more.")
        if mine is None and n_empty > 0:
            _stuck_watch(label, icon, cooking)
        return "waiting"
    _stuck_end(label, icon)
    if cooking:
        log(f"'{label}': {cooking} already cooking but {n} wanted -- filling the free slot.")
    batches = min(k, n_empty, n - cooking)
    queued = 0
    cur_empty = n_empty
    for _ in range(batches):
        adb_helper.tap(bx, by)
        of.interruptible_sleep(1.2, stop_flag)
        img2 = adb_helper.screenshot()
        no, nc = of.find_no_button(img2)
        if no is not None:
            log(f"'{label}': action opened a gem-buy dialog -- declining.")
            adb_helper.tap(*no)
            return "blocked_gem_dialog" if not queued else f"queued x{queued}"
        n2 = count_empty_slots(img2)
        if n2 < cur_empty:
            queued += 1
            cur_empty = n2
            if n2 == 0:
                break
        else:
            # Pass 2 (10/4): ~9 recent "tap the button" attempts ended "EMPTY slots stayed N". Look again after
            # a longer wait (the panel may redraw late) and keep both pictures so the real cause can be seen.
            of.interruptible_sleep(2.5, stop_flag)
            img3 = adb_helper.screenshot()
            n3 = count_empty_slots(img3)
            if n3 < cur_empty:
                queued += 1
                cur_empty = n3
                log(f"'{label}': the queue showed the new batch a moment later (EMPTY {n_empty} -> {n3}).")
                if n3 == 0:
                    break
                continue
            try:
                folder = os.path.join(BASE_DIR, "templates", "event_tapfail")
                os.makedirs(folder, exist_ok=True)
                stamp = int(time.time())
                cv2.imwrite(os.path.join(folder, f"{stamp}_before.png"), img)
                cv2.imwrite(os.path.join(folder, f"{stamp}_after.png"), img3)
            except Exception:
                pass
            log(f"'{label}': tapped the button but EMPTY slots stayed {n3} even after waiting -- NOT verified "
                "(before/after pictures saved to templates/event_tapfail/).")
            break
    ctx["made"].append(art)
    if queued:
        log(f"'{label}': queued {queued} batch(es) (wanted {n}, stock allowed {k}, EMPTY {n_empty} -> {cur_empty}).")
        try:
            _relief_note_queue(_timer_name(label, icon)[0], queued * sum(i["need"] or 0 for i in ing))
        except Exception:                               # noqa: BLE001
            pass
        try:
            note_station_timer(label, icon, img, bx, by, queued, max(0, EVENT_QUEUE_SLOTS - n_empty))
        except Exception as e:                         # noqa: BLE001 -- a timer must never break cooking
            log(f"[timer] could not note the timer ({e}).")
        return "queued" if queued == 1 else f"queued x{queued}"
    try:                                                    # it may have queued after all: count one, so the
        name, where = _timer_name(label, icon)             # next pass does not queue a second one by mistake
        if where and name != label:
            _note_my_batches(name, where, [time.time() + 600])
    except Exception:                                      # noqa: BLE001
        pass
    return "tap_unverified"


# --------------------------------------------------------------------------
# Plots (raw crops)
# --------------------------------------------------------------------------

BAR_CARD_X0, BAR_CARD_DX = 140, 281   # measured on the real 1600x900 emulator 10/2
BAR_CARD_Y = 260                       # tap point inside a card (art area)


def bar_is_open(img):
    """The 'Tap crops to plant them' bar: a perfectly FLAT dark strip across the top
    (pixel spread 0-0.7 on every real bar) with PALE-BLUE crop cards at its left.
    The old test (strip mean < 100 and a light card pixel) wrongly fired on a plain
    map with dark foliage, so arrival 'saw' a bar, tried to plant, and never tapped a
    single plot (10/2). Flatness + blue card separate it from maps (spread 26+) and
    station panels (spread ~6)."""
    strip = img[100:125, 1000:1250]
    if strip.std() > 2.5 or strip.mean() > 90:
        return False
    b, g, r = img[150:160, 228:238].reshape(-1, 3).mean(0)
    return b >= 235 and (b - r) >= 35


def bar_cards(img):
    out = []
    for k in range(6):
        cx = BAR_CARD_X0 + BAR_CARD_DX * k
        if cx > 1450:
            break
        if img[150:160, cx + 88:cx + 98].mean(axis=(0, 1)).min() > 150:
            out.append(cx)
    return out


# Named-item library (10/15). SIFT + colour could not tell some Food Club items from
# their neighbours (New Potato on the plant bar scored 15 vs 8, the plain Bread card
# at the Bread Oven 7 vs 3), so an item is stored once by name: icon_<name>.png (the
# icon the bot is chasing) and card_<name>.png (the matching card art, cropped the same
# way as the place it is chosen from). Same game art every time, so a plain picture
# match is decisive. Used only after the normal matchers are unsure.
PLANT_LIB_DIR = os.path.join(BASE_DIR, "templates", "plant_bar_library")
PLANT_LIB_ICON_MIN = 0.80     # icon vs stored icon
PLANT_LIB_CARD_MIN = 0.80     # card vs stored card art
PLANT_LIB_MARGIN = 0.15       # the winner must beat the runner-up by this much


def _card_art(img, cx):
    """Plant-bar card art only: below the timer ('3m') and above the stock badge."""
    return img[180:335, cx - 125:cx + 125]


def _inner_match(small, big, pad):
    """Best TM_CCOEFF_NORMED of `small` (trimmed by `pad` px each side) slid inside `big`."""
    s = small[pad:small.shape[0] - pad, pad:small.shape[1] - pad]
    if s.shape[0] < 8 or s.shape[1] < 8 or s.shape[0] > big.shape[0] or s.shape[1] > big.shape[1]:
        return 0.0
    return float(cv2.matchTemplate(big, s, cv2.TM_CCOEFF_NORMED).max())


def library_pick(icon, candidates):
    """candidates = [(key, card_art)]. Returns (key, name) when a stored named item
    matches the icon AND exactly one candidate card, else (None, None). Icons are
    compared on their top 70% (a '0/1' count overlay sits at the bottom)."""
    if icon is None or not candidates or not os.path.isdir(PLANT_LIB_DIR):
        return None, None
    top = icon[:max(1, int(icon.shape[0] * 0.7))]
    named = []
    for fn in sorted(os.listdir(PLANT_LIB_DIR)):
        if not (fn.startswith("icon_") and fn.endswith(".png")):
            continue
        ref = cv2.imread(os.path.join(PLANT_LIB_DIR, fn))
        if ref is None:
            continue
        # icon_<name>__2.png etc. = the same item seen at another size (board icon vs ingredient icon)
        named.append((_inner_match(ref[:max(1, int(ref.shape[0] * 0.7))], top, 4), fn[5:-4].split("__")[0]))
    if not named:
        return None, None
    named.sort(reverse=True)
    score, name = named[0]
    runner = max([s for s, n in named if n != name], default=0.0)
    if score < PLANT_LIB_ICON_MIN or score - runner < PLANT_LIB_MARGIN:
        return None, None
    card_ref = cv2.imread(os.path.join(PLANT_LIB_DIR, f"card_{name}.png"))
    if card_ref is None:
        log(f"item library: icon is '{name}' ({score:.2f}) but card_{name}.png is missing.")
        return None, None
    per_card = sorted(((_inner_match(card_ref, art, 10), key) for key, art in candidates),
                      key=lambda t: t[0], reverse=True)
    cs, key = per_card[0]
    cr = per_card[1][0] if len(per_card) > 1 else 0.0
    log(f"item library: icon is '{name}' ({score:.2f}); card scores {[round(s, 2) for s, _ in per_card]}")
    if cs >= PLANT_LIB_CARD_MIN and cs - cr >= PLANT_LIB_MARGIN:
        return key, name
    return None, None


def plant_item(icon, label, stop_flag, times=1):
    img = adb_helper.screenshot()
    if not bar_is_open(img):
        log(f"'{label}': plant bar is not open -- not planting.")
        return "bar_closed"
    cards = bar_cards(img)
    best, scores = pick_best(icon, [(cx, img[150:335, cx - 125:cx + 125]) for cx in cards])
    log(f"'{label}': plant-bar SIFT inliers {[s for _, s in scores]} -> {best}")
    if best is None:
        best, crop = library_pick(icon, [(cx, _card_art(img, cx)) for cx in cards])
        if best is not None:
            log(f"'{label}': item library says '{crop}' -> plant-bar card at x={best}.")
    if best is None:
        save_pending(icon, img, "plant-bar match not confident")
        return "unsure"
    adb_helper.tap(best, BAR_CARD_Y)
    of.interruptible_sleep(1.0, stop_flag)
    img2 = adb_helper.screenshot()
    no, nc = of.find_no_button(img2)
    if no is not None or fac.dismiss_error_dialog():
        # a 0-stock crop pops "You are out of X! Buy and plant one now? [No] [Yes N gems]"
        if no is not None:
            adb_helper.tap(*no)
        log(f"'{label}': out of that crop (stock 0) -- declined the gem purchase, nothing planted.")
        return "no_stock"
    planted = 1
    ran_out = False
    for _ in range(max(0, int(times) - 1)):
        img3 = adb_helper.screenshot()
        if not bar_is_open(img3):
            break                                   # no empty plot left (the bar closed itself)
        adb_helper.tap(best, BAR_CARD_Y)
        of.interruptible_sleep(1.0, stop_flag)
        img4 = adb_helper.screenshot()
        no, nc = of.find_no_button(img4)
        if no is not None or fac.dismiss_error_dialog():
            if no is not None:
                adb_helper.tap(*no)
            log(f"'{label}': ran out of that crop after {planted} -- declined the gem purchase.")
            ran_out = True
            break
        planted += 1
    log(f"'{label}': planted {planted} (tapped bar card at x={best}, wanted {times}).")
    if planted < int(times) and not ran_out:
        name, _ = _timer_name(label, icon)
        if name and name != label:
            _plots_full_until[_norm(name)] = time.time() + 180      # re-check after one grow time
    try:
        note_plant_timer(label, icon, img, best, planted)
    except Exception as e:                             # noqa: BLE001 -- a timer must never break planting
        log(f"[timer] could not note the timer ({e}).")
    return "planted" if planted == 1 else f"planted x{planted}"


def plot_points(img, max_points=8):
    """Tap points for the crop plots on screen, nearest the centre first.
    A plot = a brown soil blob (HSV) ringed by grey/white stone, wide rhombus shaped.
    Rejects the orange rug, a player's hair, grills, the tent doorway (rim colour,
    aspect ratio) and the HUD / nav / event-icon zones. Planted plots show less
    soil, so min area is small."""
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, (5, 90, 35), (22, 230, 130))
    m[:100, :] = 0
    m[780:, :] = 0
    m[:, 1380:] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    out = []
    for i in range(1, n):
        area, w, h = int(st[i][4]), int(st[i][2]), int(st[i][3])
        if area < 1800 or h == 0:
            continue
        ratio, fill = w / h, area / float(w * h)
        if not (1.3 <= ratio <= 3.2) or fill < 0.20 or int(cen[i][0]) < 110:
            continue
        if int(cen[i][0]) < 170 and 370 < int(cen[i][1]) < 530:      # pass 24: the club-chat button, not a plot
            continue
        blob = (lab == i).astype(np.uint8)
        ring = cv2.dilate(blob, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (45, 45))) - blob
        px = hsv[ring > 0]
        stone = float(((px[:, 1] < 55) & (px[:, 2] > 60)).mean())
        if stone < 0.35:
            continue
        out.append((int(cen[i][0]), int(cen[i][1])))
    out.sort(key=lambda p_: (p_[0] - 800) ** 2 + (p_[1] - 450) ** 2)
    try:                                           # pass 37: the Merchant cart is not a plot (tapping it opens the Merchant panel)
        cart = _fresh_building_finder().find(img, "merchant")
    except Exception:                              # noqa: BLE001
        cart = None
    if cart is not None:
        out = [p_ for p_ in out if not (abs(p_[0] - cart[0]) <= 190 and abs(p_[1] - cart[1]) <= 150)]
    return out[:max_points]


# pass 6 (10/5): plots that opened the plant bar but could not be planted (crop stock 0) are tapped LAST on the
# next sweeps, so ready crops on the other plots get harvested first.
EMPTY_PLOT_MEMORY_SEC = 1200
_empty_plot_memory = []        # [(x, y, time)]
_last_bar_plot = None
_last_sweep_pts = []           # plots the latest sweep found (same camera as the bar that opened)


def _deferred_plots():
    global _empty_plot_memory
    now = time.time()
    _empty_plot_memory = [m for m in _empty_plot_memory if now - m[2] < EMPTY_PLOT_MEMORY_SEC]
    return [(m[0], m[1]) for m in _empty_plot_memory]


def _near(p, q, tol=40):
    return abs(p[0] - q[0]) <= tol and abs(p[1] - q[1]) <= tol


def note_plot_result(result):
    """chase() reports the planting result here: stock 0 -> remember the plot, planted -> forget it."""
    global _empty_plot_memory
    p = _last_bar_plot
    if p is None:
        return
    _empty_plot_memory = [m for m in _empty_plot_memory if not _near(p, (m[0], m[1]))]
    if result == "no_stock":
        _empty_plot_memory.append((p[0], p[1], time.time()))
        log(f"plot at {p} could not be planted (crop stock 0) -- it will be tapped last on the next sweeps "
            "so ready crops on the other plots are harvested first.")


def _save_recover_debug(img, x, y, rnd):
    """Keep the screen after a failed bar reopen (newest 30 kept) so the failure can be looked at."""
    try:
        folder = os.path.join(BASE_DIR, "templates", "recover_debug")
        os.makedirs(folder, exist_ok=True)
        for old in sorted(os.listdir(folder))[:-29]:
            os.remove(os.path.join(folder, old))
        cv2.imwrite(os.path.join(folder, f"{int(time.time())}_{x}_{y}_r{rnd}.png"), img)
    except Exception as e:                                # noqa: BLE001
        log(f"could not save the recovery picture ({e}).")


def recover_no_stock(icon, label, stop_flag, times=1):
    """The 'out of crop' prompt means that crop is planted somewhere (user, 10/6): tap every OTHER plot to harvest the ready
    ones, then reopen the bar on the empty plot and plant again. Returns plant_item's result or "no_stock"."""
    global _last_bar_plot
    bar_plot = _last_bar_plot
    img = adb_helper.exact_screenshot()                    # 11/1: plot finding needs exact pixels (FLASH copies differ)
    pts = [p for p in plot_points(img) if bar_plot is None or not _near(p, bar_plot)]
    if not pts:
        pts = [p for p in _last_sweep_pts if bar_plot is None or not _near(p, bar_plot)]
        if pts:
            log(f"'{label}': no plots visible under the bar -- using the {len(pts)} the sweep just found.")
    if not pts:
        log(f"'{label}': out of that crop but no other plots known on this screen -- nothing to harvest.")
        return "no_stock"
    log(f"'{label}': crop is in the ground elsewhere -- tapping {len(pts[:6])} other plot(s) to harvest it.")
    # 10/18: the plant bar is still open from the empty plot. A tap on another plot then only CLOSES the bar --
    # it looked like "no panel = harvested", and the re-open that followed failed 7 of 7 times live. Close it first.
    if bar_is_open(adb_helper.screenshot()):
        try:
            import garden_check as _gc
            _gc.close_plant_bar(stop_flag)
        except of.StopRequested:
            raise
        except Exception:                              # noqa: BLE001
            of.close_any_open_panel(quiet=True, thorough=True)
        of.interruptible_sleep(0.6, stop_flag)
    harvested = 0
    harvested_pts = []                              # pass 17: plots this recovery harvested
    for (x, y) in pts[:6]:
        of.check_stop(stop_flag)
        adb_helper.tap(x, y)
        of.interruptible_sleep(1.1, stop_flag)
        im2 = adb_helper.screenshot()
        if bar_is_open(im2):                           # an EMPTY other plot opened the bar -- close it again, or the
            try:                                       # next tap only closes it and looks like a harvest (review 10/18)
                import garden_check as _gc
                _gc.close_plant_bar(stop_flag)
            except of.StopRequested:
                raise
            except Exception:                          # noqa: BLE001
                of.close_any_open_panel(quiet=True, thorough=True)
            of.interruptible_sleep(0.6, stop_flag)
            continue
        if fac.dismiss_error_dialog():
            continue
        if of.close_any_open_panel(quiet=True, thorough=True):
            log(f"plot at ({x},{y}): still growing (timer card closed, Skip never touched).")
        else:
            harvested += 1
            log(f"plot at ({x},{y}): no panel -> ready crop harvested.")
            harvested_pts.append((x, y))
    if not harvested or bar_plot is None:
        return "no_stock"
    of.interruptible_sleep(0.8, stop_flag)            # 10/18: let the harvest animation finish before re-tapping
    for rnd, wait in enumerate((1.2, 2.2)):         # pass 21: a second, slower round; failures leave a picture
        if rnd:
            if not fac.dismiss_error_dialog():
                of.close_any_open_panel(quiet=True, thorough=True)
        for tx, ty in harvested_pts[:2] + [bar_plot]:   # a freshly harvested plot reopens the bar; the old one did not (0 of 3 live)
            adb_helper.tap(tx, ty)
            of.interruptible_sleep(wait, stop_flag)
            shot = adb_helper.screenshot()
            if bar_is_open(shot):
                _last_bar_plot = (tx, ty)
                log(f"'{label}': harvested {harvested} plot(s); the plant bar reopened on ({tx},{ty}) -- planting again.")
                return plant_item(icon, label, stop_flag, times=times)
            _save_recover_debug(shot, tx, ty, rnd)
    log(f"'{label}': harvested {harvested} plot(s) but the plant bar did not reopen -- next pass plants.")
    return "no_stock"


LAST_SWEEP_HARVESTED = 0

# 10/18 (owner OK): a plot whose timer card said "2m 40s" is not tapped again until then (55 wasted taps of ~6 s
# in one day's log). Screen positions only repeat while the camera does, so the memory is short and a wrong skip
# only delays one harvest until the remembered time.
_growing_plots = []          # [(x, y, ready_at)]
GROW_CARD_TIME_DX, GROW_CARD_TIME_DY = -259, 456      # the time text, from the card's red X (1600x900 screen)
GROW_SKIP_MAX_SEC = 300      # review 10/18: never skip a screen spot longer -- the camera may have moved meanwhile


def _grow_card_secs(img):
    """Seconds left on an open plot timer card ('2m 40s'), or None."""
    try:
        if fac.pantry_full_dialog_x(img) is not None:  # 10/26 (Muse run check): the popup's red X was taken for the
            return None                                  # timer card's -> dark dimmed area read, black pictures saved
        t = fac.CLOSE_X_TEMPLATE
        th, tw = t.shape[:2]
        r = cv2.matchTemplate(img, t, cv2.TM_CCOEFF_NORMED)
        _, v, _, loc = cv2.minMaxLoc(r)
        if v < 0.8:
            return None
        cx, cy = loc[0] + tw // 2 + GROW_CARD_TIME_DX, loc[1] + th // 2 + GROW_CARD_TIME_DY
        if not (0 <= cx - 130 and cx + 130 <= img.shape[1] and cy + 30 <= img.shape[0]):
            return None
        # 10/19: the station-card reader saw nothing here live (OCR '' 3 of 3) -- this card has DARK text on a
        # light-blue card. Make it black-on-white and 3x bigger first (this read "2m 40s" in the offline test).
        # stops above the Skip button's top edge; +-130 wide (10/19 live: at +-95 "5m 22s" lost its "s")
        crop = img[cy - 26:cy + 20, cx - 130:cx + 130]
        g = cv2.resize(cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY), None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
        _, bw = cv2.threshold(g, 90, 255, cv2.THRESH_BINARY)
        bw = cv2.copyMakeBorder(bw, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)
        import popup_ocr
        raw = popup_ocr.read_text(cv2.cvtColor(bw, cv2.COLOR_GRAY2BGR))
        secs = parse_duration(raw)
        if secs is None:
            log(f"[timer] plot card time not read (OCR said {raw!r}) -- picture saved to templates/time_labels_unknown/.")
            try:
                os.makedirs(TIME_LABEL_UNKNOWN_DIR, exist_ok=True)
                cv2.imwrite(os.path.join(TIME_LABEL_UNKNOWN_DIR, f"plotcard_{int(time.time() * 1000)}.png"),
                            np.vstack([cv2.resize(crop, (bw.shape[1], bw.shape[0])),     # 10/26: the colour crop too,
                                       cv2.cvtColor(bw, cv2.COLOR_GRAY2BGR)]))        # so a wrong spot shows
            except OSError:
                pass
        return secs
    except Exception:                                  # noqa: BLE001
        return None


def _still_growing(p):
    now = time.time()
    _growing_plots[:] = [g for g in _growing_plots if g[2] > now]
    return any(_near(p, (g[0], g[1])) for g in _growing_plots)


LEAVE_RIPE_FREE = 10         # 11/14 (owner: "storage full all night"): with fewer free spaces, ripe crops we already
                             # have KEEP_STORE of stay in the ground (S.P.R.O.U.T. rule; ripe crops take no storage)


def leave_ripe(used_cap, stock, keep, express):
    """Pure: True = do not harvest this ripe crop now."""
    if express or not used_cap or stock is None:
        return False
    used, cap = used_cap
    return cap - used < LEAVE_RIPE_FREE and stock >= keep


def _leave_this_plot(x, y):
    try:
        import sprout
        name = sprout.name_at(x, y)
        if not name:
            return None
        stock = sprout.stock_of(name, _stock_seen)
        if leave_ripe(_storage_used(), stock, sprout.KEEP_STORE, express_active()):
            return f"{name} (have {stock})"
    except Exception:                                 # noqa: BLE001
        pass
    return None


def sweep_plots(stop_flag=None, max_taps=6):
    """GO AROUND: tap each crop plot on screen in turn and read what the game does --
    nothing = a ready crop was harvested, a grow-timer card = still growing (closed
    without touching its Skip), the plant bar = an empty plot (stop, caller plants).
    Returns (kind, found_any): kind in {'plot' (bar open), 'growing', None}."""
    global LAST_SWEEP_HARVESTED
    LAST_SWEEP_HARVESTED = 0                                    # pass 68: how many ready crops this walk harvested (silent taps)
    img = adb_helper.exact_screenshot()                    # 11/1: plot finding needs exact pixels (FLASH copies differ)
    try:                                                        # pass 67: a grow-timer card on screen would give a fake plot (on the card) -- close it first
        import garden_check as _gc
        if _gc.is_grow_timer_card(img):
            _gc._close_grow_card_if_open(img, stop_flag)
            img = adb_helper.exact_screenshot()
    except of.StopRequested:
        raise
    except Exception:                                           # noqa: BLE001
        pass
    if fac.pantry_full_recent():                                # 10/29 live: every plot tap only brought the popup back
        log("[pantry full] not sweeping the plots -- the Pantry is full (pantry relief first).")
        return None, False
    if storage_full_now() and not express_active():            # 11/1 10:24: each plot tap = 'Food Club Storage is full'
        log("[storage full] not sweeping the plots -- Food Club storage is full (harvests are refused).")
        return None, False
    if station_panel_open(img) or board_is_open(img):          # pass 36: never 'sweep' on top of a panel (its art passes the soil test)
        log("plot sweep: a station panel / the board is on screen -- not tapping anything.")
        return None, False
    pts = plot_points(img)
    global _last_bar_plot, _last_sweep_pts
    _last_bar_plot = None
    _last_sweep_pts = list(pts)
    defer = _deferred_plots()
    if defer:
        pts.sort(key=lambda p_: any(_near(p_, d) for d in defer))      # stable: remembered empty plots last
    global _plots_seen
    _plots_seen = max(_plots_seen, len(pts))
    skipped = [p_ for p_ in pts if _still_growing(p_)]
    if skipped:
        pts = [p_ for p_ in pts if p_ not in skipped]
    log(f"plot sweep: {len(pts)} plot(s) found {pts[:max_taps]}"
        + (f" (tapping {len(defer)} remembered empty plot(s) last)" if defer else "")
        + (f" (skipping {len(skipped)} still growing by their timers)" if skipped else ""))
    timer_seen = bool(skipped)
    harvested = []                                  # pass 14: plots harvested during this sweep
    for (x, y) in pts[:max_taps]:
        of.check_stop(stop_flag)
        left = _leave_this_plot(x, y)
        if left:
            log(f"[sprout] leaving ripe {left} in the ground at ({x},{y}) -- storage is nearly full")
            continue
        adb_helper.tap(x, y)
        of.interruptible_sleep(1.1, stop_flag)
        im2 = adb_helper.screenshot()
        if bar_is_open(im2):
            _last_bar_plot = (x, y)
            log(f"plot at ({x},{y}): empty -> plant bar opened")
            return "plot", True
        if fac.dismiss_error_dialog():
            if fac.pantry_full_recent(sec=15):             # 10/29: the tap was refused -- stop sweeping, relief first
                log(f"[pantry full] plot at ({x},{y}): the harvest was refused (Pantry is full) -- stopping the sweep.")
                return None, False
            if fac.STORAGE_FULL_TIMES and time.time() - fac.STORAGE_FULL_TIMES[-1] < 15:
                log(f"[storage full] plot at ({x},{y}): the harvest was refused (Food Club storage full) -- stopping the sweep.")
                return None, False
            im_after = adb_helper.screenshot()             # pass 37: a panel may be open BEHIND the popup that was just closed
            if station_panel_open(im_after) or board_is_open(im_after):
                log(f"plot at ({x},{y}): the tap opened a station panel (not a plot) -- closing it before the next tap.")
                of.close_any_open_panel(quiet=True, thorough=True)
            continue
        secs = _grow_card_secs(im2)                       # read the time left BEFORE closing the card
        try:                                              # 11/2 W.O.R.T.H. test (log only)
            import worth
            worth.note_timer(f"plot at ({x},{y})", secs, express=express_active())
        except Exception:                                 # noqa: BLE001
            pass
        try:                                              # 11/6 S.P.R.O.U.T. step 1 (log only): which crop, ready when
            import sprout
            sprout.note(x, y, sprout.card_name(im2), secs)
        except Exception:                                 # noqa: BLE001
            pass
        try:                                              # 11/1 ADS: Settings "Watch ads for free rewards"
            import ad_player
            if ad_player.ON and not ad_player.EVENT_ONLY and secs and ad_player.worth_it(secs):   # 11/6 switch
                if ad_player.watch(stop_flag, secs, what=f"plot at ({x},{y})") == "watched":
                    secs = 0                              # the ad finished the crop -- tap it again on the next sweep
        except of.StopRequested:
            raise
        except Exception as e:                            # noqa: BLE001 -- an ad problem never stops the sweep
            log(f"[ads] plot ad failed (ignored): {e!r}")
        if of.close_any_open_panel(quiet=True, thorough=True):
            timer_seen = True
            if secs:
                _growing_plots.append((x, y, time.time() + min(secs, GROW_SKIP_MAX_SEC)))
            log(f"plot at ({x},{y}): timer card = still growing (confirmed), closed it"
                + (f" -- ready in {secs // 60}m{secs % 60:02d}s, not tapped again before that" if secs else ""))
        else:
            log(f"plot at ({x},{y}): no panel -> ready crop harvested (or nothing to do)")
            harvested.append((x, y))
            try:                                    # 11/9 S.P.R.O.U.T. step 2, log only
                import sprout
                sprout.note_harvest(x, y, _stock_seen)
            except Exception:                       # noqa: BLE001
                pass
            LAST_SWEEP_HARVESTED = len(harvested)
    if harvested:                                   # pass 14: the harvested plot is empty now -- replant it
        hx, hy = harvested[0]
        of.check_stop(stop_flag)
        adb_helper.tap(hx, hy)
        of.interruptible_sleep(1.1, stop_flag)
        im3 = adb_helper.screenshot()
        if bar_is_open(im3):
            _last_bar_plot = (hx, hy)
            log(f"plot at ({hx},{hy}): harvested earlier in this sweep, empty now -> plant bar opened (replanting)")
            return "plot", True
        if not fac.dismiss_error_dialog():
            of.close_any_open_panel(quiet=True, thorough=True)
        log(f"plot at ({hx},{hy}): tapped the harvested plot again but no plant bar opened.")
    return ("growing" if timer_seen else None), bool(pts)


def arrive(stop_flag):
    """After a quick-travel: wait for a station panel / plant bar. If neither is up,
    tap screen-centre at most twice (collects a finished batch / opens a station
    panel). The centre is only right when quick-travel could centre the camera; at a
    map edge it may hit a plot's rim or a nearby building (food truck, 10/2) -- so if
    that opens nothing useful, GO AROUND and tap each plot on screen (sweep_plots).
    Returns (kind, tapped_any)."""
    _settle(adb_helper.screenshot(), stop_flag)          # 11/1 FLASH step 4b: was a fixed 1.0 s (25x = 25 s / 16 min)
    taps = 0
    saw_timer = False
    for i in range(3):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if station_panel_open(img):
            return "station", taps > 0
        if bar_is_open(img):
            return "plot", taps > 0
        if i == 2:
            break
        if taps >= 1:
            # the previous centre-tap opened something that is not a station/bar
            # (a grow-timer card, the Food Truck panel...): close it (never the Skip)
            # and stop centre-tapping -- it would just reopen
            if of.close_any_open_panel(quiet=True, thorough=True):
                saw_timer = True
                break
        adb_helper.tap(*of.SCREEN_CENTER)
        taps += 1
        # 11/1 FLASH step 4b: was a fixed 1.2 s (28x = 34 s / 16 min) -- stop as soon as a panel, the plant bar or
        # anything covering the map shows; a plain-map tap (a harvest / collect) still waits the full 1.2 s
        wait_for(lambda im: station_panel_open(im) or bar_is_open(im) or not hud_is_bright(im), 1.2, stop_flag)
        if fac.dismiss_error_dialog():       # a stray popup (Prize Tent...) -- closed
            break
    kind, found = sweep_plots(stop_flag)
    if kind:
        return kind, True
    return ("growing", True) if saw_timer else ("unknown", taps > 0 or found)


STATION_CENTRE_TAPS = 4      # 10/16 log: when the menu opened it was by tap 2-3 (26 of 27); more centre taps were wasted
STATION_NEARBY = [(0, 70), (0, -70), (-90, 0), (90, 0), (-70, 70), (70, 70)]   # spots around the centre, tried once each
STATION_OFFSETS_FILE = os.path.join(BASE_DIR, ".station_offsets.json")


def _station_offsets():
    try:
        with open(STATION_OFFSETS_FILE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _remember_station_offset(where, off):
    if not where:
        return
    data = _station_offsets()
    data[where] = list(off)
    try:
        with open(STATION_OFFSETS_FILE, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
    except OSError:
        pass


def arrive_station(label, stop_flag):
    """10/16: the travel tooltip said the item comes FROM a station, so quick-travel centred the camera on it.
    Finished items waiting on it make each tap COLLECT one (the menu stays shut), so: tap the centre a few times
    while each tap leaves the plain map. If the menu still has not opened, the station is NOT under the centre
    (quick-travel cannot centre a building near the map edge -- 34 trips on 10/16 tapped empty ground 12 times):
    try spots around the centre once each, and remember the spot that opened this station's menu so the next
    trip tries it first. Looks before every tap (never taps inside an open panel), never plants.
    Returns (kind, collected_any)."""
    _settle(adb_helper.screenshot(), stop_flag)          # 11/1 FLASH step 4: was a fixed 1.0 s -- until the camera stops
    where = _last_wanted.get("where") if _last_wanted.get("label") == label else None
    learned = _station_offsets().get(where) if where else None
    plan = []
    if learned:
        plan += [tuple(learned)] * 2
    plan += [(0, 0)] * STATION_CENTRE_TAPS
    plan += [o for o in STATION_NEARBY if list(o) != learned]
    cx, cy = of.SCREEN_CENTER
    plain = {}                                 # spot -> plain-map taps there (a collect only counts where the menu opened)
    odd = 0
    for tap, off in enumerate(plan, start=1):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if station_panel_open(img):
            return "station", False
        if bar_is_open(img) or not hud_is_bright(img):         # a plot / something else opened: close it, go on
            odd += 1
            if bar_is_open(img):
                try:
                    import garden_check as _gc
                    _gc.close_plant_bar(stop_flag)
                except of.StopRequested:
                    raise
                except Exception:                              # noqa: BLE001
                    of.close_any_open_panel(quiet=True, thorough=True)
                log(f"'{label}': a planting bar opened (a plot, not the station) -- closed it, not planting.")
            elif not fac.dismiss_error_dialog():
                of.close_any_open_panel(quiet=True, thorough=True)
                log(f"'{label}': something other than the station menu opened -- closed it.")
            if odd >= 3:
                break
            continue
        x, y = cx + off[0], cy + off[1]
        adb_helper.tap(x, y)
        after, _ = wait_for(station_panel_open, 1.4, stop_flag)    # 11/1 FLASH step 4: was a fixed 1.4 s
        if after is None:
            after = adb_helper.screenshot()
        if station_panel_open(after):
            spot = "the centre" if off == (0, 0) else f"{off[0]:+d},{off[1]:+d} from the centre"
            collected = plain.get(off, 0)
            log(f"'{label}': tap {tap} ({spot}): station menu opened"
                f"{f' (after {collected} collecting tap(s) there)' if collected else ''}.")
            if off != (0, 0) and list(off) != learned:
                _remember_station_offset(where, off)
                log(f"'{label}': remembered: {where} opens at {spot} -- trying there first next time.")
            return "station", collected > 0
        if hud_is_bright(after) and not bar_is_open(after):
            plain[off] = plain.get(off, 0) + 1
            log(f"'{label}': tap {tap} at ({x},{y}): plain map after the tap"
                f"{' (probably collected a finished item)' if off == (0, 0) or list(off) == learned else ''}.")
    log(f"'{label}': the station menu did not open after {len(plan)} taps (centre and nearby) -- "
        "not going to the plots; trying again next pass.")
    return "station_not_opened", plain.get((0, 0), 0) > 0


def chase(icon, tap_xy, label, depth, stop_flag, ctx, want=1):
    """Follow one missing item to its source and act there. Returns a short
    status string."""
    if depth > MAX_DEPTH:
        return "too_deep"
    if not tap_item_and_travel(tap_xy, label, stop_flag):
        return "travel_failed"
    if depth > 0 and _last_wanted.get("label") == label and _last_wanted.get("name"):
        _ingredient_learn(icon, _last_wanted["name"])   # recipe test: an ingredient's picture + the game's name for it
    kind, tapped = None, False
    if merchant_item(icon):                           # pass 18: open the Merchant by sight, centre taps only as a fallback
        kind = open_building_by_sight("merchant", stop_flag)
    if kind is None and _last_wanted.get("label") == label and _last_wanted.get("plot") is False:
        kind, tapped = arrive_station(label, stop_flag)      # 10/16: the game said it comes from a station
    if kind is None:
        kind, tapped = arrive(stop_flag)
    log(f"'{label}': arrived -> {kind}{' (needed centre taps)' if tapped else ''}")
    if kind == "station":
        # A centre-tap may have collected a finished batch that already satisfies the need.
        # work_station(after_collect=True) checks the card's stock box and only carries on when
        # the stock is 0 (the batch it collected was some other item) -- pass 5, 10/5.
        return work_station(icon, label, depth, stop_flag, ctx, want=want, after_collect=tapped)
    if kind == "plot" and _last_wanted.get("label") == label and _last_wanted.get("plot") is False:
        log(f"'{label}': arrived at a plot, but the game says {_last_wanted['name']} comes from "
            f"{_last_wanted['where']} -- not planting; trying again next pass.")
        return "wrong_place"
    if kind == "plot":
        r = plant_item(icon, label, stop_flag, times=min(max(1, int(want or 1)), PLANT_MAX_PER_VISIT))
        if r == "no_stock":
            r = recover_no_stock(icon, label, stop_flag, times=min(max(1, int(want or 1)), PLANT_MAX_PER_VISIT))
        note_plot_result(r)
        return r
    return kind


# --------------------------------------------------------------------------
# Board processing
# --------------------------------------------------------------------------

PRESTOCK_HOLD = True        # 10/31 Settings "Prestock before serving"
HOLD_SERVE = False          # 11/13 (owner): "Hold serving" switch next to the Food Club Event job -- no REGULAR card
                            # is handed in; the gold express card still is (owner: still serve expresses)
_hold_said = [0.0]


def hold_skips(img, card, now=None):
    """True when the hold switch keeps this ready card on the board (never a gold express card)."""
    if not HOLD_SERVE:
        return False
    try:
        if is_express_card(img, card):
            return False
    except Exception:                                  # noqa: BLE001
        pass
    now = now or time.time()
    if now - _hold_said[0] > 600:
        _hold_said[0] = now
        log("[hold] 'Hold serving' is on -- ready Food Club cards stay on the board (expresses are still served); "
            "still cooking, prestocking and reading the score.")
    return True
HOLD_MAX_SEC = 12 * 60      # 10/31: a ready card waits for prestock at most this long, then it is served anyway
_held = {}                  # card x bucket -> when it was first held for prestock


def prestock_hold(needs, keep):
    """10/31 (owner: "prestock makes the dishes, then the ingredients, then the crops, then submits an (ordinary)
    order -- so if the next order is an express we are prestocked"): which items of a READY card would drop below
    `keep` in storage once the card is served. needs = card_needs rows. Returns [(i, extra)], extra = batches still to
    make so `keep` remain after serving. Unread counts never hold a card. Pure, tested."""
    out = []
    for i, n in enumerate(needs):
        if n.get("have") is None or n.get("need") is None:
            continue
        extra = n["need"] + keep - n["have"]
        if extra > 0:
            out.append((i, extra))
    return out


def _hold_card(img, c):
    """[(slot, extra)] when this ready card should wait for prestock first, else []."""
    if (not PRESTOCK_HOLD or PRESTOCK_EACH <= 0 or express_active() or storage_full_now()
            or storage_guard_on("ready card served, not held") or not prestock_room_ok()):     # 11/1: held 08:20-08:30 while storage 22 -> 27
        return []
    key = c["cx"] // 60
    since = _held.setdefault(key, time.time())
    if time.time() - since > HOLD_MAX_SEC:
        return []
    needs = card_needs(img, c)
    return [(needs[i]["slot"], extra) for i, extra in prestock_hold(needs, PRESTOCK_EACH)]


def serve_ready_cards(stop_flag=None, max_serves=6):
    """Taps Complete on every board card whose items are all green -- after prestock (10/31): a card is held until
    serving it still leaves PRESTOCK_EACH of each of its dishes in storage, for at most HOLD_MAX_SEC."""
    served = 0
    for _ in range(max_serves):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if not board_is_open(img):
            break
        ready = []
        board = read_board(img)
        for k in [k for k in _held if k not in {c["cx"] // 60 for c in board if card_is_ready(c)}]:
            _held.pop(k, None)                               # that card was served / changed -- forget its clock
        for c in board:
            if not card_is_ready(c):
                continue
            if hold_skips(img, c):
                continue
            hold = _hold_card(img, c)
            if hold:
                left = int(HOLD_MAX_SEC - (time.time() - _held[c["cx"] // 60])) // 60
                log(f"[prestock] card at x={c['cx']} is ready, but serving it now would empty storage -- topping "
                    f"{len(hold)} item(s) up to {PRESTOCK_EACH} first (served anyway in {left} min).")
                continue
            ready.append(c)
        if not ready:
            break
        c = ready[0]
        log(f"Card at x={c['cx']} is fully green -- tapping Complete.")
        try:                                           # History tab (10/16): what is on the card being completed
            done_items = [{"name": item_name(board_icon(img, *n["slot"]["icon"])), "need": n["need"]}
                          for n in card_needs(img, c)]
        except Exception:                              # noqa: BLE001
            done_items = []
        pts = read_regular_points(img, c["cx"])        # 11/28 (owner): the card's own points, not a share of a score rise
        if pts:
            log(f"[score] card at x={c['cx']} pays {pts} points.")
        adb_helper.tap(*c["btn"])
        of.interruptible_sleep(1.5, stop_flag)
        img2 = adb_helper.screenshot()
        no, nc = of.find_no_button(img2)
        if no is not None:
            log("Complete opened a gem-buy dialog (stale read) -- declining.")
            adb_helper.tap(*no)
            break
        served += 1
        _held.pop(c["cx"] // 60, None)
        _view("add_history", "Food Club Event", done_items, points=pts)
        of.interruptible_sleep(1.0, stop_flag)
    return served


# --------------------------------------------------------------------------
# EXPRESS ORDER = state of emergency (built 10/3 from the user's design)
# --------------------------------------------------------------------------
# An express order is the GOLD card (30/45 min timer, a huge reward, lots of items). While one
# is on the board: (1) ONLY that card is worked on -- nothing is made for other cards;
# (2) the only Complete ever tapped is the express card's, and only when it is fully green;
# (3) afsd_core pauses every other feature (normal Orders, Pork, Dairy, Garden, ...) and the
# Merchant stocker; (4) it always tries, even if the clock says it is unlikely to finish;
# (5) every pass it reads the have/need counts (event_digits.py) and logs the shopping
# list, chases the biggest deficit first and queues several batches / plants several crops
# per visit. The state file lets afsd_core know an emergency is on between cycles.

EXPRESS_STATE = os.path.join(BASE_DIR, ".express_state.json")
EXPRESS_TTL_SEC = 600


def is_express_card(img, card):
    """The express card is gold (HSV h~24, s~224, v~217 in its header band); normal cards
    are grey (s~15) and a READY card is tan (s~130)."""
    x = card["cx"]
    band = img[400:470, max(0, x - 100):x + 100]
    if band.size == 0:
        return False
    hsv = cv2.cvtColor(band, cv2.COLOR_BGR2HSV)
    h, s_, v = (float(hsv[:, :, i].mean()) for i in range(3))
    return 15 <= h <= 32 and s_ >= 190 and v >= 190


def card_points_mask(img, cx):
    """10/30: the event points on a card header ("102(+6)" next to the cart) as black text on white: the digits
    are pale yellow (S < 212) with dark outlines on the gold card (S ~224)."""
    c = img[450:498, max(0, cx - 77):cx + 35]
    if c.size == 0:
        return None
    h = cv2.cvtColor(c, cv2.COLOR_BGR2HSV)
    m = (h[:, :, 1] < 212) & (h[:, :, 2] > 220) & (h[:, :, 0] >= 20) & (h[:, :, 0] <= 35)
    b = np.where(m, 0, 255).astype("uint8")
    b = cv2.resize(b, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)
    return cv2.copyMakeBorder(b, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)


def parse_card_points(text):
    """'102 (+6)' / '102(46)' (OCR slip: '+' read as 4) -> 108; '102' -> 102; junk -> None. Pure, tested."""
    t = (text or "").replace(" ", "").replace("O", "0").replace("o", "0")
    m = re.match(r"(\d{1,4})(?:\((?:\+(\d{1,2})|4(\d))\)?)?", t)
    if not m:
        return None
    bonus = m.group(2) or m.group(3)
    return int(m.group(1)) + (int(bonus) if bonus else 0)


COUNTDOWN_BOX = (400, 452, -85, 85)   # y1, y2, dx1, dx2 around the gold card's centre ("18m 31s", dark letters)
_express_clock = {}                   # {"left": secs read, "t": when, "need": rough finish secs, "verdict": ...}


def clock_reading_ok(prev_left, prev_t, new_left, now, odd):
    """Pure (11/2): OCR sometimes drops the minutes ("0m 30s" in the middle of a 17-min express). A reading more
    than 90 s away from where the last one says the clock should be is held back; it is taken only when the next
    reading agrees with it (a real jump). Returns (accept, odd) -- odd = (value, time) of a held-back reading."""
    if prev_left is None or prev_t is None:
        return True, None
    expect = prev_left - (now - prev_t)
    if abs(expect - new_left) <= 90:
        return True, None
    if odd is not None and abs((odd[0] - (now - odd[1])) - new_left) <= 30:
        n = (odd[2] if len(odd) > 2 else 1) + 1
        if n >= 3:                                     # 11/16 (Muse): misreads repeat twice -- a real jump needs 3
            return True, None
        return False, (new_left, now, n)
    return False, (new_left, now, 1)


def countdown_mask(img, cx):
    """10/31 (owner: "read the countdown"): the express card's timer as black text on white (dark letters only)."""
    y1, y2, d1, d2 = COUNTDOWN_BOX
    c = img[y1:y2, max(0, cx + d1):cx + d2]
    if c.size == 0:
        return None
    b = np.where(c.max(axis=2) < 90, 0, 255).astype("uint8")
    b = cv2.resize(b, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)
    return cv2.copyMakeBorder(b, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)


def read_express_countdown(img, cx):
    """Seconds left on the express card, or None."""
    try:
        b = countdown_mask(img, cx)
        if b is None:
            return None
        import popup_ocr
        secs = _parse_wait(popup_ocr.read_text(cv2.cvtColor(b, cv2.COLOR_GRAY2BGR)))
        return secs if secs and 0 < secs < 3 * 3600 else None
    except Exception:                                   # noqa: BLE001
        return None


def express_verdict(left_secs, need_secs):
    """'make it' / 'too slow' / None (unknown). Pure, tested. A 2-min margin: cook times are rough."""
    if not left_secs or need_secs is None:
        return None
    return "make it" if need_secs + 120 <= left_secs else "too slow"


def read_card_points(img, cx):
    """Total event points an express card pays (base + bonus), or None."""
    try:
        b = card_points_mask(img, cx)
        if b is None:
            return None
        import popup_ocr
        return parse_card_points(popup_ocr.read_text(cv2.cvtColor(b, cv2.COLOR_GRAY2BGR)))
    except Exception:                                   # noqa: BLE001
        return None


POINTS_BOX = (450, 500, -85, 40)    # y1, y2, dx1, dx2 around a card's centre: "66 (+10)" next to the event icon


def points_glyphs(img, cx):
    """11/16: yellow points digits on a regular (grey) card -> [(x, w, h, digit, score)] left to right."""
    import coin_digits as cd
    y1, y2, d1, d2 = POINTS_BOX
    c = img[y1:y2, max(0, cx + d1):cx + d2]
    if c.size == 0:
        return []
    h = cv2.cvtColor(c, cv2.COLOR_BGR2HSV)
    m = (h[:, :, 0] >= 18) & (h[:, :, 0] <= 38) & (h[:, :, 2] > 190) & (h[:, :, 1] > 60)
    n, lab, st, _c = cv2.connectedComponentsWithStats(m.astype(np.uint8))
    out = []
    for i in range(1, n):
        x, y, w, hh, a = (int(v) for v in st[i])
        if a < 15 or hh < 8 or x == 0 or x + w >= c.shape[1]:    # parts cut by the box edge (bag icon)
            continue
        f = cd._feat(lab[y:y + hh, x:x + w] == i)
        d, sc = max(((d, float(f @ t)) for d, t in cd._TEMPLATES), key=lambda q: q[1]) if cd._TEMPLATES else (None, 0.0)
        out.append((x, w, hh, d, sc))
    return sorted(out)


def parse_points_glyphs(gl):
    """Pure: glyphs -> (base, bonus) or None. Parentheses are taller than the digits, '+' is short; digits must
    match a shape (>= 0.75). '66 (+10)' -> (66, 10); '102' -> (102, 0)."""
    if not gl:
        return None
    hs = sorted(g[2] for g in gl)
    dh = hs[len(hs) // 2] if len(hs) < 3 else sorted(g[2] for g in gl if g[4] >= 0.75 and g[2] <= hs[-1])[0]
    groups, cur, tall = [], "", 0
    for x, w, hh, d, sc in gl:
        if hh >= dh * 1.15 or hh < dh * 0.75:          # '(' / ')' or '+'
            tall += hh >= dh * 1.15
            if tall >= 2 and not cur and len(groups) >= 2:
                break                                  # past ')' -- nothing after the bonus belongs to the points
            if cur:
                groups.append(cur)
                cur = ""
            continue
        if sc < 0.75:
            return None
        cur += str(d)
    if cur:
        groups.append(cur)
    if not groups or len(groups) > 2 or any(len(g) > 4 for g in groups):
        return None
    return int(groups[0]), (int(groups[1]) if len(groups) > 1 else 0)


def read_regular_points(img, cx):
    """Total points on a regular Food Club card (base + bonus), or None."""
    try:
        r = parse_points_glyphs(points_glyphs(img, cx))
        return (r[0] + r[1]) if r else None
    except Exception:                                   # noqa: BLE001
        return None


def card_eta(items, chain_secs, cooking_left):
    """Pure (11/16, owner: "how much time it has left to cook, considering the ingredients we still need"):
    items = [(name or None, missing)] -> (secs, unknown). An item already cooking counts its time left; else its
    chain (own cook/grow time + the slowest short ingredient). Items cook side by side, so the card = the slowest
    item. unknown = missing items with no name or no known time (the estimate is then a lower bound)."""
    worst, unknown = 0, 0
    for name, missing in items:
        if not missing:
            continue
        if not name:
            unknown += 1
            continue
        left = cooking_left(name)
        t = left if left is not None else chain_secs(name, missing)
        if not t:
            unknown += 1
            continue
        worst = max(worst, int(t))
    return worst, unknown


def points_rate(points, secs):
    """Pure: points per minute for a card that needs `secs` more (min 1 minute)."""
    if not points:
        return None
    return round(points / max(1.0, secs / 60.0), 1)


def eta_text(points, secs, unknown, done):
    """Pure: the Orders tab line, e.g. '~12m left · 76 pts · 6.3 pts/min'."""
    parts = []
    if done:
        parts.append("ready")
    elif secs or unknown:
        m = max(1, -(-secs // 60)) if secs else 0
        t = f"{m // 60}h {m % 60}m" if m >= 60 else f"{m}m"
        parts.append(("~" + t if secs else "time ?") + (" +?" if unknown and secs else "") + " left")
    if points:
        parts.append(f"{points} pts")
        if not done and (secs or not unknown):
            parts.append(f"{points_rate(points, secs)} pts/min")
    return " · ".join(parts)


# 11/16 (owner: "how will we know how accurate it is ... time"): LOG ONLY. Each regular card's FIRST time guess is
# kept; when the card first reads complete, the real time is compared with it. Unknown parts (+?) are tallied apart.
_eta_track = {}            # key -> {"t0", "est", "unk", "seen"}
_eta_stats = {"n": 0, "abs": 0, "signed": 0, "close": 0, "short": 0, "n_unk": 0}
ETA_FORGET_SEC = 3 * 3600  # a card not seen for this long is dropped (served off-screen, board reset ...)
ETA_CLOSE = 0.25           # "close" = within 25 % (or 2 min)


def eta_check_step(track, cards, now):
    """Pure. cards = [(key, est_secs, unknown, done)] from one board read. Returns the (key, est, unk, real_secs) of
    cards that just turned complete; new cards start their clock; complete-at-first-sight cards are never timed."""
    done_now = []
    for key, est, unk, done in cards:
        tr = track.get(key)
        if tr is None:
            if not done and est:
                track[key] = {"t0": now, "est": est, "unk": unk, "seen": now}
            elif done:
                track[key] = {"t0": None, "seen": now}
            continue
        tr["seen"] = now
        if done and tr.get("t0") is not None:
            done_now.append((key, tr["est"], tr["unk"], now - tr["t0"]))
            tr["t0"] = None                            # timed once
    for key in [k for k, v in track.items() if now - v["seen"] > ETA_FORGET_SEC]:
        del track[key]
    return done_now


def eta_close(est, real):
    return abs(real - est) <= max(120, ETA_CLOSE * real)


def _eta_check(cards, now):
    for key, est, unk, real in eta_check_step(_eta_track, cards, now):
        names = ", ".join(n for n in key[1] if n != "?") or "a card"
        off = real - est
        if unk:
            _eta_stats["n_unk"] += 1
        else:
            st = _eta_stats
            st["n"] += 1
            st["abs"] += abs(off)
            st["signed"] += off
            st["close"] += eta_close(est, real)
            st["short"] += off > 0
        st = _eta_stats
        tally = (f"so far {st['n']} card(s): off by ~{st['abs'] // max(1, st['n']) // 60}m on average, "
                 f"{st['close']} close (within 25%), guess too SHORT {st['short']}x / too long "
                 f"{st['n'] - st['short']}x" if st["n"] else "no fully-known guesses yet")
        log(f"[eta check] {names}: guessed ~{est // 60}m{' +?' if unk else ''}, ready after {int(real) // 60}m "
            f"({'+' if off >= 0 else '-'}{int(abs(off)) // 60}m) | {tally}"
            + (f"; {st['n_unk']} more had unknown parts" if st["n_unk"] else ""))


def station_wait(need, cook, slots, busy_left):
    """Pure (11/17 eta check: guessed ~3m, ready after 20m): time for `need` batches of a `cook`-second dish at a
    station with `slots` slots (None = unknown -> 1 round) whose other batches of ours finish after busy_left
    seconds. Batches fill the free slots in rounds; with no free slot the first round waits for one."""
    need = max(1, int(need or 1))
    if not slots:
        return int(cook)
    busy = sorted(max(0, b) for b in busy_left)[:max(0, slots)]
    free = [0.0] * max(0, slots - len(busy)) + list(busy)   # when each slot is next free (11/17 Muse: a slot that
    end = 0.0                                               # frees mid-way takes the next batch then)
    for _ in range(need):
        i = min(range(len(free)), key=lambda j: free[j])
        free[i] += cook
        end = max(end, free[i])
    return int(end)


def _card_eta_now(img, needs):
    """Live wrapper: time estimate for one card from the event recipes, stock seen and our cooking batches."""
    recipe_of, time_of, is_crop, have_of = _chain_funcs(_recipe_book())
    now = time.time()

    def wait_of(name, need, cook):
        k = _norm(name)
        where = (_cook_secs.get(k) or (None, None))[1]
        if not where:
            return cook
        busy = [r - now for (st, d), rs in _my_batches.items() if st == where and d != k for r in rs if r > now]
        return station_wait(need, cook, _station_slots.get(where), busy)

    def chain_secs(name, missing):
        r = chain_order([(name, missing)], recipe_of, time_of, is_crop, have_of, wait_of=wait_of)
        return r[0][1] if r else None

    def item_secs(name, missing):
        """11/17: batches already cooking only cover their own count -- the rest still needs its chain."""
        ready = [r for (_st, d), rs in _my_batches.items() if d == _norm(name) for r in rs if r > now - MY_BATCH_KEEP_SEC]
        left = max(0, int(max(ready) - now)) if ready else None
        rest = missing - len(ready)
        if rest <= 0:
            return left
        t = chain_secs(name, rest)
        return max(left or 0, t or 0) or None

    items = []
    for nd in needs:
        if nd.get("missing"):
            items.append((item_name(board_icon(img, *nd["slot"]["icon"])), nd["missing"]))
    return card_eta(items, item_secs, lambda _n: None)


EXPRESS_POPUP_TITLE = "AFSD -- EXPRESS ORDER"


def close_express_popup():
    """Closes the express pop-up if one is open (the express ended, or a newer one replaces it)."""
    try:
        import ctypes
        u = ctypes.windll.user32
        for _ in range(5):                              # in case an old build left more than one
            h = u.FindWindowW(None, EXPRESS_POPUP_TITLE)
            if not h:
                return
            u.PostMessageW(h, 0x0010, 0, 0)            # WM_CLOSE
            time.sleep(0.2)
    except Exception:                                  # noqa: BLE001 -- not Windows
        pass


def express_alarm(note=""):
    """10/17 (owner): express orders pay 10x points and a person reacting fast beats the bot -- so call the
    owner the moment one appears: a few beeps plus a pop-up on top of every window. Runs on its own thread;
    touches nothing in the game. Silent (just a log line) when not on Windows."""
    _stats["express"] += 1
    if not ALARM_ON:
        log("[alarm] EXPRESS ORDER on the board -- alarm is OFF in Settings, no beeps or pop-up.")
        return
    log("[alarm] EXPRESS ORDER on the board -- calling the owner (beeps + pop-up).")

    def ring():
        try:
            import winsound
            for _ in range(3):
                for f in (880, 1175, 1568):
                    winsound.Beep(f, 180)
                time.sleep(0.4)
        except Exception:                              # noqa: BLE001 -- not Windows / no sound device
            pass

    def popup():
        try:
            import ctypes
            close_express_popup()                      # never two: an older one goes first
            text = (f"An EXPRESS order is on the Food Club board (10x points)! Seen at {time.strftime('%H:%M')}.\n\n"
                    "AFSD is working on it now -- come and help if you can.\n"
                    "(This closes by itself when the express is done or gone.)")
            # MB_OK | MB_ICONINFORMATION | MB_TOPMOST | MB_SETFOREGROUND; closes itself after 30 min at the latest
            ctypes.windll.user32.MessageBoxTimeoutW(0, text, EXPRESS_POPUP_TITLE, 0x0 | 0x40 | 0x40000 | 0x10000,
                                                    0, 30 * 60 * 1000)
        except Exception:                              # noqa: BLE001
            pass
    import threading
    threading.Thread(target=ring, daemon=True).start()
    threading.Thread(target=popup, daemon=True).start()


STORAGE_POPUP_TITLE = "AFSD - Food Club storage FULL"
STORAGE_ALARM_GAP_SEC = 15 * 60
_storage_alarm_t = [0.0]


def storage_alarm():
    """10/20 (owner): the game's "Food Club Storage is full" popup -> call the owner (falling beeps + a pop-up on
    top), at most every 15 min. Same Settings switch as the express alarm. Touches nothing in the game."""
    now = time.time()
    if now - _storage_alarm_t[0] < STORAGE_ALARM_GAP_SEC:
        return
    _storage_alarm_t[0] = now
    if not ALARM_ON:
        log("[alarm] Food Club storage FULL -- alarm is OFF in Settings, no beeps or pop-up.")
        return
    log("[alarm] Food Club storage FULL -- calling the owner (beeps + pop-up).")

    def ring():
        try:
            import winsound
            for _ in range(2):
                for f in (1568, 1175, 880, 660):
                    winsound.Beep(f, 200)
                time.sleep(0.4)
        except Exception:                              # noqa: BLE001
            pass

    def popup():
        try:
            import ctypes
            u = ctypes.windll.user32
            h = u.FindWindowW(None, STORAGE_POPUP_TITLE)
            if h:
                u.PostMessageW(h, 0x0010, 0, 0)        # never two
                time.sleep(0.2)
            text = (f"The Food Club storage is FULL (popup seen at {time.strftime('%H:%M')}).\n\n"
                    "AFSD is cooking extra to make room, but you can free space faster by hand.\n"
                    "(This closes by itself after 15 min.)")
            u.MessageBoxTimeoutW(0, text, STORAGE_POPUP_TITLE, 0x0 | 0x30 | 0x40000 | 0x10000, 0, 15 * 60 * 1000)
        except Exception:                              # noqa: BLE001
            pass
    import threading
    threading.Thread(target=ring, daemon=True).start()
    threading.Thread(target=popup, daemon=True).start()


def _express_write(active, note="", items=None, completed=False, points=None):
    """active=True: an express is on the board (items = what it needs, kept for History). active=False: it is
    gone -- completed=True when the bot tapped its Complete; otherwise History gets a red MISSED row (10/18)."""
    import json
    try:
        if active and not express_active(max_age=45 * 60):    # a NEW express (expresses last up to ~45 min)
            express_alarm(note)
        if active:
            try:                                       # keep what was already noted for this express
                with open(EXPRESS_STATE) as f:
                    _old = json.load(f)
            except (OSError, ValueError):
                _old = {}
            if items is None:
                items = _old.get("items")
            if points is None:
                points = _old.get("points")
            with open(EXPRESS_STATE, "w") as f:
                json.dump({"seen_at": time.time(), "note": note, "items": items or [], "points": points}, f)
        elif os.path.exists(EXPRESS_STATE):
            if not completed:
                try:
                    with open(EXPRESS_STATE) as f:
                        st = json.load(f)
                except (OSError, ValueError):
                    st = {}
                items, seen = st.get("items") or [], float(st.get("seen_at") or 0)
                gone_for = time.time() - seen
                if gone_for < EXPRESS_GONE_CONFIRM_SEC:  # review 10/18: one misread board must not end an express
                    return
                if gone_for > 45 * 60:                   # left over from an old session: no history row
                    log("[history] an old express note from an earlier session was cleared (no history row).")
                else:
                    if _express_clock.get("verdict"):
                        log(f"[express clock] last call was '{_express_clock['verdict']}' -- the express was not "
                            "completed by the bot.")
                    _express_clock.clear()
                    big = [d for t_, d in _score_rises if seen - 60 <= t_ and d >= 100]
                    if big:                              # the score jumped like an express pays: finished by hand
                        log(f"[history] the express left the board and the score rose +{big[-1]} -- finished by hand.")
                        _view("add_history", "Food Club Event", items, express=True, by_hand=True, points=big[-1])
                    else:
                        log("[history] the express left the board without the bot completing it -- marked MISSED "
                            "(or finished by hand).")
                        _view("add_history", "Food Club Event", items, express=True, missed=True,
                              points=st.get("points"))       # 10/30 (owner): what it would have paid, shown red
            os.remove(EXPRESS_STATE)
            close_express_popup()                      # express done or expired: take the pop-up away
            global _express_first_seen
            _express_first_seen = None
    except OSError:
        pass


EXPRESS_GONE_CONFIRM_SEC = 90   # the gold card must be missing this long before the express counts as gone
_score_rises = []                # [(time, points)] -- lets a hand-finished express be told from a missed one


def _express_points():
    """Points the gold card pays, as run_express read it (no OCR here -- the board is published often)."""
    try:
        import json
        with open(EXPRESS_STATE) as f:
            return json.load(f).get("points")
    except Exception:                                   # noqa: BLE001
        return None


def express_active(max_age=EXPRESS_TTL_SEC):
    """True while an express card was seen on the board within the last max_age seconds."""
    try:
        import json
        with open(EXPRESS_STATE) as f:
            return time.time() - float(json.load(f)["seen_at"]) <= max_age
    except Exception:
        return False


def card_needs(img, card):
    """[{slot, color, have, need, missing}] for a card's occupied slots. have/need are None
    when the digits cannot be read (then 'missing' is 1 for a red slot, 0 for green)."""
    out = []
    for s_ in card["slots"]:
        tx, _ = s_["icon"]
        rc = event_digits.read_count(img, tx, ROW_TEXT_Y[s_["row"]])
        if rc:
            have, need, missing = rc["have"], rc["need"], max(0, rc["need"] - rc["have"])
        else:
            have = need = None
            missing = 1 if s_["color"] == "red" else 0
        out.append({"slot": s_, "color": s_["color"], "have": have, "need": need, "missing": missing})
    return out


def shopping_text(needs):
    parts = []
    for n in needs:
        s_ = n["slot"]
        c = f"{n['have']}/{n['need']}" if n["have"] is not None else "?"
        parts.append(f"r{s_['row']}c{s_['col']} {c}" + (f" (missing {n['missing']})" if n["missing"] else " ok"))
    return ", ".join(parts)


# --- Express planner TEST (10/17, watch-only: logs a plan, changes nothing) ----------------------------
# For an express card: the full shopping list through the recipe book (3 Curly Fries -> 6 Spices +
# 3 New Potato), minus the last stock the bot saw, how many harvest rounds the crops need, and what a
# crop sprint WOULD do now. Checked against what really happens before it is ever allowed to steer.
_stock_seen = {}      # crop/dish -> (have, when, name), from station cards
_grow_secs = {}       # crop -> grow time
_cook_secs = {}       # dish -> (cook time, station)
_plots_seen = 0       # most Event Plots one sweep has seen
_express_plan_t = 0.0
_express_first_seen = None


def _recipe_book():
    """dish (normalised) -> [(ingredient name, need)], from the recipe test's most common reading."""
    import json
    try:
        with open(RECIPE_TEST_FILE, encoding="utf-8") as fh:
            book = json.load(fh)
    except (OSError, ValueError):
        return {}
    out = {}
    for dish, entry in book.items():
        readings = entry.get("readings") or {}
        if not readings:
            continue
        best = max(readings.items(), key=lambda kv: kv[1])[0]
        ings = []
        for part in best.split(", "):
            nm, _, q = part.rpartition(" x")
            ings.append((nm, int(q) if q.isdigit() else None))
        out[_norm(dish)] = ings
    return out


def chain_order(items, recipe_of, time_of, is_crop, have_of, depth_max=4, wait_of=None):
    """Pure (11/15 R.U.S.H., owner: "longest chain first"): items = [(name, missing)] on the gold card.
    -> [(name, chain_secs, path, first)] longest chain first. chain_secs = the item's own cook/grow time + the
    slowest SHORT ingredient's chain (an ingredient with enough in storage adds nothing); path = the slowest chain as
    names from the first step to the dish; first = the step to start right away (a crop to plant / an item to queue)."""
    def chain(name, need, depth):
        own = time_of(name) or 0
        if wait_of and own and not is_crop(name):
            own = wait_of(name, need, own)              # 11/17: queue rounds + a busy station's wait
        if is_crop(name) or depth >= depth_max:
            return own, [name]
        best, bpath = 0, []
        for ing, per in (recipe_of(name) or []):
            short = max(0, (per or 1) * need - (have_of(ing) or 0))
            if not short:
                continue
            t, pth = chain(ing, short, depth + 1)
            if t > best:
                best, bpath = t, pth
        return own + best, bpath + [name]
    out = []
    for name, missing in items:
        if missing and missing > 0:
            t, pth = chain(name, missing, 0)
            out.append((name, t, pth, pth[0]))
    return sorted(out, key=lambda r: -r[1])


_rush_logged = {"sig": None}


def _chain_funcs(book):
    """(recipe_of, time_of, is_crop, have_of) over the event recipes + the recipe book (shared by R.U.S.H. and the
    Orders tab's per-card time estimate)."""
    try:
        import recipe_book as rb
        items = rb.load()["items"]
    except Exception:                                  # noqa: BLE001
        items, rb = {}, None

    def key(n):
        try:
            return rb.resolve(n) if rb else None
        except Exception:                              # noqa: BLE001
            return None

    def recipe_of(n):
        r = book.get(_norm(n))
        if r:
            return [(i, q) for i, q in r if not i.startswith("unknown")]
        k = key(n)
        return [((items.get(i) or {}).get("name", i).split(" / ")[0], q) for i, q in (items.get(k) or {}).get("ingredients", [])] if k else None

    def time_of(n):
        cs = _cook_secs.get(_norm(n))
        if cs:
            return cs[0]
        g = _grow_secs.get(_norm(n))
        if g:
            return g
        k = key(n)
        return (items.get(k) or {}).get("cook_sec") if k else None

    def is_crop(n):
        k = key(n)
        return _norm(n) in _plot_crops or bool(k and (items.get(k) or {}).get("kind") == "crop")

    def have_of(n):
        return (_stock_seen.get(_norm(n)) or (0,))[0]

    return recipe_of, time_of, is_crop, have_of


def _rush_plan(names_missing, book):
    """Log-only: which express item has the longest chain and what the bot WOULD start first."""
    recipe_of, time_of, is_crop, have_of = _chain_funcs(book)
    plan = chain_order(names_missing, recipe_of, time_of, is_crop, have_of)
    if not plan:
        return
    top = plan[0]
    sig = (top[0], tuple(top[2]))
    if sig == _rush_logged["sig"]:
        return
    _rush_logged["sig"] = sig
    verb = "plant" if is_crop(top[3]) else "queue"
    rest = "; ".join(f"{n} ~{t // 60}m" for n, t, _p, _f in plan[1:])
    log(f"[rush plan] longest chain: {top[0]} ~{top[1] // 60} min ({' -> '.join(top[2])}) -- WOULD start by: "
        f"{verb} {top[3]} right away" + (f"; then: {rest}" if rest else "") + " (log only)")


def express_plan(img, card, needs):
    global _express_plan_t, _express_first_seen
    now = time.time()
    if _express_first_seen is None or now - _express_first_seen > 3600:
        _express_first_seen = now
    if now - _express_plan_t < 120:
        return
    _express_plan_t = now
    try:
        book = _recipe_book()
        crops, dishes, gaps = {}, {}, []

        def add(name, qty, depth):
            k = _norm(name)
            if k in _plot_crops:
                crops[name] = crops.get(name, 0) + qty
                return
            dishes[name] = dishes.get(name, 0) + qty
            rec = book.get(k)
            if rec is None:
                gaps.append(f"{name} (no recipe yet)")
                return
            if depth >= 2:
                return
            for ing, per in rec:
                if ing.startswith("unknown") or per is None:
                    gaps.append(f"{name}: an ingredient not read yet")
                    continue
                add(ing, per * qty, depth + 1)

        for nd in needs:
            if not nd["missing"]:
                continue
            nm = item_name(board_icon(img, *nd["slot"]["icon"]))
            if not nm:
                gaps.append("an unnamed card item")
                continue
            add(nm, nd["missing"], 0)
        stock = []
        for name in list(crops):
            seen = _stock_seen.get(_norm(name))
            if seen:
                stock.append(f"{name} {seen[0]} ({int((now - seen[1]) // 60)} min ago)")
        plots = _plots_seen or 3
        grow = []
        longest = 0
        for name, qty in crops.items():
            have = (_stock_seen.get(_norm(name)) or (0,))[0]
            short = max(0, qty - have)
            g = _grow_secs.get(_norm(name), 180)
            rounds = -(-short // (2 * plots)) if short else 0    # each plot gives 2 per harvest
            longest = max(longest, rounds * g)
            grow.append(f"{name} need {qty}, have ~{have} -> {rounds} round(s) x {g // 60}m")
        cook = []
        cook_t = 0
        for name, qty in dishes.items():
            cs = _cook_secs.get(_norm(name))
            if cs:
                cook.append(f"{name} x{qty} ({cs[0] // 60}m each at {cs[1]})")
                cook_t = max(cook_t, cs[0])          # 11/16 (Muse): batches cook in parallel slots
            else:
                cook.append(f"{name} x{qty} (cook time unknown)")
        est = max(longest, cook_t) + min(longest, cook_t) // 2    # 11/16: crops grow while dishes cook
        if _express_clock.get("t"):                    # 10/31: compare the rough finish with the card's own clock
            left = int(_express_clock["left"] - (now - _express_clock["t"]))
            v = express_verdict(left, est)
            if v:
                _express_clock.update(need=est, verdict=v)
                log(f"[express clock] needs ~{est // 60} min, the card has {max(0, left) // 60} min -- "
                    + ("on track." if v == "make it" else "probably TOO SLOW -- keeps trying anyway (owner rule: "
                                                        "never drop an express)."))
        try:                                           # 11/15 R.U.S.H.: longest chain first (log only)
            nm_miss = []
            for nd in needs:
                if nd["missing"]:
                    nm = item_name(board_icon(img, *nd["slot"]["icon"]))
                    if nm:
                        nm_miss.append((nm, nd["missing"]))
            _rush_plan(nm_miss, book)
        except Exception as e:                         # noqa: BLE001
            log(f"[rush plan] skipped: {e!r}")
        age = int((now - _express_first_seen) // 60)
        sprint = [n for n, q in crops.items() if q > (_stock_seen.get(_norm(n)) or (0,))[0]]
        log(f"[express plan] (express seen {age} min ago) crops: {'; '.join(grow) or 'none'} | "
            f"cooking: {', '.join(cook) or 'none'} | stock seen: {', '.join(stock) or 'none'} | "
            f"plots ~{plots} | rough finish in ~{est // 60} min"
            + (f" | a crop sprint would stay at the plots for: {', '.join(sprint)}" if sprint else "")
            + (f" | gaps: {', '.join(gaps)}" if gaps else ""))
    except Exception as e:                             # noqa: BLE001 -- a test must never break the run
        log(f"[express plan] skipped: {e}")


def run_express(stop_flag=None, max_chases=8):
    """One emergency pass over the board. Returns (served, results)."""
    ctx = {"made": [], "express": True}
    results = []
    served = 0
    handled = []
    log("EXPRESS ORDER ACTIVE -- STATE OF EMERGENCY: working ONLY on the gold card, no other "
        "order will be made or completed.")
    first = True
    for n in range(max_chases):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if not board_is_open(img):
            img = open_board(stop_flag)
            if img is None:
                results.append({"item": "EXPRESS", "status": "board_not_opened"})
                break
        cards = read_board(img)
        ex = [c for c in cards if is_express_card(img, c)]
        if not ex:
            log("EXPRESS: the gold card is no longer on the board (completed or expired) -- "
                "emergency over.")
            _express_write(False)
            break
        card = ex[0]
        slot_pos = _publish_board(img, cards, express=card) or {}       # Orders window (10/16)
        needs = card_needs(img, card)
        try:
            ex_items = [{"name": item_name(board_icon(img, *d_["slot"]["icon"])), "need": d_["need"]} for d_ in needs]
        except Exception:                              # noqa: BLE001
            ex_items = None
        _left = read_express_countdown(img, card["cx"])
        _card = tuple(sorted(str(i.get("name")) for i in (ex_items or [])))
        if _card and _express_clock.get("card") not in (None, _card):    # 11/16 (Muse): a new gold card -> fresh clock
            for _k in ("left", "t", "odd", "need", "verdict"):
                _express_clock.pop(_k, None)
        if _card:
            _express_clock["card"] = _card
        if _left:
            ok, odd = clock_reading_ok(_express_clock.get("left"), _express_clock.get("t"), _left, time.time(),
                                       _express_clock.get("odd"))
            _express_clock["odd"] = odd
            if ok:
                if not _express_clock.get("t") or abs((_express_clock["left"] - (time.time() - _express_clock["t"])) - _left) > 90:
                    log(f"[express clock] the gold card says {_left // 60}m {_left % 60:02d}s left.")
                _express_clock.update(left=_left, t=time.time())
        _pts = read_card_points(img, card["cx"])
        if _pts:
            log(f"EXPRESS: the gold card pays {_pts} points.")
        _express_write(True, "express card on board", items=ex_items, points=_pts)
        text = shopping_text(needs)
        log(f"EXPRESS shopping list: {text}")
        express_plan(img, card, needs)
        if first:
            results.append({"item": "EXPRESS needs", "status": text})
            first = False
        if card_is_ready(card):
            log("EXPRESS card is fully green -- tapping ITS Complete (the only Complete allowed).")
            adb_helper.tap(*card["btn"])
            of.interruptible_sleep(1.5, stop_flag)
            no, nc = of.find_no_button(adb_helper.screenshot())
            if no is not None:
                log("EXPRESS: Complete opened a gem-buy dialog (stale read) -- declining.")
                adb_helper.tap(*no)
                break
            chk = adb_helper.screenshot()                # review 10/18: record it only once the gold card is really gone
            try:
                still = board_is_open(chk) and any(is_express_card(chk, c_) for c_ in read_board(chk))
            except Exception:                            # noqa: BLE001
                still = False
            if still:
                log("EXPRESS: the gold card is still on the board after Complete -- the tap did not register; "
                    "trying again next pass.")
                break
            served += 1
            _stats["served"] += 1
            results.append({"item": "EXPRESS", "status": "COMPLETED"})
            try:
                _view("add_history", "Food Club Event",
                      [{"name": item_name(board_icon(img, *d_["slot"]["icon"])), "need": d_["need"]} for d_ in needs],
                      express=True, points=_express_points())
            except Exception:                          # noqa: BLE001
                pass
            _view("add_completed", "Food Club Event", 1)
            if _express_clock.get("verdict"):
                log(f"[express clock] last call was '{_express_clock['verdict']}' -- the bot COMPLETED it.")
            _express_clock.clear()
            _express_write(False, completed=True)
            break
        target = None
        for nd in sorted(needs, key=lambda d_: -d_["missing"]):
            if nd["color"] != "red":
                continue
            icon = board_icon(img, *nd["slot"]["icon"])
            if any(_same(icon, h) for h in handled):
                continue
            target = (icon, nd)
            break
        if target is None:
            log("EXPRESS: every missing item was already worked this pass -- waiting for the batches.")
            break
        icon, nd = target
        handled.append(icon)
        label = f"EXPRESS item #{n + 1}"
        pos = slot_pos.get(id(nd["slot"]))
        if pos:
            _view("set_item", "Food Club Event", pos[0], pos[1], status="working on it now...", kind="active", active=True)
        global _last_timer_name
        _last_timer_name = None
        status = chase(icon, nd["slot"]["icon"], label, 0, stop_flag, ctx, want=max(1, nd["missing"]))
        log(f"{label}: {status}")
        if pos:
            known = _last_wanted.get("label") == label and _last_wanted.get("name")
            if known:
                _remember_name(icon, _last_wanted["name"])
            fr = _view("friendly", status, _last_wanted.get("where") if known else None) or (str(status), "waiting")
            _view("set_item", "Food Club Event", pos[0], pos[1], status=fr[0], kind=fr[1],
                  name=_last_wanted["name"] if known else None, active=False, timer=_last_timer_name)
        results.append({"item": label, "status": status})
        of.close_any_open_panel(quiet=True, thorough=True)
        of.interruptible_sleep(0.8, stop_flag)
        if open_board(stop_flag) is None:
            break
    _view("clear_active", "Food Club Event")
    if board_is_open(adb_helper.screenshot()):
        of.close_any_open_panel(quiet=True)
    return served, results


# pass 10 (10/6): the planner -- ask for as many as the board card is actually short
WANT_CAP = 12
PLANT_MAX_PER_VISIT = 8


def board_slot_want(img, card, slot):
    """need - have for one board slot (event_digits); 1 when the digits cannot be read."""
    try:
        for n in card_needs(img, card):
            if n["slot"] is slot:
                return max(1, min(int(n["missing"]), WANT_CAP))
    except Exception:                                  # noqa: BLE001
        pass
    return 1


# --------------------------------------------------------------------------
# Orders window (10/16): publish what the board shows and what each chase did (display only)
# --------------------------------------------------------------------------
_name_cache = []          # [(board icon, name)] for the current event (memory copy of the saved names)
BOARD_NAMES_ROOT = os.path.join(BASE_DIR, "templates", "board_names")
BOARD_NAME_MATCH = 0.82   # 10/16: same item across boards >= 0.89, two different items <= 0.70
_names_event = None       # which event's names are loaded


def _view(fn, *a, **k):
    """Calls orders_view.<fn>; never lets the window break the bot."""
    try:
        import orders_view
        return getattr(orders_view, fn)(*a, **k)
    except Exception:                                  # noqa: BLE001
        return None


def _event_key():
    """Names are kept per event: the key is a fingerprint of the current event icon, so training a
    New event icon starts a fresh list by itself (the old event's names stay on disk)."""
    try:
        import hashlib
        with open(BOARD_ICON_TEMPLATE, "rb") as fh:
            return hashlib.md5(fh.read()).hexdigest()[:10]
    except OSError:
        return "no_icon"


def _names_dir():
    return os.path.join(BOARD_NAMES_ROOT, _event_key())


def _load_names():
    """(Re)loads the saved names when the event changed or on first use. Cheap: a few dozen tiny pictures."""
    global _names_event
    key = _event_key()
    if _names_event == key:
        return
    _names_event = key
    _name_cache.clear()
    d = _names_dir()
    try:
        with open(os.path.join(d, "names.json"), encoding="utf-8") as fh:
            index = json.load(fh)
    except (OSError, ValueError):
        index = {}
    for fn, name in index.items():
        ic = cv2.imread(os.path.join(d, fn))
        if ic is not None:
            _name_cache.append((ic, name))
    if _name_cache:
        log(f"item names: {len(_name_cache)} remembered for this event.")


def _icon_score(a, b):
    """How alike two board icons are (top 70%: the have/need count sits under the icon)."""
    try:
        return _inner_match(a[:max(1, int(a.shape[0] * 0.7))], b[:max(1, int(b.shape[0] * 0.7))], 6)
    except Exception:                                  # noqa: BLE001
        return 0.0


def _remember_name(icon, name):
    """Saves a name the game told us (travel tooltip) with the item's board picture, for this event."""
    if icon is None or not name:
        return
    _load_names()
    for k, (ic, nm) in enumerate(_name_cache):
        if _icon_score(ic, icon) >= BOARD_NAME_MATCH:
            if nm != name:                             # the game's newest word wins
                _name_cache[k] = (ic, name)
                _save_names()
                log(f"item names: corrected '{nm}' -> '{name}'.")
            return
    _name_cache.append((icon.copy(), name))
    _save_names()
    log(f"item names: learned '{name}' ({len(_name_cache)} known for this event).")


def _save_names():
    d = _names_dir()
    try:
        os.makedirs(d, exist_ok=True)
        index = {}
        for k, (ic, nm) in enumerate(_name_cache):
            fn = f"{k:03d}.png"
            cv2.imwrite(os.path.join(d, fn), ic)
            index[fn] = nm
        with open(os.path.join(d, "names.json"), "w", encoding="utf-8") as fh:
            json.dump(index, fh, indent=0)
    except OSError:
        pass


def _crop_slot(img, sl):
    """11/1: is this board item an event-plot crop (name learned from the 'grown on your Event Plot' tooltips)?"""
    try:
        nm = item_name(board_icon(img, *sl["icon"]))
    except Exception:                                  # noqa: BLE001
        return False
    return bool(nm) and _norm(nm) in _plot_crops


def storage_focus_order(cards, is_crop, units=None):
    """11/1 pure: cards ordered for storage focus -- cards with at least one red DISH first (cooking frees storage),
    then (11/14, Muse: the deadlock focus took card #1 with 8 units missing while #2 needed 2) the FEWEST MISSING UNITS
    (units(card), None = unknown -> last), then fewest red items. A card whose only reds are crops cannot move while
    storage is full."""
    def key(c):
        reds = [s for s in c["slots"] if s["color"] == "red"]
        dish = any(not is_crop(s) for s in reds)
        u = units(c) if units else None
        return (0 if dish else 1, u if u is not None else 999, len(reds))
    return sorted(cards, key=key)


FOCUS_ROTATE_SEC = 240      # 11/14 (owner: "it needs to figure this out"): storage full and the focus card has not
FOCUS_SKIP_SEC = 900        # been served in 4 min (its station jammed with batches that can't be collected while
_focus = {"key": None, "since": 0.0, "skip": {}}       # full) -> try the next card for 15 min instead of looping


def focus_pick(keys, state, now):
    """Pure: which card key to focus on. keys = ordered best-first. Returns (key, rotated_from or None)."""
    skip = state["skip"]
    for k in list(skip):
        if skip[k] <= now:
            del skip[k]
    live = [k for k in keys if k not in skip] or keys
    if state["key"] not in live:
        state.update(key=live[0], since=now)
        return live[0], None
    if now - state["since"] >= FOCUS_ROTATE_SEC and len(live) > 1:
        old = state["key"]
        skip[old] = now + FOCUS_SKIP_SEC
        live = [k for k in live if k != old]
        state.update(key=live[0], since=now)
        return live[0], old
    return state["key"], None


def _missing_units(img, card):
    try:
        needs = card_needs(img, card)
        if any(nd.get("missing") is None for nd in needs):
            return None
        return sum(nd["missing"] for nd in needs)
    except Exception:                                  # noqa: BLE001
        return None


def item_name(icon):
    """A board icon's name: remembered for this event (from the game's own tooltips), else the item
    library; None if not known yet."""
    _load_names()
    best, best_s = None, 0.0
    for ic, nm in _name_cache:
        sc = _icon_score(ic, icon)
        if sc > best_s:
            best, best_s = nm, sc
    if best_s >= BOARD_NAME_MATCH:
        return best
    try:
        if not os.path.isdir(PLANT_LIB_DIR):
            return None
        top = icon[:max(1, int(icon.shape[0] * 0.7))]
        found = {}
        for fn in os.listdir(PLANT_LIB_DIR):
            if not (fn.startswith("icon_") and fn.endswith(".png")):
                continue
            ref = cv2.imread(os.path.join(PLANT_LIB_DIR, fn))
            if ref is None:
                continue
            nm = fn[5:-4].split("__")[0]
            found[nm] = max(found.get(nm, 0.0), _inner_match(ref[:max(1, int(ref.shape[0] * 0.7))], top, 4))
        ranked = sorted(found.items(), key=lambda kv: kv[1], reverse=True)
        if ranked and ranked[0][1] >= PLANT_LIB_ICON_MIN and (len(ranked) < 2 or ranked[0][1] - ranked[1][1] >= PLANT_LIB_MARGIN):
            return ranked[0][0].replace("_", " ").title()
    except Exception:                                  # noqa: BLE001
        pass
    return None


# --- Scoreboard (watch-only test, 10/17) -------------------------------------------------------------
# The event board shows the club's progress in the current level ("550/800"). Read it once a minute
# (in the background, from the board screenshot the bot already has) and log points gained this run and
# per hour, so a change to the bot can be judged by points instead of guesses. A drop (751/800 -> 40/900)
# is a level-up: the rest of the old level counts too.
SCORE_BOX = (700, 268, 900, 300)
SCORE_EVERY_SEC = 60
_score = {"run": None, "start": None, "last": None, "gained": 0, "t": 0.0}


# --- Food Club Storage test (10/17, owner's idea, watch-only) -----------------------------------------
# Collecting at a station or plot shows "Food Club Storage 18/30" top-left for a moment. Any screenshot
# that happens to show it is read (background OCR, at most every 20 s, only when the number changed) and
# logged, so we learn how full storage runs -- the "Storage is full" popup used to block the bot.
# 10/17 v2: labels are matched on their DARK LETTERS (gray < 90), not colours -- the green behind
# "Food Club Storage" is a fill bar, so a colour template missed 7/30-11/30. Two labels, kept apart:
# Food Club banners score 0.84-1.00 on their own label and <= 0.65 on Fridge; Fridge banners 1.00 vs <= 0.31.
# The label pictures live in the code (base64 PNG) so an update never needs a new picture file.
STORAGE_NUM_BOX = (281, 106, 352, 142)
_STORAGE_LABELS_B64 = {
    "Food Club Storage": "iVBORw0KGgoAAAANSUhEUgAAALAAAAAcCAAAAADkAmoXAAACeUlEQVRYCdXBUW4c1wFFwTr7X/RNz7xukvMR2YiMQK7Kv0z+ZfI/Gfnb5iX/hOaWXxl5zEsuIz+NfJoj/4Dmll8Zuc0RRn4Y8mFueZn8huaWXxm5zS1GfhjyYciQy+Q3NOQvjRxzaYiRn0Y+jBhymfyGhvylkWOIESM/jXwYMeQy+Q0Z+UsjxxAjRn4a+TBi5GXkv5uXfBm5jJDJlyEvQ94mI8fIZWJkxIiR5duQY44wlzAZucwR5hbzEpnc5i3MW5gjx8hjZMSIOfIYcswR8xZzxDwyj8yRjBxzZI6YW46Rx8iIEXPLYy55m0suc2RumUfmkbmVOTJiZMRoyJBj5DEyYsSQkS9zyTG5jBgZMTJkaL40ZChzZMTIiNEII8fIY2TEiBFGvsxLXiaXESMjRoYMDTE0YihzZIRphNEII8fIY2TEiBFGfhjyMrmMMBlhcswthuZRhrxMLtMIoxFGjpHLyMiIESOM/DTkMrlMLpOR2/wU86GMvE0u0wijEUaOkcvIyIgRI4y8DWHkMrlMLpORYz7EfCgjb5PLNMJohJFjCCMjI0aMMPI2hJHL5DK5TEaO+RDzoYy8TS6TCaMRRo4hjIyMGDHCyNsQRi6Ty4SRkWPI3GJoyFBG3kaMTJgMMXIbMWRkxIgRQ96GMHIZYcTIyDFkaIihIUMZeRsxMjJibrnNLUbmFnPLbR65DDFiYuSYR/OlIUMZOeYt5oi55TFvYcTcMkcec8vLXGLeYuSYR/MlcyQmt7nkMi95GY18mUsuIwyNjEa+zZG3IcwljBzzyDwyR/J/MJf8LSMj5hbzEvmDLYZ8y59qiCHf8qcaYsi3/KnmS779B8UuZCwpftfZAAAAAElFTkSuQmCC",
    "Fridge": "iVBORw0KGgoAAAANSUhEUgAAAEoAAAAcCAAAAADjbHZHAAABE0lEQVRIDa3BUXLTUABFMZ39L/oS/OxOCwP5idR8SvMpzafkY/Ix+Zh8TJhb/mXkjTC3fDPyGHkjzC3fDLmNvBGG/GnkMfJGGPnb8mXkjTDyfyNvhJFjYvIyeYzcRl5GvgkjxxwxwtzCHGF+y5cwcswtI+YRc4s58ghzxJCREUOGDBkyYuQR5pYRJiNGGBlhZMTII8wtIyxGjDAywsiIkUeYI0aOESOMjDAytzzCkMvIMWKEkRFG5pZHGHIZOUaMMDLCyMhPYchl5BgxwsgIIyM/hSGXkWPEiCEjjIwYeYQhl5FjxNC8ZISRESOPMOQycowwt5hbzCVfwpDLyDHyMjJibjGXfMkPI8fIY4ShkZeRb34BA0KJGkE+T3oAAAAASUVORK5CYII=",
}
_storage = {"t": 0.0, "sig": None, "last": None, "busy": False, "label": None, "seen": {}}


def _storage_mask(img):
    return ((cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) < 90).astype(np.uint8) * 255)


def _load_storage_labels():
    import base64
    out = {}
    for k, v in _STORAGE_LABELS_B64.items():
        im = cv2.imdecode(np.frombuffer(base64.b64decode(v), np.uint8), cv2.IMREAD_GRAYSCALE)
        if im is not None:
            out[k] = im
    return out


_storage_labels = _load_storage_labels()


def parse_storage(text):
    import re
    m = re.search(r"(\d+)\s*/\s*(\d+)", str(text or "").replace(" ", ""))
    if not m:
        return None
    val, top = m.group(1), int(m.group(2))
    while len(val) > 1 and int(val) > top:          # a stray edge read as an extra leading digit (124/30)
        val = val[1:]
    val = int(val)
    return (val, top) if 0 <= val <= top and 5 <= top <= 1000 else None


def _storage_prep(img):
    x1, y1, x2, y2 = STORAGE_NUM_BOX
    g = cv2.cvtColor(img[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY)
    g = cv2.resize(g, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    _, b = cv2.threshold(g, 170, 255, cv2.THRESH_BINARY_INV)
    b = cv2.copyMakeBorder(b, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)
    return cv2.cvtColor(b, cv2.COLOR_GRAY2BGR)


def storage_banner_shown(img):
    """Which storage banner is showing top-left: "Food Club Storage", "Fridge", or None."""
    if not _storage_labels or img is None or img.shape[0] < 200 or img.shape[1] < 420:
        return None
    m = _storage_mask(img[60:200, 0:420])
    scores = {k: float(cv2.matchTemplate(m, t, cv2.TM_CCOEFF_NORMED).max()) for k, t in _storage_labels.items()}
    best = max(scores, key=scores.get)
    need = 0.75 if best == "Food Club Storage" else 0.85
    others = [v for k, v in scores.items() if k != best]
    if scores[best] >= need and all(scores[best] - v >= 0.15 for v in others):
        return best
    return None


STORAGE_JUMP = 8          # 11/14 (Muse): reads swung 20 -> 1 -> 12 / 22 -> 2 in 30 s = OCR dropped a digit
STORAGE_JUMP_SEC = 300


def storage_reading_ok(prev, prev_t, held, r, now):
    """(take it?, new held). A Food Club reading more than STORAGE_JUMP off the last one (< 5 min old) is held back
    and only taken when the next reading agrees with it (within 2)."""
    if not prev or now - (prev_t or 0) > STORAGE_JUMP_SEC or abs(r[0] - prev[0]) <= STORAGE_JUMP:
        return True, None
    if held and held[1] == r[1] and abs(held[0] - r[0]) <= 2:
        return True, None
    return False, r


def _storage_observer(img):
    now = time.time()
    if _storage["busy"] or now - _storage["t"] < 20:
        return
    label = storage_banner_shown(img)
    if not label:
        return
    x1, y1, x2, y2 = STORAGE_NUM_BOX
    sig = cv2.resize(cv2.cvtColor(img[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY), (24, 12)).tobytes()
    if sig == _storage["sig"]:
        return
    _storage.update(t=now, sig=sig, busy=True)
    pic = _storage_prep(img)

    def work():
        try:
            import popup_ocr
            r = parse_storage(popup_ocr.read_text(pic))
            if r and label == "Food Club Storage":
                ok, _storage["held"] = storage_reading_ok(_storage.get("last"), _storage.get("last_t"),
                                                          _storage.get("held"), r, time.time())
                if not ok:
                    log(f"[storage] Food Club Storage read {r[0]}/{r[1]} -- far from the last "
                        f"{_storage['last'][0]}, holding it back until a second reading agrees")
                    return
            if r and _storage["seen"].get(label) != r:
                _storage["seen"][label] = r
                if label == "Food Club Storage":
                    _storage["last"] = r
                    _storage["last_t"] = time.time()
                warn = " -- NEARLY FULL" if r[0] >= r[1] - 3 else ""
                log(f"[storage] {label} {r[0]}/{r[1]}{warn}")
                if label == "Food Club Storage":
                    _storage_test_reading(r)
                    _relief_check_reading(r)
                    if r[0] >= r[1] - 1:
                        storage_relief_test("storage full")
        except Exception:                              # noqa: BLE001
            pass
        finally:
            _storage["busy"] = False
    import threading
    threading.Thread(target=work, daemon=True).start()


adb_helper.SCREENSHOT_OBSERVERS[:] = [f for f in adb_helper.SCREENSHOT_OBSERVERS
                                      if getattr(f, "__name__", "") != "_storage_observer"] + [_storage_observer]


def _score_prep(img):
    x1, y1, x2, y2 = SCORE_BOX
    g = cv2.cvtColor(img[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY)
    g = cv2.resize(g, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    _, b = cv2.threshold(g, 150, 255, cv2.THRESH_BINARY_INV)          # white digits -> black on white
    b = cv2.copyMakeBorder(b, 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)
    return cv2.cvtColor(b, cv2.COLOR_GRAY2BGR)


def parse_score(text):
    import re
    t = str(text or "").replace("O", "0").replace("o", "0")
    m = re.search(r"(\d+)\s*[/|\\lI1]?\s*(\d+)", t) if "/" not in t else re.search(r"(\d+)\s*/\s*(\d+)", t)
    cands = []
    if m and "/" in t:
        cands.append((int(m.group(1)), int(m.group(2))))
    else:                                              # no slash seen: "5501800" (slash read as 1) or "550 800"
        digits = re.findall(r"\d+", t)
        if len(digits) == 2:
            cands.append((int(digits[0]), int(digits[1])))
        elif len(digits) == 1:
            d = digits[0]
            for k in range(len(d) - 4, 0, -1):         # drop one char as the slash; the level size has 3+ digits  # 11/1: levels 775 / 925 are not multiples of 50
                if d[k] in "17":
                    a_, b_ = d[:k], d[k + 1:]
                    if a_ and b_ and int(b_) % 5 == 0:      # 11/28: levels 260 / 775 / 925 ("2311260" = 231/260)
                        cands.append((int(a_), int(b_)))
    for val, top in cands:
        if 0 <= val <= top and 50 <= top <= 100000:
            return val, top
    return None


def _score_update(reading, now=None):
    now = now or time.time()
    run = None
    try:
        import orders_view
        run = orders_view._run.get("started")
    except Exception:                                  # noqa: BLE001
        pass
    if _score["run"] != run or _score["start"] is None:
        _score.update(run=run, start=now, last=reading, gained=0, read_t=now)
        log(f"[score] start of this run: {reading[0]}/{reading[1]}")
        return
    old = _score["last"]
    if reading[1] == old[1]:
        if reading[0] < old[0]:
            # Same level size but lower: a misread -- or a level-up into a level of the same size (live 10/17:
            # 975/1000 -> 39/1000). It is a level-up when the old score was nearly full, or when the same lower
            # number is read twice in a row; otherwise ignore it once.
            again = _score.get("pending") is not None and abs(_score["pending"][0] - reading[0]) <= 60
            if old[0] < 0.85 * old[1] and not again:
                _score["pending"] = reading
                log(f"[score] ignoring a reading of {reading[0]}/{reading[1]} (was {old[0]}/{old[1]}) -- misread? "
                    "(counted as a level-up if it is read again)")
                return
            d = (old[1] - old[0]) + reading[0]
        else:
            d = reading[0] - old[0]
        _score["pending"] = None
    elif reading[0] < old[0] or reading[1] > old[1]:    # level-up: the rest of the old level + the new progress
        d = (old[1] - old[0]) + reading[0]
    else:
        d = 0
    _score["gained"] += d
    if d > 0:
        try:                                            # 11/15: last-24-h points for the Orders tab
            import points_day
            points_day.note_gain(d, now)
        except Exception:                               # noqa: BLE001
            pass
    _score["last"] = reading
    prev_t, _score["read_t"] = _score.get("read_t") or now, now
    if d > 0:
        _score_rises.append((now, d))
        del _score_rises[:-20]                                          # 10/18 freetime: points per order, shown in History
        who = _view("credit_points", "Food Club Event", d, prev_t, now)
        if who:
            log(f"[score] +{d} credited to {who}")
    hours = max((now - _score["start"]) / 3600.0, 1e-6)
    mins = int((now - _score["start"]) // 60)
    log(f"[score] {reading[0]}/{reading[1]}" + (f" (+{d})" if d else "") +
        f" -- {_score['gained']} points in {mins} min this run" +
        (f", about {_score['gained'] / hours:.0f} per hour" if mins >= 10 else ""))


def note_score(img):
    """Called with every board screenshot; reads the score at most once a minute, off the main thread."""
    now = time.time()
    if now - _score["t"] < SCORE_EVERY_SEC:
        return
    _score["t"] = now
    pic = _score_prep(img)

    x1, y1, x2, y2 = SCORE_BOX
    raw = cv2.resize(img[y1:y2, x1:x2], None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)

    def work():
        try:
            import popup_ocr
            texts = []
            for p in (pic, raw):                       # cleaned black-on-white first, then the plain crop
                t = popup_ocr.read_text(p)
                texts.append(t)
                r = parse_score(t)
                if r:
                    _score_update(r, now)
                    return
            _score["misses"] = _score.get("misses", 0) + 1
            if _score["misses"] <= 5:                  # 10/17: first live run read nothing -- show what OCR saw
                log(f"[score] could not read the points: OCR said {texts!r} (picture saved)")
                try:
                    folder = os.path.join(RECIPE_TEST_DIR, "score")
                    os.makedirs(folder, exist_ok=True)
                    cv2.imwrite(os.path.join(folder, f"score_{int(now)}.png"), img[y1 - 60:y2 + 10, x1:x2])
                except Exception:                      # noqa: BLE001
                    pass
        except Exception as e:                         # noqa: BLE001 -- a test must never break the run
            log(f"[score] skipped: {e}")
    import threading
    threading.Thread(target=work, daemon=True).start()


def _publish_board(img, cards, express=None):
    """Sends the board as read to the Orders window. Returns {id(slot): (order_no, index)}.
    `express` = the gold express card (it is marked in the window)."""
    try:
        note_score(img)
    except Exception:                                  # noqa: BLE001
        pass
    where = {}
    orders = []
    seen_cards = []
    for no, c in enumerate(sorted(cards, key=lambda c: c["cx"]), start=1):
        items = []
        try:
            needs = card_needs(img, c)
        except Exception:                              # noqa: BLE001
            needs = [{"slot": s_, "color": s_["color"], "have": None, "need": None} for s_ in c["slots"]]
        for k, n in enumerate(needs):
            sl = n["slot"]
            where[id(sl)] = (no, k)
            it = {"name": item_name(board_icon(img, *sl["icon"])), "have": n["have"], "need": n["need"]}
            if n["color"] == "green":
                it.update(status="ready", kind="done")
            items.append(it)
        o = {"no": no, "items": items, "express": express is not None and c is express}
        try:                                           # 11/16: points + time left + points/min on the Orders tab
            pts = _express_points() if o["express"] else read_regular_points(img, c["cx"])
            done = bool(needs) and all(not n.get("missing") for n in needs)
            secs, unk = (0, 0) if done else _card_eta_now(img, needs)
            o.update(points=pts, eta_secs=secs, rate=None if done else points_rate(pts, secs),
                     eta=eta_text(pts, secs, unk, done), eta_always=True)
            if not o["express"]:
                seen_cards.append(((round(c["cx"] / 60), tuple(i.get("name") or "?" for i in items)),
                                   secs, unk, done))
        except Exception as e:                         # noqa: BLE001
            log(f"[card score] skipped: {e!r}")
        orders.append(o)
    try:                                               # 11/16: how good were the time guesses?
        _eta_check(seen_cards, time.time())
    except Exception as e:                             # noqa: BLE001
        log(f"[eta check] skipped: {e!r}")
    rates = [o.get("rate") or 0 for o in orders]
    if len([r for r in rates if r]) > 1:               # the card that pays the most points per minute of cooking
        best = orders[rates.index(max(rates))]
        best["eta"] = best["eta"] + " · best"
    _view("set_orders", "Food Club Event", orders,
          note="EXPRESS ORDER -- the bot works only on the gold card until it is done or expires." if express is not None else "")
    return where


# Step A of the cooking plan (10/16): note when each batch / crop will be ready (display only for now).
_station_free_at = {}      # station name -> when its queue is expected to be empty (batches WE started)
_last_timer_name = None    # name of the newest timer noted -- run_once ties it to the board row it chased


def parse_duration(text):
    """'3m' -> 180, '45s' -> 45, '1h' -> 3600, '2m 57s' -> 177, '1h 30m' -> 5400. None if no time in it."""
    import re
    t = (text or "").lower().replace("rn", "m")
    parts = re.findall(r"(\d+)\s*([hms])", t)
    if not parts:
        return None
    secs = sum(int(n) * {"h": 3600, "m": 60, "s": 1}[u] for n, u in parts)
    return secs if 0 < secs <= 24 * 3600 else None


TIME_LABEL_DIR = os.path.join(BASE_DIR, "templates", "time_labels")         # <seconds>__<n>.png examples
TIME_LABEL_UNKNOWN_DIR = os.path.join(BASE_DIR, "templates", "time_labels_unknown")
_time_examples = None


def _clean_time_label(crop):
    """Dark-brown time text on a light card -> tight black-on-white picture of just the text, or None.
    Blobs touching the crop edge (card border, the Bread Oven's star tips) and specks are dropped."""
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    _, bw = cv2.threshold(gray, 110, 255, cv2.THRESH_BINARY)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(255 - bw)
    keep = np.full_like(bw, 255)
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if area < 12 or y <= 0 or y + h >= bw.shape[0] or x <= 0 or x + w >= bw.shape[1]:
            continue
        keep[lab == i] = 0
    ys, xs = np.where(keep == 0)
    if len(xs) == 0:
        return None
    return keep[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


def _time_vec(glyph):
    h, w = glyph.shape
    im = cv2.resize(glyph, (max(1, round(w * 24 / h)), 24), interpolation=cv2.INTER_AREA)
    im = im[:, :48] if im.shape[1] >= 48 else cv2.copyMakeBorder(im, 0, 0, 0, 48 - im.shape[1], cv2.BORDER_CONSTANT, value=255)
    v = (255 - im.astype(np.float32)).ravel()
    v -= v.mean()
    nv = np.linalg.norm(v)
    return (v / nv if nv else v), w / h


def _match_time_label(glyph):
    """Compares the label picture with the saved examples (10/16: 475/479 right in a leave-one-out test,
    Windows OCR read 0 of 7 live). Needs a close match AND the 3 closest examples to agree; else None."""
    global _time_examples
    if _time_examples is None:
        _time_examples = []
        try:
            for fn in os.listdir(TIME_LABEL_DIR):
                g = cv2.imread(os.path.join(TIME_LABEL_DIR, fn), cv2.IMREAD_GRAYSCALE)
                if g is not None and fn.split("__")[0].isdigit():
                    _time_examples.append((_time_vec(g), int(fn.split("__")[0])))
        except OSError:
            pass
    if not _time_examples:
        return None
    x, ar = _time_vec(glyph)
    sims = sorted(((float(x @ y), secs) for (y, ar2), secs in _time_examples
                   if abs(ar - ar2) <= 0.25 * max(ar, ar2)), reverse=True)[:3]
    if not sims or sims[0][0] < 0.85 or len({s for _, s in sims}) != 1:
        return None
    return sims[0][1]


def read_time_label(img, box):
    """A card's cook/grow time ('3m', '45s', '1h') in seconds, or None. Picture match first (saved examples),
    Windows OCR as the fallback; when both fail the label is saved to templates/time_labels_unknown/."""
    try:
        x1, y1, x2, y2 = box
        glyph = _clean_time_label(img[max(0, y1):y2, max(0, x1):x2])
        if glyph is None:
            return None
        secs = _match_time_label(glyph)
        if secs:
            return secs
        import popup_ocr
        big = cv2.copyMakeBorder(cv2.resize(glyph, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST),
                                 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=255)
        raw = popup_ocr.read_text(cv2.cvtColor(big, cv2.COLOR_GRAY2BGR))
        secs = parse_duration(raw)
        if secs is None:
            try:
                os.makedirs(TIME_LABEL_UNKNOWN_DIR, exist_ok=True)
                cv2.imwrite(os.path.join(TIME_LABEL_UNKNOWN_DIR, f"{int(time.time() * 1000)}.png"), glyph)
            except OSError:
                pass
            log(f"[timer] time label not recognised (OCR said '{raw}') -- picture saved to templates/time_labels_unknown/.")
        return secs
    except Exception:                                  # noqa: BLE001
        return None


# 10/19 (owner): stations Food Club cooks at, by their recipe-book name ("Dairu" read -> "Dairy"), remembered
# across runs. order_fulfill keeps long cooks off these while Food Club is ticked (Settings tab).
FC_STATIONS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".foodclub_stations.json")
_fc_stations = None


def food_club_stations():
    global _fc_stations
    if _fc_stations is None:
        try:
            with open(FC_STATIONS_FILE, encoding="utf-8") as fh:
                _fc_stations = set(json.load(fh))
        except (OSError, ValueError):
            _fc_stations = {"Dairy"}                        # known from the 10/19 logs before anything is learned
    return set(_fc_stations)


def _note_fc_station(where):
    try:
        import recipe_book as rb
        known = {it["station"] for it in rb.load()["items"].values() if it.get("station")}
        match = next((k for k in known if same_name(k, where)), None)
        if not match or match in food_club_stations():
            return
        _fc_stations.add(match)
        with open(FC_STATIONS_FILE, "w", encoding="utf-8") as fh:
            json.dump(sorted(_fc_stations), fh)
        log(f"[long cooks] Food Club uses the {match} -- Auto Fulfill keeps long cooks off it while Food Club runs.")
    except Exception:                                       # noqa: BLE001
        pass


def _timer_name(label, icon):
    if _last_wanted.get("label") == label and _last_wanted.get("name"):
        return _last_wanted["name"], _last_wanted.get("where")
    return (item_name(icon) if icon is not None else None) or label, None


_my_batches = {}           # (station, dish) -> ready times of batches WE queued (10/17)
MY_BATCH_KEEP_SEC = 240    # a finished batch sits on the station until the next pass collects it


def _worth_cooking(label, icon, ctx):
    """11/2 W.O.R.T.H. (log only): the soonest batch of this dish we queued -- how long until it is ready."""
    try:
        import worth
        name, where = _timer_name(label, icon)
        now = time.time()
        ready = [r for r in _my_batches.get((where, _norm(name or "")), []) if r > now]
        if ready:
            worth.note_timer(f"{name} at {where}", int(min(ready) - now), express=bool(ctx.get("express")))
    except Exception:                                   # noqa: BLE001
        pass


SLOT_AD_Y_MIN = 780          # the green "Skip [video][gem]" sits under the cooking slot (~y 863)
SLOT_DIALOG_X = (1057, 152)  # the skip dialog's red X (saved picture seen_20261101_195337)


def slot_ad_ok(on, event_only, where, secs, min_left, max_left, used_up, express=False):
    """Pure (11/6): watch an ad on this station's cooking slot? Ads on, an EVENT station (Ghost Merchant, Witch's
    Cauldron -- never Dairy / Bread Oven), the timer inside the game's video window (min_left .. max_left; during an
    express any time left in the window), and today's ads not used up. event_only is the Settings switch -- it only
    stops crop ads; event-dish slots are the reason for it."""
    if not on or used_up or secs is None or secs > max_left:
        return False
    if not panel_prestock_allowed(where):
        return False
    return secs >= (60 if express else min_left)


def slot_dialog_open(img):
    """Pure: the item skip dialog (Skip [gem] + video) is open -- its red X sits at SLOT_DIALOG_X. On the dialog
    picture 36% of the 70x70 box there is red; on a plain station panel 0% (light-blue card)."""
    if img is None or img.shape[:2] != (900, 1600):
        return False
    x, y = SLOT_DIALOG_X
    b = img[y - 35:y + 35, x - 35:x + 35].astype(int)
    return float(((b[:, :, 2] > 180) & (b[:, :, 1] < 90) & (b[:, :, 0] < 90)).mean()) > 0.15


def _slot_ad(label, icon, ctx, stop_flag):
    """11/6 E.S.C.A.P.E. (owner: ads on event dishes): the station menu is open and the bot is only waiting for its
    own batch -- tap the green Skip [video] under the cooking slot, then the VIDEO button (never the gem one)."""
    try:
        import ad_player
        import ad_skip
        name, where = _timer_name(label, icon)
        now = time.time()
        ready = [r for r in _my_batches.get((where, _norm(name or "")), []) if r > now]
        secs = int(min(ready) - now) if ready else None
        if not slot_ad_ok(ad_player.ON, ad_player.EVENT_ONLY, where, secs, ad_player.MIN_LEFT_SEC,
                          ad_player.SLOT_MAX_LEFT_SEC, ad_player.used_up(), bool(ctx.get("express"))):
            return None
        img = adb_helper.screenshot()
        hits = [(loc, sc) for n, loc, sc in ad_skip.spot_hits(img) if n == "skip_ad_button" and loc[1] >= SLOT_AD_Y_MIN]
        if not hits:
            return None
        (bx, by), _sc = max(hits, key=lambda h: h[1])
        log(f"[ads] {name} at {where}: {secs // 60}m{secs % 60:02d}s left on our batch -- tapping the slot's "
            f"Skip [video] at ({bx},{by}).")
        adb_helper.tap(bx, by)
        of.interruptible_sleep(1.0, stop_flag)
        res = ad_player.watch(stop_flag, secs, what=f"{name} at {where}", min_left=60 if ctx.get("express") else None)
        img2 = adb_helper.screenshot()
        if slot_dialog_open(img2):                      # the skip dialog is still up (stale timer / no video) -- X it
            adb_helper.tap(*SLOT_DIALOG_X)
            of.interruptible_sleep(0.6, stop_flag)
        if res == "watched":
            _my_batches[(where, _norm(name or ""))] = [r for r in _my_batches.get((where, _norm(name or "")), [])
                                                        if r != min(ready)] + [time.time()]
        return res
    except of.StopRequested:
        raise
    except Exception as e:                              # noqa: BLE001 -- an ad problem never stops the station work
        log(f"[ads] slot ad failed (ignored): {e!r}")
        return None


def _batches_of_this_dish(label, icon):
    """How many batches of this dish we queued here that are still cooking (or finished but not yet
    collected). None when unknown: no real name, or nothing queued at this station since AFSD started
    -- then the old rule (every occupied slot counts) stays, so a restart never over-cooks."""
    name, where = _timer_name(label, icon)
    if not name or name == label or not where:
        return None
    if not any(st == where for st, _ in _my_batches):
        return None
    now = time.time()
    return sum(1 for r in _my_batches.get((where, _norm(name)), []) if r + MY_BATCH_KEEP_SEC > now)


def _note_my_batches(name, where, ready):
    now = time.time()
    for k in list(_my_batches):
        _my_batches[k] = [r for r in _my_batches[k] if r + MY_BATCH_KEEP_SEC > now]
    _my_batches.setdefault((where, _norm(name)), []).extend(ready)


def note_station_timer(label, icon, img, bx, by, queued, busy_slots):
    """After queueing `queued` batches on a station card: when will they be ready?"""
    secs = read_time_label(img, (bx - 75, by - 440, bx + 75, by - 386))
    name, where = _timer_name(label, icon)
    mine_ok = bool(where) and name != label
    where = where or "a station"
    if not secs:
        if mine_ok:
            _note_my_batches(name, where, [time.time() + 600 * (i + 1) for i in range(queued)])
        log(f"[timer] {name}: queued {queued}, but the card's cook time could not be read -- no timer.")
        return
    now = time.time()
    start = max(now, _station_free_at.get(where, 0.0))
    approx = busy_slots > 0 and _station_free_at.get(where, 0.0) <= now      # a batch we did not start is ahead of ours
    ready = [start + secs * (i + 1) for i in range(queued)]
    _station_free_at[where] = ready[-1]
    _cook_secs[_norm(name)] = (secs, where)
    if mine_ok:
        _note_my_batches(name, where, ready)
    global _last_timer_name
    _last_timer_name = name
    _view("add_timer", "Food Club Event", name, where, ready, approx)
    log(f"[timer] {name} at {where}: cook {secs // 60}m{secs % 60:02d}s x{queued} -> ready "
        + ", ".join(time.strftime("%H:%M:%S", time.localtime(r)) for r in ready)
        + (" (at least -- another batch was already cooking)" if approx else ""))


def note_plant_timer(label, icon, img, cx, planted):
    """After planting: all plots grow side by side, so every one is ready after the card's grow time."""
    secs = read_time_label(img, (cx - 75, 136, cx + 75, 190))
    name, _ = _timer_name(label, icon)
    if not secs:
        log(f"[timer] {name}: planted {planted}, but the grow time could not be read -- no timer.")
        return
    ready = time.time() + secs
    _crop_ready[_norm(name)] = max(_crop_ready.get(_norm(name), 0.0), ready)
    _grow_secs[_norm(name)] = secs
    global _last_timer_name
    _last_timer_name = name
    _view("add_timer", "Food Club Event", name, "Event Plot", [ready] * planted)
    try:                                            # 11/9 S.P.R.O.U.T. step 2, log only
        import sprout
        sprout.note_planted(name, planted, _stock_seen)
    except Exception:                               # noqa: BLE001
        pass
    log(f"[timer] {name} on the Event Plot: grow {secs // 60}m{secs % 60:02d}s x{planted} -> ready "
        f"{time.strftime('%H:%M:%S', time.localtime(ready))}")


# --- Skip test (10/17, watch-only: Step B groundwork) ---------------------------------------------------
# Before each board trip: would the timers say "still cooking / still growing, skip it"? After the trip:
# was that right (the trip found nothing to do) or wrong (it queued, planted or collected something)?
# Step B (really skipping) is only switched on once this is right nearly every time.
SKIP_MARGIN_SEC = 20
_skip_score = {"right": 0, "wrong": 0, "missed": 0, "went": 0}


_station_slots = {}       # station -> queue slots seen on its panel


def _skip_guess(icon, want=1):
    """10/17 v2 (from the first live results): 'cooking' alone was wrong 9 times out of 23 -- the card
    needed MORE batches and the trip planted ingredients for them. Now: skip only when the batches cooking
    cover what the card still needs, or when the dish's station queue is full of our own batches."""
    try:
        name = item_name(icon)
        if not name:
            return None
        k, now = _norm(name), time.time()
        if _crop_ready.get(k, 0.0) > now + SKIP_MARGIN_SEC and k in _plot_crops:
            return (name, "growing", _crop_ready[k] - now)
        mine = [r for (st, d), rs in _my_batches.items() if d == k for r in rs if r > now + SKIP_MARGIN_SEC]
        if mine and len(mine) >= max(1, int(want or 1)):
            return (name, f"cooking ({len(mine)} batch(es) for {want} wanted)", min(mine) - now)
        cs = _cook_secs.get(k)
        if cs:
            where = cs[1]
            busy = [r for (st, d), rs in _my_batches.items() if st == where for r in rs if r > now + SKIP_MARGIN_SEC]
            slots = _station_slots.get(where)
            if slots and len(busy) >= slots:
                return (name, f"{where} queue full ({len(busy)}/{slots} ours)", min(busy) - now)
        return (name, None, 0)
    except Exception:                                  # noqa: BLE001
        return None


SKIP_LIVE = True          # 11/17: skip-test results 74 right / 26 wrong; every "cooking" WRONG was a trip that
                          # collected a finished batch at that station -- so skip only "cooking" guesses with no
                          # batch of ours there ready or about to be (crops / full queues still travel)


def skip_live_ok(guess, batches, now, express=False, margin=None):
    """Pure: really skip this board trip? Only a 'cooking (...)' guess, not during an express, and no
    batch of ours at the stations cooking this dish is ready within the margin."""
    if not guess or express:
        return False
    name, why, left = guess
    if not why or not str(why).startswith("cooking"):
        return False
    m = SKIP_MARGIN_SEC if margin is None else margin
    k = _norm(name)
    stations = {st for (st, d) in batches if d == k}
    for (st, d), rs in batches.items():
        if st in stations and any(r <= now + m for r in rs):
            return False
    return True


def _skip_judge(label, guess, status):
    try:
        if not guess:
            return
        name, why, left = guess
        st = str(status)
        useless = not any(w in st for w in ("queued", "planted", "collected", "served", "complete"))
        if why:
            key = "right" if useless else "wrong"
            verdict = "RIGHT (nothing to do there)" if useless else "WRONG (the trip did something useful)"
        else:
            _skip_score["went"] += 1
            key = "missed" if useless else None
            verdict = None
        if key:
            _skip_score[key] += 1
        if why:
            log(f"[skip test] {label} {name}: timers say {why}, ready in {int(left) // 60}m{int(left) % 60:02d}s "
                f"-- would skip; trip result: {st} -> {verdict}")
        else:
            return                                     # 10/31: the "wasted trip the timers did not foresee" lines
                                                       # (105/day) taught nothing -- only real skip verdicts are logged
        s_ = _skip_score
        log(f"[skip test] so far: would-skip right {s_['right']}, wrong {s_['wrong']}; "
            f"unforeseen wasted trips {s_['missed']}")
    except Exception:                                  # noqa: BLE001
        pass


# --- Hourly summary (10/17 log diet: one line that says how the last hour went) ---------------------------
_merchant_note = ""
_stats = {"since": time.time(), "passes": 0, "trips": 0, "served": 0, "board_opens": 0, "travel_failed": 0,
          "no_stock": 0, "waiting": 0, "queued": 0, "planted": 0, "express": 0, "sprint": 0}


def _stats_trip(status):
    st = str(status)
    _stats["trips"] += 1
    for key in ("travel_failed", "no_stock", "waiting", "queued", "planted"):
        if key in st:
            _stats[key] += 1


# --- Stuck-slot test (10/19, watch-only, owner: "log only test"): Cream waited 72 min at the Dairy behind 4
# ice creams the bot had not queued -- it cannot tell its own batches from someone else's, so it counted all 4.
# The idea under test: after STUCK_TEST_SEC of waiting with the busy slots unchanged, queue into the free slot
# anyway. This only LOGS when that would happen and how long the dish kept waiting after it. Never taps.
STUCK_TEST_SEC = 600
_stuck = {}                       # (station, dish) -> {"first", "busy", "fired"}
_stuck_stats = {"fires": 0, "minutes": 0.0}


def _stuck_key(label, icon):
    try:
        name, where = _timer_name(label, icon)
    except Exception:                                       # noqa: BLE001
        return None
    if not name or name == label or not where:
        return None
    return (where, name)


def _stuck_watch(label, icon, busy):
    try:
        k = _stuck_key(label, icon)
        if not k:
            return
        now = time.time()
        e = _stuck.get(k)
        if e is None or e["busy"] != busy:                  # slots changed: something moved, start over
            if e and e["fired"]:
                _stuck_close(k, "the busy slots changed")
            _stuck[k] = {"first": now, "busy": busy, "fired": None}
            return
        waited = (now - e["first"]) / 60
        if e["fired"] is None and now - e["first"] >= STUCK_TEST_SEC:
            e["fired"] = now
            _stuck_stats["fires"] += 1
            log(f"[stuck test] {k[1]} at {k[0]}: waited {waited:.0f} min, {busy} busy slot(s) never changed and "
                "none were queued by the bot -- the fix WOULD put it in the free slot now.")
        elif e["fired"]:
            log(f"[stuck test] {k[1]} at {k[0]}: still waiting, {(now - e['fired']) / 60:.0f} min since the fix "
                "would have queued it.")
    except Exception as ex:                                 # noqa: BLE001 -- a test must never break the run
        log(f"[stuck test] skipped: {ex}")


def _stuck_close(k, why):
    e = _stuck.pop(k, None)
    if e and e["fired"]:
        mins = (time.time() - e["fired"]) / 60
        _stuck_stats["minutes"] += mins
        log(f"[stuck test] {k[1]} at {k[0]}: wait ended ({why}) {mins:.0f} min after the fix would have queued it "
            f"-- up to {mins:.0f} min the fix could have saved.")


def _stuck_end(label, icon):
    try:
        k = _stuck_key(label, icon)
        if k in _stuck:
            _stuck_close(k, "the bot queued it")
    except Exception:                                       # noqa: BLE001
        pass


# --- Storage test (10/19, owner: "build in any logs for testing" before a long run) -----------------------------
# Live 10/19 11:41 and 12:27: storage hit 30/30, the storage-full popup came back 3+ times and the purge trashed all
# 3 Food Club orders (6 lost). Storage sat at 19-26/30 all morning (10/17: 12-24), with the express buffer holding
# up to 6 berries + 4 wheat. Watch-only: logs (a) each reading at/above STORAGE_GUARD_AT and the stock the bot last
# saw, (b) every seed-reserve planting the proposed guard WOULD skip at that level, (c) each storage-full popup and
# purge with the last reading before it. Counts in the [hour] line. Changes nothing.
STORAGE_GUARD_AT = 27
_stg = {"high": False, "would_skip": 0, "popups_seen": 0, "popups": 0, "purges": 0}


_guard_logged = {"t": 0.0}


def storage_guard_on(who=""):
    """10/20 (owner: yes) STORAGE GUARD: at STORAGE_GUARD_AT or more (Settings, 0 = off) the seed reserve and the
    express buffer are switched off -- the bot cooks with what is in storage instead of planting extra crops into it.
    10/19 storage hit 30/30 twice and the purge trashed all 3 Food Club orders each time (6 orders lost)."""
    u = _storage_used()
    if not STORAGE_GUARD_AT or not u or u[0] < STORAGE_GUARD_AT:
        return False
    if time.time() - _guard_logged["t"] > 120:
        _guard_logged["t"] = time.time()
        log(f"[storage guard] storage {u[0]}/{u[1]} (guard at {STORAGE_GUARD_AT}) -- no extra crops for the reserve / "
            f"express buffer; cooking with what is there{' (' + who + ')' if who else ''}.")
    return True


def _storage_used():
    """(used, capacity) of the Food Club storage if read in the last 10 min, else None.
    10/20 (owner): a "storage is full" popup newer than the last banner reading counts as FULL -- the banner was
    last read at 23-25/30 while the popup came 10 times, so the guard never switched on."""
    now = time.time()
    last_t = _storage.get("last_t", 0) if _storage.get("last") else 0
    try:
        pop_t = fac.STORAGE_FULL_TIMES[-1] if fac.STORAGE_FULL_TIMES else 0
    except Exception:                                       # noqa: BLE001
        pop_t = 0
    if pop_t > last_t and now - pop_t < 600:
        cap = _storage["last"][1] if _storage.get("last") else 30
        return (cap, cap)
    if last_t and now - last_t < 600:
        return _storage["last"]
    return None


def storage_full_now():
    """Food Club storage at capacity-1 or more (or a full popup since the last reading)."""
    u = _storage_used()
    return bool(u) and u[0] >= u[1] - 1


def _stock_summary(limit=8):
    now = time.time()
    fresh = [(v[0], v[2]) for v in _stock_seen.values() if v[0] and now - v[1] < 1800]
    fresh.sort(reverse=True)
    return ", ".join(f"{nm} {n}" for n, nm in fresh[:limit]) or "nothing read recently"


def _storage_test_reading(r):
    try:
        high = r[0] >= STORAGE_GUARD_AT
        if high and not _stg["high"]:
            log(f"[storage test] storage {r[0]}/{r[1]} reached the guard line ({STORAGE_GUARD_AT}) -- the guard WOULD now "
                f"stop planting extras and stop holding the express buffer. Stock last seen: {_stock_summary()}.")
        elif not high and _stg["high"]:
            log(f"[storage test] storage back below the guard line: {r[0]}/{r[1]}.")
        _stg["high"] = high
    except Exception as e:                             # noqa: BLE001
        log(f"[storage test] skipped: {e}")


def _storage_test_reserve(nm, have, keep, want):
    try:
        u = _storage_used()
        if u and u[0] >= STORAGE_GUARD_AT:
            _stg["would_skip"] += 1
            log(f"[storage test] storage {u[0]}/{u[1]}: the guard WOULD NOT plant {nm} for the reserve now "
                f"(have {have}, keeping {keep}{' -- express buffer' if keep > SEED_RESERVE else ''}); it would cook "
                f"with what is there instead.")
    except Exception:                                  # noqa: BLE001
        pass


# --- Storage relief test (10/20, owner: "open a stove that cooks something that takes a lot of ingredients, check if
# we have those and make it if we do, especially if we have 0 of that item"). LOG ONLY -- taps nothing. When Food Club
# storage is full (or one short), a storage-full popup shows, or a purge is about to run, it writes what it WOULD
# cook to make room: a dish whose ingredients are all in stock beyond what the cards on the board still need, most
# space freed first (ingredients used - 1 made), then the dish there is least of. And it checks the idea's key
# assumption: after the bot itself queues a batch, the next storage reading should drop by the ingredients it used.
RELIEF_TEST_GAP_SEC = 300
RELIEF_TEST_ON = False    # 11/17: retired -- live storage relief (relief_panel) has run since 11/4; this log-only test
                          # only knows recipe_test.json and kept saying "nothing to cook" while relief really cooked
_relief = {"t": 0.0, "q": None, "n": 0, "found": 0}


def _relief_candidates():
    """[(frees, out_have, dish, where, uses)] best first, and the reasons the others were left out."""
    import json
    try:
        with open(RECIPE_TEST_FILE, encoding="utf-8") as fh:
            raw = json.load(fh)
    except (OSError, ValueError):
        raw = {}
    book = _recipe_book()
    where_of = {_norm(d): e.get("where") for d, e in raw.items()}
    names = {_norm(d): d for d in raw}
    now = time.time()
    stock = {k: v[0] for k, v in _stock_seen.items() if now - v[1] < 2700}
    keep = {}                                          # what the board still needs: its dishes and their ingredients
    try:
        import orders_view
        _v, st = orders_view.snapshot()
        for o in (st.get("Food Club Event") or {}).get("orders", []):
            for it in o["items"]:
                if not it.get("name") or it.get("kind") == "done":
                    continue
                short = max(0, (it.get("need") or 1) - (it.get("have") or 0))
                keep[_norm(it["name"])] = keep.get(_norm(it["name"]), 0) + (it.get("need") or 1)
                for ing, q in book.get(_norm(it["name"]), []):
                    keep[_norm(ing)] = keep.get(_norm(ing), 0) + short * (q or 1)
    except Exception:                                  # noqa: BLE001
        pass
    out, why = [], {}
    seen = {_norm(d): e.get("seen", 0) for d, e in raw.items()}
    for dk, ings in book.items():
        if seen.get(dk, 0) < 3:
            continue                                   # an OCR misspelling of a name ("Bacon Eggs B Hash Browns")
        if not ings or any(q is None or nm.startswith("unknown") for nm, q in ings):
            why[names.get(dk, dk)] = "recipe not fully read"
            continue
        uses = sum(q for _n, q in ings)
        if uses < 2:
            continue                                   # 1 in, 1 out frees nothing
        short = [nm for nm, q in ings if stock.get(_norm(nm)) is None or stock[_norm(nm)] - keep.get(_norm(nm), 0) < q]
        if short:
            why[names.get(dk, dk)] = "not enough spare " + ", ".join(short)
            continue
        out.append((uses - 1, stock.get(dk, 0), names.get(dk, dk), where_of.get(dk), uses))
    out.sort(key=lambda t: (-t[0], t[1]))
    return out, why


def storage_relief_test(reason):
    """Log what the bot WOULD cook to make room (at most every RELIEF_TEST_GAP_SEC). Never taps."""
    if not RELIEF_TEST_ON:
        return
    try:
        now = time.time()
        if now - _relief["t"] < RELIEF_TEST_GAP_SEC:
            return
        _relief["t"] = now
        _relief["n"] += 1
        cands, why = _relief_candidates()
        u = _storage.get("last")
        head = f"[storage relief test] {reason} (storage {u[0]}/{u[1]})" if u else f"[storage relief test] {reason}"
        if cands:
            _relief["found"] += 1
            frees, have, dish, where, uses = cands[0]
            more = "; next best: " + ", ".join(f"{c[2]} (frees {c[0]})" for c in cands[1:3]) if len(cands) > 1 else ""
            log(f"{head}: WOULD cook {dish} at {where or 'its station (not learned yet)'} -- uses {uses}, makes 1, "
                f"frees {frees}; have {have} of it{more}.")
        else:
            log(f"{head}: nothing to cook to make room -- " + ("; ".join(f"{d}: {w}" for d, w in list(why.items())[:5])
                                                              or "no recipes read yet") + ".")
        log(f"[storage relief test] so far: {_relief['found']} of {_relief['n']} full moments had a dish to cook. "
            f"Stock seen: {_stock_summary()}.")
    except Exception as e:                             # noqa: BLE001 -- a test must never break the run
        log(f"[storage relief test] skipped: {e!r}")


def _relief_note_queue(name, uses):
    """Remember a batch the bot queued, with the storage reading just before (if fresh)."""
    u, t = _storage.get("last"), _storage.get("last_t", 0)
    if u and time.time() - t < 180 and uses:
        _relief["q"] = {"t": time.time(), "name": name, "uses": uses, "before": u[0]}


def _relief_check_reading(r):
    q = _relief.get("q")
    if not q or time.time() - q["t"] > 150:
        _relief["q"] = None
        return
    _relief["q"] = None
    drop = q["before"] - r[0]
    log(f"[storage relief test] queued {q['name']} (uses {q['uses']}): storage {q['before']} -> {r[0]} "
        + ("-- ingredients left storage when cooking STARTED (the idea works)." if drop >= q["uses"] - 1 else
           "-- no clear drop (other things may have been collected meanwhile)."))


def _storage_test_popups():
    """Called once per pass: storage-full popups closed since the last pass, with the last reading before them."""
    try:
        n = len(fac.STORAGE_FULL_TIMES)
        if n > _stg["popups_seen"]:
            new = n - _stg["popups_seen"]
            _stg["popups"] += new
            u = _storage.get("last")
            age = int(time.time() - _storage.get("last_t", time.time()))
            log(f"[storage test] storage-full popup x{new} -- last reading {u[0] if u else '?'}/{u[1] if u else '?'} "
                f"({age} s before); stock last seen: {_stock_summary()}.")
            storage_relief_test("storage-full popup")
        _stg["popups_seen"] = n
    except Exception:                                  # noqa: BLE001
        pass


def _stats_tick(served=0):
    _stats["passes"] += 1
    _stats["served"] += served
    now = time.time()
    if now - _stats["since"] < 3600:
        return
    s_ = _stats
    mins = int((now - s_["since"]) // 60)
    pts = ""
    if _score.get("start"):
        pts = f", event points this run so far {_score['gained']}"
    log(f"[hour] last {mins} min: {s_['served']} order(s) completed{pts}; {s_['passes']} passes, "
        f"{s_['board_opens']} board openings, {s_['trips']} trips "
        f"(queued {s_['queued']}, planted {s_['planted']}, waiting {s_['waiting']}, out of seeds {s_['no_stock']}, "
        f"travel failed {s_['travel_failed']}); express orders {s_['express']} (sprint plantings {s_['sprint']}); skip test right "
        f"{_skip_score['right']} / wrong {_skip_score['wrong']}"
        + (f"; storage last seen {_storage['last'][0]}/{_storage['last'][1]}" if _storage.get("last") else "")
        + (f"; cards finished {len(_card_lives)}, average {sum(_card_lives) / len(_card_lives):.0f} min on the board"
           if _card_lives else "")
        + (f"; storage test (this run): guard would have skipped {_stg['would_skip']} reserve planting(s), storage-full popups "
           f"{_stg['popups']}, purges {_stg['purges']}" if (_stg['would_skip'] or _stg['popups'] or _stg['purges']) else "")
        + (f"; stuck test (whole run): fix would have fired {_stuck_stats['fires']}x, {_stuck_stats['minutes']:.0f} "
           f"min waited after that, {sum(1 for e in _stuck.values() if e['fired'])} still waiting"
           if _stuck_stats["fires"] else ""))
    _card_lives.clear()
    for k in s_:
        s_[k] = 0
    s_["since"] = now


# --- Card test (10/17 freetime, watch-only: groundwork for "finish one card at a time") ------------------
# Each pass: how far every card is from done (red items AND missing units), which card the bot's order
# (fewest red items first) starts with vs the card with the fewest missing units, and how long each card
# lives from first seen to gone (completed). Changes nothing the bot does.
_cards_seen = {}       # card key -> first seen time
_card_lives = []       # minutes from first seen to gone


def _card_key(img, card):
    names = []
    for nd in card_needs(img, card):
        nm = item_name(board_icon(img, *nd["slot"]["icon"])) or "?"
        names.append(f"{nm}x{nd['need'] if nd['need'] is not None else '?'}")
    return tuple(sorted(names))


# 10/19 freetime (watch-only): two Assorted Meats cards stayed red 70 min with their "have/need" unreadable
# ("?/?"), so the bot never knew how many to make. One picture of each unreadable count (per dish, at most
# COUNT_PIC_MAX kept) goes to templates/count_unknown/ and rides along with Send logs.
COUNT_UNKNOWN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "count_unknown")
COUNT_PIC_MAX = 10
_count_pic_done = set()


def _save_unread_count(img, needs):
    for nd in needs:
        if nd["have"] is not None:
            continue
        try:
            nm = _norm(item_name(board_icon(img, *nd["slot"]["icon"])) or "unknown")
            if nm in _count_pic_done:
                continue
            _count_pic_done.add(nm)
            os.makedirs(COUNT_UNKNOWN_DIR, exist_ok=True)
            old = sorted(os.listdir(COUNT_UNKNOWN_DIR))
            for f in old[:max(0, len(old) - COUNT_PIC_MAX + 1)]:
                os.remove(os.path.join(COUNT_UNKNOWN_DIR, f))
            tx, _ = nd["slot"]["icon"]
            ty = ROW_TEXT_Y[nd["slot"]["row"]]
            crop = img[max(0, ty - 60):ty + 30, max(0, tx - 70):tx + 70]      # icon bottom + the count text
            path = os.path.join(COUNT_UNKNOWN_DIR, f"{nm}_{int(time.time())}.png")
            cv2.imwrite(path, crop)
            log(f"[count test] could not read the amount under {nm} ({nd['color']}) -- picture saved to "
                f"templates/count_unknown/.")
        except Exception as e:                         # noqa: BLE001
            log(f"[count test] skipped: {e}")


# 10/19 freetime (watch-only): would a text reader be a good backup for the digit reader? Once every
# OCR_TEST_SEC, in a background thread, every RED card amount is cut out, turned black-on-white (pure red
# pixels only -- that is how the digits differ from a red picture behind them) and read by Windows OCR. Where
# the digit reader has an answer the two are compared; where it has none, the backup's answer is logged.
OCR_TEST_SEC = 300
_ocr_test = {"t": 0.0, "agree": 0, "disagree": 0, "backup_only": 0, "neither": 0, "busy": False}


def _ocr_count(crop):
    import re
    import popup_ocr
    b, g, r = cv2.split(crop)
    mask = ((r > 200) & (g < 90) & (b < 90)).astype(np.uint8)
    bw = np.where(mask > 0, 0, 255).astype(np.uint8)
    bw = cv2.resize(bw, None, fx=3, fy=3, interpolation=cv2.INTER_NEAREST)
    txt = popup_ocr.read_text(cv2.cvtColor(bw, cv2.COLOR_GRAY2BGR)).replace(" ", "")
    m = re.search(r"(\d+)[/|lI](\d+)", txt)
    return (int(m.group(1)), int(m.group(2))) if m else None, txt


OCR_TEST = False      # 10/31: retired -- 820 lines in 2 days, the Windows OCR backup was wrong every time


def _ocr_count_test(img, cards):
    if not OCR_TEST:
        return
    if _ocr_test["busy"] or time.time() - _ocr_test["t"] < OCR_TEST_SEC:
        return
    jobs = []
    try:
        for c in cards:
            for nd in card_needs(img, c):
                if nd["color"] != "red":
                    continue
                tx, _ = nd["slot"]["icon"]
                ty = ROW_TEXT_Y[nd["slot"]["row"]]
                nm = item_name(board_icon(img, *nd["slot"]["icon"])) or "?"
                jobs.append((nm, nd["have"], nd["need"], img[max(0, ty - 26):ty + 26, max(0, tx - 50):tx + 50].copy()))
    except Exception as e:                             # noqa: BLE001
        log(f"[ocr test] skipped: {e}")
        return
    if not jobs:
        return
    _ocr_test["t"], _ocr_test["busy"] = time.time(), True

    def work():
        try:
            for nm, have, need, crop in jobs:
                got, raw = _ocr_count(crop)
                if have is not None:
                    if got == (have, need):
                        _ocr_test["agree"] += 1
                    else:
                        _ocr_test["disagree"] += 1
                        log(f"[ocr test] {nm}: digit reader {have}/{need}, backup read '{raw}' -- WRONG")
                elif got:
                    _ocr_test["backup_only"] += 1
                    log(f"[ocr test] {nm}: digit reader could not read it, backup says {got[0]}/{got[1]}")
                else:
                    _ocr_test["neither"] += 1
                    log(f"[ocr test] {nm}: neither could read it (backup saw '{raw}')")
            log(f"[ocr test] so far: agree {_ocr_test['agree']}, backup wrong {_ocr_test['disagree']}, "
                f"backup read what the digit reader could not {_ocr_test['backup_only']}, neither {_ocr_test['neither']}")
        except Exception as e:                         # noqa: BLE001
            log(f"[ocr test] skipped: {e}")
        finally:
            _ocr_test["busy"] = False
    import threading
    threading.Thread(target=work, daemon=True).start()


def _card_test(img, cards):
    try:
        now = time.time()
        rows, keys = [], []
        for c in cards:
            if is_express_card(img, c):
                continue
            needs = card_needs(img, c)
            _save_unread_count(img, needs)
            red = sum(1 for nd in needs if nd["missing"])
            units = sum(nd["missing"] for nd in needs)
            key = _card_key(img, c)
            keys.append(key)
            _cards_seen.setdefault(key, now)
            short = ", ".join(f"{(item_name(board_icon(img, *nd['slot']['icon'])) or '?')} "
                              f"{nd['have'] if nd['have'] is not None else '?'}/{nd['need'] if nd['need'] is not None else '?'}"
                              for nd in needs if nd["missing"])
            age = int((now - _cards_seen[key]) // 60)
            rows.append((red, units, age, short or "all green"))
        for key in [k for k in _cards_seen if k not in keys]:
            mins = (now - _cards_seen.pop(key)) / 60.0
            _card_lives.append(mins)
            log(f"[card test] a card is gone from the board after {mins:.0f} min ({', '.join(key)})")
        if not rows:
            return
        by_units = min(range(len(rows)), key=lambda i: (rows[i][1], rows[i][0]))
        txt = " | ".join(f"#{i + 1}: {r[0]} red, {r[1]} units missing, on board {r[2]} min ({r[3]})"
                         for i, r in enumerate(rows))
        note = ("the bot's order already starts with it" if by_units == 0 else
                f"the bot starts with #1 ({rows[0][1]} units), the closest card is #{by_units + 1} ({rows[by_units][1]} units)")
        if _quiet("card_test", 900, tuple((r[0], r[1], r[3]) for r in rows)):   # 11/28: only when the board changed
            log(f"[card test] {txt} || closest to done: #{by_units + 1}; {note}")
    except Exception as e:                             # noqa: BLE001 -- a test must never break the run
        log(f"[card test] skipped: {e}")


# 10/19 (owner): after a purge all three order slots sat empty and the bot reopened the board every ~25 s for
# 30+ min. When no card has an item: read the board's text for a countdown ("12:34", "12m 5s") and leave the board
# shut until then -- capped at BOARD_EMPTY_MAX_SEC so an express is never missed for long. No countdown read:
# wait 1, 2, 4, then 5 min. Never taps anything on the empty board (its buttons may cost gems).
BOARD_EMPTY_MAX_SEC = 300
_board_empty = {"until": 0.0, "backoff": 0, "said": 0.0, "pic": False}


def _parse_wait(text):
    import re
    t = (text or "").replace(" ", "").lower()
    best = None
    for m in re.finditer(r"(?:(\d+)h)?(\d+)m(?:(\d+)s)?|(\d+):(\d{2})(?::(\d{2}))?|(\d+)s", t):
        g = m.groups()
        if g[1] is not None:
            secs = int(g[0] or 0) * 3600 + int(g[1]) * 60 + int(g[2] or 0)
        elif g[3] is not None:
            secs = (int(g[3]) * 3600 + int(g[4]) * 60 + int(g[5])) if g[5] else int(g[3]) * 60 + int(g[4])
        else:
            secs = int(g[6])
        if 0 < secs < 24 * 3600:
            best = secs if best is None else min(best, secs)
    return best


def _board_is_empty(img):
    text = ""
    try:
        import popup_ocr
        text = popup_ocr.read_text(img, (0, 240, img.shape[1], 790))
    except Exception:                                  # noqa: BLE001
        pass
    secs = _parse_wait(text)
    if secs:
        wait = min(secs + 5, BOARD_EMPTY_MAX_SEC)
        why = f"the board says {secs // 60}m{secs % 60:02d}s"
    else:
        _board_empty["backoff"] += 1
        wait = min(60 * 2 ** (_board_empty["backoff"] - 1), BOARD_EMPTY_MAX_SEC)
        why = "no countdown could be read"
    _board_empty["until"] = time.time() + wait
    log(f"Board has NO orders ({why}; text read: {text[:120]!r}) -- next look in {wait // 60}m{wait % 60:02d}s.")
    if not _board_empty["pic"]:
        _board_empty["pic"] = True
        try:
            save_unknown_screen(img)
        except Exception:                              # noqa: BLE001
            pass


SAME_STATION_EXTRAS = True     # 10/21 (owner: yes) -- set False to switch off


def _same_station_extras(board_img, cards, handled, label, stop_flag, ctx):
    """10/21 (owner: yes): ~124 board openings an hour, one per item. After a trip ends on an open station panel,
    every OTHER red board item made at this same station is worked right here (no extra board opening or travel).
    Strict: only items whose picture clearly matches one of this panel's cards (pick_best, no name/library guess),
    and no ingredient chasing from here (depth = MAX_DEPTH) -- an item that needs a chase is left for its own trip."""
    out = []
    try:
        img = adb_helper.screenshot()
        btns = station_buttons(img)
        if not btns or not station_panel_open(img):
            return out
        arts = [(i, card_art(img, b[0], b[1])) for i, b in enumerate(btns)]
        k = 0
        for c in cards:
            for sl in c["slots"]:
                if sl["color"] != "red":
                    continue
                icon = board_icon(board_img, *sl["icon"])
                if any(_same(icon, h) for h in handled):
                    continue
                best, _sc = pick_best(icon, arts)
                if best is None or dict(_sc).get(best, 0) < 40:   # strong picture match only (right card: 80-170)
                    continue
                of.check_stop(stop_flag)
                k += 1
                lab = f"{label}+same station {k}"
                want = board_slot_want(board_img, c, sl)
                log(f"'{lab}': this board item is made here too -- working it in the same visit (want {want}).")
                r = _work_station_core(icon, lab, MAX_DEPTH, stop_flag, ctx, want=want)
                log(f"{lab}: {r}")
                out.append({"item": lab, "status": r})
                if r != "too_deep":                     # needs a chase -> leave it for its own trip this pass
                    handled.append(icon)
                    _stats["same_station"] = _stats.get("same_station", 0) + 1
                img = adb_helper.screenshot()
                if not station_buttons(img):
                    return out
    except StopRequested:
        raise
    except Exception as e:                              # noqa: BLE001
        log(f"'{label}': same-station extras skipped: {e!r}")
    return out


def run_once(stop_flag=None, max_chases=4):
    """One pass: complete ready cards, then chase up to max_chases distinct
    missing items. Returns (served, [ {item, status} ])."""
    ctx = {"made": []}
    results = []
    wait = _board_empty["until"] - time.time()
    if wait > 0 and not express_active():
        if time.time() - _board_empty["said"] > 60:
            _board_empty["said"] = time.time()
            log(f"Board has no orders -- not opening it again for {int(wait) // 60}m{int(wait) % 60:02d}s.")
        _view("set_note", "Food Club Event", "No orders on the board right now -- waiting for new ones.")
        of.interruptible_sleep(min(wait, 20), stop_flag)      # a calm wait, not a 3-second empty cycle loop
        return 0, [{"item": "-", "status": "board_empty_wait"}]
    of.close_any_open_panel(quiet=True, thorough=True)
    img = open_board(stop_flag)
    if img is None:
        _view("set_note", "Food Club Event", "The board did not open this pass -- see the log (Open board steps).")
        return 0, [{"item": "-", "status": "board_not_opened"}]
    if any(is_express_card(img, c) for c in read_board(img)):
        _view("set_note", "Food Club Event", "EXPRESS ORDER -- working only on the gold card.")
        return run_express(stop_flag)          # state of emergency: nothing else is touched
    if os.path.exists(EXPRESS_STATE):                      # not express_active(): its 10-min TTL may have run out
        log("The express card is gone from the board -- emergency over.")
        _express_write(False)
    served = serve_ready_cards(stop_flag)
    _view("add_completed", "Food Club Event", served)
    handled = []
    for n in range(max_chases):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if not board_is_open(img):
            img = open_board(stop_flag)
            if img is None:
                break
        cards = sorted(read_board(img), key=lambda c: sum(s["color"] == "red" for s in c["slots"]))
        if n == 0 and cards and not any(c["slots"] for c in cards):
            _board_is_empty(img)                           # 10/19 (owner): read the wait instead of reopening
            break
        if n == 0:
            _board_empty.update(until=0.0, backoff=0)
            _card_test(img, cards)
            try:                                       # 11/13: name unknown board items from their tooltips
                if learn_board_names(img, cards, stop_flag):
                    img = adb_helper.screenshot()
                    cards = sorted(read_board(img), key=lambda c: sum(s["color"] == "red" for s in c["slots"]))
            except StopRequested:
                raise
            except Exception as e:                     # noqa: BLE001
                log(f"[names] failed (ignored): {e!r}")
            _storage_test_popups()
            _ocr_count_test(img, cards)
        if n > 0 and any(is_express_card(img, c) for c in cards):
            # 10/17: an express order that appears mid-pass used to wait for the next pass (owner watched it
            # sit for minutes); the board is re-read between every trip anyway, so switch right away.
            log("An EXPRESS card appeared during this pass -- switching to emergency mode now.")
            ex_served, ex_results = run_express(stop_flag)
            return served + ex_served, results + ex_results
        slot_pos = _publish_board(img, cards) or {}
        work = cards
        if storage_full_now():
            # 10/20 (owner): storage full -> finish ONE card (fewest red items) instead of feeding all three; a
            # served card takes its dishes out of storage, and no new ingredients are pulled in for the others.
            reds = [c for c in cards if any(s["color"] == "red" for s in c["slots"])]
            if reds:
                # 11/1 night: the focus card's only red item was a CROP (Twilight Root) -- harvesting it is refused
                # while storage is full, so the bot walked to the plots every ~25 s for 23 min (08:45-09:08) with the
                # storage popup each time. Prefer a card with a red DISH: cooking takes ingredients OUT of storage.
                reds = storage_focus_order(reds, lambda sl: _crop_slot(img, sl), lambda c: _missing_units(img, c))
                keys = [int(round(c["cx"] / 60.0)) for c in reds]
                k, rotated = focus_pick(keys, _focus, time.time())
                if rotated is not None:
                    log(f"[storage focus] the card at x~{rotated * 60} has not been served in "
                        f"{FOCUS_ROTATE_SEC // 60} min (its station is probably jammed) -- trying another card.")
                work = [reds[keys.index(k)]]
                if n == 0:
                    u = _missing_units(img, work[0])
                    log(f"[storage focus] storage full -- working only on the card with "
                        f"{sum(s['color'] == 'red' for s in work[0]['slots'])} red item(s)"
                        f"{f' ({u} unit(s) missing, the closest to done)' if u is not None else ''} until it is served.")
                    _stg["focus"] = _stg.get("focus", 0) + 1
        if not express_active() and fac.pantry_relief_wanted():
            log("[pantry full] the Pantry is full -- ending this Food Club pass so pantry relief runs right away.")
            break
        target = None
        full_now = storage_full_now()
        if full_now and not express_active() and any(card_is_ready(c) for c in cards):
            # 11/1 10:23: two READY cards were held for prestock while storage was full (popup 9x in 40 s) --
            # serving a card is the quickest way to make room, so a full storage releases every hold.
            n_served = serve_ready_cards(stop_flag)
            if n_served:
                log(f"[storage focus] storage full -- served {n_served} ready card(s) to make room.")
                served += n_served
                _view("add_completed", "Food Club Event", n_served)
                continue
        for c in work:
            for sl in c["slots"]:
                if sl["color"] != "red":
                    continue
                if full_now and _crop_slot(img, sl):
                    continue                               # 11/1: full storage refuses harvests (10:24: 7 popups on 2 crop trips)
                icon = board_icon(img, *sl["icon"])
                if any(_same(icon, h) for h in handled):
                    continue
                target = (icon, sl, c)
                break
            if target:
                break
        hold_want = None
        if target is None:                                 # 10/31: no red item left -- top up a held ready card
            for c in work:
                if not card_is_ready(c) or (c["cx"] // 60) not in _held:
                    continue
                for sl, extra in _hold_card(img, c):
                    icon = board_icon(img, *sl["icon"])
                    if not any(_same(icon, h) for h in handled):
                        target, hold_want = (icon, sl, c), extra
                        break
                if target:
                    break
        if target is None:
            break
        icon, sl, card = target
        handled.append(icon)
        label = f"board item #{n + 1}" + (" (prestock)" if hold_want else "")
        want = hold_want or board_slot_want(img, card, sl)
        if want > 1:
            log(f"'{label}': the card is short {want} of this item -- asking for all {want}.")
        pos = slot_pos.get(id(sl))
        if pos:
            _view("set_item", "Food Club Event", pos[0], pos[1], status="working on it now...", kind="active", active=True)
        global _last_timer_name
        _last_timer_name = None
        guess = _skip_guess(icon, want)
        if SKIP_LIVE and skip_live_ok(guess, _my_batches, time.time(), express_active()):
            left = int(guess[2])
            log(f"[skip] {label} {guess[0]}: {guess[1]}, ready in {left // 60}m{left % 60:02d}s -- "
                f"not travelling there now")
            _skip_score["skipped"] = _skip_score.get("skipped", 0) + 1
            results.append({"item": label, "status": "skipped_cooking"})
            if pos:
                _view("set_item", "Food Club Event", pos[0], pos[1], status=f"cooking, ready in {left // 60}m",
                      kind="waiting", active=False)
            continue
        status = chase(icon, sl["icon"], label, 0, stop_flag, ctx, want=want)
        log(f"{label}: {status}")
        _skip_judge(label, guess, status)
        _stats_trip(status)
        results.append({"item": label, "status": status})
        if SAME_STATION_EXTRAS:
            results.extend(_same_station_extras(img, work, handled, label, stop_flag, ctx))
        if pos:
            known = _last_wanted.get("label") == label and _last_wanted.get("name")
            if known:
                _remember_name(icon, _last_wanted["name"])
            fr = _view("friendly", status, _last_wanted.get("where") if known else None) or (str(status), "waiting")
            _view("set_item", "Food Club Event", pos[0], pos[1], status=fr[0], kind=fr[1],
                  name=_last_wanted["name"] if known else None, active=False, timer=_last_timer_name)
        of.close_any_open_panel(quiet=True, thorough=True)
        of.interruptible_sleep(0.3, stop_flag)           # 11/1 FLASH step 4b: was 0.8 s -- open_board waits for a still map itself
        if open_board(stop_flag) is None:
            break
        if "collected_blocker" in str(status):            # pass 16: a collected batch may have just finished a card
            n_served = serve_ready_cards(stop_flag)
            if n_served:
                log(f"'{label}': the collected batch completed {n_served} card(s) -- served right away.")
                served += n_served
                _view("add_completed", "Food Club Event", n_served)
    _view("clear_active", "Food Club Event")
    # leave the screen clean
    if board_is_open(adb_helper.screenshot()):
        of.close_any_open_panel(quiet=True)
    _stats_tick(served)
    try:
        import worth
        worth.note_pass(results)
    except Exception:                                   # noqa: BLE001
        pass
    return served, results


# --------------------------------------------------------------------------
# Merchant stocker: keep every Dorothy Merchant item at >= MERCHANT_MIN_STOCK
# --------------------------------------------------------------------------
# The Merchant (3 cards: gold bottle 3m, rainbow vial 3m, mint shake 4m) makes
# the intermediate items most event cards need, so the user wants 2 of each in
# stock at all times and the 2 queue slots refilled whenever they are free.
# Stock is read from the white count box under each card (0/1 are read
# exactly, anything else = "2+" = enough, see order_fulfill.read_card_stock_low).
# Never touches the cyan Unlock button (only lime action buttons are tapped).

MERCHANT_DIR = os.path.join(BASE_DIR, "templates", "event_merchant")
MERCHANT_MIN_STOCK = 2
MERCHANT_STOCKING = False                # 10/31 (owner): off -- "no_route" every pass (343x 10/30-31); Prestock covers it
MERCHANT_COOK_SEC = (180, 180, 240)      # cards 0,1,2 (3m, 3m, 4m)
MERCHANT_VISIT_GAP_SEC = 150             # don't re-travel more often than this
MERCHANT_IDLE_GAP_SEC = 420              # pass 5: next trip after a visit where every card was already stocked
_merchant_idle = False
_merchant_arts_cache = []
_merchant_pending = {0: [], 1: [], 2: []}   # ready-at times of batches WE queued
_merchant_last_visit = 0.0


def _merchant_arts():
    if not _merchant_arts_cache:
        for i in range(3):
            a = cv2.imread(os.path.join(MERCHANT_DIR, f"{i}.png"))
            if a is not None:
                _merchant_arts_cache.append(a)
    return _merchant_arts_cache


def is_merchant_panel(img):
    """True if the open station panel is the Dorothy Merchant (its 3 card arts
    match the saved ones; other stoves score <= 6 inliers, the real panel
    116+)."""
    arts = _merchant_arts()
    btns = station_buttons(img)
    if len(arts) != 3 or len(btns) != 3:
        return False
    hits = sum(sift_match_score(arts[i], card_art(img, b[0], b[1])) >= 40
               for i, b in enumerate(btns))
    return hits >= 2


def merchant_item(icon):
    """True when a board / panel icon is one of the Merchant's products (matches a saved Merchant art)."""
    arts = _merchant_arts()
    if len(arts) != 3:
        return False
    best, scores = pick_best(icon, list(enumerate(arts)))
    if best is None:
        return False
    sift = dict(scores).get(best, 0)
    if sift >= 40:                                       # pass 30: an egg scores 24-29 against the gold-bottle art
        return True
    ih = _hs_hist(icon[:max(1, int(icon.shape[0] * 0.7))])
    return float(np.minimum(ih, _hs_hist(arts[best])).sum()) >= 0.70


_last_building_miss = 0.0


def _save_building_miss(img, name):
    """Keep a picture of a screen where the building could not be found (1 per minute, newest 40 kept)."""
    global _last_building_miss
    if time.time() - _last_building_miss < 60:
        return
    _last_building_miss = time.time()
    try:
        folder = os.path.join(BASE_DIR, "templates", "building_misses")
        os.makedirs(folder, exist_ok=True)
        for old in sorted(os.listdir(folder))[:-39]:
            os.remove(os.path.join(folder, old))
        cv2.imwrite(os.path.join(folder, f"{int(time.time())}_{name}.png"), img)
        log(f"'{name}': saved this screen to templates/building_misses/ so the finder can learn this look.")
    except Exception as e:                                # noqa: BLE001
        log(f"'{name}': could not save the miss picture ({e}).")


_bf_loaded_at = 0.0


def _fresh_building_finder():
    """building_finder, reloaded when its file or a template changed since the last load (it is not in afsd_core's reload list)."""
    global _bf_loaded_at
    import importlib
    import building_finder as bf
    try:
        newest = os.path.getmtime(bf.__file__)
        for f in os.listdir(bf.TEMPLATE_DIR):
            newest = max(newest, os.path.getmtime(os.path.join(bf.TEMPLATE_DIR, f)))
    except OSError:
        return bf
    if _bf_loaded_at == 0.0 or newest > _bf_loaded_at:
        if _bf_loaded_at != 0.0 or not getattr(bf, "ALIASES", None):
            bf = importlib.reload(bf)
            log("building_finder reloaded (its file or a template changed).")
        _bf_loaded_at = time.time()
    return bf


_last_tapfail = 0.0


def _save_tapfail(img, name, xy):
    """Picture of the screen after a tap that did not open the building (1 per 20 s; shares the miss folder, newest 40 kept)."""
    global _last_tapfail
    if time.time() - _last_tapfail < 20:
        return
    _last_tapfail = time.time()
    try:
        folder = os.path.join(BASE_DIR, "templates", "building_misses")
        os.makedirs(folder, exist_ok=True)
        for old in sorted(os.listdir(folder))[:-39]:
            os.remove(os.path.join(folder, old))
        cv2.imwrite(os.path.join(folder, f"{int(time.time())}_{name}_tapfail_{int(round(xy[0]))}_{int(round(xy[1]))}.png"), img)
    except Exception as e:                                # noqa: BLE001
        log(f"'{name}': could not save the tap-fail picture ({e}).")


BUILDING_TAP_ATTEMPTS = 12          # pass 28: a stack of finished items needs one tap per item


def open_building_by_sight(name, stop_flag=None):
    """After a quick-travel: find the building on the map by its pictures and tap it. Returns "station" when the right panel is open,
    otherwise None (the caller then falls back to arrive()). Never taps anything it has not recognised."""
    try:
        bf = _fresh_building_finder()
    except Exception as e:                                # noqa: BLE001
        log(f"'{name}': building finder unavailable ({e}) -- using the screen centre.")
        return None
    of.interruptible_sleep(1.0, stop_flag)
    for attempt in range(BUILDING_TAP_ATTEMPTS):
        of.check_stop(stop_flag)
        img = adb_helper.screenshot()
        if not hud_is_bright(img) and not station_panel_open(img) and not bar_is_open(img):
            if fac.dismiss_error_dialog():                 # pass 39: a popup (storage full ...) may sit over the panel
                img = adb_helper.screenshot()
        if station_panel_open(img):
            return "station" if (name != "merchant" or is_merchant_panel(img)) else None
        if bar_is_open(img):
            return None
        try:
            r = bf.find(img, name)
        except Exception as e:                            # noqa: BLE001
            log(f"'{name}': finder error ({e}) -- using the screen centre.")
            return None
        if r is None:
            log(f"'{name}': not found on this screen by sight -- using the screen centre.")
            _save_building_miss(img, name)
            return None
        x, y, n = r
        log(f"'{name}' found by sight at ({x:.0f},{y:.0f}) ({n} matching features) -- tapping it.")
        adb_helper.tap(int(round(x)), int(round(y)))
        of.interruptible_sleep(1.6, stop_flag)
        img2 = adb_helper.screenshot()
        if station_panel_open(img2) and (name != "merchant" or is_merchant_panel(img2)):
            return "station"
        log(f"'{name}': the tap did not open the {name} panel -- closing whatever opened.")
        _save_tapfail(img2, name, (x, y))
        if hud_is_bright(img2) and not station_panel_open(img2) and not bar_is_open(img2):
            log(f"'{name}': plain map after the tap (a finished batch was probably collected) -- tapping again.")
            continue
        if not fac.dismiss_error_dialog():
            of.close_any_open_panel(quiet=True, thorough=True)
        if attempt >= 1:                               # pass 28: only plain-map taps (collecting) may go on past the second try
            return None
    return None


def route_to_merchant(stop_flag=None):
    """Opens the board and follows any slot whose icon is a Merchant item
    (gold bottle / vial / mint shake -- red OR green, the tooltip shows for
    both) to the Merchant. Returns True once its panel is open."""
    global _merchant_note
    arts = _merchant_arts()
    if len(arts) != 3:
        log("Merchant stock: saved Merchant arts missing -- cannot route.")
        return False
    img = open_board(stop_flag)
    if img is None:
        return False
    for c in read_board(img):
        for sl in c["slots"]:
            icon = board_icon(img, *sl["icon"])
            best, scores = pick_best(icon, list(enumerate(arts)))
            if best is None:
                continue
            _merchant_note = ""
            log(f"Merchant stock: board slot {sl['icon']} is a Merchant item "
                f"(card {best}) -- travelling to the Merchant.")
            if not tap_item_and_travel(sl["icon"], "merchant route", stop_flag):
                return False
            kind = open_building_by_sight("merchant", stop_flag)      # pass 18
            if kind is None:
                kind, tapped = arrive(stop_flag)
            if kind == "station" and is_merchant_panel(adb_helper.screenshot()):
                return True
            log(f"Merchant stock: arrived '{kind}' but it is not the Merchant panel.")
            return False
    if _merchant_note != "none":
        log("Merchant stock: no Merchant item on the board to route through -- skipping (said once until that changes).")
    _merchant_note = "none"
    return False


def stock_merchant_here(stop_flag=None, ctx=None):
    """On an OPEN Merchant panel: queue batches (into EMPTY slots only) for any
    card whose stock is below MERCHANT_MIN_STOCK, counting batches we queued
    that are still cooking. If a needed card is blocked on a missing crop and
    no slot work is left, chase that crop (plants it) as the last step.
    Returns a short status string."""
    global _merchant_last_visit, _merchant_idle
    ctx = ctx if ctx is not None else {"made": []}
    _merchant_last_visit = time.time()
    _merchant_idle = False
    img = adb_helper.screenshot()
    btns = station_buttons(img)
    if len(btns) != 3 or not is_merchant_panel(img):
        return "not_merchant"
    now = time.time()
    for i in _merchant_pending:
        _merchant_pending[i] = [t for t in _merchant_pending[i] if t > now]
    stock = [of.read_card_stock_low(img, b[0]) for b in btns]   # the real count, or None = unreadable (treated as enough)
    queued = []
    log(f"Merchant stock: counts {[('2+' if s is None else s) for s in stock]}, "
        f"cooking-by-us {[len(_merchant_pending[i]) for i in range(3)]}.")
    _merchant_idle = all((99 if s is None else s) + len(_merchant_pending[i]) >= MERCHANT_MIN_STOCK
                         for i, s in enumerate(stock))
    free = count_empty_slots(img)
    guard = 0
    collected_round = False
    while free > 0 and guard < 4:
        guard += 1
        of.check_stop(stop_flag)
        need = {}
        for i, b in enumerate(btns):
            have = 99 if stock[i] is None else stock[i]
            deficit = MERCHANT_MIN_STOCK - have - len(_merchant_pending[i])
            if deficit > 0:
                blobs = count_blobs(img, b[1] - 70, b[1] - 40, b[0] - 175, b[0] + 175)
                if blobs and all(c == "green" for _, c in blobs):
                    need[i] = deficit
        if not need:
            break
        i = max(need, key=lambda k: (need[k], -k))
        bx, by = btns[i][0], btns[i][1]
        adb_helper.tap(bx, by)
        of.interruptible_sleep(1.2, stop_flag)
        img2 = adb_helper.screenshot()
        no, nc = of.find_no_button(img2)
        if no is not None:
            log("Merchant stock: action opened a gem-buy dialog -- declining.")
            adb_helper.tap(*no)
            break
        ck = fac.collect_finished_dialog_ok(img2)
        if ck is not None:                                     # pass 27: the notice hides the EMPTY labels -- NOT a queued batch
            log("Merchant stock: 'collect finished items first' notice -- not counted as queued; tapping OK.")
            adb_helper.tap(*ck)
            of.interruptible_sleep(1.5, stop_flag)
            if collected_round:
                break
            collected_round = True
            fac.close_any_open_panel(quiet=True, thorough=True)
            if open_building_by_sight("merchant", stop_flag) != "station":
                log("Merchant stock: could not reopen the Merchant after collecting -- stopping this visit.")
                break
            img = adb_helper.screenshot()
            btns = station_buttons(img)
            if len(btns) != 3 or not is_merchant_panel(img):
                break
            stock = [of.read_card_stock_low(img, b[0]) for b in btns]
            free = count_empty_slots(img)
            log(f"Merchant stock: collected the finished batch; counts now {[('2+' if s is None else s) for s in stock]}, "
                f"{free} EMPTY slot(s).")
            continue
        free2 = count_empty_slots(img2)
        if free2 < free:
            _merchant_pending[i].append(time.time() + MERCHANT_COOK_SEC[i])
            queued.append(i)
            log(f"Merchant stock: queued card {i} (EMPTY slots {free} -> {free2}).")
            free = free2
            img = img2
        else:
            log(f"Merchant stock: tapped card {i} but EMPTY slots stayed {free2} -- NOT verified, stopping.")
            break
    # cards still short on a crop: plant/harvest it (leaves the panel)
    img = adb_helper.screenshot()
    if station_panel_open(img) and is_merchant_panel(img):
        btns = station_buttons(img)
        for i, b in enumerate(btns):
            have = 99 if stock[i] is None else stock[i]
            if MERCHANT_MIN_STOCK - have - len(_merchant_pending[i]) <= 0:
                continue
            blobs = count_blobs(img, b[1] - 70, b[1] - 40, b[0] - 175, b[0] + 175)
            reds = [x for x, c in blobs if c == "red"]
            if reds:
                sub = ingredient_icon(img, reds[0], b[1])
                r = chase(sub, (reds[0], b[1] - 56), f"merchant card {i} crop", 1, stop_flag, ctx)
                return f"queued {queued}, crop chase for card {i}: {r}"
    return f"queued {queued}" if queued else "nothing_needed_or_no_free_slot"


def stock_merchant(stop_flag=None, force=False):
    """Visit the Merchant (via a board Merchant item) and top it up, at most
    once per MERCHANT_VISIT_GAP_SEC. Returns a result dict for the report."""
    gap = MERCHANT_IDLE_GAP_SEC if _merchant_idle else MERCHANT_VISIT_GAP_SEC
    if not force and time.time() - _merchant_last_visit < gap:
        return {"item": "merchant stock", "status": "skipped_recent_visit"}
    try:
        fac.close_any_open_panel(quiet=True, thorough=True)
        if not route_to_merchant(stop_flag):
            return {"item": "merchant stock", "status": "no_route"}
        status = stock_merchant_here(stop_flag)
    finally:
        pass
    fac.close_any_open_panel(quiet=True, thorough=True)
    log(f"Merchant stock: {status}")
    return {"item": "merchant stock", "status": status}


def format_report(served, results):
    lines = [f"Event orders: completed {served}"]
    for r in results:
        lines.append(f"  {r['item']}: {r['status']}")
    return "\n".join(lines)


# --------------------------------------------------------------------------
# STORAGE FULL -> discard the event board's orders (pass 8, 10/6; user's decision)
# --------------------------------------------------------------------------
STORAGE_FULL_PURGE = True        # 11/17 (owner): ON again, one order at a time (Settings > Food Club); was OFF since 10/20.
# pass 38 (10/7 03:30): ON again with a gem-icon check + gem-counter check on every discard (pass 32 had switched it off)
PURGE_MIN_POPUPS = 3            # popup closed this many times ...
PURGE_WINDOW_SEC = 1800         # ... within this many seconds (11/17 owner: 30 min)
PURGE_COOLDOWN_SEC = 2100       # a discarded order is blacked out for 30 min: never purge more often than this
PURGE_MAX_PER_RUN = 3
TRASH_DX = -165                 # trash button x = Complete button x + this (same y), measured on saved boards
DISCARD_YES_LOC = (968, 521)    # the green Yes of "Are you sure you want to discard this order?"
_last_purge = 0.0


def storage_full_recent(now=None):
    now = now or time.time()
    return sum(1 for t in fac.STORAGE_FULL_TIMES if now - t <= PURGE_WINDOW_SEC)


def trash_point(card):
    return (card["btn"][0] + TRASH_DX, card["btn"][1])


def trash_is_red(img, pt):
    """The trash button is a red square with a white bin: >= 8% of a 44x44 patch is strong red
    (measured 17-18% on the real buttons; the green Complete button and grey card read 0%)."""
    x, y = pt
    patch = img[max(0, y - 22):y + 22, max(0, x - 22):x + 22]
    if patch.size == 0:
        return False
    px = patch.reshape(-1, 3).astype(int)
    red = (px[:, 2] > 170) & (px[:, 1] < 100) & (px[:, 0] < 100)
    return float(red.mean()) >= 0.08


def discard_dialog_open(img):
    tpl = cv2.imread(fac.DISCARD_TEMPLATE_PATH)
    reg = img[300:620, 440:1160]
    if tpl is None or reg.shape[0] < tpl.shape[0] or reg.shape[1] < tpl.shape[1]:
        return False
    return float(cv2.matchTemplate(reg, tpl, cv2.TM_CCOEFF_NORMED).max()) >= 0.85


def purge_candidates(img, tried_x=()):
    """[(card, trash_point)] for cards that may be discarded: not the gold express card, not fully green
    (ready = complete it instead), trash button really there and red, not tried yet."""
    out = []
    for c in read_board(img):
        if is_express_card(img, c):
            continue
        if card_is_ready(c):
            continue
        pt = trash_point(c)
        if not trash_is_red(img, pt):
            continue
        if any(abs(pt[0] - x) < 30 for x in tried_x):
            continue
        out.append((c, pt))
    return out


def _gem_icon_near(img, loc, half_w=150, half_h=48):
    """True when gem-coloured (red/pink, saturated) pixels sit around loc -- every gem-costing button in the game shows a gem icon."""
    x, y = loc
    hsv = cv2.cvtColor(img[max(0, y - half_h):y + half_h, max(0, x - half_w):x + half_w], cv2.COLOR_BGR2HSV)
    red = ((hsv[:, :, 0] < 8) | (hsv[:, :, 0] > 165)) & (hsv[:, :, 1] > 120) & (hsv[:, :, 2] > 120)
    return float(red.mean()) > 0.012


def purge_board(stop_flag=None, max_n=None):
    """Discards up to max_n (default PURGE_MAX_PER_RUN) eligible event orders, the card with the most missing units
    first. Returns how many were discarded."""
    max_n = PURGE_MAX_PER_RUN if max_n is None else max_n
    if open_board(stop_flag) is None:                      # pass 31: open_board returns the screenshot (an array) or None
        log("STORAGE FULL purge: the event board did not open -- nothing discarded.")
        return 0
    done = 0
    tried = []
    for _ in range(max_n + 2):
        of.check_stop(stop_flag)
        if done >= max_n:
            break
        img = adb_helper.screenshot()
        if not board_is_open(img):
            break
        cands = purge_candidates(img, tried)
        if not cands:
            break
        cands.sort(key=lambda cp: -(_missing_units(img, cp[0]) or 0))     # 11/17: furthest from done first
        card, pt = cands[0]
        tried.append(pt[0])
        log(f"STORAGE FULL purge: discarding the order at x={card['cx']} (trash button at {pt}).")
        adb_helper.tap(*pt)
        of.interruptible_sleep(1.3, stop_flag)
        img2 = adb_helper.screenshot()
        if not discard_dialog_open(img2):
            log("STORAGE FULL purge: tapped trash but the discard question did not appear -- stopping.")
            break
        if _gem_icon_near(img2, DISCARD_YES_LOC):                  # pass 38: a price on the Yes button = never press it
            log("STORAGE FULL purge: the discard Yes button shows a gem icon -- answering No and stopping.")
            adb_helper.tap(*fac.DISCARD_NO_LOC)
            break
        g_before = read_gems(img2)
        adb_helper.tap(*DISCARD_YES_LOC)
        of.interruptible_sleep(2.0, stop_flag)
        img3 = adb_helper.screenshot()
        g_after = read_gems(img3)
        if g_before is not None and g_after is not None and g_after < g_before:
            _purge_blocked[0] = True
            log(f"GEM DROP during the storage purge: {g_before} -> {g_after} -- purge switched OFF, stopping.")
            break
        if discard_dialog_open(img3):
            log("STORAGE FULL purge: the discard question is still open after Yes -- answering No and stopping.")
            adb_helper.tap(*fac.DISCARD_NO_LOC)
            break
        no, nc = of.find_no_button(img3)
        if no is not None:
            log("STORAGE FULL purge: a gem-buy prompt appeared -- declining and stopping.")
            adb_helper.tap(*no)
            break
        done += 1
        log(f"STORAGE FULL purge: order discarded ({done} so far).")
    return done


# 11/17 (owner: "deleting orders if it keeps seeing that full message over and over ... one order after 3 times in
# 30 min and escalating more to delete more; the bot can still try the orders in the other slots"). Popups seconds
# apart count as ONE moment. Only moments after the last purge count; each purge within ESCALATE_SEC of the one before
# deletes one more order (max PURGE_STEP_MAX, so at least one card is always left to work). The card furthest from
# done goes first; never the gold express, never a ready card.
PURGE_MOMENT_GAP_SEC = 60
PURGE_ESCALATE_SEC = 2 * 3600
PURGE_STEP_MAX = 2
PURGE_GAP_SEC = 300             # never two purges closer than this
_purge_hist = []                # times of the purges (escalation)
_purge_blocked = [False]        # a gem drop during a discard switches purging off for the rest of the run


def storage_moments(times, since, now, window=None, gap=None):
    """Pure: popup times -> number of separate full moments after `since` in the last `window` seconds."""
    window = PURGE_WINDOW_SEC if window is None else window
    gap = PURGE_MOMENT_GAP_SEC if gap is None else gap
    n, last = 0, None
    for t in sorted(t for t in times if t > since and now - t <= window):
        if last is None or t - last >= gap:
            n += 1
        last = t
    return n


def purge_count(times, now, last_purge, purges):
    """Pure -> how many orders to delete now (0 = none). 3 moments since the last purge -> 1; again within
    PURGE_ESCALATE_SEC of the previous purge -> one more each time, up to PURGE_STEP_MAX."""
    if now - last_purge < PURGE_GAP_SEC:
        return 0
    if storage_moments(times, last_purge, now) < PURGE_MIN_POPUPS:
        return 0
    recent = [t for t in purges if now - t <= PURGE_ESCALATE_SEC]
    return min(PURGE_STEP_MAX, 1 + len(recent))


def maybe_purge_orders(stop_flag=None, now=None):
    """Called at the start of main(): delete orders when the storage-full popup keeps coming back."""
    global _last_purge
    if not STORAGE_FULL_PURGE or _purge_blocked[0] or express_active():
        return 0
    now = now or time.time()
    n = purge_count(fac.STORAGE_FULL_TIMES, now, _last_purge, _purge_hist)
    if not n:
        return 0
    _last_purge = now
    _purge_hist.append(now)
    m = storage_moments(fac.STORAGE_FULL_TIMES, 0, now)
    log(f"STORAGE FULL purge: storage full {m} times in the last {PURGE_WINDOW_SEC // 60} min and nothing freed it -- "
        f"deleting {n} order(s), the furthest from done first (express + ready cards kept; the others stay worked).")
    _stg["purges"] += 1
    _relief["t"] = 0.0
    log(f"[storage test] PURGE about to run -- last storage reading {_storage.get('last')}; stock last seen: "
        f"{_stock_summary()}.")
    done = purge_board(stop_flag, max_n=n)
    log(f"STORAGE FULL purge: finished, {done} order(s) discarded.")
    return done


_gem_last = None
_gem_next_check = 0.0


def read_gems(img=None):
    """The HUD gem counter (None when unreadable). Never taps.
    11/1: with FLASH on, the window copy (85% size, blown up) made Windows OCR miss the gems under the discard
    dialog -- every order dismissal said "cannot read the gem counter" (3/3 on 11/1 10:06, 0 before FLASH). Now the
    game's own digit shapes are tried first, and when the picture still can't be read and FLASH is on, ONE exact adb
    screenshot is read instead (the screen is the same: a dialog is waiting for an answer)."""
    v = _read_gems_once(img)
    if v is None:
        try:
            import flash
            if flash.ON:
                v = _read_gems_once(adb_helper.adb_screenshot())
        except Exception:                              # noqa: BLE001
            v = None
    return v


def _read_gems_once(img=None):
    try:
        if img is None:
            img = adb_helper.screenshot()
        try:
            import coin_digits
            g = (coin_digits.read_hud(img) or {}).get("gems")
            if g is not None:
                return g
        except Exception:                              # noqa: BLE001
            pass
        import collections
        import popup_ocr
        vals = []
        for region in ((1400, 5, 1520, 75), (1415, 10, 1510, 70), (1405, 8, 1515, 72)):     # pass 61: the first box alone reads "" on the live map
            txt = popup_ocr.read_text(img, region)
            digits = "".join(ch for ch in txt if ch.isdigit())
            if 1 <= len(digits) <= 4:
                vals.append(int(digits))
        if not vals:
            return None
        v, n = collections.Counter(vals).most_common(1)[0]
        return v if n >= 2 else vals[0]
    except Exception:                                  # noqa: BLE001
        return None


def gem_watch(tag="cycle", force=False, img=None):
    """Log the gem count (at most every 90 s) and shout when it DROPS. Observation only -- nothing in the bot should ever spend gems."""
    global _gem_last, _gem_next_check
    if not force and time.time() < _gem_next_check:
        return _gem_last
    _gem_next_check = time.time() + 90
    g = read_gems(img)
    if g is None:
        return _gem_last
    if _gem_last is not None and g < _gem_last:
        log(f"GEM DROP: {_gem_last} -> {g} ({tag}) -- nothing in the bot should spend gems; check the log lines just before this one.")
    elif g != _gem_last:
        log(f"GEMS: {g}")
    _gem_last = g
    return g


def read_storage_now(img):
    """11/15: read the Food Club storage banner on this picture right away (the observer reads it in the background,
    max every 20 s). Returns (used, cap) or None; a good reading updates _storage like the observer does."""
    if storage_banner_shown(img) != "Food Club Storage":
        return None
    import popup_ocr
    r = parse_storage(popup_ocr.read_text(_storage_prep(img)))
    if not r:
        return None
    _storage["last"], _storage["last_t"] = r, time.time()
    _storage["seen"]["Food Club Storage"] = r
    return r


STORAGE_CHECK_FRESH_SEC = 600
_storage_check = {"run": None}


def storage_check_due(run, done_run, last_t, now, express):
    """Pure (11/15, owner: "food club checks on the storage when it starts"): once per run, unless a reading is
    fresh (STORAGE_CHECK_FRESH_SEC) or an express is on."""
    return bool(run) and run != done_run and not express and now - (last_t or 0) > STORAGE_CHECK_FRESH_SEC


def storage_check_at_start(stop_flag=None):
    """Go to the event crop plots (their plant bar shows the "Food Club Storage N/30" banner), read it, close the
    bar. Never plants or harvests."""
    try:
        import orders_view
        run = orders_view._run.get("started")
    except Exception:                                  # noqa: BLE001
        run = None
    last_t = _storage.get("last_t", 0) if _storage.get("last") else 0
    if not storage_check_due(run, _storage_check["run"], last_t, time.time(), express_active()):
        return None
    _storage_check["run"] = run
    import tests_job
    import garden_check
    r = None
    try:
        if not tests_job._reach_event_plots(stop_flag):
            log("[storage] start check: no board item led to the event crop plots -- skipped this run.")
            return None
        for _ in range(4):
            of.interruptible_sleep(0.6, stop_flag)
            img = adb_helper.screenshot()
            r = read_storage_now(img) if img is not None else None
            if r:
                break
        if r:
            log(f"[storage] start check: Food Club Storage {r[0]}/{r[1]}" +
                (" -- NEARLY FULL" if r[0] >= r[1] - 3 else ""))
        else:
            pic = "none"
            if img is not None:
                d = os.path.join(BASE_DIR, "templates", "tests")
                os.makedirs(d, exist_ok=True)
                pic = os.path.join(d, f"{time.strftime('%Y%m%d_%H%M%S')}_storage_check.jpg")
                cv2.imwrite(pic, img)
            log(f"[storage] start check: no storage banner at the plots (no plant bar open?) -- picture {pic}")
    finally:
        try:
            img = adb_helper.screenshot()
            if img is not None and bar_is_open(img):
                garden_check.close_plant_bar(stop_flag)
            of.close_any_open_panel(quiet=True)
        except StopRequested:
            raise
        except Exception:                              # noqa: BLE001
            pass
    return r


def main(stop_flag=None):
    log("=== event orders run start ===")
    try:                                          # 11/15 (owner): check the storage number at the start of a run
        storage_check_at_start(stop_flag)
    except StopRequested:
        raise
    except Exception as e:                        # noqa: BLE001
        log(f"[storage] start check failed (ignored): {e!r}")
    try:
        gem_watch("start of run")
    except StopRequested:
        raise
    except Exception:                             # noqa: BLE001
        pass
    try:                                          # pass 8: storage full -> discard the orders
        maybe_purge_orders(stop_flag)
    except StopRequested:
        raise
    except Exception as e:                        # noqa: BLE001
        log(f"STORAGE FULL purge failed (ignored): {e}")
    served, results = run_once(stop_flag)
    if MERCHANT_STOCKING and not express_active():
        results.append(stock_merchant(stop_flag))
    log(format_report(served, results).replace("\n", " | "))
    log("=== event orders run end ===")
    return served, results


if __name__ == "__main__":
    # Offline self-test: python event_orders.py <screenshot.png>
    path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        BASE_DIR, "event_pdf_extract", "storybook", "live_1_after_shoes.png")
    im = cv2.imread(path)
    print("buttons:", find_green_buttons(im, 780, 890))
    for c in read_board(im):
        print(c["cx"], c["btn"], [(s["row"], s["col"], s["color"]) for s in c["slots"]],
              "READY" if card_is_ready(c) else "")



def banner_text(now=None):
    """11/2 (owner: express banner): one line for the window while an express is on the board, else ''.
    'EXPRESS on the board  ·  Halloween Cupcakes x2, Ghostly Essence x2  ·  about 12 min left  ·  136 pts'"""
    import json
    now = now or time.time()
    if not express_active():
        return ""
    try:
        with open(EXPRESS_STATE) as f:
            st = json.load(f)
    except (OSError, ValueError):
        st = {}
    parts = ["\u2605 EXPRESS on the board"]
    items = [f"{d.get('name') or 'item'} x{d.get('need') or 1}" for d in (st.get("items") or [])]
    if items:
        parts.append(", ".join(items))
    if _express_clock.get("t") and _express_clock.get("left") is not None:
        left = int(_express_clock["left"] - (now - _express_clock["t"]))
        if left > 0:
            parts.append(f"about {left // 60} min left")
    if st.get("points"):
        parts.append(f"{st['points']} pts")
    v = _express_clock.get("verdict")
    if v:
        parts.append(v)
    return "  \u00b7  ".join(parts)
