"""11/28 (owner): SETUP WIZARD -- shown the first time AFSD opens (and from Settings > LDPlayer > Setup wizard).
One step at a time, each with a check: LDPlayer installed -> LDPlayer running -> ADB connection on -> screen size
-> Food Street installed. The checks are plain functions (tests/test_setup_wizard.py); the window only shows them.
Nothing here taps the game."""
import os
import re
import subprocess
import threading
import webbrowser

LDPLAYER_URL = "https://www.ldplayer.net/"
GAME_PACKAGE = "com.supersolid.honestfood"
GAME_URL = "https://play.google.com/store/apps/details?id=" + GAME_PACKAGE
LD_PROC_RE = re.compile(r"^(dnplayer|Ld\d*BoxHeadless|LdVBoxHeadless)\.exe", re.I | re.M)


def _run(cmd, timeout=15):
    """Output text of a command, '' when it cannot run. Never raises."""
    try:
        import adb_resilience
        return adb_resilience.safe_run(cmd, timeout, text=True).stdout or ""
    except Exception:                                      # noqa: BLE001
        return ""


def refresh_ldplayer_path():
    """LDPlayer may be installed while AFSD is open: look again and point every module at the new folder."""
    import adb_helper
    d = adb_helper.find_ldplayer()
    adb_helper.LDPLAYER_DIR = d
    adb_helper.ADB = os.path.join(d, "adb.exe")
    try:
        import adb_resilience
        adb_resilience.ADB = adb_helper.ADB
        adb_resilience.LDCONSOLE = os.path.join(d, "ldconsole.exe")
    except Exception:                                      # noqa: BLE001
        pass
    try:
        import afsd_core
        afsd_core.DNCONSOLE = os.path.join(d, "dnconsole.exe")
    except Exception:                                      # noqa: BLE001
        pass
    return d


# ---------- pure parts (tested) ----------
def running_from_tasklist(text):
    return bool(LD_PROC_RE.search(text or ""))


def devices_from(text):
    """'adb devices' output -> (ready devices, other lines such as unauthorized / offline)."""
    ready, other = [], []
    for line in (text or "").splitlines()[1:]:
        line = line.strip()
        if not line:
            continue
        if line.endswith("\tdevice"):
            ready.append(line.split("\t")[0])
        else:
            other.append(line.replace("\t", " "))
    return ready, other


def size_from(text):
    """'wm size' output -> (w, h) in use (Override wins over Physical), or None."""
    found = {}
    for kind, w, h in re.findall(r"(Physical|Override) size:\s*(\d+)x(\d+)", text or ""):
        found[kind] = (int(w), int(h))
    return found.get("Override") or found.get("Physical")


def size_ok(wh):
    if not wh:
        return False
    w, h = max(wh), min(wh)
    return abs(w / h - 16 / 9) < 0.02


# ---------- checks: each returns (ok, message) ----------
def check_installed():
    d = refresh_ldplayer_path()
    if os.path.exists(os.path.join(d, "adb.exe")):
        return True, f"Found LDPlayer in {d}."
    return False, "LDPlayer is not installed yet (no adb.exe in its usual folders)."


def check_running():
    if running_from_tasklist(_run(["tasklist"], 20)):
        return True, "LDPlayer is running."
    return False, "LDPlayer is not running. Press Start LDPlayer, or open it from its desktop icon."


def start_ldplayer():
    import adb_helper
    dn = os.path.join(adb_helper.LDPLAYER_DIR, "dnconsole.exe")
    if not os.path.exists(dn):
        dn = os.path.join(adb_helper.LDPLAYER_DIR, "ldconsole.exe")
    try:
        subprocess.Popen([dn, "launch", "--index", "0"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:                                      # noqa: BLE001
        return False


def check_adb():
    import adb_helper
    for addr in ("127.0.0.1:5555", "127.0.0.1:5554", "127.0.0.1:5557"):
        _run([adb_helper.ADB, "connect", addr], 8)
    ready, other = devices_from(_run([adb_helper.ADB, "devices"], 10))
    if ready:
        adb_helper.DEVICE = None
        return True, f"The bot can see LDPlayer ({ready[0]})."
    if any("unauthorized" in o for o in other):
        return False, "LDPlayer is asking to allow the connection -- look in LDPlayer for an 'Allow' box and press it."
    return False, "The bot cannot see LDPlayer yet. Turn on its ADB connection (steps above), restart LDPlayer, then Check again."


def _device():
    import adb_helper
    ready, _ = devices_from(_run([adb_helper.ADB, "devices"], 10))
    return ready[0] if ready else None


def check_size():
    import adb_helper
    dev = _device()
    if not dev:
        return False, "LDPlayer is not connected -- go back one step."
    wh = size_from(_run([adb_helper.ADB, "-s", dev, "shell", "wm", "size"], 10))
    if size_ok(wh):
        return True, f"Screen is {max(wh)}x{min(wh)} -- good" + (" (1600x900 is best)." if max(wh) != 1600 else ".")
    return False, (f"Screen is {wh[0]}x{wh[1]}. " if wh else "Could not read the screen size. ") + \
        "Set it to 1600x900 in LDPlayer (steps above), then Check again."


def check_game():
    import adb_helper
    dev = _device()
    if not dev:
        return False, "LDPlayer is not connected -- go back to the ADB step."
    if GAME_PACKAGE in _run([adb_helper.ADB, "-s", dev, "shell", "pm", "list", "packages", GAME_PACKAGE], 15):
        return True, "Food Street is installed. Open it once and sign in, then you are ready."
    return False, "Food Street is not installed in LDPlayer yet. Install it from the Play Store inside LDPlayer."


STEPS = [
    ("Install LDPlayer",
     "AFSD plays the game inside LDPlayer, a free Android emulator.\n\n"
     "1. Press Download LDPlayer and install it in its usual folder.\n2. Then press Check.",
     [("Download LDPlayer", lambda: webbrowser.open(LDPLAYER_URL))], check_installed),
    ("Start LDPlayer",
     "Open LDPlayer and wait until you see the Android home screen.",
     [("Start LDPlayer", start_ldplayer)], check_running),
    ("Turn on ADB",
     "AFSD talks to LDPlayer through ADB. A fresh LDPlayer often has it switched off.\n\n"
     "1. In LDPlayer press the gear (Settings).\n2. Other settings > ADB debugging > Open local connection.\n"
     "3. Save, close LDPlayer, open it again.\n4. Press Check.", [], check_adb),
    ("Screen size",
     "The bot is made for a 1600 x 900 screen.\n\n"
     "In LDPlayer: Settings > Advanced > Resolution > Tablet 1600 x 900, Save, restart LDPlayer, press Check.",
     [], check_size),
    ("Install Food Street",
     "Install Food Street from the Play Store inside LDPlayer, open it once and sign in.",
     [("Open Play Store page", lambda: webbrowser.open(GAME_URL))], check_game),
]


def open_wizard(root, on_done=None, colors=None):
    """The wizard window. on_done(finished: bool) runs when it closes."""
    import tkinter as tk
    c = {"bg": "#1b1f2a", "fg": "#e8e8e8", "dim": "#9aa3b2", "gold": "#c9a84c", "ok": "#5cc07a", "bad": "#f0c040",
         "btn": "#2a3142"}
    c.update(colors or {})
    win = tk.Toplevel(root)
    win.title("AFSD setup")
    win.configure(bg=c["bg"])
    win.geometry("560x420")
    win.transient(root)
    state = {"i": 0, "ok": [False] * len(STEPS)}
    head = tk.Label(win, font=("Segoe UI", 15, "bold"), bg=c["bg"], fg=c["gold"], anchor="w")
    head.pack(fill="x", padx=20, pady=(18, 4))
    step_lbl = tk.Label(win, font=("Segoe UI", 9), bg=c["bg"], fg=c["dim"], anchor="w")
    step_lbl.pack(fill="x", padx=20)
    body = tk.Label(win, font=("Segoe UI", 11), bg=c["bg"], fg=c["fg"], justify="left", anchor="nw",
                    wraplength=510)
    body.pack(fill="both", expand=True, padx=20, pady=10)
    actions = tk.Frame(win, bg=c["bg"])
    actions.pack(fill="x", padx=20)
    result = tk.Label(win, font=("Segoe UI", 10, "bold"), bg=c["bg"], fg=c["dim"], justify="left", anchor="w",
                      wraplength=510)
    result.pack(fill="x", padx=20, pady=8)
    nav = tk.Frame(win, bg=c["bg"])
    nav.pack(fill="x", padx=20, pady=(0, 16))

    def mk(parent, text, cmd, side="left"):
        b = tk.Button(parent, text=text, command=cmd, bg=c["btn"], fg=c["fg"], activebackground=c["gold"],
                      relief="flat", padx=12, pady=5, font=("Segoe UI", 10))
        b.pack(side=side, padx=(0, 8))
        return b

    def close(finished):
        try:
            win.destroy()
        finally:
            if on_done:
                on_done(finished)

    def run_check():
        i = state["i"]
        result.config(text="Checking...", fg=c["dim"])
        check_b.config(state="disabled")

        def work():
            try:
                ok, msg = STEPS[i][3]()
            except Exception as e:                         # noqa: BLE001
                ok, msg = False, f"The check failed: {e!r}"

            def show():
                if state["i"] != i or not win.winfo_exists():
                    return
                state["ok"][i] = ok
                result.config(text=("✓ " if ok else "✗ ") + msg, fg=c["ok"] if ok else c["bad"])
                check_b.config(state="normal")
                next_b.config(text="Finish" if i == len(STEPS) - 1 else "Next →")
            try:
                win.after(0, show)
            except Exception:                              # noqa: BLE001
                pass
        threading.Thread(target=work, daemon=True).start()

    def show_step():
        i = state["i"]
        title, text, acts, _ = STEPS[i]
        head.config(text=title)
        step_lbl.config(text=f"Step {i + 1} of {len(STEPS)}")
        body.config(text=text)
        for w in actions.winfo_children():
            w.destroy()
        for label, fn in acts:
            mk(actions, label, fn)
        result.config(text="")
        back_b.config(state="normal" if i else "disabled")
        next_b.config(text="Finish" if i == len(STEPS) - 1 else "Next →")
        run_check()

    def go(delta):
        i = state["i"] + delta
        if i >= len(STEPS):
            close(True)
            return
        state["i"] = max(0, i)
        show_step()

    back_b = mk(nav, "← Back", lambda: go(-1))
    check_b = mk(nav, "Check again", run_check)
    mk(nav, "Close", lambda: close(False), side="right")
    next_b = mk(nav, "Next →", lambda: go(1), side="right")
    win.protocol("WM_DELETE_WINDOW", lambda: close(False))
    show_step()
    return win
