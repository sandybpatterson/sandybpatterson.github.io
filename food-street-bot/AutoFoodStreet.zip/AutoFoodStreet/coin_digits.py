"""Reads the reward numbers on a clipboard order card (10/23, owner: "build the coin reader").

Each card's header (order_fulfill.REWARD_REGION, a 280x65 crop) shows a coin stack + number and a green star + number
as white digits with a dark outline. Windows OCR read them as '' or "94 64", so the digits are matched against shapes
cut from 282 saved headers (templates/coin_digits/<digit>_<k>.png, 18x24 masks, labelled by clustering; 100% on
held-out glyphs). Read-only, never taps.
"""
import glob
import os

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
H, W = 24, 18
COINS_X = (40, 150)                                     # x band of the coin number inside the header crop
STARS_X = (175, 270)                                    # x band of the star (XP) number
MATCH_MIN = 0.75
_TEMPLATES = []
for _p in sorted(glob.glob(os.path.join(BASE_DIR, "templates", "coin_digits", "*.png"))):
    _t = cv2.imread(_p, cv2.IMREAD_GRAYSCALE)
    if _t is not None:
        _v = _t.astype(np.float32).ravel()
        _v = (_v - _v.mean()) / (_v.std() + 1e-6)
        _TEMPLATES.append((int(os.path.basename(_p)[0]), _v / np.linalg.norm(_v)))


def _glyphs(crop, x1, x2):
    band = crop[:, x1:x2].astype(np.int16)
    white = (band.min(axis=2) > 200) & ((band.max(axis=2) - band.min(axis=2)) < 30)
    n, lab, st, _c = cv2.connectedComponentsWithStats(white.astype(np.uint8))
    out = []
    for i, (x, y, w, h, a) in enumerate(st[1:], 1):
        if 14 <= h <= 40 and a >= 20 and w <= 30:
            out.append((x, lab[y:y + h, x:x + w] == i))
    return [m for _x, m in sorted(out, key=lambda t: t[0])]


def _feat(m):
    h, w = m.shape
    nw = max(1, min(W, int(round(w * H / h))))
    g = cv2.resize(m.astype(np.uint8) * 255, (nw, H), interpolation=cv2.INTER_AREA)
    c = np.zeros((H, W), np.uint8)
    c[:, :nw] = g
    v = c.astype(np.float32).ravel()
    v = (v - v.mean()) / (v.std() + 1e-6)
    return v / (np.linalg.norm(v) + 1e-6)


def _number(crop, x1, x2):
    gl = _glyphs(crop, x1, x2)
    if not gl or len(gl) > 5 or not _TEMPLATES:
        return None
    digits = []
    for m in gl:
        f = _feat(m)
        d, s = max(((d, float(f @ t)) for d, t in _TEMPLATES), key=lambda ds: ds[1])
        if s < MATCH_MIN:
            return None
        digits.append(str(d))
    return int("".join(digits))


def read_reward(crop):
    """{"coins": int|None, "stars": int|None} from a card's reward-header crop."""
    if crop is None or crop.size == 0 or crop.shape[1] < STARS_X[1]:
        return {"coins": None, "stars": None}
    return {"coins": _number(crop, *COINS_X), "stars": _number(crop, *STARS_X)}


# 10/24 (owner: "work on the coin reader"): the TOP BAR coins/gems are the same white digits in a slightly different
# font (a '9' scored 0.75 against the reward shapes). Shapes cut from the bar itself (templates/hud_digits/<d>_<k>.png,
# raw masks from 4 screenshots: 3940, 6318, 7023, 6564 + gems 76-78) are tried together with the reward shapes.
# Windows OCR on the bar dropped digits overnight (8464 -> 464, 8538 -> 858); the shape reader counts every digit.
HUD_COINS_X = (1095, 1225)
HUD_GEMS_X = (1410, 1520)
HUD_Y = (10, 70)
HUD_MIN = 0.8
_HUD_T = []
for _p in sorted(glob.glob(os.path.join(BASE_DIR, "templates", "hud_digits", "*.png"))):
    _m = cv2.imread(_p, cv2.IMREAD_GRAYSCALE)
    if _m is not None:
        _HUD_T.append((int(os.path.basename(_p)[0]), _feat(_m > 127)))


def read_hud(img):
    """{"coins": int|None, "gems": int|None} from a full screenshot's top bar (shape match, no OCR)."""
    out = {"coins": None, "gems": None}
    if img is None or img.shape[0] < HUD_Y[1] or img.shape[1] < HUD_GEMS_X[1]:
        return out
    band = img[HUD_Y[0]:HUD_Y[1]]
    shapes = _HUD_T + _TEMPLATES
    for key, (x1, x2) in (("coins", HUD_COINS_X), ("gems", HUD_GEMS_X)):
        gl = _glyphs(band, x1, x2)
        if not gl or len(gl) > 7 or not shapes:
            continue
        ds = []
        for m in gl:
            f = _feat(m)
            d, s = max(((d, float(f @ t)) for d, t in shapes), key=lambda z: z[1])
            if s < HUD_MIN:
                ds = None
                break
            ds.append(str(d))
        if ds:
            out[key] = int("".join(ds))
    return out
