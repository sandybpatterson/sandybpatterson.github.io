"""Reads the "have/need" count under an event-board item ("1/3", "0/2", "12/12").

The game draws these in a red or green outlined font; the FILL is a clean saturated
colour, so a colour mask gives crisp glyph shapes. Glyphs are cut with connected
components, resized and matched against templates in templates/event_digits/
(0-9 and "slash"). Anything that does not match well returns None (never a guess) and the
unmatched glyph is saved to templates/event_digits_pending/ so it can be labelled later.
Built 10/3 for the express-order "state of emergency" (counting what is still missing).
"""
import os
import time
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TPL_DIR = os.path.join(BASE_DIR, "templates", "event_digits")
PENDING_DIR = os.path.join(BASE_DIR, "templates", "event_digits_pending")
GLYPH_SIZE = (20, 28)          # w, h every glyph is normalised to
MATCH_MIN = 0.75
_cache = {}


def _mask(box):
    c = box.astype(int)
    b, g, r = c[:, :, 0], c[:, :, 1], c[:, :, 2]
    red = (r > 200) & (g < 90) & (b < 90)
    grn = (g > 200) & (r < 110) & (b < 110)
    return red, grn


def glyphs(img, tx, text_y, half_w=34, half_h=22):
    """Returns (color, [glyph images]) left-to-right for the count text centred at
    (tx, text_y); color is 'red'/'green'/None."""
    x1, y1 = max(0, tx - half_w), max(0, text_y - half_h)
    box = img[y1:text_y + half_h, x1:tx + half_w]
    if box.size == 0:
        return None, []
    red, grn = _mask(box)
    color = "red" if red.sum() > grn.sum() else "green"
    m = (red if color == "red" else grn).astype(np.uint8) * 255
    if int((m > 0).sum()) < 40:
        return None, []
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    parts = [i for i in range(1, n) if st[i][4] >= 12 and st[i][3] >= 10]
    # 10/19: on a RED picture (Assorted Meats, Cola) bits of the picture pass the red mask too and the read
    # failed ("6/7" -> None, so the bot assumed 1). Digits and the slash are the tallest parts and never touch
    # the box's sides: keep only those. Offline: 79 reads unchanged, 12 more read, 0 lost.
    if len(parts) > 3:                      # 10/28: a red tomato above "0/2" leaks in as a wide blob touching the TOP
        top = [i for i in parts if st[i][1] > 0]                    # edge (Hot Dog, Grilled Fish); digits never do
        parts = top if len(top) >= 3 else parts
    if parts:
        tall = max(st[i][3] for i in parts)
        keep = [i for i in parts if st[i][3] >= 0.6 * tall and st[i][0] > 0 and st[i][0] + st[i][2] < m.shape[1]]
        parts = keep or parts
    out = []
    for i in sorted(parts, key=lambda i: st[i][0]):
        x, y, w, h, _a = st[i]
        g = (lab[y:y + h, x:x + w] == i).astype(np.uint8) * 255
        out.append(cv2.resize(g, GLYPH_SIZE, interpolation=cv2.INTER_AREA))
    return color, out


def _templates():
    if _cache.get("t") is None:
        t = {}
        if os.path.isdir(TPL_DIR):
            for f in os.listdir(TPL_DIR):
                if f.endswith(".png"):
                    name = f.split("__")[0].replace(".png", "")
                    t.setdefault(name, []).append(
                        cv2.imread(os.path.join(TPL_DIR, f), 0).astype(np.float32))
        _cache["t"] = t
    return _cache["t"]


def reload_templates():
    _cache.clear()


def classify(glyph):
    """(label, score) of the best template match, label None when below MATCH_MIN."""
    g = glyph.astype(np.float32)
    best, name = -1.0, None
    for label, tl in _templates().items():
        for t in tl:
            r = cv2.matchTemplate(g, t, cv2.TM_CCOEFF_NORMED)[0][0]
            if r > best:
                best, name = float(r), label
    return (name if best >= MATCH_MIN else None), best


def read_count(img, tx, text_y, save_unknown=True, half_w=34, half_h=22):
    """-> {'color','have','need'} or None. Sanity-checked against the colour: red means
    have < need, green means have >= need; a contradiction (a misread) returns None."""
    color, gl = glyphs(img, tx, text_y, half_w=half_w, half_h=half_h)
    if not gl:
        return None
    labels = []
    for g in gl:
        lab, sc = classify(g)
        if lab is None:
            if save_unknown:
                _save_pending(g)
            return None
        labels.append(lab)
    if "slash" not in labels or labels.count("slash") != 1:
        return None
    k = labels.index("slash")
    a, b = labels[:k], labels[k + 1:]
    if not a or not b or any(not s.isdigit() for s in a + b):
        return None
    have, need = int("".join(a)), int("".join(b))
    if (color == "red") != (have < need):
        return None          # colour says otherwise -- distrust this read
    return {"color": color, "have": have, "need": need}


def _save_pending(g):
    try:
        os.makedirs(PENDING_DIR, exist_ok=True)
        if len(os.listdir(PENDING_DIR)) < 60:
            cv2.imwrite(os.path.join(PENDING_DIR, f"{int(time.time()*1000)}.png"), g)
    except Exception:
        pass


def train(img, tx, text_y, text):
    """Learn glyph templates from a slot whose true text is known, e.g. text='1/3'."""
    color, gl = glyphs(img, tx, text_y)
    chars = ["slash" if ch == "/" else ch for ch in text]
    if len(gl) != len(chars):
        return False
    os.makedirs(TPL_DIR, exist_ok=True)
    for g, ch in zip(gl, chars):
        n = len([f for f in os.listdir(TPL_DIR) if f.startswith(ch + "__")])
        cv2.imwrite(os.path.join(TPL_DIR, f"{ch}__{n}.png"), g)
    reload_templates()
    return True
