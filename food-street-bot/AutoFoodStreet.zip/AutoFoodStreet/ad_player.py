"""11/1 ADS (owner: "build a working setting to play and skip ads"): watch the game's free video ad on a timer card to
finish the item now. Learned from 5 Record-ad sessions (CLAUDE.md 11/1):

  * A growing plot / cooking slot opens a card: item name, time left, a green "Skip [gem] 1" (COSTS A GEM -- never)
    and a separate square VIDEO button (templates/skip_ad_icon.png) -> tap only that.
  * The ad is its own Android activity: AppLovin (com.applovin...) or Facebook (com.facebook.ads...). The game is
    com.unity3d.player.UnityPlayerActivity. When the game is in front again, the ad is over (the reward is "finish
    now"; the card's timer only updates once it is closed).
  * AppLovin: after the video, a tap bottom-left (36,851) shows its buttons; the only way on is "Google Play >"
    (39,816) -> the Play Store opens -> Android Back returns to the ad -> its X top-left (40,44) closes it.
  * Facebook: "Reward in N s" countdown, then the top-right button says "Skip" (~1560,92; before that it says "Open
    Website" -- never tap that) -> end card -> Back / X.
  * Owner: an ad takes 30-45 s to get through -- not worth it for less than MIN_LEFT_SEC (60 s) left.

Safety: ad-screen spots are tapped ONLY while an ad activity is in front (never inside the game, where a gem button
could sit there); inside the Play Store only the Back key is used. Settings > Ads "Watch ads for free rewards"
(`watch_ads`, default OFF) sets ON."""
import os
import time

import cv2

ON = False
MIN_LEFT_SEC = 180           # 11/2: live ads took 80-180 s for the bot (owner 30-45 s by hand) -- worth it only above 3 min
MAX_PER_HOUR = 12
# 11/6 (owner: "add a save for event dishes switch"): Settings > Ads "Save ads for event dishes" (default on) -> no ads
# on crop plots, ads only on event-dish station slots. Logs 11/4 + 11/5: exactly 10 ads a day, then only "no video
# button" -- probably a daily limit (owner did not know). EVENT_ONLY set by afsd_core._apply_settings.
EVENT_ONLY = True
SLOT_MAX_LEFT_SEC = 330      # the game offers the video only in a timer's last ~5 min (73 tries above it: 0 buttons)
USED_UP_AFTER = 4            # this many "no video button" in a row on short timers after a watch = today's ads are gone
_today = {"date": None, "watched": 0, "no_button": 0, "streak": 0, "used_up": False}
AD_START_SEC = 15            # the ad must take over within this long after the video tap
NO_EXIT_GIVEUP_SEC = 100    # 11/4: no exit control ever seen by then (playable ad) -> Back keys + unstuck ladder
SPOT_TRIES = 3              # 11/4: a top-left button tapped this often without leaving the ad is not tapped again
AD_MAX_SEC = 240             # give up (Back key) after this long in an ad (11/2: the emulator lags inside ads)
APPLOVIN_EXIT_AFTER_SEC = 40 # owner's ads ran ~40 s before Google Play / X were needed
BOTTOM_TAP = (36, 851)       # AppLovin: shows the hidden buttons
GOOGLE_PLAY = (39, 816)      # AppLovin: "Google Play >"
TOP_LEFT_X = (40, 44)        # AppLovin: X once back from the store
TOP_RIGHT_X = (1560, 44)     # some ads put their X top-right
# 11/2 owner recording rec_20261101_222202: AppLovin ads play PORTRAIT (900x1600). `input tap` uses the screen as it is
# turned, so the spots differ: "Google Play >" pill top-left, the X top-right (after the store visit).
P_GOOGLE_PLAY = (86, 34)
P_X = (854, 40)


def portrait(img):
    """Pure: is this picture taller than wide (a portrait ad)?"""
    return img is not None and img.shape[0] > img.shape[1]


def top_left_button(img):
    """11/2: centre (full-size portrait px) of the bright button in the top-left corner of a portrait ad -- the
    "Google Play >" pill or the small "skip to end" icon (live 11/2 at (118,40)); None when nothing is there."""
    if img is None or not portrait(img):
        return None
    import cv2
    import numpy as np
    sx = img.shape[1] / 900.0
    hit = _skip_icon(img, sx)          # 11/2: the round "skip" icon also sits on BRIGHT ad pictures (blob rule misses)
    if hit is not None:
        return hit
    hit = google_play_pill(img)        # 11/4 (Muse photos): the "Google Play" pill, matched by its picture
    if hit is not None:
        return hit
    box = img[0:int(110 * sx), 0:int(330 * sx)]
    g = cv2.cvtColor(box, cv2.COLOR_BGR2GRAY) if box.ndim == 3 else box
    if float(np.median(g)) > 90:                  # a bright picture there, not a button on black
        return None
    n, lab, st, cen = cv2.connectedComponentsWithStats((g > 120).astype(np.uint8))
    best = None
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] >= 6 * sx * sx and (best is None or st[i, cv2.CC_STAT_AREA] > st[best, cv2.CC_STAT_AREA]):
            best = i
    if best is None:
        return None
    x0, y0, w, h = st[best, 0], st[best, 1], st[best, 2], st[best, 3]
    return (int((x0 + w / 2) / sx), int((y0 + h / 2) / sx))


SKIP_ICON_MIN = 0.7
_icons = []
PILL_MIN = 0.66              # 11/4: real pills 0.68-1.00 on every saved ad; the playable's coin counter 0.58
_pill = []


def google_play_pill(img):
    """11/4: centre (full-size portrait px) of the "Google Play" pill top-left, by picture (templates/ad_pill, cut at
    half size from live_20261104_102556); None when it is not there (e.g. a playable's coin counter in that corner)."""
    if img is None or not portrait(img):
        return None
    if not _pill:
        t = cv2.imread(os.path.join(BASE, "templates", "ad_pill", "gp_pill_half.png"), cv2.IMREAD_GRAYSCALE)
        if t is None:
            return None
        _pill.append(t)
    t = _pill[0]
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    h = cv2.resize(g, (450, 800), interpolation=cv2.INTER_AREA)[0:60, 0:170]
    r = cv2.matchTemplate(h, t, cv2.TM_CCOEFF_NORMED)
    _, v, _, loc = cv2.minMaxLoc(r)
    if v < PILL_MIN:
        return None
    k = img.shape[1] / 450.0 / (img.shape[1] / 900.0)     # half-size px -> 900-wide portrait px
    return (int((loc[0] + t.shape[1] / 2) * k), int((loc[1] + t.shape[0] / 2) * k))


def _skip_icon(img, sx):
    """Template match of the round "skip to end" icon (templates/ad_icons, cut 11/2 from a dark and a bright ad)."""
    import cv2
    if not _icons:
        d = os.path.join(BASE, "templates", "ad_icons")
        for f in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            t = cv2.imread(os.path.join(d, f), cv2.IMREAD_GRAYSCALE)
            if t is not None:
                _icons.append(t)
    if not _icons:
        return None
    full = cv2.resize(img, (900, 1600)) if abs(sx - 1.0) > 0.01 else img
    g = cv2.cvtColor(full[0:110, 0:330], cv2.COLOR_BGR2GRAY) if full.ndim == 3 else full[0:110, 0:330]
    best, at, size = 0.0, None, None
    for t in _icons:
        r = cv2.matchTemplate(g, t, cv2.TM_CCOEFF_NORMED)
        _, v, _, loc = cv2.minMaxLoc(r)
        if v > best:
            best, at, size = v, loc, t.shape
    if best < SKIP_ICON_MIN:
        return None
    return (at[0] + size[1] // 2, at[1] + size[0] // 2)


def top_right_box(img):
    """Pure: OCR box for a top-right Skip/X in either orientation."""
    h, w = img.shape[:2]
    return (w - 220, 20, w, 140)
FB_SKIP = (1560, 92)         # Facebook: "Skip" after the reward countdown
FB_SKIP_BOX = (1380, 50, 1600, 140)
GP_BOX = (0, 760, 520, 895)
BASE = os.path.dirname(os.path.abspath(__file__))
_hist = []                   # times of watched ads
ACTIVE = 0.0                # 11/2: time an ad started while one is being sat out (auto restart waits)
LAST = None                  # 11/2: (time, what, result) of the last ad, for the Orders tab line
LOG = None


GAME_PACKAGE = "com.supersolid.honestfood"   # 11/12: closed when an ad cannot be left any other way


def _log(msg):
    try:
        if LOG:
            LOG(f"[ads] {msg}")
    except Exception:                                   # noqa: BLE001
        pass


_shot_dir = None
SHOT_EVERY_SEC = 5          # 11/4 (owner: "take and upload more screenshots ... Muse will go through the image logs")
SHOT_MAX = 60               # pictures per ad


def _shot(tag):
    """Half-size JPEG of the screen into templates/ad_training/live_<time>/ (Send logs carries the newest 2 ads)."""
    try:
        import adb_helper
        img = adb_helper.adb_screenshot()               # exact: FLASH squeezes a portrait ad into 1600x900
        if img is None or _shot_dir is None:
            return img
        os.makedirs(_shot_dir, exist_ok=True)
        n = len(os.listdir(_shot_dir))
        if n < SHOT_MAX:
            cv2.imwrite(os.path.join(_shot_dir, f"{n:02d}_{tag}.jpg"),
                        cv2.resize(img, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA),
                        [cv2.IMWRITE_JPEG_QUALITY, 60])
        return img
    except Exception:                                   # noqa: BLE001
        return None


def classify_focus(focus):
    """Pure: what is in front -- 'game', 'applovin', 'facebook', 'store', 'other' or 'unknown'."""
    f = str(focus or "")
    if not f or f.startswith("?") or "null" in f:
        return "unknown"
    if "UnityPlayerActivity" in f:
        return "game"
    if "applovin" in f.lower():
        return "applovin"
    if "facebook.ads" in f.lower():
        return "facebook"
    if "com.android.vending" in f:
        return "store"
    return "other"


def _today_reset():
    d = time.strftime("%Y-%m-%d")
    if _today["date"] != d:
        _today.update(date=d, watched=0, no_button=0, streak=0, used_up=False)


def note_day(res, secs_left=None):
    """11/6: count today's ads; after USED_UP_AFTER "no video button" in a row on timers short enough to offer one,
    assume today's ads are used up (no more tries until the date changes). -> today's line for the log."""
    _today_reset()
    if res == "watched":
        _today["watched"] += 1
        _today["streak"] = 0
    elif res == "no_button" and secs_left is not None and secs_left <= SLOT_MAX_LEFT_SEC:
        _today["no_button"] += 1
        _today["streak"] += 1
        if _today["streak"] >= USED_UP_AFTER and not _today["used_up"]:
            _today["used_up"] = True
            _log(f"[ads] {USED_UP_AFTER} short timers in a row had no video button after {_today['watched']} ad(s) "
                 "today -- looks like today's ads are used up; not trying again until tomorrow.")
    return (f"[ads] today: {_today['watched']} watched, {_today['no_button']} timers without a video button"
            + (" (used up)" if _today["used_up"] else ""))


def used_up():
    _today_reset()
    return _today["used_up"]


def worth_it(secs_left, now=None, hist=None, min_left=None):
    """Pure: watch an ad for this timer? (> MIN_LEFT_SEC left, under MAX_PER_HOUR in the last hour)."""
    now = now or time.time()
    hist = _hist if hist is None else hist
    if secs_left is None or secs_left < (MIN_LEFT_SEC if min_left is None else min_left) or used_up():
        return False
    return sum(1 for t in hist if now - t < 3600) < MAX_PER_HOUR


def find_video_button(img):
    """(x, y) of the square video button on a timer card (>= 0.8), else None. Never the wide 'Skip [gem]' one."""
    tpl = cv2.imread(os.path.join(BASE, "templates", "skip_ad_icon.png"))
    if img is None or tpl is None:
        return None
    best, loc = 0.0, None
    for s in (0.7, 0.8, 0.9, 1.0, 1.1, 1.25):
        t = cv2.resize(tpl, None, fx=s, fy=s)
        if t.shape[0] >= img.shape[0] or t.shape[1] >= img.shape[1]:
            continue
        r = cv2.matchTemplate(img, t, cv2.TM_CCOEFF_NORMED)
        _, v, _, l = cv2.minMaxLoc(r)
        if v > best:
            best, loc = v, (l[0] + t.shape[1] // 2, l[1] + t.shape[0] // 2)
    return loc if best >= 0.8 else None


def _focus():
    import ad_skip
    return ad_skip._focus()


def _text(img, box):
    try:
        import popup_ocr
        return popup_ocr.read_text(img, region=box, timeout=10).lower()
    except Exception:                                   # noqa: BLE001
        return ""


def status_line(now=None, hist=None, last=None):
    """Pure (11/2): 'Ads: 3 watched this hour (12 max) · last: plot at (..) watched 4 min ago' or '' when off."""
    now = now or time.time()
    hist = _hist if hist is None else hist
    last = LAST if last is None else last
    n = sum(1 for t in hist if now - t < 3600)
    txt = f"Ads: {n} watched this hour ({MAX_PER_HOUR} max)"
    if last:
        mins = int((now - last[0]) // 60)
        txt += f" · last: {last[1]} {last[2]} {'just now' if mins < 1 else f'{mins} min ago'}"
    return txt


_TALLY = {"watched": 0, "stuck": 0, "no_ad": 0, "no_button": 0, "secs": [], "loss": 0}
_EXIT = {"how": None, "secs": None}         # set by _sit_out: what brought the game back, and when


def tally_line(t=None):
    """Pure (11/4): '[ads] so far this run: 3 watched (avg 64 s), 1 stuck, 0 no ad, 0 no button'."""
    t = _TALLY if t is None else t
    sec = sorted(t["secs"])
    avg = (f" (avg {sum(sec) / len(sec):.0f} s, median {sec[len(sec) // 2]:.0f} s)") if sec else ""
    return (f"[ads] so far this run: {t['watched']} watched{avg}, {t['stuck']} stuck, {t['no_ad']} no ad, "
            f"{t['no_button']} no button, {t.get('loss', 0)} cost more time than they saved")


def watch(stop_flag=None, secs_left=None, what="item", min_left=None):
    global LAST
    t0 = time.time()
    _EXIT.update(how=None, secs=None)
    res = _watch(stop_flag, secs_left, what, min_left)
    if res != "skipped":
        LAST = (time.time(), what, res.replace("_", " "))
        # 11/4 (owner, at work with ads on): one line per ad + a running tally, so every ad can be followed in the logs
        if res in _TALLY:
            _TALLY[res] += 1
        if res == "watched" and _EXIT["secs"] is not None:
            _TALLY["secs"].append(_EXIT["secs"])
        took = time.time() - t0
        loss = res in ("watched", "stuck") and secs_left and took >= secs_left
        if loss:
            _TALLY["loss"] = _TALLY.get("loss", 0) + 1      # 11/4 owner: an ad must pay for itself
        _log(f"[ads] RESULT {what}: {res} -- {time.time() - t0:.0f} s from the video tap to back in the game"
             + (f"; exit: {_EXIT['how']}" if _EXIT["how"] else "")
             + (f"; timer had {secs_left // 60}m{secs_left % 60:02d}s" if secs_left else "")
             + (f"; pictures {os.path.basename(_shot_dir)}" if _shot_dir else "")
             + ("; NET LOSS (took longer than the timer it skipped)" if loss else ""))
        _log(tally_line())
        _log(note_day(res, secs_left))
    return res


def _watch(stop_flag=None, secs_left=None, what="item", min_left=None):
    """With a timer card open: tap its video button, sit through the ad, come back. Returns 'watched', 'skipped',
    'no_button', 'no_ad' or 'stuck'. Never taps a gem button; the card is left for the caller to close."""
    import adb_helper
    import find_and_center as fac
    import order_fulfill as of
    if not ON or not worth_it(secs_left, min_left=min_left):
        return "skipped"
    img = adb_helper.screenshot()
    btn = find_video_button(img)
    if btn is None:
        _log(f"{what}: no video button on the card -- not watching.")
        return "no_button"
    _log(f"{what}: {secs_left // 60}m{secs_left % 60:02d}s left -- tapping the VIDEO button at {btn} (never the gem one).")
    adb_helper.tap(*btn)
    t0 = time.time()
    kind = "game"
    while time.time() - t0 < AD_START_SEC:
        fac.interruptible_sleep(1.0, stop_flag)
        kind = classify_focus(_focus())
        if kind not in ("game", "unknown"):
            break
    if kind in ("game", "unknown"):
        no, _ = of.find_no_button(adb_helper.screenshot())
        if no is not None:
            adb_helper.tap(*no)
            _log(f"{what}: a gem question came up instead of an ad -- answered No.")
        else:
            _log(f"{what}: no ad started within {AD_START_SEC} s.")
        return "no_ad"
    return sit_out(stop_flag, what, kind)


def sit_out(stop_flag=None, what="item", kind=None, already=0.0):
    """Sit through an ad that is in front now (also used at Start when one was left on screen). `already` = seconds
    the ad has probably been playing (so the exit taps start at once)."""
    import adb_helper
    import find_and_center as fac
    global _shot_dir, ACTIVE
    if kind is None:
        kind = classify_focus(_focus())
    _shot_dir = os.path.join(BASE, "templates", "ad_training", "live_" + time.strftime("%Y%m%d_%H%M%S"))
    ACTIVE = time.time()
    try:
        return _sit_out(stop_flag, what, kind, already, adb_helper, fac)
    finally:
        ACTIVE = 0.0


def _sit_out(stop_flag, what, kind, already, adb_helper, fac):
    ad_t0, seen, gp_tried, store_visits, x_taps, last_shot, errs = time.time(), kind, 0.0, 0, 0, 0.0, 0
    last_act = None
    spot_taps, exit_seen = {}, False          # 11/4 (Muse photos): no blind taps, no tapping a dead spot forever
    ad_t0 -= already
    _log(f"{what}: ad playing ({kind}).")
    while time.time() - ad_t0 < AD_MAX_SEC:
        if (not exit_seen and not store_visits and kind == "applovin"
                and time.time() - ad_t0 >= NO_EXIT_GIVEUP_SEC):
            # 11/4: a PLAYABLE ad (Tasty Travels, live_20261104_095951) shows no skip, no X, no Google Play pill --
            # it waits for someone to play it. Waiting 240 s for an ending that never comes cost more than the
            # timer. Give up early: Back keys, then the unstuck ladder (game restart).
            _log(f"{what}: {time.time() - ad_t0:.0f} s -- no Google Play pill, skip icon or X ever showed (a playable "
                 f"ad?) -- giving up early. It may have a NEXT / download button; tapping those needs the owner's yes.")
            break
        fac.interruptible_sleep(2.0, stop_flag)
        try:
            focus = _focus()
            kind = classify_focus(focus)
            t = time.time() - ad_t0
            if time.time() - last_shot >= SHOT_EVERY_SEC:
                last_shot = time.time()
                _shot(f"t{int(t):03d}s_{kind}")
            if kind == "game":
                _hist.append(time.time())
                _EXIT.update(how=last_act or "the ad closed by itself", secs=round(t))
                _log(f"{what}: ad over after {t:.0f} s ({seen}{', via the Play Store' if store_visits else ''}) -- "
                     f"back in the game.")
                return "watched"
            if kind == "store":                               # never touch the store -- Back only
                store_visits += 1
                _log(f"{what}: {t:.0f} s -- Play Store in front, pressing Back (never touching the store).")
                adb_helper.back()
                last_act = "Back from the Play Store"
                continue
            if kind == "unknown":
                continue
            if kind == "applovin" and t >= APPLOVIN_EXIT_AFTER_SEC:
                img = _shot(f"t{int(t):03d}s_applovin")
                port = portrait(img)
                if store_visits:                              # back from the store: the X is up now
                    if port:
                        spot = P_X
                    else:
                        spot = TOP_LEFT_X if x_taps % 2 == 0 else TOP_RIGHT_X
                    x_taps += 1
                    _log(f"{what}: {t:.0f} s -- back from the store, tapping the X at {spot} "
                         f"({'portrait' if port else 'landscape'} ad).")
                    adb_helper.tap(*spot)
                    last_act = f"X at {spot} after the store"
                    fac.interruptible_sleep(1.0, stop_flag)
                    continue
                if time.time() - gp_tried > 10:
                    gp_tried = time.time()
                    if port:
                        # owner 11/2: one tap on the "Google Play >" pill top-left; it is the only way on.
                        # 11/2 live: on a video ad that corner holds a small "skip to end" button at (118,40)
                        # instead -- the fixed spot (86,34) missed it. Tap whatever is drawn there.
                        # 11/4 (Muse photos): never blind -- on a playable the top-left is a COIN COUNTER; the old
                        # fallback (86,34) tapped it ~17x for nothing. Only a matched pill / skip icon is tapped,
                        # and a spot that did nothing 3x is not tapped again.
                        spot = top_left_button(img)
                        key = (spot[0] // 40, spot[1] // 40) if spot else None
                        if spot is None:
                            _log(f"{what}: {t:.0f} s -- portrait ad, no Google Play pill / skip icon top-left -- not "
                                 f"tapping blind.")
                        elif spot_taps.get(key, 0) >= SPOT_TRIES:
                            exit_seen = False            # a dead button is no way out -> early give-up applies
                            _log(f"{what}: {t:.0f} s -- top-left button at {spot} did nothing {SPOT_TRIES}x -- "
                                 f"not tapping it again.")
                        else:
                            exit_seen = True
                            spot_taps[key] = spot_taps.get(key, 0) + 1
                            _log(f"{what}: {t:.0f} s -- portrait ad, tapping its top-left button at {spot} "
                                 f"(try {spot_taps[key]}).")
                            adb_helper.tap(*spot)
                            last_act = f"top-left button at {spot}"
                    else:
                        # 11/4 (owner, auto-rotate OFF in LDPlayer -> portrait ads play SIDEWAYS in a landscape
                        # screen): "the Google Play button shows up in the bottom left then silently fades till you
                        # click that area again". The old code read the text (OCR, up to 10 s) BETWEEN the two taps,
                        # so the button had faded before the second tap. Now: show tap, Google Play tap 0.4 s later,
                        # and only then a picture + OCR for the log.
                        _log(f"{what}: {t:.0f} s -- sideways/landscape ad: tapping bottom-left {BOTTOM_TAP} to show its "
                             f"buttons, then Google Play {GOOGLE_PLAY} at once (it fades).")
                        adb_helper.tap(*BOTTOM_TAP)
                        fac.interruptible_sleep(0.4, stop_flag)
                        adb_helper.tap(*GOOGLE_PLAY)
                        exit_seen = True                 # owner-confirmed spot on sideways ads (11/1, 11/4)
                        last_act = "Google Play (bottom-left, sideways ad)"
                        fac.interruptible_sleep(1.0, stop_flag)
                        img = _shot(f"t{int(t):03d}s_after_gp")
                        txt = _text(img, GP_BOX) if img is not None else ""
                        _log(f"{what}: after the Google Play tap"
                             + (f", bottom-left text {txt[:40]!r}" if txt else "") + ".")
            elif kind == "facebook" and t >= 12:
                img = _shot(f"t{int(t):03d}s_facebook")
                port = portrait(img)
                txt = _text(img, top_right_box(img) if port else FB_SKIP_BOX) if img is not None else ""
                if "skip" in txt:
                    spot = P_X if port else FB_SKIP
                    _log(f"{what}: {t:.0f} s -- Facebook ad says Skip, tapping it at {spot}.")
                    adb_helper.tap(*spot)
                    last_act = f"Facebook Skip at {spot}"
                elif t >= 75:
                    _log(f"{what}: {t:.0f} s -- Facebook ad end card, pressing Back.")
                    adb_helper.back()
                    last_act = "Back on the Facebook end card"
            elif kind == "other" and t >= 6:
                _log(f"{what}: {t:.0f} s -- something else in front ({focus[:60]}), pressing Back.")
                adb_helper.back()
                last_act = "Back on another app"
        except Exception as e:                    # noqa: BLE001 -- 11/2: an adb timeout mid-ad must not
            if "StopRequested" in type(e).__name__:   # abandon the ad (it stayed on screen until morning)
                raise
            errs += 1
            _log(f"{what}: {time.time() - ad_t0:.0f} s -- adb problem inside the ad ({type(e).__name__}); keeping at it ({errs}).")
            fac.interruptible_sleep(3.0, stop_flag)
    _shot("stuck")
    for i in range(3):                                   # 11/2: get back to the game before giving up
        try:
            adb_helper.back()
            fac.interruptible_sleep(2.0, stop_flag)
            if classify_focus(_focus()) == "game":
                _log(f"{what}: still in the ad after {time.time() - ad_t0:.0f} s -- Back x{i + 1} got the game back.")
                return "stuck"
        except Exception as e:                           # noqa: BLE001
            if "StopRequested" in type(e).__name__:
                raise
    # 11/12 (Muse: 3 dead 30-min windows): the ad lives inside the game's own process, so nothing above closed it
    # and LDPlayer stayed PORTRAIT (551x980) -- every cycle then crashed. Closing the GAME closes its ad with it; the
    # normal launch steps start the game again (landscape). No buttons inside the ad are touched.
    try:
        adb_helper._run(["shell", "am", "force-stop", GAME_PACKAGE])
        _log(f"{what}: still in the ad after {time.time() - ad_t0:.0f} s and 3 Back keys -- closed the GAME (its ad "
             f"goes with it); it is started again next.")
        return "stuck"
    except Exception as e:                               # noqa: BLE001
        if "StopRequested" in type(e).__name__:
            raise
        _log(f"{what}: still in the ad after {time.time() - ad_t0:.0f} s and 3 Back keys, closing the game failed "
             f"({e!r}) -- the unstuck ladder takes over.")
    return "stuck"
