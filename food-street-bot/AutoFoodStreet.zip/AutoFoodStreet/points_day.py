"""11/15 (owner): Orders tab "Points / hour" = event points of the last 24 h / hours the bot ran in those 24 h, and
a small grey "points per hour over the whole 24 h". Survives the 30-min auto restarts and AFSD reopening.
State .points_day.json: {"gains": [[t, points], ...], "runs": [[start, end], ...]} (older than 24 h dropped)."""
import json
import os
import time

PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".points_day.json")
DAY = 24 * 3600
JOIN_GAP_SEC = 180           # a running tick within this of the last run's end extends it
SAVE_GAP_SEC = 60
_st = {"data": None, "saved": 0.0}


def _load():
    if _st["data"] is None:
        try:
            with open(PATH, encoding="utf-8") as fh:
                d = json.load(fh)
            _st["data"] = {"gains": list(d.get("gains", [])), "runs": list(d.get("runs", []))}
        except (OSError, ValueError, TypeError):
            _st["data"] = {"gains": [], "runs": []}
    return _st["data"]


def _save(now, force=False):
    if not force and now - _st["saved"] < SAVE_GAP_SEC:
        return
    _st["saved"] = now
    try:
        with open(PATH, "w", encoding="utf-8") as fh:
            json.dump(_st["data"], fh)
    except OSError:
        pass


def prune(data, now):
    data["gains"] = [g for g in data["gains"] if now - g[0] <= DAY]
    data["runs"] = [r for r in data["runs"] if now - r[1] <= DAY]
    return data


def add_running(data, now):
    """Pure: extend the last run interval or start a new one."""
    if data["runs"] and 0 <= now - data["runs"][-1][1] <= JOIN_GAP_SEC:
        data["runs"][-1][1] = now
    else:
        data["runs"].append([now, now])
    return data


def summary(data, now):
    """Pure -> (points in 24 h, hours running in 24 h, points/hour while running or None, points/hour over 24 h)."""
    start = now - DAY
    pts = sum(p for t, p in data["gains"] if t >= start)
    secs = sum(max(0.0, e - max(s, start)) for s, e in data["runs"] if e > start)
    hrs = secs / 3600.0
    return pts, hrs, (pts / hrs if hrs >= 1 / 6 else None), pts / 24.0


def note_gain(points, now=None):
    try:
        now = now or time.time()
        d = _load()
        d["gains"].append([now, int(points)])
        prune(d, now)
        _save(now, force=True)
    except Exception:                                   # noqa: BLE001
        pass


def note_running(now=None):
    try:
        now = now or time.time()
        prune(add_running(_load(), now), now)
        _save(now)
    except Exception:                                   # noqa: BLE001
        pass


def current(now=None):
    now = now or time.time()
    return summary(_load(), now)
