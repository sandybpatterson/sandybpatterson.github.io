"""Garden Plot (crop grid) automation. Scope for v1: locate the grid,
harvest any ready-to-collect crops, and replant Carrot in whatever empty
plots result (Carrot is the only crop this project currently consumes
downstream, via Pig Pen's Ham/Bacon). Not a general all-crop planner.

Ready-to-harvest detection is intentionally left unimplemented until we
have a real screenshot of a mature crop to build/verify a template from
(same "verify against a real screenshot" lesson as every other station in
this project) — see CLAUDE.md.
"""
import os
import sys
import time
import datetime
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from adb_helper import screenshot, tap, swipe
from find_and_center import find_and_center, StopRequested, close_any_open_panel, check_stop, interruptible_sleep
import pig_pen_check
import digit_reader
import order_fulfill as of  # plant_bar_is_open, find_no_button -- reused
                              # for replant_carrots' gem-dialog safety check
from order_fulfill import find_question_button  # more robust than a fixed
                                                   # tap position -- verifies
                                                   # the tooltip actually
                                                   # appeared via template
                                                   # match before tapping it

LOG = os.path.join(BASE_DIR, "run_log.txt")

GARDEN_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "garden_plot.png"))
# The prize wheel + lighthouse on the pier, right next to the Garden Plot/
# Pig Pen cluster -- the user's idea 9/27, after find_and_center's search
# for Pig Pen was found (via a full log review) to be failing the
# overwhelming majority of the time once the camera drifts far enough
# from its cached position. Unlike Pig Pen, this landmark is large,
# highly distinctive (self-match 1.0, worst false-positive 0.20 tested
# against 6 unrelated screenshots), and can never be rebuilt/moved/
# rotated by the player, unlike an ordinary station. Not yet wired into
# the actual Garden Plot navigation flow (that needs a real hierarchical
# search: find this landmark first via find_and_center, THEN a much
# shorter bounded search from that known-good position toward the garden
# -- deliberately NOT a fixed-offset jump, since that approach was tried
# and explicitly rejected earlier in this project for drifting onto wrong
# targets across zoom levels). This is the finder function that step
# would need; see CLAUDE.md for the follow-up plan.
PIER_LANDMARK_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "pier_landmark.png"))
CARROT_READY_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "carrot_ready.png"))
# Built 9/27 for the generalized ingredient-recursion feature -- proven
# manually first (Tomato Soup and Croissant->Butter->Milk->Greens chain
# walks), then wired into real automation. Both cropped from real live
# screenshots and false-positive tested against 4 unrelated station
# panels (max 0.38, self-match 1.0) before trusting them, same discipline
# as every other template in this project.
TOMATO_READY_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "tomato_ready.png"))
GREENS_READY_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "greens_ready.png"))
# Reuses the same wheat_ready.png template order_fulfill.py's own
# find_ready_wheat already used for the original v1 Wheat-only recursion
# -- Wheat moved onto this generic crop path 9/27 after a real bug was
# found in that older, Wheat-specific code (it never checked for the
# "out of stock, buy for gems?" dialog when replanting, so it could tap
# the plant-bar icon and silently fail to actually plant anything).
WHEAT_READY_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "wheat_ready.png"))
# Keyed by INGREDIENT-library name (see order_fulfill.py's ingredient
# library), not the plant-bar's own naming -- "cabbage" is this project's
# ingredient name for what the game itself calls "Greens" (PLANT_BAR_
# COLUMNS separately uses "lettuce" for the same crop's plant-bar column,
# an inconsistency inherited from before the two systems were connected).
READY_CROP_TEMPLATES = {
    "carrot": CARROT_READY_TEMPLATE,
    "tomato": TOMATO_READY_TEMPLATE,
    "cabbage": GREENS_READY_TEMPLATE,
    "wheat": WHEAT_READY_TEMPLATE,
}
# Maps an ingredient-library crop name to its PLANT_BAR_COLUMNS key, for
# the same reason as above.
INGREDIENT_TO_PLANT_BAR_KEY = {
    "carrot": "carrot",
    "tomato": "tomato",
    "cabbage": "lettuce",
    "wheat": "wheat",
    "corn": "corn",
    "mushroom": "mushroom",
}
MATCH_THRESHOLD = 0.6
MAX_CARROTS_PER_RUN = 10  # matches the confirmed total Garden Plot count
                           # (9/24 in-game build list) -- never worth
                           # trying to harvest/replant more than the
                           # garden could possibly hold in one run
SCALES = [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4]
FAST_SCALES = [0.4, 0.6, 0.8, 1.0, 1.2, 1.4]
READY_SCALES = [0.7, 0.85, 1.0, 1.15, 1.3]
READY_THRESHOLD = 0.6

# Plant-crops bar: a fixed screen-space overlay (not scaled by camera
# zoom, same as a station panel) that appears after tapping any empty
# plot. Column x-positions measured live 9/24 across two separate tests
# (both plantings landed correctly): Wheat, Corn, Tomato, Lettuce,
# Carrot, Mushroom, evenly spaced ~280px apart, all at the same y.
PLANT_BAR_ROW_Y = 270
PLANT_BAR_COLUMNS = {
    "wheat": 140,
    "corn": 420,
    "tomato": 700,
    "lettuce": 980,
    "carrot": 1259,
    "mushroom": 1540,
}
# Stock-count box offset relative to a crop's own column x (PLANT_BAR_
# COLUMNS), specifically for Carrot -- confirmed live 9/26 this is wide
# enough to avoid clipping the digit (a tighter attempt clipped the top of
# a '3', dropping its read confidence from 1.00 to 0.58) while still
# excluding the crop icon itself, which contaminated an earlier over-wide
# attempt at building the digit templates. Not yet verified as a general
# per-crop offset -- each crop's icon is a different width/shape, so this
# specific box has only been confirmed correct for Carrot.
CARROT_STOCK_BOX_DX = (71, 131)
CARROT_STOCK_BOX_Y = (325, 385)
# Tapping open ground below the bar closes it safely. Confirmed 9/24 that
# using the Android back button instead falls through to the app-level
# "quit the game?" confirmation -- never use back() to close this bar.
SAFE_CLOSE_TAP = (1150, 480)

# Quick-travel shortcut: rather than a blind map search (v1 approach,
# FAILED live 9/24 -- a 40-step/160px-hop spiral can't cover enough
# ground when the camera starts far from the Garden Plot, confirmed by
# confidence staying near-zero the whole search), reuse the Pig Pen
# panel's own "insufficient ingredient" tooltip. Tapping the red carrot
# icon under either recipe card pops "Grow Carrot on your Garden Plot"
# with a blue "?" -- tapping that jumps the camera straight there.
# Coordinates measured live 9/24 against a real Pig Pen panel screenshot.
CARROT_ICON_LOC = (622, 500)
CARROT_COUNT_TEXT_LOC = (622, 517)


def carrot_insufficient(img):
    """Cheap red-vs-green pixel check on the carrot count text under the
    Ham recipe card -- red means insufficient (the quick-travel tooltip
    will be available), green means we already have enough and there's
    nothing for this run to do. Deliberately not full digit OCR (that
    project is separately paused) -- we only need insufficient-or-not,
    not the exact number."""
    x, y = CARROT_COUNT_TEXT_LOC
    region = img[y - 8:y + 8, x - 20:x + 20]
    b, g, r = region[:, :, 0].mean(), region[:, :, 1].mean(), region[:, :, 2].mean()
    insufficient = r > g + 20
    log(f"carrot_insufficient check: r={r:.0f} g={g:.0f} b={b:.0f} -> "
        f"{'RED/insufficient' if insufficient else 'green/sufficient'}")
    return insufficient


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] {msg}\n")
    try:
        print(f"[{ts}] {msg}")
    except (AttributeError, OSError):
        pass


def _multiscale_match(img, template, scales, threshold):
    best_loc, best_val = None, 0.0
    th, tw = template.shape[:2]
    for scale in scales:
        w, h = int(tw * scale), int(th * scale)
        if w < 10 or h < 10 or w > img.shape[1] or h > img.shape[0]:
            continue
        resized = cv2.resize(template, (w, h))
        res = cv2.matchTemplate(img, resized, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val > best_val:
            best_val = max_val
            best_loc = (max_loc[0] + w // 2, max_loc[1] + h // 2)
    if best_val >= threshold:
        return best_loc, best_val
    return None, best_val


def find_garden(img, fast=False):
    scales = FAST_SCALES if fast else SCALES
    search_img = img
    factor = 1.0
    if fast:
        factor = 0.5
        search_img = cv2.resize(img, (int(img.shape[1] * factor), int(img.shape[0] * factor)))
    loc, val = _multiscale_match(search_img, GARDEN_TEMPLATE, scales, MATCH_THRESHOLD)
    if loc is not None and fast:
        loc = (int(loc[0] / factor), int(loc[1] / factor))
    return loc, val


def find_pier_landmark(img, fast=False):
    """Same multi-scale search pattern as find_garden -- see the module-
    level comment on PIER_LANDMARK_TEMPLATE for why this landmark was
    chosen. find_fn(img, fast) -> (loc, conf) signature matches what
    find_and_center() expects, so this can be dropped in directly."""
    scales = FAST_SCALES if fast else SCALES
    search_img = img
    factor = 1.0
    if fast:
        factor = 0.5
        search_img = cv2.resize(img, (int(img.shape[1] * factor), int(img.shape[0] * factor)))
    loc, val = _multiscale_match(search_img, PIER_LANDMARK_TEMPLATE, scales, MATCH_THRESHOLD)
    if loc is not None and fast:
        loc = (int(loc[0] / factor), int(loc[1] / factor))
    return loc, val


def find_ready_carrot(img):
    """Mature carrot plants (tall green tops), cropped live 9/24 from a
    real screenshot right before harvesting. Searches the whole screen
    rather than fixed slot coordinates -- same pattern as the ready-to-
    collect Ham/Cream icons elsewhere, since a plot's screen position
    depends on wherever the grid happens to be centered."""
    best_loc, best_val = None, 0.0
    th, tw = CARROT_READY_TEMPLATE.shape[:2]
    for scale in READY_SCALES:
        w, h = int(tw * scale), int(th * scale)
        if w < 10 or h < 10 or w > img.shape[1] or h > img.shape[0]:
            continue
        resized = cv2.resize(CARROT_READY_TEMPLATE, (w, h))
        res = cv2.matchTemplate(img, resized, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val > best_val:
            best_val = max_val
            best_loc = (max_loc[0] + w // 2, max_loc[1] + h // 2)
    if best_val >= READY_THRESHOLD:
        return best_loc, best_val
    return None, best_val


def _same_spot_again(loc, locations, px=15):
    """pass 77: True when the LAST tapped spot is found again (a real harvest would have removed it)."""
    return bool(locations) and abs(loc[0] - locations[-1][0]) <= px and abs(loc[1] - locations[-1][1]) <= px


def harvest_ready_carrots(stop_flag=None, max_harvests=10):
    """Repeatedly find-and-tap ready carrot plants until none remain
    detectable. Re-screenshots after every tap since collecting one
    changes what's on screen (and the last collect can auto-open the
    plant-crops bar -- caller should check for that separately). Returns
    the list of harvested plot locations -- each one is now a KNOWN-empty
    plot, which is exactly what replant_carrots() needs: this sidesteps
    the previously-unsolved "find an arbitrary empty plot" problem by
    only ever replanting plots we just personally emptied."""
    locations = []
    for _ in range(max_harvests):
        check_stop(stop_flag)
        img = screenshot()
        loc, conf = find_ready_carrot(img)
        if loc is None:
            break
        if _same_spot_again(loc, locations):                        # pass 77: a real harvest makes the carrot vanish
            log(f"Ready carrot found at {loc} again right after tapping it -- that was a false match (an empty plot), not a harvest.")
            locations.pop()
            break
        log(f"Ready carrot found at {loc} (confidence {conf:.2f}) -- harvesting.")
        tap(*loc)
        locations.append(loc)
        interruptible_sleep(1, stop_flag)
    log(f"Harvested {len(locations)} ready carrot plant(s) this run.")
    return locations


def find_ready_crop(img, crop_name):
    """Generalizes find_ready_carrot to any crop in READY_CROP_TEMPLATES.
    Returns (None, 0.0) for a crop with no template yet -- callers should
    treat that as 'can't check, assume nothing ready' rather than an
    error."""
    tmpl = READY_CROP_TEMPLATES.get(crop_name)
    if tmpl is None:
        return None, 0.0
    best_loc, best_val = None, 0.0
    th, tw = tmpl.shape[:2]
    for scale in READY_SCALES:
        w, h = int(tw * scale), int(th * scale)
        if w < 10 or h < 10 or w > img.shape[1] or h > img.shape[0]:
            continue
        resized = cv2.resize(tmpl, (w, h))
        res = cv2.matchTemplate(img, resized, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val > best_val:
            best_val = max_val
            best_loc = (max_loc[0] + w // 2, max_loc[1] + h // 2)
    if best_val >= READY_THRESHOLD:
        return best_loc, best_val
    return None, best_val


def harvest_ready_crop(crop_name, stop_flag=None, max_harvests=5):
    """Generalizes harvest_ready_carrots to any crop in
    READY_CROP_TEMPLATES. Returns the list of harvested locations (empty
    if the crop has no ready template or none were found)."""
    locations = []
    import find_and_center as _fac
    if _fac.pantry_full_recent():                                    # 10/25: 20+ min of fake tomato harvests
        log(f"[pantry full] not harvesting {crop_name} -- the Pantry is full (each harvest only brings the "
            "'Pantry is full' popup back). Free space by hand: sell / cook extras.")
        return locations
    for _ in range(max_harvests):
        check_stop(stop_flag)
        img = screenshot()
        if _fac.pantry_full_dialog_x(img) is not None:               # the last tap was refused: not a harvest
            if locations:
                locations.pop()
            _fac.PANTRY_FULL_AT[0] = time.time()
            tap(*_fac.PANTRY_FULL_X)
            interruptible_sleep(1, stop_flag)
            log(f"[pantry full] the {crop_name} harvest was refused (Pantry is full) -- stopping harvests for "
                f"{_fac.PANTRY_FULL_HOLD_SEC // 60} min.")
            break
        loc, conf = find_ready_crop(img, crop_name)
        if loc is None:
            break
        if _same_spot_again(loc, locations):                        # pass 77: a real harvest makes the crop vanish
            log(f"Ready {crop_name} found at {loc} again right after tapping it -- that was a false match (an empty plot), not a harvest.")
            locations.pop()
            break
        log(f"Ready {crop_name} found at {loc} (confidence {conf:.2f}) -- harvesting.")
        tap(*loc)
        locations.append(loc)
        interruptible_sleep(1, stop_flag)
    log(f"Harvested {len(locations)} ready {crop_name} plant(s) this run.")
    return locations


def read_carrot_stock(img):
    """Reads the actual Carrot stock number from an OPEN plant-crops bar,
    using the 'plant_bar' digit font -- confirmed live 9/26 that this UI's
    stock-count font does NOT match the older 'stock_box' font digit_
    reader.py was originally built against (a real '3' scored top match
    '8' there). Returns None if the bar isn't open or the digit can't be
    confidently read (never guesses) -- caller should fall back to the
    red/green carrot_insufficient() check if this returns None, since that
    doesn't need an exact count."""
    if not of.plant_bar_is_open(img):
        return None
    x = PLANT_BAR_COLUMNS["carrot"]
    dx1, dx2 = CARROT_STOCK_BOX_DX
    y1, y2 = CARROT_STOCK_BOX_Y
    result, confs = digit_reader.read_number(img, (x + dx1, y1, x + dx2, y2), font="plant_bar")
    return result


def replant_carrots(locations, stop_flag=None):
    """Replants Carrot in each given (now-empty) plot location -- built
    9/26 to close the TODO left in main(): rather than solving the
    general "find an arbitrary empty plot" problem (never reliably
    calibrated, per CLAUDE.md), this only replants plots harvest_ready_
    carrots() just emptied, whose screen positions are already known
    exactly. Confirmed live: tapping a just-harvested plot's own location
    reliably reopens the "Tap crops to plant them" bar there. Stops
    immediately (without tapping) the moment a gem-buy dialog appears --
    that only happens if Carrot stock hits exactly 0 mid-run, and this
    project never spends gems under any circumstance."""
    planted = 0
    for loc in locations:
        check_stop(stop_flag)
        tap(*loc)
        interruptible_sleep(0.8, stop_flag)
        img = screenshot()
        if not of.plant_bar_is_open(img):
            log(f"Plant bar didn't open after tapping harvested plot at {loc} (best-effort tap, "
                "landed somewhere unexpected) -- skipping this plot rather than guessing further.")
            continue
        tap(PLANT_BAR_COLUMNS["carrot"], PLANT_BAR_ROW_Y)
        interruptible_sleep(0.8, stop_flag)
        img = screenshot()
        no_loc, no_conf = of.find_no_button(img)
        if no_loc is not None:
            log(f"Gem-buy dialog appeared after tapping Carrot (confidence {no_conf:.2f}) -- "
                "Carrot stock must have hit 0. Declining and stopping replant for this run "
                "(never spending gems).")
            tap(*no_loc)
            interruptible_sleep(0.5, stop_flag)
            break
        planted += 1
        log(f"Replanted Carrot at {loc} ({planted}/{len(locations)}).")
    close_plant_bar(stop_flag=stop_flag)
    log(f"Replanted {planted} of {len(locations)} harvested plot(s) this run.")
    return planted


# Full crop-bar layout, confirmed live 9/29 -- the bar has grown to 10
# unlocked crops plus 1 locked slot (a chili pepper, "Unlocks at level: 42"),
# not the original 6 PLANT_BAR_COLUMNS covers. Two stable scroll
# checkpoints, confirmed via repeat-swipe-no-op that PAGE2 is the true end:
# PAGE1 (bar's default/reset position) and PAGE2 (after one long-slow swipe,
# possibly needing a 2nd swipe attempt -- confirmed live it can take either
# one or two swipes to fully reach the end). Mushroom sits in the "seam"
# between pages -- its icon is cut off on BOTH pages, but its stock box is
# only fully visible/readable from PAGE2's left edge, so it's listed there.
RESTOCK_PAGE1 = [("wheat", 140), ("corn", 420), ("tomato", 700),
                  ("cabbage", 980), ("carrot", 1259)]
RESTOCK_PAGE2 = [("mushroom", 85), ("onion", 330), ("sugar_cane", 605),
                  ("garlic", 890), ("rice", 1175)]
RESTOCK_MIN_STOCK = 5
RESTOCK_MAX_LAPS = 4  # safety cap -- a lap that plants nothing productive
                       # (every crop already >=5, or every read was
                       # unconfident) should never spin forever


def _read_crop_stock(img, x):
    """Reads a crop's current stock count from an OPEN plant-crops bar at
    column x. Returns an int, or None if it can't be read confidently --
    callers must treat None as 'unknown, don't guess,' the same discipline
    every other uncertain read in this project follows, NOT as 0.
    Digit-reading for this font is a real, only-partially-solved problem
    as of 9/29 (see CLAUDE.md) -- confirmed live to work reliably on some
    card positions and not others (likely a segmentation/contamination
    issue in a few specific spots, not a wrong font). A card genuinely
    showing 'Free' (seen live for Rice at 0 stock) reads as 0 here --
    confirmed by the user this specific wording means exactly zero, same
    as every other crop's plain '0'."""
    try:                                               # pass 63: the plant bar's own stock-box reader ("free" / int / None)
        import plant_stock
        return plant_stock.read_stock(img, x)
    except Exception:                                  # noqa: BLE001
        return None
    dx1, dx2 = CARROT_STOCK_BOX_DX
    y1, y2 = CARROT_STOCK_BOX_Y
    region = img[y1:y2, x + dx1:x + dx2]
    # "Free" has no digits at all -- matchTemplate against a text region
    # with no glyphs isolates zero connected components, so read_number
    # naturally returns None here rather than a false digit; explicitly
    # checking for the word would need a whole separate OCR pass this
    # project doesn't have, so this relies on the caller's own live
    # observation (confirmed 9/29) that "Free" always means 0 for these
    # crops -- treated as a known, documented equivalence, not a guess.
    result, _confs = digit_reader.read_number(img, (x + dx1, y1, x + dx2, y2), font="plant_bar")
    return result


def restock_all_crops(stop_flag=None, min_stock=RESTOCK_MIN_STOCK, max_laps=RESTOCK_MAX_LAPS, targets=None):
    """Given an ALREADY-OPEN plant-crops bar (with at least one empty plot
    highlighted by the blue arrow), tops up every crop to at least
    min_stock, one plot at a time, sweeping left to right across both
    scroll pages -- the user's own design, 9/29: 'starting from the left
    hand side with wheat, check to see if we have 5 or more, if we do
    not, tap on that wheat and plant it, and if we have 5 or more then
    move on to the next crop.' Repeats laps (up to max_laps) since a
    single sweep only fills as many plots as there are crops in the list;
    stops early once a full lap makes no progress (every readable crop is
    already sufficient) or the bar closes itself (no empty plots left).
    Never spends gems -- declines the 'out of stock, buy for N gems?'
    dialog immediately and moves on, exactly as replant_carrots() does.
    Returns the total number planted."""
    planted_total = 0
    for lap in range(max_laps):
        check_stop(stop_flag)
        img = screenshot()
        if not of.plant_bar_is_open(img):
            log(f"restock_all_crops: bar closed (no empty plots left) after {planted_total} "
                f"planted across {lap} lap(s).")
            return planted_total

        planted_this_lap = 0
        for page_num, page in enumerate((RESTOCK_PAGE1, RESTOCK_PAGE2), start=1):
            if page_num == 2:
                # long-slow swipe forward, retried once -- confirmed live
                # 9/29 this can take either one or two swipes to fully
                # reach the true end, unlike the single-swipe-suffices
                # finding for the Orders board/recipe panels.
                for _ in range(2):
                    check_stop(stop_flag)
                    swipe(1400, PLANT_BAR_ROW_Y, 200, PLANT_BAR_ROW_Y, 2000)
                    interruptible_sleep(1.5, stop_flag)
                img = screenshot()
                if not of.plant_bar_is_open(img):
                    log("restock_all_crops: bar closed mid-sweep (ran out of empty plots).")
                    return planted_total + planted_this_lap

            for name, x in page:
                check_stop(stop_flag)
                stock = _read_crop_stock(img, x)
                if stock is None:
                    log(f"restock_all_crops: '{name}' stock unreadable this pass -- "
                        "skipping rather than guessing.")
                    continue
                if stock == "free":                                    # pass 63: stock 0 and none growing -> one free seed
                    log(f"restock_all_crops: '{name}' shows Free (one free seed) -- planting it.")
                elif stock == 0:
                    log(f"restock_all_crops: '{name}' is at 0 while some are still growing -- planting more would ask for gems, skipping.")
                    continue
                elif stock >= (targets or {}).get(name, min_stock):     # 10/23: per-crop target (orders' needs)
                    continue
                else:
                    log(f"restock_all_crops: '{name}' stock is {stock} (< {(targets or {}).get(name, min_stock)}) -- planting.")
                tap(x, PLANT_BAR_ROW_Y)
                interruptible_sleep(0.8, stop_flag)
                img = screenshot()
                no_loc, no_conf = of.find_no_button(img)
                if no_loc is not None:
                    log(f"restock_all_crops: '{name}' hit a gem-buy dialog (confidence "
                        f"{no_conf:.2f}, must be genuinely out of stock) -- declining, "
                        "never spending gems, moving on.")
                    tap(*no_loc)
                    interruptible_sleep(0.5, stop_flag)
                    img = screenshot()
                    continue
                planted_this_lap += 1
                if not of.plant_bar_is_open(img):
                    log(f"restock_all_crops: bar closed after planting '{name}' "
                        "(no empty plots left).")
                    return planted_total + planted_this_lap

        # reset back to page 1 for the next lap
        for _ in range(2):
            check_stop(stop_flag)
            swipe(200, PLANT_BAR_ROW_Y, 1400, PLANT_BAR_ROW_Y, 2000)
            interruptible_sleep(1.5, stop_flag)

        planted_total += planted_this_lap
        if planted_this_lap == 0:
            log(f"restock_all_crops: lap {lap + 1} planted nothing (every readable crop "
                f">= {min_stock}, or every read was unconfident) -- stopping rather than "
                "spinning on empty plots we can't fill.")
            break

    return planted_total


# Fallback tap points for close_plant_bar, tried in order -- SAFE_CLOSE_TAP
# is the historically-used one, but confirmed live 9/26 it is NOT reliably
# open ground: whether that exact coordinate lands on grass or on top of a
# growing plot depends on which plots happen to be occupied at the moment,
# which varies run to run as carrots grow/get harvested. Corners far from
# the grid and the crop-icon strip are much less likely to ever have a
# plot rendered on top of them.
CLOSE_BAR_CANDIDATES = [SAFE_CLOSE_TAP, (60, 850), (1550, 850), (60, 420)]


def close_plant_bar(stop_flag=None, max_attempts=len(CLOSE_BAR_CANDIDATES)):
    """Closes the 'Tap crops to plant them' bar by tapping open ground --
    confirmed live this bar has no close-X, so a normal close_any_open_
    panel() call can't catch it. A single fixed 'safe' tap point isn't
    reliable (see CLOSE_BAR_CANDIDATES comment), so this tries a few
    different candidates, verifying after each, rather than trusting one
    blind tap and returning. Also runs close_any_open_panel() afterward as
    a safety net, in case one of these taps landed on a DIFFERENT panel
    that DOES have a close-X (confirmed live: a fallback tap here can open
    a growing plot's own grow-timer info card instead of closing anything).
    Returns True if the bar is confirmed closed."""
    for pt in CLOSE_BAR_CANDIDATES[:max_attempts]:
        img = screenshot()
        if not of.plant_bar_is_open(img):
            # thorough=True: a fallback tap here has landed on a growing
            # plot's own grow-timer info card (e.g. "Carrot, 14m 4s, Skip
            # [3 gems]") before -- a world-space tooltip whose close-X can
            # sit outside the normal bounded-region search, so a plain
            # close_any_open_panel() can miss it and leave it open.
            close_any_open_panel(quiet=True, thorough=True)
            return True
        check_stop(stop_flag)
        tap(*pt)
        interruptible_sleep(0.6, stop_flag)
    img = screenshot()
    still_open = of.plant_bar_is_open(img)
    if still_open:
        log("close_plant_bar: still open after trying all fallback tap points -- leaving it "
            "rather than guessing further. Check manually.")
    close_any_open_panel(quiet=True, thorough=True)
    return not still_open


# Orders-clipboard route to the Garden Plot (10/3, user's request): open the Orders
# board, find red items that could be crops, tap one + its quick-travel "?", and
# confirm by SIGHT that the camera landed on the Garden Plot. Tried first because it
# needs no map search; the Pig Pen route below is the fallback.
USE_ORDERS_BOARD_TRAVEL = True
USE_PIG_PEN_FALLBACK = False         # pass 56: never search the map for the Pig Pen (owner: menu fast-travel only)
ORDERS_BOARD_MAX_TRIPS = 4


def _orders_board_open(img):
    return len(of.find_card_positions(img)) > 0


def _open_orders_board(stop_flag=None):
    """Opens the clipboard menu if it isn't already open. Only taps the (fixed HUD)
    clipboard icon when the screen is a plain map -- never over a popup/panel."""
    import event_orders  # local: hud_is_bright lives there
    img = screenshot()
    if _orders_board_open(img):
        return True
    if not event_orders.hud_is_bright(img):
        log("Orders route: screen is not a plain map -- not tapping the clipboard icon.")
        return False
    for _ in range(2):
        tap(*of.ORDERS_ICON_LOC)
        interruptible_sleep(1.2, stop_flag)
        if _orders_board_open(screenshot()):
            return True
    return False


CROP_INGREDIENT_NAMES = {"carrot", "cabbage", "wheat", "tomato", "corn", "mushroom",
                         "onion", "sugar_cane", "garlic", "rice"}


def garden_from_station_panel(stop_flag=None, max_tries=3):
    """The Orders trip landed on a STATION panel (e.g. a Smoothie Bar card for a veggie
    juice order) instead of the Garden Plot. Same trick as the Pig Pen route: any RED
    crop ingredient on any visible card is a quick-travel vehicle to the plots (Veggie
    Juice = carrot + cabbage + apple). Reads every visible card's ingredient row, taps
    the first red ingredient the ingredient library names as a crop, follows its '?',
    and confirms the Garden Plot by sight. Returns True only when confirmed."""
    import event_orders
    img = screenshot()
    seen, reds, greens = [], [], []
    for b in event_orders.station_buttons(img):
        bx = b[0]
        for color, x, y, name in of.read_ingredients(img, bx):
            seen.append(f"{name or '?'}:{color or '-'}")
            if name in CROP_INGREDIENT_NAMES:
                (reds if color == "red" else greens if color == "green" else []).append((name, x, y))
    # Red crops first (known to give the travel tooltip). Green ones next: the order item that
    # brought us here is often a dish that simply is not cooked yet, so its ingredients can all
    # be green -- tapping a green crop icon may still offer the quick-travel tooltip.
    cands, names = [], set()
    for c in reds + greens:
        if c[0] not in names:
            names.add(c[0])
            cands.append(c)
    log(f"Station panel: ingredients seen {seen}; crop candidates {[(n, 'red' if (n, x, y) in reds else 'green') for n, x, y in cands]}")
    if not cands:
        try:
            os.makedirs(os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "garden_route_debug"), exist_ok=True)
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "garden_route_debug",
                                f"{int(time.time())}.png")
            cv2.imwrite(path, img)
            log(f"Station panel: no crop ingredient visible on any card -- saved the screen to {path}.")
        except Exception:                      # noqa: BLE001
            log("Station panel: no crop ingredient visible on any card -- nothing to follow.")
        return False
    for name, x, y in cands[:max_tries]:
        check_stop(stop_flag)
        log(f"Station panel: {name} at ({x},{y}) -- tapping it and its quick-travel '?'.")
        tap(x, y)
        interruptible_sleep(0.25, stop_flag)
        img = screenshot()
        q_loc, q_conf = find_question_button(img, retry=1)
        if q_loc is None:
            no_loc, _ = of.find_no_button(img)
            if no_loc is not None:
                log("Station panel: a gem-buy dialog appeared instead -- declining (No).")
                tap(*no_loc)
                interruptible_sleep(1, stop_flag)
            else:
                log(f"Station panel: no '?' tooltip after tapping {name} (best {q_conf:.2f}).")
            continue
        tap(*q_loc)
        for _ in range(3):
            interruptible_sleep(1.0, stop_flag)
            shot = screenshot()
            ok, conf = _garden_confirmed(shot, strict=False)
            if ok:
                log(f"Station panel: the Garden Plot is on screen via {name} (match {conf:.2f}).")
                _close_grow_card_if_open(shot, stop_flag)
                return True
        _trace_picture("garden_route", f"{name}'s '?' did not end on the plots")
        log(f"Station panel: {name} went somewhere other than the Garden Plot.")
        return False
    return False


def is_grow_timer_card(img):
    """pass 65: a crop's world-space grow-timer card (name, time left, Skip [gems], red X) is on screen -- it only ever opens at the plots."""
    try:
        import find_and_center as fac
        if img is None or img.shape[:2] != (900, 1600):
            return False
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        card = hsv[200:600, 640:960]
        pale = ((card[:, :, 0] >= 95) & (card[:, :, 0] <= 112) & (card[:, :, 1] >= 25) & (card[:, :, 1] <= 110) & (card[:, :, 2] >= 200)).mean()
        left = hsv[300:600, 100:520, 2].mean()
        right = hsv[300:600, 1060:1400, 2].mean()
        btn = hsv[650:735, 630:980]
        lime = ((btn[:, :, 0] >= 36) & (btn[:, :, 0] <= 62) & (btn[:, :, 1] >= 150) & (btn[:, :, 2] >= 170)).mean()
        if not (pale >= 0.35 and left < 120 and right < 120 and lime >= 0.25):
            return False
        b, g, r = [img[655:735, 830:945, i].astype(int) for i in range(3)]
        if ((r > 170) & (g < 90) & (b < 130)).mean() < 0.05:                # the Skip button carries a gem
            return False
        res = cv2.matchTemplate(img[100:260, 900:1100], fac.CLOSE_X_TEMPLATE, cv2.TM_CCOEFF_NORMED)
        return float(res.max()) >= 0.8
    except Exception:                                  # noqa: BLE001
        return False


def _close_grow_card_if_open(img, stop_flag=None):
    """Close the grow-timer card with its X (never Skip) so the run can go on."""
    if is_grow_timer_card(img):
        log("Garden: a crop's grow-timer card is open (the plot is still growing) -- closing it with its X; Skip is never touched.")
        close_any_open_panel(quiet=True, thorough=True)
        interruptible_sleep(0.8, stop_flag)


def _garden_confirmed(img, strict=True):
    """pass 56/57: the plots are on screen -- the old Garden picture matches, or at least 3 crop plots are visible.
    strict=False (right after a crop ingredient's "Grow X on your Garden Plot" tooltip): the plain map or the plant bar,
    with no station panel / Orders board on top, also counts."""
    try:
        _, conf = find_garden(img)
        if conf >= MATCH_THRESHOLD:
            return True, conf
        if is_grow_timer_card(img):                     # pass 65: the card only opens at the plots
            return True, conf
        import event_orders
        if len(event_orders.plot_points(img)) >= 3:
            return True, conf
        if not strict and not of.panel_is_open(img) and (event_orders.bar_is_open(img) or event_orders.hud_is_bright(img)):
            return True, conf
        return False, conf
    except Exception:                                  # noqa: BLE001
        return False, 0.0


def _trace_picture(tag, note):
    try:                                               # pass 57: a read-only picture of a failed trip
        import run_trace
        run_trace.fail_picture(tag, note)
    except Exception:                                  # noqa: BLE001
        pass


_RECIPE_CROPS = None


def _dish_has_crop(name):
    """True when recipes.json lists a crop among the dish's ingredients (a good gateway to the Garden Plot)."""
    global _RECIPE_CROPS
    if _RECIPE_CROPS is None:
        try:
            import json
            d = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "recipes.json"), encoding="utf-8"))
            items = d.get("items", d)
            _RECIPE_CROPS = {k: any(i[0] in CROP_INGREDIENT_NAMES or i[0] == "sugar" for i in (v.get("ingredients") or []))
                             for k, v in items.items() if isinstance(v, dict)}
        except Exception:                              # noqa: BLE001
            _RECIPE_CROPS = {}
    return bool(_RECIPE_CROPS.get(name))


SCAN_MAX_ITEMS = 20                 # 11/9: never scan more red items than a board can hold (the silent-stall loop)


def travel_via_orders_board(stop_flag=None, max_trips=ORDERS_BOARD_MAX_TRIPS):
    """Fast-travels to the Garden Plot through the Orders board -- never by searching the map.
    1. A red item that is NOT a known dish is a raw-crop item: its "?" goes straight to the plots.
    2. Otherwise (pass 56) a red MADE DISH is a gateway: its "?" opens the station panel, where a crop ingredient's
       "?" ("Grow X on your Garden Plot") goes to the plots (garden_from_station_panel). Dishes with a crop in
       their recipe are tried first.
    Returns True only when the plots are confirmed on screen (_garden_confirmed). Never taps Serve / trash / gem buttons;
    a gem-buy dialog is declined by find_no_button."""
    import find_and_center as fac
    tried = []
    trips = 0
    close_any_open_panel(quiet=True, thorough=True)
    fac.dismiss_error_dialog()
    while trips < max_trips:
        check_stop(stop_flag)
        if not _open_orders_board(stop_flag):
            log("Orders route: could not open the Orders board.")
            return False
        of.reset_orders_scroll(stop_flag)
        of.wait_for_screen_stable(stop_flag)
        raw, gateways, on_page = None, [], 0
        scan_skip = list(tried)
        for page in (0, 1):
            if page == 1:
                of.swipe_to_far_end(stop_flag)
                of.wait_for_screen_stable(stop_flag)
            img = screenshot()
            on_page = page
            seen_locs = set()
            for _scan in range(SCAN_MAX_ITEMS):
                item = of.find_missing_item(img, skip_slots=scan_skip)
                if item is None:
                    break
                # 11/9 (Muse: 10 SILENT STALLS of 15-25 min right after "plot round start"): a card cut off at the board
                # edge has no header signature, the skip list can never match it, and this loop got the same card back
                # forever -- no log, no new screenshot -- until the 30-min auto restart. Same spot twice = done.
                loc = tuple(item.get("tap_loc") or ())
                if loc in seen_locs:
                    break
                seen_locs.add(loc)
                scan_skip.append(item["slot_key"])
                ident = of.identify_dish(item["icon"])
                if ident is not None:
                    gateways.append((item, ident["name"], page))
                    continue
                raw = item
                break
            if raw is not None:
                break
        candidate, via, cand_page = raw, None, on_page
        if candidate is None and gateways:
            gateways.sort(key=lambda g: 0 if _dish_has_crop(g[1]) else 1)
            candidate, via, cand_page = gateways[0][0], gateways[0][1], gateways[0][2]
        if candidate is None:
            log("Orders route: no red item on the Orders board to travel from.")
            close_any_open_panel(quiet=True, thorough=True)
            return False
        tried.append(candidate["slot_key"])
        trips += 1
        if cand_page != on_page:                                    # pass 71: the item was seen on another page than the one now showing
            log(f"Orders route: that item is on board page {cand_page + 1} but page {on_page + 1} is showing -- scrolling back first.")
            of.reset_orders_scroll(stop_flag)
            of.wait_for_screen_stable(stop_flag)
        if via:
            log(f"Orders route: no raw-crop item -- using the red '{via}' at {candidate['tap_loc']} as a gateway "
                f"(trip {trips}/{max_trips}): its station panel, then a crop ingredient's quick-travel '?'.")
        else:
            log(f"Orders route: trying unidentified red item at {candidate['tap_loc']} "
                f"(trip {trips}/{max_trips}) -- tapping it and its quick-travel '?'.")
        if not of.travel_to_missing_item(candidate, stop_flag):
            no_loc, _ = of.find_no_button(screenshot())
            if no_loc is not None:
                log("Orders route: a gem-buy dialog appeared instead -- declining (No).")
                tap(*no_loc)
                interruptible_sleep(1, stop_flag)
            close_any_open_panel(quiet=True, thorough=True)
            continue
        # arrived somewhere -- are the plots on screen?
        conf = 0.0
        for _ in range(3):
            interruptible_sleep(1.0, stop_flag)
            shot = screenshot()
            ok, conf = _garden_confirmed(shot)
            if ok:
                log(f"Orders route: the Garden Plot is on screen after quick-travel (match {conf:.2f}).")
                _close_grow_card_if_open(shot, stop_flag)
                return True
        if of.panel_is_open(screenshot()):
            log(f"Orders route: landed on a station panel (Garden match {conf:.2f}) -- "
                "following one of its crop ingredients to the plots instead.")
            if garden_from_station_panel(stop_flag):
                return True
        log(f"Orders route: that trip did not reach the Garden Plot (best Garden match {conf:.2f}) -- clearing any panel and trying the next one.")
        close_any_open_panel(quiet=True, thorough=True)
    log(f"Orders route: gave up after {trips} trip(s).")
    return False


def travel_via_pig_pen(stop_flag=None):
    """Original route: find Pig Pen, open its panel, tap the carrot ingredient and its
    quick-travel '?'. Returns True if travel was triggered, False otherwise."""
    loc, conf = find_and_center(pig_pen_check.find_pig_pen, label="Pig Pen", stop_flag=stop_flag)
    if loc is None:
        log("Pig Pen not found -- can't reach Garden Plot via the quick-travel shortcut. Giving up this run.")
        return False
    log(f"Pig Pen located and centered at {loc} (confidence {conf:.2f}) -- using it as the Garden Plot shortcut.")

    check_stop(stop_flag)
    tap(*loc)
    interruptible_sleep(1, stop_flag)
    img = screenshot()

    # No longer gated on carrot_insufficient() -- per the user's request
    # 9/26, Garden Plot upkeep (harvest + replant, capped at
    # MAX_CARROTS_PER_RUN) now runs every time regardless of whether
    # Pig Pen's own recipe currently needs carrots. Tapping the carrot icon
    # while it happens to be green (sufficient) may not produce a travel
    # tooltip -- if so this gives up this run and retries next cycle.
    log(f"Carrot insufficient: {carrot_insufficient(img)} (informational -- no longer gates this run).")
    tap(*CARROT_ICON_LOC)
    interruptible_sleep(0.3, stop_flag)
    img = screenshot()
    q_loc, q_conf = find_question_button(img, retry=1)
    if q_loc is None:
        log(f"No quick-travel '?' tooltip found after tapping the carrot icon "
            f"(best match {q_conf:.2f}) -- tooltip timing missed or something else "
            "appeared. Giving up this run rather than tapping blind.")
        tap(1541, 124)  # close Pig Pen panel, best-effort
        return False
    log(f"Quick-travel '?' found at {q_loc} (confidence {q_conf:.2f}) -- tapping it.")
    tap(*q_loc)
    interruptible_sleep(1, stop_flag)
    return True


def main(stop_flag=None, min_stock=None):
    log("=== garden run start ===")
    try:
        close_any_open_panel(thorough=True)

        traveled = False
        if USE_ORDERS_BOARD_TRAVEL:
            traveled = travel_via_orders_board(stop_flag)
            if not traveled:
                log("Orders route did not reach the Garden Plot -- falling back to the Pig Pen route.")
        if not traveled and not USE_PIG_PEN_FALLBACK:
            log("No fast-travel route to the Garden Plot from the menu this cycle -- NOT searching the map; trying again next cycle.")
            log("=== garden run end (no menu route) ===")
            return
        if not traveled:
            if not travel_via_pig_pen(stop_flag):
                log("=== garden run end (could not travel) ===")
                return

        img = screenshot()
        _, confirm_conf = find_garden(img)
        log(f"Post-travel Garden Plot confirmation confidence: {confirm_conf:.2f} (informational only).")

        harvested_locs = harvest_ready_carrots(stop_flag=stop_flag, max_harvests=MAX_CARROTS_PER_RUN)
        if harvested_locs:
            # Open the plant bar at the first harvested (now-empty) plot,
            # then hand off to restock_all_crops() -- built 9/29 per the
            # user's design, replacing the old Carrot-only replant_carrots()
            # for this call site. restock_all_crops() itself sweeps every
            # crop to RESTOCK_MIN_STOCK across as many of the harvested
            # plots as it can, closing the bar on its own once no empty
            # plots remain; replant_carrots() is left in the module,
            # unused here, in case a Carrot-only path is ever needed again.
            check_stop(stop_flag)
            tap(*harvested_locs[0])
            interruptible_sleep(0.8, stop_flag)
            img = screenshot()
            if of.plant_bar_is_open(img):
                planted = restock_all_crops(stop_flag=stop_flag, min_stock=min_stock or RESTOCK_MIN_STOCK)
                log(f"restock_all_crops planted {planted} crop(s) this run.")
                close_plant_bar(stop_flag=stop_flag)
            else:
                log(f"Plant bar didn't open after tapping harvested plot at {harvested_locs[0]} "
                    "-- skipping restock this run rather than guessing further.")

        log("=== garden run end ===")
    except StopRequested:
        log("=== garden run stopped early by user ===")
        raise


def tend_plots(stop_flag=None, min_stock=None, rounds=3, targets=None):
    """10/22 (owner, "plant empty plots while waiting"): the 8-h clipboard run had 9 of 10 plots empty for hours.
    Go to the Garden Plot (Orders-board route, never a map search), walk the plots -- ready crops are harvested,
    growing ones are left alone (their timer card is closed, never Skip) -- and when an empty plot opens the plant
    bar, plant from stock with restock_all_crops (Free seeds / stock only, gem dialogs declined). Returns
    (harvested, planted)."""
    import event_orders as eo
    harvested = planted = 0
    log("[plots] plot round start (orders are waiting)"
        + (f" -- planting up to: {', '.join(f'{k} {v}' for k, v in sorted(targets.items()))}" if targets else ""))
    try:
        if not travel_via_orders_board(stop_flag):
            log("[plots] no route to the Garden Plot from the Orders board this time -- skipped.")
            return 0, 0
        for _r in range(rounds):
            check_stop(stop_flag)
            kind, found = eo.sweep_plots(stop_flag, max_taps=10)
            harvested += getattr(eo, "LAST_SWEEP_HARVESTED", 0) or 0
            if kind != "plot":
                break
            n = restock_all_crops(stop_flag=stop_flag, min_stock=min_stock or RESTOCK_MIN_STOCK, targets=targets)
            planted += n
            close_plant_bar(stop_flag=stop_flag)
            if n == 0:
                break
        close_any_open_panel(quiet=True, thorough=True)
        log(f"[plots] plot round done: harvested {harvested}, planted {planted}.")
    except StopRequested:
        log("[plots] plot round stopped early by user")
        raise
    return harvested, planted


if __name__ == "__main__":
    main()
