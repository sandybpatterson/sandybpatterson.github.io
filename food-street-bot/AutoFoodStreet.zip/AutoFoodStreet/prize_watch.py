"""Prize-ready watcher (10/10). READ-ONLY: looks at one screenshot, never taps.

A time-limited event icon in the bottom bar (the Food Club event shoes, the globe event, the Chef Challenge hat)
wears a green CHECKMARK (and a blue count bubble) when something is ready to collect. check() finds those checks
by template (templates/nav_ready_check.png; real checks score 0.89-1.0 on saved screens, everything else <= 0.5),
logs `PRIZE READY: <icon>` when one appears and `PRIZE cleared` when it goes, and keeps READY for other code.
Only on a plain map (the white Orders clipboard is bright), so popups/panels never count.
"""
import os
import time

import cv2
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE, "run_log.txt")
TEMPLATE = cv2.imread(os.path.join(BASE, "templates", "nav_ready_check.png"))
REGION = (730, 895, 900, 1480)              # y1, y2, x1, x2 of the bottom icon bar
THRESHOLD = 0.75
SCALES = (0.8, 0.9, 1.0, 1.1, 1.2)
CHECK_GAP_SEC = 120
# nearest-icon names for the current bar layout (icon x centres); anything else is logged as "icon at x"
ICON_NAMES = ((1055, "street Food Truck (gold tickets)"), (1210, "Chef Challenge (blue tickets)"), (1367, "globe event"))   # layout as of 10/10 (it changes with events)

READY = {}                                  # name -> (x, y, confidence) of the checks seen on the last look
_next_check = 0.0


def log(msg):
    line = f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] [prize] {msg}"
    print(line)
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def plain_map(img):
    return img is not None and img.shape[:2] == (900, 1600) and \
        float(np.percentile(cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2GRAY), 90)) >= 240


def icon_name(x):
    best = min(ICON_NAMES, key=lambda n: abs(n[0] - x))
    return best[1] if abs(best[0] - x) <= 70 else f"icon at x={x}"


def find_checks(img):
    """[(name, x, y, confidence)] for every ready-check in the bottom bar ([] unless it is a plain map)."""
    if TEMPLATE is None or not plain_map(img):
        return []
    y1, y2, x1, x2 = REGION
    reg = img[y1:y2, x1:x2]
    cands = []
    for s in SCALES:
        t = cv2.resize(TEMPLATE, None, fx=s, fy=s)
        res = cv2.matchTemplate(reg, t, cv2.TM_CCOEFF_NORMED)
        while True:
            _, v, _, loc = cv2.minMaxLoc(res)
            if v < THRESHOLD:
                break
            cands.append((float(v), loc[0] + x1 + t.shape[1] // 2, loc[1] + y1 + t.shape[0] // 2))
            res[max(0, loc[1] - 20):loc[1] + 20, max(0, loc[0] - 20):loc[0] + 20] = -1
    found = []
    for v, cx, cy in sorted(cands, reverse=True):           # best match first; one hit per icon
        if not any(abs(cx - f[1]) < 50 for f in found):
            found.append((icon_name(cx), cx, cy, v))
    return found


def check(img=None, force=False):
    """Look once (at most every CHECK_GAP_SEC); log appearances / disappearances. Returns the READY dict."""
    global _next_check
    if not force and time.time() < _next_check:
        return READY
    _next_check = time.time() + CHECK_GAP_SEC
    try:
        if img is None:
            import adb_helper
            img = adb_helper.screenshot()
        if not plain_map(img):
            return READY                     # popup / panel on screen -- keep what we knew
        now = {n: (x, y, c) for n, x, y, c in find_checks(img)}
    except Exception as e:                   # noqa: BLE001
        log(f"look failed (ignored): {e}")
        return READY
    for n, (x, y, c) in now.items():
        if n not in READY:
            log(f"PRIZE READY: {n} has a green check at ({x},{y}) (match {c:.2f}) -- something is ready to collect there.")
    for n in list(READY):
        if n not in now:
            log(f"PRIZE cleared: {n} no longer shows a check.")
    READY.clear()
    READY.update(now)
    return READY


# --- 11/14 (owner: "yes build the prize collecting"): tap a READY icon and take what it offers -- free reward buttons
# only (find_and_center.dismiss_error_dialog: Collect / Claim / OK, never gems / buy / unlock); a buy or gem question
# -> No; then close whatever is left. Pictures before/after in templates/tests/*_prize_*.jpg (first look at each new
# screen). The Chef Challenge hat is skipped (its own job collects); a tap that opens the Food Club board just closes.
COLLECT_GAP_SEC = 30 * 60
_tried = {}


def _pic(img, tag):
    try:
        d = os.path.join(BASE, "templates", "tests")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, time.strftime("%Y%m%d_%H%M%S") + f"_prize_{tag}.jpg")
        cv2.imwrite(p, img, [cv2.IMWRITE_JPEG_QUALITY, 70])
        return os.path.basename(p)
    except Exception:                                  # noqa: BLE001
        return "?"


def collect(stop=None):
    """Try once per COLLECT_GAP_SEC per ready icon. Returns how many icons were opened."""
    import adb_helper
    import find_and_center as fac
    import order_fulfill as of
    import event_orders as eo
    done = 0
    now = time.time()
    for name, (x, y, _c) in list(READY.items()):
        if "chef" in name.lower() or now - _tried.get(name, 0) < COLLECT_GAP_SEC:
            continue
        _tried[name] = now
        adb_helper.tap(x, y)
        of.interruptible_sleep(2.0, stop)
        img = adb_helper.screenshot()
        if img is None:
            continue
        p1 = _pic(img, "open")
        if eo.board_is_open(img):
            log(f"PRIZE: {name} opened the Food Club board -- nothing to collect here, closing.")
            fac.close_any_open_panel(quiet=True, thorough=True)
            continue
        no, _nc = of.find_no_button(img)
        if no is not None:
            log(f"PRIZE: {name} asked a buy / gem question -- tapping No.")
            adb_helper.tap(*no)
            continue
        took = 0
        for _ in range(3):
            if not fac.dismiss_error_dialog():
                break
            took += 1
            of.interruptible_sleep(1.5, stop)
        p2 = _pic(adb_helper.screenshot(), "after")
        fac.close_any_open_panel(quiet=True, thorough=True)
        log(f"PRIZE: opened {name} -- tapped {took} free reward button(s); pictures {p1}, {p2}.")
        done += 1
    return done
