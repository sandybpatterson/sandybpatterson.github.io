"""building_finder -- finds an event building (Merchant cart, Oz Stove, Emerald City Stove) on a map screenshot by SIFT features.

SIDE PROJECT (not wired into the bot). Why: after a quick-travel the bot taps the screen CENTRE to open the station. Ten times in 70
minutes (10/6) the centre was a neighbour (garden bed, Dairy, the wrong stove) and the bot gave up with `unsure`; and when no board
slot is a Merchant item the Merchant stocker cannot route at all. A finder that returns WHERE the building actually is lets the bot
tap it directly: find (x, y) -> tap -> check the panel.

Method: SIFT keypoints of a saved crop of the building; ratio-test matches against the live frame; RANSAC homography; the building
centre is the homography image of the crop's centre. A match is accepted only with enough inliers AND a sane transform
(scale 0.6..1.6, no flip, centre on screen), so a frame without the building returns None instead of a wrong place.
"""
import os

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(HERE, "building_templates")
MIN_INLIERS = 42                         # real hits on 467 saved frames: 47-308 inliers; the two false hits (station panels) had 27 and 37
# the live look of the cart is a clean, specific picture: on 450 other saved screens it never reached 15 inliers, while real live frames
# score 21-64 (41 and 43 were seen at the bar of 42) -- so it gets a lower bar than the generic templates
MIN_BY_TEMPLATE = {"merchant_live": 20, "merchant_top": 16}
# merchant_top = the umbrella + Dorothy + cart top only (cut from a frame where a row of finished bottles covers the lower cart): real frames
# 20-96 inliers, 420 other saved screens never above 9. Its tap point is the cart body, not the template centre (template pixel coords).
ANCHORS = {"merchant_top": (415, 205)}
RATIO = 0.75
_sift = None
_cache = {}


def _get_sift():
    global _sift
    if _sift is None:
        _sift = cv2.SIFT_create(nfeatures=2500)
    return _sift


def features(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    kp, des = _get_sift().detectAndCompute(gray, None)
    return kp, des


def template(name):
    if name not in _cache:
        img = cv2.imread(os.path.join(TEMPLATE_DIR, name + ".png"))
        if img is None:
            raise FileNotFoundError(name)
        kp, des = features(img)
        _cache[name] = (img.shape[:2], kp, des)
    return _cache[name]


def frame_features(img, hud_top=95, hud_bottom=770):
    mask = np.zeros(img.shape[:2], np.uint8)
    mask[hud_top:hud_bottom, :] = 255
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    kp, des = _get_sift().detectAndCompute(gray, mask)
    return kp, des


# several looks of the same building (the game's zoom / the cart's contents / the camera differ between sessions): a building name maps
# to every template that shows it, and the best match wins
ALIASES = {"merchant": ["merchant_live", "merchant_top", "merchant"]}


def find(img, name, hud_top=95, hud_bottom=770, frame=None):
    """(x, y, inliers) of the best match among the building's templates, or None."""
    fr = frame if frame is not None else frame_features(img, hud_top, hud_bottom)
    best = None
    for tn in ALIASES.get(name, [name]):
        r = _find_one(img, tn, hud_top, hud_bottom, fr)
        if r is not None and (best is None or r[2] > best[2]):
            best = r
    return best


def _find_one(img, name, hud_top, hud_bottom, frame):
    """(x, y, inliers) of one template on the frame, or None. The fixed HUD bands (top bar, bottom nav) are ignored."""
    (th, tw), tkp, tdes = template(name)
    kp, des = frame
    if des is None or tdes is None or len(kp) < 8 or len(tkp) < 8:
        return None
    matches = cv2.BFMatcher().knnMatch(tdes, des, k=2)
    good = [m for m, n in (p for p in matches if len(p) == 2) if m.distance < RATIO * n.distance]
    need = MIN_BY_TEMPLATE.get(name, MIN_INLIERS)
    if len(good) < need:
        return None
    src = np.float32([tkp[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
    dst = np.float32([kp[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
    H, inl = cv2.findHomography(src, dst, cv2.RANSAC, 6.0)
    if H is None or inl is None:
        return None
    n_in = int(inl.sum())
    if n_in < need:
        return None
    # sane transform: roughly a scale + shift (no strong shear or flip)
    a, b, c, d = H[0, 0], H[0, 1], H[1, 0], H[1, 1]
    scale = (abs(a * d - b * c)) ** 0.5
    if not (0.6 <= scale <= 1.6) or a <= 0 or d <= 0 or abs(b) > 0.5 or abs(c) > 0.5:
        return None
    ax, ay = ANCHORS.get(name, (tw / 2.0, th / 2.0))
    centre = cv2.perspectiveTransform(np.float32([[[ax, ay]]]), H)[0, 0]
    x, y = float(centre[0]), float(centre[1])
    if not (0 <= x < img.shape[1] and hud_top <= y < hud_bottom):
        return None
    return x, y, n_in


def find_all(img, names=("merchant", "oz_stove", "emerald_stove")):
    fr = frame_features(img)
    return {n: find(img, n, frame=fr) for n in names}


def make_templates():
    """Cut the three templates from the saved live captures (run once; the crops are kept in building_templates/)."""
    base = os.path.dirname(HERE)
    os.makedirs(TEMPLATE_DIR, exist_ok=True)
    d1 = cv2.imread(os.path.join(base, "event_pdf_extract", "storybook", "diag_1.png"))
    r1 = cv2.imread(os.path.join(base, "event_pdf_extract", "storybook", "run_1_after.png"))
    crops = {"merchant": d1[340:840, 880:1390], "oz_stove": r1[70:440, 550:1060], "emerald_stove": r1[290:760, 985:1260]}
    for n, c in crops.items():
        cv2.imwrite(os.path.join(TEMPLATE_DIR, n + ".png"), c)
    return list(crops)


if __name__ == "__main__":
    print(make_templates())
