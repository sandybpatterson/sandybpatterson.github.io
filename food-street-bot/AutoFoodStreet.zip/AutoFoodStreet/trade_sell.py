"""trade_sell.py -- sell EXTRA items through the My Trades screen (built 10/14, live-tested by selling 1 tomato soup).

Rules (owner): coins only, NEVER gems; always sell at the MAX price (press-and-hold the price "+" until it stops rising);
only items on the SELLABLE whitelist; never the Unlock slot (20 gems), never Remove (costs gems), never a friend's / world card.
Everything is found by picture, nothing by blind coordinates except the fixed buttons that were measured on live 1600x900 captures:
  Trades icon (480,820) | close X (1527,130) | slots y=360, x = 125/377/630/883 | slot 5 (x~1135) is the gem UNLOCK -- never touched
  picker: tabs pantry (635,300) / fridge (635,520), item tiles in the left panel, quantity + (1503,513), price + (1503,662), Put on Sale (1335,822).
Counts on the tiles are read with a small self-trained digit set (templates/tile_digits); an unreadable count means NO sale.
"""
import datetime
import glob
import os
import time

import cv2
import numpy as np

from adb_helper import screenshot, tap, swipe
from find_and_center import check_stop, interruptible_sleep

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(BASE_DIR, "run_log.txt")
UI_DIR = os.path.join(BASE_DIR, "templates", "trade_ui")
TILES_DIR = os.path.join(BASE_DIR, "templates", "trade_tiles")
DIGITS_DIR = os.path.join(BASE_DIR, "templates", "tile_digits")
DIGITS_PENDING = os.path.join(BASE_DIR, "templates", "tile_digits_pending")

TRADES_ICON = (480, 820)
CLOSE_X = (1527, 130)
SLOT_X = (125, 377, 630, 883)
SLOT_Y = 360
TABS = {"pantry": (635, 300), "fridge": (635, 520)}
QTY_PLUS = (1503, 513)
PRICE_PLUS = (1503, 662)
PUT_ON_SALE = (1335, 822)
PRICE_BOX = (1250, 625, 1450, 705)             # x1,y1,x2,y2 of the price number (compared as a picture, not read)
PREVIEW_BOX = (1190, 210, 1480, 440)
PANEL_W = 566                                  # the item list occupies x 0..566
SCROLL_DRAG = ((280, 800), (280, 250), 1800)
# what may be sold, and which tab it lives on (first tab tried first)
SELLABLE = {"fish": ("fridge", "pantry"), "seaweed": ("fridge", "pantry"), "tomato_soup": ("fridge",),
            # 10/25 (owner): crops that grow in under 10 min may be sold when the Pantry is full -- NEVER saws
            "wheat": ("pantry",), "corn": ("pantry",), "tomato": ("pantry",), "cabbage": ("pantry",),
            "apple_juice": ("fridge",),                     # 10/25 (owner): Sell Apple Juice test
            # 10/29 (owner): "you can sell other crops like apples and lemons if need be, as long as you can harvest them"
            "apple": ("pantry",), "lemon": ("pantry",),
            # 10/30 (owner): "prep work can sell crops, fruit, beans etc to free up storage"
            "garlic": ("pantry",), "rice": ("pantry",), "coffee_bean": ("pantry",), "sugar_cane": ("pantry",),
            "onion": ("pantry",), "carrot": ("pantry",), "mushroom": ("pantry",), "strawberry": ("pantry",),
            # 11/15 (owner, Busy Mode: "sell anything that takes less than 15 minutes to make"): dishes with a tile
            # (templates/trade_tiles, cut from the stock-take tiles) -- never saws, tools or deeds
            "bacon": ("fridge", "pantry"), "caprese_salad": ("fridge", "pantry"), "chicken_drumstick": ("fridge", "pantry"),
            "coffee_latte": ("fridge", "pantry"), "cream_of_mushroom": ("fridge", "pantry"), "espresso": ("fridge", "pantry"),
            "grilled_fish": ("fridge", "pantry"), "pancakes": ("fridge", "pantry"), "ham": ("fridge", "pantry"),
            "salad_nicoise": ("fridge", "pantry"), "veggie_juice": ("fridge", "pantry")}
FRUIT_RELIEF = ("apple", "lemon")                        # pantry relief tries these after the quick crops
MORE_RELIEF = ("onion", "carrot", "garlic", "strawberry", "coffee_bean", "sugar_cane", "mushroom", "rice")  # then these
QUICK_CROPS = ("wheat", "corn", "tomato", "cabbage")     # grow 45 s / 2 m / 3 m / 7 m (recipes.json)
RELIEF_MAX = 5                                           # at most this many of one crop per relief sale


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] [trade] {msg}\n")
    except OSError:
        pass
    try:
        print(f"[{ts}] [trade] {msg}")
    except (AttributeError, OSError):
        pass


def _imread(folder, name):
    return cv2.imread(os.path.join(folder, name))


def _best(img, tmpl, region=None):
    """(score, x, y centre) of the best TM_CCOEFF_NORMED match of tmpl inside region (x1,y1,x2,y2)."""
    x1, y1, x2, y2 = region or (0, 0, img.shape[1], img.shape[0])
    sub = img[y1:y2, x1:x2]
    if tmpl is None or sub.shape[0] < tmpl.shape[0] or sub.shape[1] < tmpl.shape[1]:
        return 0.0, None, None
    r = cv2.matchTemplate(sub, tmpl, cv2.TM_CCOEFF_NORMED)
    _, mv, _, ml = cv2.minMaxLoc(r)
    return float(mv), x1 + ml[0] + tmpl.shape[1] // 2, y1 + ml[1] + tmpl.shape[0] // 2


# ---------------------------------------------------------------------------------------------
# screens
# ---------------------------------------------------------------------------------------------

def plain_map(img):
    v = cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2]
    return float(np.percentile(v, 90)) >= 240


def trades_open(img):
    s, _, _ = _best(img, _imread(UI_DIR, "my_trades_title.png"), (560, 100, 820, 180))
    return s >= 0.8 and not picker_open(img)       # the faint title behind the item picker does not count


def picker_open(img):
    s, _, _ = _best(img, _imread(UI_DIR, "put_on_sale_btn.png"), (1090, 760, 1580, 890))
    return s >= 0.8


def open_trades(stop_flag=None):
    """Plain map -> My Trades. The screen first shows a loading splash (it fetches from the server)."""
    img = screenshot()
    if trades_open(img):
        return True
    # 10/26 live: a station panel (red X at 1541,122) was still open -- plain_map only looks at the bottom-right
    # corner, which stays bright behind a panel, so the Trades tap landed on the panel and nothing happened.
    try:
        from find_and_center import close_any_open_panel
        if close_any_open_panel(quiet=True):
            log("open_trades: closed a leftover panel first.")
            interruptible_sleep(1.0, stop_flag)
            img = screenshot()
            if trades_open(img):
                return True
    except Exception as e:                          # noqa: BLE001
        log(f"open_trades: panel check failed (ignored): {e!r}")
    if not plain_map(img):
        log("open_trades: the screen is not a plain map view -- not tapping the Trades icon.")
        return False
    tap(*TRADES_ICON)
    t0 = time.time()
    last = None
    while time.time() - t0 < 50:                    # 10/26 live: 30 s was not enough once (server loading splash)
        interruptible_sleep(2.0, stop_flag)
        last = screenshot()
        if trades_open(last):
            return True
    log("open_trades: My Trades never showed (50 s) -- picture saved to templates/fail_pictures.")
    try:
        if last is not None:
            d = os.path.join(BASE_DIR, "templates", "fail_pictures")
            os.makedirs(d, exist_ok=True)
            cv2.imwrite(os.path.join(d, f"{int(time.time())}_trades_not_open.png"), last)
    except Exception:                               # noqa: BLE001
        pass
    return False


def close_trades(stop_flag=None):
    def closed(im):          # the pale Friends strip on the Trades screen also reads "bright" in the corner, so check the title too
        return plain_map(im) and not trades_open(im) and not picker_open(im)
    for _ in range(3):
        img = screenshot()
        if closed(img):
            return True
        tap(*CLOSE_X)
        interruptible_sleep(1.8, stop_flag)
    return closed(screenshot())


def _hud_coins(img):
    try:
        import coin_digits
        r = coin_digits.read_hud(img) if img is not None else None
        return (r or {}).get("coins")
    except Exception:                               # noqa: BLE001
        return None


def collect_sold(stop_flag=None):
    """Taps every 'Sold!' card (free coins). Returns how many."""
    n = 0
    sold = _imread(UI_DIR, "sold_banner.png")
    for _ in range(5):
        img = screenshot()
        s, x, y = _best(img, sold, (0, 290, 1010, 450))
        if s < 0.8:
            break
        log(f"collecting a sold card at ({x},{y}) (match {s:.2f})")
        before = _hud_coins(img)
        tap(x, y)
        interruptible_sleep(2.0, stop_flag)
        n += 1
        after = _hud_coins(screenshot())                 # 10/26 Muse: say what each sold card paid
        if before is not None and after is not None:
            log(f"sold card collected: coins {before} -> {after} ({after - before:+d})")
    return n


def free_slots(img):
    """Indexes of empty 'Create a sale' slots."""
    t = _imread(UI_DIR, "create_sale.png")
    out = []
    for i, x in enumerate(SLOT_X):
        s, _, _ = _best(img, t, (x - 110, 310, x + 110, 440))
        if s >= 0.8:
            out.append(i)
    return out


# ---------------------------------------------------------------------------------------------
# tile counts (small self-trained digit set)
# ---------------------------------------------------------------------------------------------
_DIGIT_CACHE = {}


def _digit_templates():
    if not _DIGIT_CACHE:
        for p in glob.glob(os.path.join(DIGITS_DIR, "*.png")):
            d = os.path.basename(p)[:-4].split("__")[0]
            g = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
            if g is not None:
                _DIGIT_CACHE.setdefault(d, []).append(g.astype(np.float32))
    return _DIGIT_CACHE


def _glyphs(img, box):
    """Dark-ink glyphs inside box (x1,y1,x2,y2), left to right, each normalised to a 28x28 picture."""
    x1, y1, x2, y2 = box
    g = cv2.cvtColor(img[y1:y2, x1:x2], cv2.COLOR_BGR2GRAY)
    mask = (g < 100).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    comps = [st[i] for i in range(1, n) if st[i][4] >= 40 and st[i][3] >= 14]
    comps.sort(key=lambda c: c[0])
    out = []
    for x, y, w, h, _a in comps:
        crop = mask[y:y + h, x:x + w] * 255
        s = 24.0 / h
        r = cv2.resize(crop, (max(1, int(round(w * s))), 24), interpolation=cv2.INTER_AREA)
        canvas = np.zeros((28, 28), np.uint8)
        ox = max(0, (28 - r.shape[1]) // 2)
        canvas[2:26, ox:ox + min(28, r.shape[1])] = r[:, :28]
        out.append(canvas)
    return out


def tile_box(x, y):
    """The count box of a tile whose icon-crop centre is (x, y)."""
    return (x + 22, y + 26, x + 82, y + 80)


def read_number(img, box, save_unknown=True):
    """The tile's count: the picker's own digit shapes first, then the station stock-box shapes (stock_digits, 0-9).
    10/25 live: pantry relief 'could not read the stock count' for tomato + cabbage -- templates/tile_digits lives only
    on the PC and lacks digits. stock_digits.read_box read all 34 counts on the saved picker pages right."""
    n = _read_number_own(img, box, save_unknown)
    if n is not None:
        return n
    # 10/29: wheat / corn / apple / lemon "could not read the stock count" -- the snapped box sat a few px high and cut
    # the top of the digit. Try the box nudged down too; take a number only when every read that worked agrees.
    try:
        import stock_digits
        x1, y1, x2, y2 = box
        reads = set()
        for dy in (0, 6, 12, 18):
            for dx in (0, -12):
                r = stock_digits.read_box(img[y1 + dy:y2 + dy, max(0, x1 + dx):x2 + dx])
                if r is not None:
                    reads.add(r)
        return reads.pop() if len(reads) == 1 else None
    except Exception:                                   # noqa: BLE001
        return None


def _read_number_own(img, box, save_unknown=True):
    """Reads the dark number inside box. Returns an int, or None when any glyph is not confidently one of the trained digits."""
    tpl = _digit_templates()
    gl = _glyphs(img, box)
    if not gl or len(gl) > 3:
        return None
    digits = ""
    for g in gl:
        gf = g.astype(np.float32)
        scores = sorted(((float(cv2.matchTemplate(gf, t, cv2.TM_CCOEFF_NORMED).max()), d)
                         for d, ts in tpl.items() for t in ts), reverse=True)
        best = scores[0] if scores else (0.0, None)
        second = next((s for s, d in scores[1:] if d != best[1]), 0.0)
        if best[1] is None or best[0] < 0.8 or best[0] - second < 0.05:
            if save_unknown:
                try:
                    os.makedirs(DIGITS_PENDING, exist_ok=True)
                    cv2.imwrite(os.path.join(DIGITS_PENDING, f"{int(time.time() * 1000)}.png"), g)
                except OSError:
                    pass
            return None
        digits += best[1]
    return int(digits) if digits else None


def train_digit(label, glyph):
    os.makedirs(DIGITS_DIR, exist_ok=True)
    k = len(glob.glob(os.path.join(DIGITS_DIR, f"{label}*.png")))
    cv2.imwrite(os.path.join(DIGITS_DIR, f"{label}.png" if k == 0 else f"{label}__{k}.png"), glyph)
    _DIGIT_CACHE.clear()


# ---------------------------------------------------------------------------------------------
# picker
# ---------------------------------------------------------------------------------------------

def _tile_templates():
    out = {}
    for p in glob.glob(os.path.join(TILES_DIR, "*.png")):
        name = os.path.basename(p)[:-4]
        if not name.startswith("ref_"):
            out[name] = cv2.imread(p)
    return out


def _sift_refs():
    return {os.path.basename(p)[4:-4]: cv2.imread(p) for p in glob.glob(os.path.join(TILES_DIR, "ref_*.png"))}


def _sift_match(a, b, min_inliers=12):
    """(inliers, centre of a inside b) -- SIFT + RANSAC between two pictures of the same art at different scales."""
    sift = cv2.SIFT_create()
    ga, gb = cv2.cvtColor(a, cv2.COLOR_BGR2GRAY), cv2.cvtColor(b, cv2.COLOR_BGR2GRAY)
    ka, da = sift.detectAndCompute(ga, None)
    kb, db = sift.detectAndCompute(gb, None)
    if da is None or db is None or len(ka) < 4 or len(kb) < 4:
        return 0, None
    good = []
    for m_n in cv2.BFMatcher().knnMatch(da, db, k=2):
        if len(m_n) == 2 and m_n[0].distance < 0.75 * m_n[1].distance:
            good.append(m_n[0])
    if len(good) < 4:
        return len(good), None
    src = np.float32([ka[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
    dst = np.float32([kb[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
    H, inl = cv2.findHomography(src, dst, cv2.RANSAC, 5.0)
    n = int(inl.sum()) if inl is not None else 0
    if H is None or n < min_inliers:
        return n, None
    c = cv2.perspectiveTransform(np.float32([[[a.shape[1] / 2, a.shape[0] / 2]]]), H)[0, 0]
    return n, (int(c[0]), int(c[1]))


def find_tile(img, name):
    """-> (x, y) centre of the tile showing `name` in the item list, or None. Exact tile picture first; the Boat-panel art (SIFT) as fallback."""
    t = _tile_templates().get(name)
    if t is not None:
        s, cx, cy = _best(img, t, (0, 0, PANEL_W, img.shape[0]))
        if s >= 0.85:                                  # template = icon crop y-78..y+20, maybe with its top trimmed
            # (10/25 crop tiles: top 28 px cut off the stock-take sheet). 10/26: the sheet-cut tiles sit ~22 px off the
            # real grid, so the count box missed the number ("could not read the stock count") -- snap to the grid.
            return _snap_to_tile(img, (int(cx), int(cy + t.shape[0] // 2 - 20)))
    ref = _sift_refs().get(name)
    if ref is not None:
        panel = img[:, :PANEL_W]
        n, c = _sift_match(ref, panel, min_inliers=15)
        if c is not None:
            log(f"{name}: tile found by art match ({n} inliers) near {c} -- snapping to the grid")
            return _snap_to_tile(img, c)
    return None


def _snap_to_tile(img, c):
    """Snap an approximate point to the centre of the nearest tile (columns 97/280/463; rows by the dark digit boxes)."""
    cx = min((97, 280, 463), key=lambda x: abs(x - c[0]))
    # tile rows repeat every 183 px; find the row phase from the strong horizontal tile borders
    strip = cv2.cvtColor(img[:, 20:560], cv2.COLOR_BGR2GRAY).astype(np.float32)
    prof = np.abs(np.diff(strip, axis=0)).mean(axis=1)
    best_phase = max(range(183), key=lambda p: sum(prof[y] for y in range(p, len(prof), 183)))
    row = round((c[1] - 100 - ((best_phase - 17) % 183)) / 183.0)
    return cx, int(100 + ((best_phase - 17) % 183) + row * 183)


def _goto_tab(tab, stop_flag=None):
    tap(*TABS[tab])
    interruptible_sleep(1.5, stop_flag)


def _drag(top_to_bottom, stop_flag=None):
    (x1, y1), (x2, y2), ms = SCROLL_DRAG
    if top_to_bottom:
        swipe(x1, y1, x2, y2, ms)
    else:
        swipe(x2, y2, x1, y1, ms)
    _list_still(stop_flag)                              # 11/1 FLASH step 4: was a fixed 1.8 s (23x = 41 s in 16 min)


LIST_STILL_DIFF = 0.5        # mean pixel change of the list area below which the scroll has stopped
LIST_STILL_MAX_SEC = 1.8


def list_moved(a, b):
    """Pure: mean pixel change of the picker list area (left panel) between two pictures."""
    if a is None or b is None or a.shape != b.shape:
        return 999.0
    return float(np.abs(a[150:860, :PANEL_W].astype(np.int16) - b[150:860, :PANEL_W].astype(np.int16)).mean())


def _list_still(stop_flag=None):
    """Wait until two looks 0.25 s apart show the list standing still (min 0.5 s, max LIST_STILL_MAX_SEC)."""
    t0 = time.time()
    interruptible_sleep(0.5, stop_flag)
    prev = screenshot()
    while time.time() - t0 < LIST_STILL_MAX_SEC:
        interruptible_sleep(0.25, stop_flag)
        cur = screenshot()
        if list_moved(prev, cur) < LIST_STILL_DIFF:
            return
        prev = cur


NUDGE_DRAG = ((280, 700), (280, 400), 900)          # a short, slow drag: the list moves ~300 px, no fling
LOW_ROW_Y = 700                                       # a tile this low may have its count box cut off by the screen edge


def _with_count(name, img, xy, stop_flag, tab):
    """10/29 live: wheat / corn / cabbage sat in the BOTTOM row with their counts below the screen edge -> "could not read
    the stock count". A low tile without a readable count: nudge the list up a little and read it again."""
    cnt = read_number(img, tile_box(*xy))
    if cnt is None and xy[1] > LOW_ROW_Y:
        (x1, y1), (x2, y2), ms = NUDGE_DRAG
        swipe(x1, y1, x2, y2, ms)
        interruptible_sleep(1.5, stop_flag)
        img2 = screenshot()
        xy2 = find_tile(img2, name)
        if xy2 is not None:
            cnt2 = read_number(img2, tile_box(*xy2))
            log(f"{name}: count was below the screen edge -- nudged the list up, read {cnt2}.")
            return {"tab": tab, "xy": xy2, "count": cnt2, "img": img2}
    return {"tab": tab, "xy": xy, "count": cnt, "img": img}


def _scan_down(name, stop_flag, tab):
    prev = None
    for _step in range(8):
        check_stop(stop_flag)
        img = screenshot()
        xy = find_tile(img, name)
        if xy is not None:
            return _with_count(name, img, xy, stop_flag, tab)
        if prev is not None and float(np.abs(img[:, :PANEL_W].astype(np.int16) - prev[:, :PANEL_W].astype(np.int16)).mean()) < 1.0:
            return None                                 # the list did not move: that was the end
        prev = img
        _drag(True, stop_flag)
    return None


def locate_item(name, stop_flag=None):
    """Finds the item's tile in the picker (tabs tried in SELLABLE order, list scrolled to the top then down).
    Returns {"tab", "xy", "count", "img"} or None."""
    for tab in SELLABLE.get(name, ("fridge", "pantry")):
        _goto_tab(tab, stop_flag)
        # 10/29 (owner): the list opens at its top. 11/1 (owner: "still pulling down from the top 3 times"):
        # scan DOWN from the view it opened with; the 3 drags to the top only as a second try when that missed.
        for again in (False, True):
            if again:
                for _ in range(3):
                    _drag(False, stop_flag)            # to the top
            hit = _scan_down(name, stop_flag, tab)
            if hit is not None:
                return hit
    return None


def stock_count(name, stop_flag=None):
    """How many of `name` are in the pantry/fridge (read off the picker tile). None = unknown (never guess).
    Opens and closes the picker and the Trades screen itself."""
    if not open_trades(stop_flag):
        return None
    try:
        collect_sold(stop_flag)
        img = screenshot()
        fr = free_slots(img)
        if not fr:
            log("stock_count: no free sale slot to open the picker with.")
            return None
        tap(SLOT_X[fr[0]], SLOT_Y)
        interruptible_sleep(2.5, stop_flag)
        if not picker_open(screenshot()):
            return None
        hit = locate_item(name, stop_flag)
        tap(*CLOSE_X)                                   # close the picker
        interruptible_sleep(1.5, stop_flag)
        return None if hit is None else hit["count"]
    finally:
        close_trades(stop_flag)


# ---------------------------------------------------------------------------------------------
# selling
# ---------------------------------------------------------------------------------------------

def _price_crop(img):
    x1, y1, x2, y2 = PRICE_BOX
    return img[y1:y2, x1:x2].astype(np.int16)


def set_max_price(stop_flag=None, max_holds=6):
    """Press-and-hold the price '+' until the number stops changing. Returns True once it is stable."""
    prev = _price_crop(screenshot())
    for i in range(max_holds):
        swipe(PRICE_PLUS[0], PRICE_PLUS[1], PRICE_PLUS[0], PRICE_PLUS[1], 4500)
        interruptible_sleep(1.0, stop_flag)
        cur = _price_crop(screenshot())
        if float(np.abs(cur - prev).mean()) < 0.5:
            return True
        prev = cur
    return False


PREVIEW_LOOK_MIN = 0.6
COUNT_PICS = os.path.join(BASE_DIR, "templates", "fail_pictures")


def _preview_look(tile_icon, preview):
    """10/29 live: tomato's simple round art gave 9 SIFT points (needs 10) and the sale was dropped. Second opinion:
    the tile icon scaled to the preview's size, best colour match at a few scales (0..1)."""
    try:
        best = 0.0
        ph, pw = preview.shape[:2]
        for f in (1.4, 1.7, 2.0, 2.3):
            t = cv2.resize(tile_icon, None, fx=f, fy=f, interpolation=cv2.INTER_LINEAR)
            if t.shape[0] > ph or t.shape[1] > pw:
                continue
            best = max(best, float(cv2.minMaxLoc(cv2.matchTemplate(preview, t, cv2.TM_CCOEFF_NORMED))[1]))
        return best
    except Exception:                                   # noqa: BLE001
        return 0.0


def _save_count_picture(name, hit):
    """10/29: wheat + corn 'could not read the stock count' -- keep the picker picture (Send logs carries fail_pictures)."""
    try:
        os.makedirs(COUNT_PICS, exist_ok=True)
        p = os.path.join(COUNT_PICS, f"{int(time.time())}_picker_count_{name}.png")
        cv2.imwrite(p, hit["img"])
        log(f"{name}: count not readable at {hit['xy']} -- picture saved ({os.path.basename(p)}).")
    except Exception:                                   # noqa: BLE001
        pass


PRICE_PICS = os.path.join(BASE_DIR, "templates", "busy_prices")
PRICE_DIGITS_DY, PRICE_DIGITS_DX = 28, 90       # inside PRICE_BOX: below "Price", right of the coin pile


def _read_price(img, name=""):
    """11/10 B.U.S.Y. step 1: the number in PRICE_BOX after set_max_price. Digit shapes first, Windows OCR second.
    The crop is saved to templates/busy_prices/<name>.png (Send logs) so the reads can be checked."""
    x1, y1, x2, y2 = PRICE_BOX
    crop = img[y1:y2, x1:x2]
    try:
        os.makedirs(PRICE_PICS, exist_ok=True)
        cv2.imwrite(os.path.join(PRICE_PICS, f"{name or 'item'}.png"), crop)
    except Exception:                                  # noqa: BLE001
        pass
    try:
        import coin_digits
        d = crop[PRICE_DIGITS_DY:, PRICE_DIGITS_DX:]      # 11/10: digits only -- the "Price" word + coin icon spoiled it
        n = coin_digits._number(d, 0, d.shape[1])
        if n:
            return n
    except Exception:                                  # noqa: BLE001
        pass
    try:
        import popup_ocr
        import re as _r
        digits = _r.sub(r"\D", "", popup_ocr.read_text(img, PRICE_BOX) or "")
        return int(digits) if digits else None
    except Exception:                                  # noqa: BLE001
        return None


def sell(name, qty, stop_flag=None, dry_run=False, keep=0, want_price=False):
    """Lists `qty` of `name` for sale at the max price. Returns {"ok": bool, "reason": str, "sold": n}.
    dry_run=True does every step up to (not including) Put on Sale, then backs out -- for live checks."""
    res = lambda ok, why, n=0: {"ok": ok, "reason": why, "sold": n}
    if name not in SELLABLE:
        return res(False, f"{name} is not on the sellable list")
    if qty < 1:
        return res(False, "nothing to sell")
    if not open_trades(stop_flag):
        return res(False, "could not open My Trades")
    try:
        collect_sold(stop_flag)
        fr = free_slots(screenshot())
        if not fr:
            return res(False, "no free sale slot (never unlock one with gems)")
        slot = fr[0]
        tap(SLOT_X[slot], SLOT_Y)
        interruptible_sleep(2.5, stop_flag)
        if not picker_open(screenshot()):
            return res(False, "the item picker did not open")
        hit = locate_item(name, stop_flag)
        if hit is None:
            tap(*CLOSE_X); interruptible_sleep(1.5, stop_flag)
            return res(False, f"{name} not found in the picker")
        count = hit["count"]
        if count is None:
            _save_count_picture(name, hit)
            tap(*CLOSE_X); interruptible_sleep(1.5, stop_flag)
            return res(False, "could not read the stock count -- not selling blind")
        qty = min(qty, count - keep)
        if qty < 1:
            tap(*CLOSE_X); interruptible_sleep(1.5, stop_flag)
            return res(False, f"only {count} in stock, keeping {keep}")
        x, y = hit["xy"]
        tap(x, y)
        interruptible_sleep(1.5, stop_flag)
        img = screenshot()
        # the big preview must be the same art as the tile we meant (never sell the wrong thing)
        tile_icon = hit["img"][max(0, y - 78):y + 20, max(0, x - 78):x + 78]
        px1, py1, px2, py2 = PREVIEW_BOX
        n, _c = _sift_match(tile_icon, img[py1:py2, px1:px2], min_inliers=10)
        look = _preview_look(tile_icon, img[py1:py2, px1:px2]) if n < 10 else 1.0
        if n < 10 and not (n >= 5 and look >= PREVIEW_LOOK_MIN):
            log(f"sell {name}: the preview does not match the tile ({n} inliers, picture match {look:.2f}) -- aborting.")
            if dry_run == "price":                       # 11/10 B.U.S.Y.: keep a picture to see why (8 of 15 stopped here)
                try:
                    os.makedirs(PRICE_PICS, exist_ok=True)
                    cv2.imwrite(os.path.join(PRICE_PICS, f"{name}_preview_miss.jpg"), img, [cv2.IMWRITE_JPEG_QUALITY, 60])
                except Exception:                        # noqa: BLE001
                    pass
            tap(*CLOSE_X); interruptible_sleep(1.5, stop_flag)
            return res(False, "preview did not match the chosen tile")
        for _ in range(qty - 1):
            tap(*QTY_PLUS)
            interruptible_sleep(0.4, stop_flag)
        if not set_max_price(stop_flag):
            log("sell: the price kept changing after 6 holds -- aborting.")
            tap(*CLOSE_X); interruptible_sleep(1.5, stop_flag)
            return res(False, "price never settled")
        if dry_run:
            price = _read_price(screenshot(), name) if dry_run == "price" else None   # 11/10 B.U.S.Y. price test
            log(f"DRY RUN: would list {qty} x {name} at the max price (stock {count})"
                + (f", max price {price}" if dry_run == "price" else "") + "; backing out without Put on Sale.")
            tap(*CLOSE_X)
            interruptible_sleep(1.5, stop_flag)
            return {"ok": False, "reason": "dry run", "sold": 0, "price": price, "stock": count}
        price = None
        if want_price:                                  # 11/15 Busy Mode: a real sale also records the max price
            try:
                price = _read_price(screenshot(), name)
            except Exception:                           # noqa: BLE001
                price = None
        log(f"selling {qty} x {name} at the max price (stock was {count})" + (f", {price} coins each" if price else "") + ".")
        tap(*PUT_ON_SALE)
        interruptible_sleep(2.5, stop_flag)
        after = screenshot()
        if not trades_open(after):
            return res(False, "after Put on Sale the Trades screen was not showing")
        if slot in free_slots(after):
            return res(False, "the slot is still empty after Put on Sale")
        out = res(True, "listed", qty)
        out.update(price=price, stock=count)
        return out
    finally:
        close_trades(stop_flag)


def pantry_relief(keep_for, stop_flag=None):
    """10/25 (owner: "I told you that you could sell crops under 10 min"): the Pantry is full -- sell up to RELIEF_MAX of
    the first quick crop that has more than it must keep (keep_for(crop) = crop reserve + what open orders need).
    Coins only, max price, never saws or anything else. Returns the sell() result of the crop sold, or None."""
    for crop in QUICK_CROPS + FRUIT_RELIEF + MORE_RELIEF:
        if _tile_templates().get(crop) is None and _sift_refs().get(crop) is None:
            log(f"[pantry relief] no picture of the {crop} tile yet -- skipping it.")
            continue
        keep = max(0, int(keep_for(crop)))
        r = sell(crop, RELIEF_MAX, stop_flag, keep=keep)
        log(f"[pantry relief] {crop} (keeping {keep}): {'SOLD ' + str(r['sold']) if r['ok'] else 'not sold -- ' + r['reason']}")
        if r["ok"]:
            return r
        if "no free sale slot" in r["reason"] or "could not open" in r["reason"]:
            return r                                    # nothing else will work either
    return None


STALL_EACH = 3                                           # 10/27: at most this many of one crop per listing
STALL_LISTINGS = 2                                       # at most this many listings per stall-fill turn


def stall_fill(keep_for, stop_flag=None):
    """10/27 (owner: yes -- "a full stall does bring more money", and visitors who help picked trees come when you sell):
    list extras of the quick crops (grow < 10 min: wheat, corn, tomato, cabbage -- never saws, nothing else) at the max
    price into FREE sale slots only, keeping keep_for(crop) (crop reserve + what the open orders still need).
    Stops when the stall is full. Returns the number of listings made."""
    made = 0
    for crop in QUICK_CROPS:
        if made >= STALL_LISTINGS:
            break
        if _tile_templates().get(crop) is None and _sift_refs().get(crop) is None:
            continue
        keep = max(0, int(keep_for(crop)))
        r = sell(crop, STALL_EACH, stop_flag, keep=keep)
        log(f"[stall fill] {crop} (keeping {keep}): " + (f"LISTED {r['sold']}" if r["ok"] else "not listed -- " + r["reason"]))
        if r["ok"]:
            made += 1
        elif "no free sale slot" in r["reason"] or "could not open" in r["reason"]:
            break                                       # stall full / Trades did not open -- nothing else will work
    return made


def sell_extras(needs, keep=2, stop_flag=None):
    """needs: {"fish": n, "seaweed": m} = what the current orders still need. Sells (stock - needs - keep) of each, if > 0.
    Returns a list of per-item result dicts."""
    out = []
    for name in ("fish", "seaweed"):
        need = int(needs.get(name, 0))
        cnt = stock_count(name, stop_flag)
        if cnt is None:
            log(f"{name}: stock unknown -- not selling.")
            out.append({"item": name, "ok": False, "reason": "stock unknown", "sold": 0})
            continue
        extra = cnt - need - keep
        log(f"{name}: stock {cnt}, orders need {need}, keeping {keep} spare -> extra {max(0, extra)}")
        if extra <= 0:
            out.append({"item": name, "ok": True, "reason": "no extras", "sold": 0})
            continue
        r = sell(name, extra, stop_flag)
        r["item"] = name
        out.append(r)
    return out
