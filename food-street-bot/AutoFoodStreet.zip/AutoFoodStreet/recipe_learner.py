"""10/28 (owner: "the bot needs to be able to grow with the user"): learn a NEW dish by itself.

When an order holds a dish the recipe book does not know and its '?' travels to a station the owner owns (so it is not
an unbuilt-stove dish), the bot is standing on that station's open menu. Here it:
  1. finds the dish's card by tapping each card PICTURE and reading the name bubble (event_orders.read_card_names --
     pictures only, a buy dialog is always declined),
  2. reads the card: ingredient counts (have/need digits), each ingredient's NAME from the game's own tooltip (tap the
     ingredient icon, read "Get Sausage from the Butcher", never tap the '?'), and the cook time label ("8m"),
  3. saves the recipe to recipes_learned.json (NOT recipes.json: an Update would overwrite that) marked learned /
     unconfirmed, and the board icon + card picture to the dish library (order_fulfill.train_dish),
so the next time the order comes round the bot cooks it like any other dish. Log lines: [learn].
Never taps Make, '?', Unlock, or anything that costs gems."""
import os
import re
import time

import order_fulfill as of

LEARN_NEW = True
PIC_DIR = os.path.join(of.BASE_DIR, "templates", "learned")      # one picture per learned card (in Send logs)


def log(msg):
    of.log("[learn] " + msg)


def _key(name):
    return re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_")


ROW_SWIPES = 4                 # 11/12: swipe the card row up to this many times (stops when the row stops moving)
FAIL_LIMIT = 3                 # 11/12: after this many misses in a row, stop trying that dish for GIVE_UP_SEC
GIVE_UP_SEC = 2 * 3600
_FAILS = {}                    # name (lower) -> [misses, until]


def _note_fail(name):
    e = _FAILS.setdefault(name.lower(), [0, 0.0])
    e[0] += 1
    if e[0] >= FAIL_LIMIT:
        e[1] = time.time() + GIVE_UP_SEC
        log(f"'{name}': no card of that name after {e[0]} tries -- not trying to learn it for {GIVE_UP_SEC // 3600} h.")
        e[0] = 0


def _gave_up(name):
    e = _FAILS.get(name.lower())
    return bool(e and e[1] > time.time())


MAX_COOK_SEC = 12 * 3600     # 11/6: the longest real cook in the book is 5h 20m; anything over 12 h is a misread


def parse_cook_time(text):
    """'8m' / '1h 5m' / '45s' / '3h' (OCR noise tolerated) -> seconds, or None."""
    t = (text or "").lower().replace(" ", "")
    m = re.search(r"(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?", t)
    best = None
    for m in re.finditer(r"(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?", t):
        if any(m.groups()):
            h, mi, s = (int(g) if g else 0 for g in m.groups())
            best = h * 3600 + mi * 60 + s
            break
    if best is not None and best > MAX_COOK_SEC:      # 11/6: Lemon Meringue Pie came out ~357 h (real 2h 30m)
        return None
    return best


def _ingredient_xs(eo, img, bx, by):
    xs = []
    for x, _col in eo.count_blobs(img, by - 70, by - 40, bx - 175, bx + 175):
        if all(abs(x - o) > 30 for o in xs):
            xs.append(x)
    return sorted(xs)


def _ingredient_name(eo, x, by, stop):
    """Tap the ingredient icon, read its tooltip (never the '?'), let it fade. -> parse_tooltip dict or None."""
    import adb_helper
    import popup_ocr
    adb_helper.tap(x, by - 56)
    of.interruptible_sleep(0.35, stop)
    s2 = adb_helper.screenshot()
    q, _qc = eo.find_tooltip_question(s2)
    if q is None:
        no, _nc = of.find_no_button(s2)
        if no is not None:                                   # a gem-buy dialog: always No
            adb_helper.tap(*no)
            of.interruptible_sleep(1.0, stop)
        return None
    x1, y1, x2, y2 = eo.TOOLTIP_BOX
    raw = popup_ocr.read_text(s2, (q[0] + x1, q[1] + y1, q[0] + x2, q[1] + y2)) or ""
    info = eo.parse_tooltip(raw)
    if not info:                                             # 10/28: lemon tooltip unreadable -- see what it said
        log(f"ingredient tooltip at x={x} not understood: {raw!r}")
    of.interruptible_sleep(4.0, stop)                        # let the tooltip fade before the next tap
    return info


def _known_key(rb, name):
    """Recipe-book key for a tooltip name; 'Lemons' (plural) -> lemon. None when unknown."""
    for n in (name, name[:-1] if name.lower().endswith("s") else None,
              name[:-2] if name.lower().endswith("es") else None):
        if not n:
            continue
        try:
            return rb.resolve(n)
        except KeyError:
            pass
    return None


def _known_station(rb, where):
    """'Dairu' (OCR slip) -> 'Dairy': the closest station already in the recipe book, else as read."""
    import difflib
    where = re.sub(r"^(?:fr\S{0,4}\s+)?(?:the|tne)\s+", "", (where or "").strip(), flags=re.I)
    known = sorted({it.get("station") for it in rb.load()["items"].values() if it.get("station")})
    best = difflib.get_close_matches(where, known, n=1, cutoff=0.75)
    return best[0] if best else where


def learn_here(name, station, board_icon, stop=None):
    """On the station menu the dish's '?' opened: learn `name`. Returns its recipe key, or None."""
    name = (name or "").strip(" -")                         # 11/12: OCR left "Pho Noodle Soup -"
    if not LEARN_NEW or not name:
        return None
    if _gave_up(name):
        return None
    import adb_helper
    import event_digits
    import event_orders as eo
    import popup_ocr
    import recipe_book as rb
    img = None
    for _ in range(4):
        img = adb_helper.screenshot()
        if of.panel_is_open(img):
            break
        of.interruptible_sleep(0.7, stop)
    else:
        log(f"'{name}': the {station} menu was not open -- learning next time.")
        return None
    btns = eo.station_buttons(img)
    if not btns:
        log(f"'{name}': no card buttons found on the {station} menu -- learning next time.")
        return None
    names = eo.read_card_names(img, btns, stop)
    if names is None:
        return None
    hits = [i for i, n in enumerate(names) if eo.same_name(n, name)]
    swipes, seen = 0, list(names)
    # 11/12: Pho was off the right edge; Tomato Soup (owner) off the LEFT edge -> look right, then back left.
    for x1, x2, n in ((1400, 200, ROW_SWIPES), (200, 1400, ROW_SWIPES * 2)):
        last = names
        for _ in range(n):
            if len(hits) == 1:
                break
            of.check_stop(stop)
            swipes += 1
            of.swipe(x1, of.PANEL_SWIPE_Y, x2, of.PANEL_SWIPE_Y, of.LONG_SWIPE_DURATION_MS)
            of.interruptible_sleep(of.LONG_SWIPE_SETTLE_SEC, stop)
            img = adb_helper.screenshot()
            if not of.panel_is_open(img):
                break
            btns = eo.station_buttons(img)
            more = eo.read_card_names(img, btns, stop) if btns else None
            if more is None or more == last:                # this end of the row: nothing new came into view
                break
            seen += [m for m in more if m not in seen]
            names = last = more
            hits = [i for i, m in enumerate(names) if eo.same_name(m, name)]
    log(f"'{name}' at the {station}: the cards say {names if len(hits) == 1 else seen}" + (f" (after {swipes} swipe(s))" if swipes else "")
        + " -> " + (f"card {hits[0] + 1}" if len(hits) == 1 else "no single match"))
    if len(hits) != 1:
        _note_fail(name)
        return None
    i = hits[0]
    bx, by = btns[i][0], btns[i][1]
    img = adb_helper.screenshot()                            # fresh: the name bubble may still be fading
    text_y = by - (of.ACTION_BUTTON_Y - of.INGREDIENT_TEXT_Y)
    ingredients, missing = [], []
    for x in _ingredient_xs(eo, img, bx, by):
        of.check_stop(stop)
        c = event_digits.read_count(img, x, text_y, save_unknown=False)
        info = _ingredient_name(eo, x, by, stop)
        if not c or not info:
            missing.append(f"x={x}: " + ("count unreadable" if not c else "tooltip unreadable"))
            continue
        key = _known_key(rb, info["name"])
        if key is None:
            key = _key(info["name"])
            info["where"] = _known_station(rb, info["where"])
            rb.add_learned(key, {"name": info["name"], "station": info["where"],
                                 "kind": "crop" if info.get("plot") else "made", "cook_sec": 0, "yield": 1,
                                 "ingredients": [], "note": "auto-learned ingredient (recipe not read yet)"})
            log(f"new ingredient '{info['name']}' (from the {info['where']}) added to the recipe book.")
        ingredients.append([key, int(c["need"])])
    if missing or not ingredients:
        log(f"'{name}': could not read every ingredient ({'; '.join(missing) or 'none found'}) -- not saving a half "
            "recipe; trying again next time.")
        return None
    x1, y1, x2, y2 = bx - 175, by - 440, bx + 80, by - 380
    cook = parse_cook_time(popup_ocr.read_text(img, (max(0, x1), max(0, y1), x2, y2)) or "")
    key = _key(name)
    rb.add_learned(key, {"name": name, "station": station, "kind": "dish", "cook_sec": cook or None, "yield": 1,
                         "ingredients": ingredients, "counts_confirmed": False, "show_on_page": True,
                         "note": "auto-learned " + time.strftime("%m/%d %H:%M") + (" (cook time not read)" if not cook else "")})
    try:
        if board_icon is not None and board_icon.size:
            of.train_dish(board_icon, key, card_index=i, panel_img=img, panel_cx=bx)
        import cv2
        os.makedirs(PIC_DIR, exist_ok=True)
        cv2.imwrite(os.path.join(PIC_DIR, f"{key}_{int(time.time())}.jpg"),
                    img[max(0, by - 460):by + 40, max(0, bx - 190):bx + 190], [1, 80])
    except Exception as e:                                    # noqa: BLE001
        log(f"'{name}': recipe saved, but the pictures failed ({e!r}).")
    of._RECIPE_NAMES = None                                   # tooltips now find it in the book
    log(f"LEARNED '{name}' at the {station}: " + ", ".join(f"{k} {n}" for k, n in ingredients)
        + (f", cooks {cook // 60}m{cook % 60:02d}s" if cook else ", cook time not read") + " -- cooking it from now on.")
    return key
