"""picked_trees.py -- the "Picked Tree Problem" (owner 10/21 + 10/25).

Tapping a tree / bush / shrub that is already picked opens its menu: the name on top, a blue "Ask for Help" button
(hand icon) and a green "Remove" button (Helping Hand or saw). Owner's rules:
  - tap ASK FOR HELP -- every tree gets it only ONCE; a visitor clicks the tree later and it fruits again;
  - NEVER Remove (it uses a Helping Hand / saw item); when Ask for Help is gone the tree is "spent": log + picture, X;
  - don't keep sending the bot back to trees that are picked: rest that fruit for a while.
Picture of the menu: templates/unknown_screens/1792704765_not_reward.png (Coffee Bush). Before this module the bot
read the green Remove button as a reward button, saw it was not "Collect", saved a picture and walked away -- and came
back to the same bush again and again (12+ pictures on 10/23).
"""
import datetime
import json
import os
import time

import cv2

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(BASE_DIR, "run_log.txt")
TPL_DIR = os.path.join(BASE_DIR, "templates", "picked_trees")
PIC_DIR = os.path.join(TPL_DIR, "seen")
STATE = os.path.join(BASE_DIR, ".picked_trees.json")

MENU_REGION = (400, 150, 1200, 880)           # x1, y1, x2, y2 -- the menu sits in the middle (Coffee Bush 595-1004)
MATCH_MIN = 0.8
TITLE_BOX = (-35, -480, 375, -400)            # title line relative to the Ask for Help text's top-left (595,152..)
CLOSE_X = (995, 175)                          # the menu's red X (Coffee Bush picture: 970-1030, 130-210)
REST_ASKED_SEC = 45 * 60                      # help asked: leave that fruit alone this long
REST_EMPTY_SEC = 20 * 60                      # trip found nothing ripe: try again after this
PICS_PER_RUN = 6
# 11/8 O.R.C.H.A.R.D. (Orchard Rounds: Cut, Harvest, Ask, Replant, Decide) step 1, LOG ONLY -- owner's rules:
# ask for help first and let it regrow; only then a saw (trees) / Helping Hand (bushes); only when we have one
# ("if not just leave it be" -- they come from the hot dog man and the pier rewards billboard); replant (costs coins)
# next to trees of the same type via the build menu search (not built: needs a recording).
# 11/8 (owner: "yes go ahead") LIVE: a spent plant is cut when ALL hold -- owner's rules + the red-hand check:
#   menu has no Ask for Help; tool known (Tree = saw, Bush = Helping Hand) and have >= need; NO red hand sign near the
#   tapped tree on the map picture taken before the tap (red hand = help asked, visitor not here yet -- the menu looks
#   spent then too, owner 11/8); no help asked on that kind in the last ASK_BLOCK_SEC; at most CUT_MAX_PER_DAY.
# Remove is ONE tap, no confirm (owner's 10/25 recording: tap (802,740) -> map, saws 47 -> 46). No replanting yet.
CUT_LIVE = True                               # Settings > Orchard "Remove spent trees and bushes" (afsd_core)
CUT_MAX_PER_DAY = 3
ASK_BLOCK_SEC = 24 * 3600
REMOVE_TAP = (166, 26)                        # Remove button, relative to remove_text's top-left (owner tapped 802,740)
HAND_MIN = 0.7
HAND_NEAR = (-220, -260, 220, 80)             # x1, y1, x2, y2 around the tap: the sign hangs ~60 px above the tree
COUNT_BOX = (255, 2, 335, 53)                 # the white "46/1" on the Remove button, relative to remove_text's top-left

_tpl = {}
_pics = [0]


def log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(f"[{datetime.datetime.now().isoformat(timespec='seconds')}] [picked trees] {msg}\n")
    except OSError:
        pass


def _t(name):
    if name not in _tpl:
        _tpl[name] = cv2.imread(os.path.join(TPL_DIR, name))
    return _tpl[name]


def _find(img, name):
    t = _t(name)
    if t is None or img is None or img.shape[:2] != (900, 1600):
        return 0.0, None
    x1, y1, x2, y2 = MENU_REGION
    _mn, mx, _ml, loc = cv2.minMaxLoc(cv2.matchTemplate(img[y1:y2, x1:x2], t, cv2.TM_CCOEFF_NORMED))
    return mx, (x1 + loc[0], y1 + loc[1])


def read_menu(img):
    """None, or {"ask": (x, y) to tap or None, "remove": bool, "title": str} when a picked-tree menu is showing."""
    sa, la = _find(img, "ask_for_help_text.png")
    sr, lr = _find(img, "remove_text.png")
    if sr < MATCH_MIN and sa < MATCH_MIN:
        return None
    ask = None
    if sa >= MATCH_MIN:
        t = _t("ask_for_help_text.png")
        ask = (la[0] + t.shape[1] // 2 + 60, la[1] + t.shape[0] // 2)       # middle of the blue button
    ref = la if sa >= MATCH_MIN else (lr[0], lr[1] - 96)                    # Remove sits 96 px under Ask for Help
    if ask is None and not _red_x(img):
        return None                           # "Remove" alone on some other screen (My Trades ...) -- not this menu
    return {"ask": ask, "remove": sr >= MATCH_MIN, "title": _title(img, ref), "score": round(max(sa, sr), 2)}


def _red_x(img):
    """The menu's red X where the Coffee Bush picture has it (bright red square around CLOSE_X)."""
    x, y = CLOSE_X
    box = img[y - 40:y + 40, x - 40:x + 40].astype(int)
    red = (box[..., 2] > 180) & (box[..., 1] < 90) & (box[..., 0] < 90)
    return int(red.sum()) >= 800


def _title(img, ref):
    try:
        import popup_ocr
        x1, y1 = ref[0] + TITLE_BOX[0], ref[1] + TITLE_BOX[1]
        x2, y2 = ref[0] + TITLE_BOX[2], ref[1] + TITLE_BOX[3]
        txt = popup_ocr.read_text(img, (max(0, x1), max(0, y1), min(1600, x2), min(900, y2))) or ""
        return " ".join(txt.split())[:40] or "?"
    except Exception:                          # noqa: BLE001 -- the title is only for the log
        return "?"


def _pic(img, tag):
    if _pics[0] >= PICS_PER_RUN:
        return None
    _pics[0] += 1
    try:
        os.makedirs(PIC_DIR, exist_ok=True)
        p = os.path.join(PIC_DIR, f"{time.strftime('%Y%m%d_%H%M%S')}_{tag}.png")
        cv2.imwrite(p, img)
        return os.path.relpath(p, BASE_DIR)
    except Exception:                          # noqa: BLE001
        return None


def _load():
    try:
        with open(STATE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _save(st):
    try:
        with open(STATE, "w", encoding="utf-8") as fh:
            json.dump(st, fh, indent=1)
    except OSError:
        pass


def rest(fruit, secs, why):
    """Leave `fruit` (apple, coffee_bean, ...) alone for secs (keeps the longer rest if one is already set)."""
    if not fruit:
        return
    st = _load()
    until = max(st.get("rest", {}).get(fruit, 0), time.time() + secs)
    st.setdefault("rest", {})[fruit] = until
    _save(st)
    log(f"resting '{fruit}' until {time.strftime('%H:%M', time.localtime(until))} -- {why}.")


def resting(fruit):
    """Seconds left on the rest of `fruit` (0 = go ahead)."""
    return max(0, int(_load().get("rest", {}).get(fruit, 0) - time.time()))


def waiting_for_help():
    """10/27: True when the bot asked for help on a tree in the last REST_ASKED_SEC -- visitors (who do the helping)
    come when something is for sale, so the stall filler sells a little more often then."""
    now = time.time()
    return any(now - (t.get("last_asked") or 0) < REST_ASKED_SEC for t in _load().get("trees", {}).values())


def handle(img, where, fruit=None, tap=None, sleep=None, screenshot=None, before=None, tap_xy=None):
    """If img shows a picked-tree menu: tap Ask for Help (once per tree -- the game removes the button after) or,
    when it is spent, only log it; then close the menu with the red X. Returns True when it handled a menu."""
    m = read_menu(img)
    if m is None:
        return False
    if tap is None:
        from adb_helper import tap
    if screenshot is None:
        from adb_helper import screenshot
    if sleep is None:
        sleep = time.sleep
    st = _load()
    name = m["title"] if m["title"] != "?" else (fruit or "tree")
    rec = st.setdefault("trees", {}).setdefault(name, {"asked": 0, "spent": 0})
    if m["ask"] is not None:
        tap(*m["ask"])
        sleep(1.5)
        after = screenshot()
        rec["asked"] += 1
        rec["last_asked"] = time.time()
        pic = _pic(after, "after_ask")
        log(f"ASKED FOR HELP on '{name}' ({where}; match {m['score']}) -- a visitor can now pick it for us"
            + (f"; picture after the tap: {pic}" if pic else "") + ".")
        img = after
    else:
        rec["spent"] += 1
        rec["last_spent"] = time.time()
        pic = _pic(img, "spent")
        log(f"'{name}' has no Ask for Help left ({where}) -- help already used; it needs Remove (Helping Hand / saw), "
            f"which the bot never does on its own" + (f"; picture {pic}" if pic else "") + ".")
        tool = tool_for(name)
        verdict, why = cut_verdict(tool, tool_count(img))
        rec["would_cut" if verdict == "cut" else "would_leave"] = rec.get(
            "would_cut" if verdict == "cut" else "would_leave", 0) + 1
        if verdict != "cut":
            log(f"[orchard] '{name}': leaving it be -- {why}.")
        else:
            block = live_block(name, before, tap_xy, st)
            if block:
                log(f"[orchard] '{name}': spent ({why}) but NOT cutting -- {block}.")
            elif _cut(img, name, tool, tap, sleep, screenshot, st):
                img = screenshot()
                try:                           # 11/9 O.R.C.H.A.R.D. step 4: plant a new one on the same spot
                    import replant
                    if replant.after_cut(name, tap_xy, st, log, tap=tap, sleep=sleep, screenshot=screenshot):
                        img = screenshot()
                except Exception as e:         # noqa: BLE001
                    log(f"[orchard] replant failed (ignored): {e!r}")
    _save(st)
    if read_menu(img) is not None:            # still open: red X only, never Remove
        tap(*CLOSE_X)
        sleep(1.2)
    if fruit:
        rest(fruit, REST_ASKED_SEC, f"'{name}' is picked (help {'asked' if m['ask'] else 'already used'})")
    return True


def tool_for(title):
    """Pure: which item a spent plant's Remove uses -- 'saw' for trees, 'helping hand' for bushes/shrubs."""
    t = (title or "").lower()
    if "tree" in t:
        return "saw"
    if "bush" in t or "shrub" in t:
        return "helping hand"
    return None


def tool_count(img):
    """(have, need) from the white "46/1" on the Remove button, or None. The slash by the event count shapes, the
    digits by the top-bar shapes (coin_digits: the same bold game font; the event shapes read '4' 0.58, '1' 0.69)."""
    try:
        import numpy as np
        import coin_digits as cd
        import event_digits as ed
        sr, lr = _find(img, "remove_text.png")
        if sr < MATCH_MIN:
            return None
        x1, y1, x2, y2 = (lr[0] + COUNT_BOX[0], lr[1] + COUNT_BOX[1], lr[0] + COUNT_BOX[2], lr[1] + COUNT_BOX[3])
        box = img[y1:y2, x1:x2]
        m = (box.min(axis=2) > 200).astype(np.uint8) * 255
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        hb = box.shape[0]
        parts = [i for i in range(1, n) if st[i][4] >= 12 and 10 <= st[i][3] < hb - 4]
        if parts:
            tall = max(st[i][3] for i in parts)
            parts = [i for i in parts if st[i][3] >= 0.6 * tall]
        shapes = cd._HUD_T + cd._TEMPLATES
        labels = []
        for i in sorted(parts, key=lambda i: st[i][0]):
            x, y, w, h, _a = st[i]
            g = lab[y:y + h, x:x + w] == i
            lb, _sc = ed.classify(cv2.resize(g.astype(np.uint8) * 255, ed.GLYPH_SIZE, interpolation=cv2.INTER_AREA))
            if lb != "slash":
                f = cd._feat(g)
                d, sc = max(((d, float(f @ t)) for d, t in shapes), key=lambda z: z[1]) if shapes else (None, 0)
                if sc < cd.HUD_MIN:
                    return None
                lb = str(d)
            labels.append(lb)
        if labels.count("slash") != 1:
            return None
        k = labels.index("slash")
        a, b = labels[:k], labels[k + 1:]
        if not a or not b:
            return None
        return int("".join(a)), int("".join(b))
    except Exception:                          # noqa: BLE001
        return None


def cut_verdict(tool, count):
    """Pure: ('cut' | 'leave', why) for a spent plant (no Ask for Help left = help was asked before)."""
    if tool is None:
        return "leave", "not sure if it takes a saw or a Helping Hand"
    if count is None:
        return "leave", f"could not read how many {tool}s we have"
    have, need = count
    if have < need:
        return "leave", f"not enough {tool}s ({have}/{need}) -- more come from the hot dog man and the pier billboard"
    return "cut", f"{tool}s {have}/{need}"


def red_hands(img):
    """Full-size (x, y) centres of red hand signs on a map picture (help asked, visitor not here yet)."""
    t = _t(os.path.join("..", "orchard", "red_hand.png"))
    if t is None or img is None or img.shape[:2] != (900, 1600):
        return []
    small = cv2.resize(img, (800, 450), interpolation=cv2.INTER_AREA)
    out = []
    for sc in (0.4, 0.5, 0.6):                 # sign at 0.8x .. 1.2x of the 10/25 zoom, matched at half size
        tt = cv2.resize(t, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
        r = cv2.matchTemplate(small, tt, cv2.TM_CCOEFF_NORMED)
        ys, xs = (r >= HAND_MIN).nonzero()
        for y, x in zip(ys, xs):
            c = (int((x + tt.shape[1] / 2) * 2), int((y + tt.shape[0] / 2) * 2))
            if all(abs(c[0] - o[0]) > 30 or abs(c[1] - o[1]) > 30 for o in out):
                out.append(c)
    return out


def hand_near(hands, xy):
    """Pure: is any red hand sign in the HAND_NEAR box around the tapped spot?"""
    if xy is None:
        return False
    x, y = xy
    return any(x + HAND_NEAR[0] <= hx <= x + HAND_NEAR[2] and y + HAND_NEAR[1] <= hy <= y + HAND_NEAR[3]
               for hx, hy in hands)


def live_block(name, before, tap_xy, st, now=None):
    """Pure-ish: None when cutting is allowed, else why not (the owner's safety rules)."""
    now = now or time.time()
    if not CUT_LIVE:
        return "cutting is switched off"
    if before is None or tap_xy is None:
        return "no map picture from before the tap (needed to check for a red hand)"
    if _t(os.path.join("..", "orchard", "red_hand.png")) is None:
        return "the red hand picture is missing (templates/orchard/red_hand.png) -- cannot check, so no cutting"
    hands = red_hands(before)
    if hand_near(hands, tap_xy):
        return f"a red hand sign is over it -- help was asked and the visitor has not come yet"
    rec = st.get("trees", {}).get(name, {})
    if now - (rec.get("last_asked") or 0) < ASK_BLOCK_SEC:
        return "help was asked on a tree of this kind in the last 24 h -- it may still be waiting"
    today = time.strftime("%Y-%m-%d", time.localtime(now))
    if st.get("cuts", {}).get(today, 0) >= CUT_MAX_PER_DAY:
        return f"already cut {CUT_MAX_PER_DAY} today"
    return None


def _cut(img, name, tool, tap, sleep, screenshot, st):
    """Tap Remove once, decline any gem question, check the menu closed. Returns True when it was cut."""
    sr, lr = _find(img, "remove_text.png")
    if sr < MATCH_MIN:
        return False
    before_pic = _orchard_pic(img, "cut_menu")
    tap(lr[0] + REMOVE_TAP[0], lr[1] + REMOVE_TAP[1])
    sleep(1.5)
    after = screenshot()
    try:
        import order_fulfill as of
        no, _c = of.find_no_button(after)
        if no is not None:                     # a buy question -- never Yes
            tap(*no)
            sleep(1.0)
            log(f"[orchard] Remove on '{name}' asked something with a No button -- tapped No, not cut.")
            return False
    except Exception:                          # noqa: BLE001
        pass
    after_pic = _orchard_pic(after, "cut_after")
    ok = read_menu(after) is None
    today = time.strftime("%Y-%m-%d")
    if ok:
        st.setdefault("cuts", {})[today] = st.get("cuts", {}).get(today, 0) + 1
        st.setdefault("cut_log", []).append({"t": time.time(), "name": name, "tool": tool})
        st["cut_log"] = st["cut_log"][-50:]
    log(f"[orchard] {'CUT' if ok else 'tapped Remove on'} '{name}' with a {tool}"
        + ("" if ok else " but the menu is still open") + f" ({st.get('cuts', {}).get(today, 0)} today)"
        + f"; pictures {before_pic} -> {after_pic}.")
    return ok


_orchard_pics = [0]


def _orchard_pic(img, tag):
    if _orchard_pics[0] >= 12:
        return None
    _orchard_pics[0] += 1
    try:
        d = os.path.join(BASE_DIR, "templates", "orchard", "seen")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, f"{time.strftime('%Y%m%d_%H%M%S')}_{tag}.jpg")
        cv2.imwrite(p, img, [cv2.IMWRITE_JPEG_QUALITY, 70])
        return os.path.relpath(p, BASE_DIR)
    except Exception:                          # noqa: BLE001
        return None


def summary():
    st = _load()
    trees = st.get("trees", {})
    if not trees:
        return "no picked-tree menus seen yet"
    return "; ".join(f"{k}: asked {v.get('asked', 0)}x, spent {v.get('spent', 0)}x, would cut {v.get('would_cut', 0)}x"
                     for k, v in trees.items())
