"""Shared look for every AFSD tab (10/20 redesign, owner: "I want all of the tabs to look that great").

Small Tk building blocks so Orders, Prep work, Log and Settings match: cards, pills, steppers, switches, bars,
rings, chips and the hover (i). Looks only -- nothing here talks to the game.
"""
import tkinter as tk
import tkinter.font as tkfont

BG = "#1e1e1e"
PANEL = "#2a2a2a"
CARD = "#262626"
LINE = "#3a3a3a"
GOLD = "#c9a227"
GOLD_DIM = "#8a6f1e"
TEXT = "#e8e8e8"
DIM = "#9a9a9a"
GREEN = "#6fcf6f"
AMBER = "#f0a040"
RED = "#e06060"
TEAL = "#4fc3a1"
BLUE = "#4fa3e0"
PURPLE = "#b48ce0"

_fonts = {}


def font(size=10, bold=False, family="Segoe UI"):
    key = (family, size, bold)
    if key not in _fonts:
        _fonts[key] = tkfont.Font(family=family, size=size, weight="bold" if bold else "normal")
    return _fonts[key]


def _rgb(c):
    c = str(c)
    if c.startswith("#") and len(c) == 7:
        return [int(c[i:i + 2], 16) for i in (1, 3, 5)]
    if c.startswith("#") and len(c) == 4:                # "#a33"
        return [int(ch * 2, 16) for ch in c[1:]]
    try:                                                # a colour name ("white", "SystemButtonFace" ...)
        return [v // 257 for v in tk._default_root.winfo_rgb(c)]
    except Exception:                                   # noqa: BLE001
        return [42, 42, 42]


def mix(c1, c2, t):
    """Colour between c1 (t=0) and c2 (t=1)."""
    a, b = _rgb(c1), _rgb(c2)
    return "#" + "".join(f"{round(x + (y - x) * t):02x}" for x, y in zip(a, b))


def _outer_bg(parent):
    try:
        return parent.cget("bg")
    except tk.TclError:
        return BG


def round_rect(cv, x1, y1, x2, y2, r, fill="", outline="", width=1, tags=""):
    """A rounded rectangle on a canvas: filled from rectangles + quarter circles, outlined with arcs + lines, so the
    straight edges stay perfectly straight."""
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    d = 2 * r
    if fill:
        for bx in ((x1, y1, x1 + d, y1 + d), (x2 - d, y1, x2, y1 + d), (x1, y2 - d, x1 + d, y2),
                   (x2 - d, y2 - d, x2, y2)):
            cv.create_oval(*bx, fill=fill, outline=fill, tags=tags)
        cv.create_rectangle(x1 + r, y1, x2 - r, y2, fill=fill, outline=fill, tags=tags)
        cv.create_rectangle(x1, y1 + r, x2, y2 - r, fill=fill, outline=fill, tags=tags)
    if outline and outline != fill:
        for bx, start in (((x1, y1, x1 + d, y1 + d), 90), ((x2 - d, y1, x2, y1 + d), 0),
                          ((x1, y2 - d, x1 + d, y2), 180), ((x2 - d, y2 - d, x2, y2), 270)):
            cv.create_arc(*bx, start=start, extent=90, style="arc", outline=outline, width=width, tags=tags)
        for ln in ((x1 + r, y1, x2 - r, y1), (x1 + r, y2, x2 - r, y2), (x1, y1 + r, x1, y2 - r),
                   (x2, y1 + r, x2, y2 - r)):
            cv.create_line(*ln, fill=outline, width=width, tags=tags)


class _Body(tk.Frame):
    """The inside of a RoundCard. Packing / gridding it moves the whole rounded card."""

    def __init__(self, card, **kw):
        super().__init__(card, **kw)
        self._card = card

    def pack(self, *a, **k):
        return self._card.pack(*a, **k)
    pack_configure = pack

    def grid(self, *a, **k):
        return self._card.grid(*a, **k)
    grid_configure = grid

    def place(self, *a, **k):
        return self._card.place(*a, **k)
    place_configure = place

    def pack_forget(self):
        return self._card.pack_forget()

    def grid_forget(self):
        return self._card.grid_forget()

    def destroy(self):
        card, self._card = self._card, None
        if card is not None and not getattr(card, "_dying", False):
            card._dying = True
            try:
                card.destroy()                     # takes this frame with it
                return
            except tk.TclError:
                pass
        tk.Frame.destroy(self)


class RoundCard(tk.Canvas):
    """A box with rounded corners. Put widgets in `.body`. stretch=True: the body fills the card both ways (for
    a card that holds a list or text that should grow with the window)."""

    def __init__(self, parent, fill=CARD, edge=LINE, thick=1, radius=12, stretch=False):
        super().__init__(parent, bg=_outer_bg(parent), highlightthickness=0, bd=0)
        self.fill, self.edge, self.thick, self.radius, self.stretch = fill, edge, thick, radius, stretch
        self.p = max(thick + 2, int(radius * 0.3) + 2)
        self.body = _Body(self, bg=fill)
        self._win = self.create_window(self.p, self.p, window=self.body, anchor="nw")
        self.body.bind("<Configure>", self._fit, add="+")
        self.bind("<Configure>", self._resized, add="+")
        self._size = (0, 0)

    def _fit(self, _e=None):
        p2 = 2 * self.p
        w = self.body.winfo_reqwidth() + p2
        h = (self.body.winfo_reqheight() if self.stretch else self.body.winfo_height()) + p2
        if (w, h) != (int(self.cget("width")), int(self.cget("height"))):
            tk.Canvas.configure(self, width=w, height=h)

    def _resized(self, e):
        p2 = 2 * self.p
        if self.stretch:
            self.itemconfigure(self._win, width=max(1, e.width - p2), height=max(1, e.height - p2))
        else:
            self.itemconfigure(self._win, width=max(1, e.width - p2))
        self._draw(e.width, e.height)

    def _draw(self, w, h):
        self.delete("shape")
        t = self.thick
        round_rect(self, t / 2, t / 2, w - t / 2 - 1, h - t / 2 - 1, self.radius, fill=self.fill,
                   outline=self.edge if t else self.fill, width=max(t, 1), tags="shape")
        self.tag_lower("shape")

    def destroy(self):
        self._dying = True                         # the body inside must not destroy this card a second time
        tk.Canvas.destroy(self)

    def set_edge(self, edge, thick=None):
        self.edge = edge
        if thick is not None:
            self.thick = thick
        self._draw(self.winfo_width(), self.winfo_height())


def card(parent, edge=LINE, thick=1, bg=CARD, radius=12, stretch=False):
    """A rounded box; returns its inside frame (pack/grid it like a normal frame, put widgets in it)."""
    return RoundCard(parent, fill=bg, edge=edge, thick=thick, radius=radius, stretch=stretch).body


def title(parent, text, bg=BG, size=11, color=GOLD):
    return tk.Label(parent, text=text, font=font(size, True), bg=bg, fg=color)


class RoundButton(tk.Canvas):
    """A rounded button that takes the usual tk.Button options (text, bg, fg, state, command, font, width in
    characters), so code that does button.config(text=..., bg=..., state=...) keeps working."""
    MINE = ("text", "bg", "background", "fg", "foreground", "state", "command", "font", "activebackground",
            "activeforeground", "disabledforeground", "relief", "padx", "pady", "chars", "radius", "outer")

    def __init__(self, parent, text="", command=None, bg=PANEL, fg=TEXT, font=None, chars=None, padx=14, pady=5,
                 radius=9, state="normal", **_ignored):
        super().__init__(parent, bg=_outer_bg(parent), highlightthickness=0, bd=0, cursor="hand2")
        self.o = dict(text=text, command=command, bg=bg, fg=fg, font=font or globals()["font"](10), chars=chars,
                      padx=padx, pady=pady, radius=radius, state=state)
        self._hover = False
        self.bind("<Enter>", lambda e: self._set_hover(True))
        self.bind("<Leave>", lambda e: self._set_hover(False))
        self.bind("<ButtonRelease-1>", self._click)
        self._layout()

    def _set_hover(self, on):
        self._hover = on
        self._draw()

    def _click(self, e):
        if getattr(self, "suppress_click", False):        # 11/15: the release that ends a drag-scroll is no click
            self.suppress_click = False
            return
        if self.o["state"] == "disabled" or not (0 <= e.x <= self.winfo_width() and 0 <= e.y <= self.winfo_height()):
            return
        if self.o["command"]:
            self.o["command"]()

    def _layout(self):
        f = self.o["font"]
        tw = f.measure("0" * self.o["chars"]) if self.o["chars"] else 0
        lines = str(self.o["text"]).split("\n")
        tw = max(tw, max(f.measure(ln) for ln in lines))
        th = f.metrics("linespace") * len(lines)
        tk.Canvas.configure(self, width=tw + 2 * self.o["padx"], height=th + 2 * self.o["pady"])
        self._draw()

    def _draw(self):
        self.delete("all")
        w, h = int(self.cget("width")), int(self.cget("height"))
        bg, fg = self.o["bg"], self.o["fg"]
        if self.o["state"] == "disabled":
            bg, fg = mix(bg, _outer_bg(self.master), 0.5), "#6a6a6a"
        elif self._hover:
            bg = mix(bg, "#ffffff", 0.12)
        round_rect(self, 0, 0, w - 1, h - 1, self.o["radius"], fill=bg, outline=bg)
        self.create_text(w / 2, h / 2, text=self.o["text"], fill=fg, font=self.o["font"], justify="center")

    def configure(self, cnf=None, **kw):
        kw.update(cnf or {})
        mine = {k: kw.pop(k) for k in list(kw) if k in self.MINE}
        for k, v in mine.items():
            k = {"background": "bg", "foreground": "fg"}.get(k, k)
            if k in self.o:
                self.o[k] = v
        if kw:
            kw.pop("width", None)
            kw.pop("height", None)
            if kw:
                tk.Canvas.configure(self, **kw)
        if mine:
            self._layout()
    config = configure

    def cget(self, key):
        key = {"background": "bg", "foreground": "fg"}.get(key, key)
        if key in self.o and key not in ("bg",):
            return self.o[key]
        return tk.Canvas.cget(self, key)

    def __setitem__(self, key, value):
        self.configure(**{key: value})


class RoundLabel(tk.Canvas):
    """Rounded tag with text (pills and chips). chars = fixed width in characters."""

    def __init__(self, parent, text, fg, fill, font_, chars=None, padx=8, pady=2, radius=None, cursor=""):
        super().__init__(parent, bg=_outer_bg(parent), highlightthickness=0, bd=0, cursor=cursor)
        tw = max(font_.measure(text), font_.measure("0" * chars) if chars else 0)
        h = font_.metrics("linespace") + 2 * pady
        w = tw + 2 * padx
        tk.Canvas.configure(self, width=w, height=h)
        round_rect(self, 0, 0, w - 1, h - 1, radius if radius is not None else h / 2, fill=fill, outline=fill)
        self.create_text(w / 2, h / 2, text=text, fill=fg, font=font_)


def pill(parent, text, color, bg=CARD, size=9, chars=None):
    """Small coloured status tag: coloured text on a dark tint of the same colour, round ends."""
    return RoundLabel(parent, text, color, mix(bg, color, 0.18), font(size, True), chars=chars)


def button(parent, text, command, primary=False, bg=CARD, size=10, **kw):
    return RoundButton(parent, text=text, command=command, font=font(size, primary),
                       bg=GOLD if primary else mix(bg, "#ffffff", 0.08), fg="#1e1e1e" if primary else TEXT, **kw)


def entry(parent, var, width=24, bg=CARD):
    """A text box inside a rounded dark field. Pack/grid the returned Entry as usual (it moves the field)."""
    field_bg = mix(bg, "#000000", 0.25)
    rc = RoundCard(parent, fill=field_bg, edge=LINE, thick=1, radius=9, stretch=True)
    e = tk.Entry(rc.body, textvariable=var, width=width, bg=field_bg, fg=TEXT, insertbackground=TEXT, relief="flat",
                 highlightthickness=0, bd=0, font=font(10))
    e.pack(fill="both", expand=True, padx=4, pady=1)
    for name in ("pack", "pack_configure", "grid", "grid_configure", "place", "pack_forget", "grid_forget"):
        setattr(e, name, getattr(rc, name))
    return e


def bar(parent, frac, color, width=120, height=6, bg=CARD):
    """Progress bar with round ends."""
    c = tk.Canvas(parent, width=width, height=height, bg=bg, highlightthickness=0)
    set_bar(c, frac, color)
    return c


def set_bar(c, frac, color):
    """(Re)draw a bar() in place -- 10/24, the Orders tab updates cards without rebuilding them."""
    c.delete("all")
    width, height, bg = int(c.cget("width")), int(c.cget("height")), c.cget("bg")
    r = height / 2
    c.create_line(r, r, width - r, r, fill=mix(bg, "#ffffff", 0.1), width=height, capstyle="round")
    frac = max(0, min(1, frac))
    if frac > 0:
        c.create_line(r, r, max(r + 0.5, r + (width - 2 * r) * frac), r, fill=color, width=height, capstyle="round")


def ring(parent, frac, color, size=38, text="", bg=CARD):
    c = tk.Canvas(parent, width=size, height=size, bg=bg, highlightthickness=0)
    set_ring(c, frac, color, text)
    return c


def set_ring(c, frac, color, text=""):
    c.delete("all")
    size, bg = int(c.cget("width")), c.cget("bg")
    p = 4
    c.create_oval(p, p, size - p, size - p, outline=mix(bg, "#ffffff", 0.1), width=4)
    frac = max(0, min(1, frac))
    if frac >= 0.999:
        c.create_oval(p, p, size - p, size - p, outline=color, width=4)
    elif frac > 0:
        c.create_arc(p, p, size - p, size - p, start=90, extent=-360 * frac, outline=color, width=4, style="arc")
    if text:
        c.create_text(size / 2, size / 2, text=text, fill=TEXT, font=font(8, True))


class Switch(tk.Canvas):
    """On/off switch bound to a BooleanVar; `command` runs after every flip."""
    W, H = 38, 20

    def __init__(self, parent, var, command=None, bg=CARD, disabled=False):
        super().__init__(parent, width=self.W, height=self.H, bg=bg, highlightthickness=0,
                         cursor="arrow" if disabled else "hand2")
        self.var, self.command, self._bg, self.disabled = var, command, bg, disabled
        if not disabled:                       # 10/31: a "coming soon" switch is drawn greyed out and ignores clicks
            self.bind("<Button-1>", self._flip)
        var.trace_add("write", lambda *_: self._draw())
        self._draw()

    def _flip(self, _e=None):
        self.var.set(not self.var.get())
        if self.command:
            self.command()

    def _draw(self):
        self.delete("all")
        on = bool(self.var.get())
        w, h, r = self.W, self.H, self.H / 2
        col = mix(self._bg, "#ffffff", 0.08) if self.disabled else GOLD if on else mix(self._bg, "#ffffff", 0.18)
        self.create_oval(0, 0, h, h, fill=col, width=0)
        self.create_oval(w - h, 0, w, h, fill=col, width=0)
        self.create_rectangle(r, 0, w - r, h, fill=col, width=0)
        x = w - r if on else r
        knob = mix(self._bg, "#ffffff", 0.3) if self.disabled else "#1e1e1e" if on else "#d0d0d0"
        self.create_oval(x - r + 3, 3, x + r - 3, h - 3, fill=knob, width=0)


class Stepper(tk.Canvas):
    """[ −  value  + ] in one rounded field, bound to an IntVar, clamped to lo..hi; `command(value)` after a change."""

    def __init__(self, parent, var, lo, hi, step=1, unit="", command=None, bg=CARD, width=3):
        super().__init__(parent, bg=_outer_bg(parent), highlightthickness=0, bd=0)
        self.var, self.lo, self.hi, self.step, self.command, self.unit = var, lo, hi, step, command, unit
        self._bg = bg
        f = font(10, True)
        self.bw = 26
        self.vw = f.measure("0" * width + (" " + unit if unit else "")) + 14
        self.h = f.metrics("linespace") + 8
        tk.Canvas.configure(self, width=self.bw * 2 + self.vw, height=self.h)
        self._hot = None
        self.bind("<Motion>", self._motion)
        self.bind("<Leave>", lambda e: self._set_hot(None))
        self.bind("<Button-1>", self._click)
        var.trace_add("write", lambda *_: self._draw())
        self._draw()

    def _side(self, x):
        return -1 if x < self.bw else (1 if x > self.bw + self.vw else None)

    def _motion(self, e):
        self._set_hot(self._side(e.x))

    def _set_hot(self, side):
        if side != self._hot:
            self._hot = side
            self.config(cursor="hand2" if side else "")
            self._draw()

    def _click(self, e):
        side = self._side(e.x)
        if side:
            self.add(side * self.step)

    def _value(self):
        try:
            return int(self.var.get())
        except (tk.TclError, ValueError):
            return self.lo

    def add(self, d):
        v = max(self.lo, min(self.hi, self._value() + d))
        self.var.set(v)
        if self.command:
            self.command(v)

    def _draw(self):
        try:
            self.delete("all")
        except tk.TclError:
            return
        w, h, bw = self.bw * 2 + self.vw, self.h, self.bw
        round_rect(self, 0, 0, w - 1, h - 1, h / 2, fill=mix(self._bg, "#ffffff", 0.08),
                   outline=mix(self._bg, "#ffffff", 0.08))
        self.create_rectangle(bw, 0, bw + self.vw, h - 1, fill=mix(self._bg, "#000000", 0.25), width=0)
        f = font(11, True)
        self.create_text(bw / 2 + 2, h / 2, text="−", fill=GOLD if self._hot == -1 else TEXT, font=f)
        self.create_text(w - bw / 2 - 2, h / 2, text="+", fill=GOLD if self._hot == 1 else TEXT, font=f)
        self.create_text(bw + self.vw / 2, h / 2, text=f"{self._value()}" + (f" {self.unit}" if self.unit else ""),
                         fill=TEXT, font=font(10, True))


def chip(parent, text, active, command, count=None, bg=BG, color=GOLD):
    lab = RoundLabel(parent, f"{text}" + (f"  {count}" if count is not None else ""), color if active else TEXT,
                     mix(bg, color, 0.25) if active else mix(bg, "#ffffff", 0.07), font(9, active), padx=11,
                     pady=4, cursor="hand2")
    lab.bind("<Button-1>", lambda e: command())
    return lab


def info(parent, text, bg=CARD):
    """A small (i): hover it to see more. Returns the label; the caller packs it."""
    lab = tk.Label(parent, text="ⓘ", font=font(11), bg=bg, fg=DIM, cursor="question_arrow")
    tip = {}

    def show(_e):
        if tip.get("w"):
            return
        w = tk.Toplevel(lab)
        w.wm_overrideredirect(True)
        w.configure(bg=GOLD_DIM)
        tk.Label(w, text=text, justify="left", bg=PANEL, fg=TEXT, wraplength=340, padx=10, pady=6,
                 font=font(9)).pack(padx=1, pady=1)
        w.wm_geometry(f"+{lab.winfo_rootx() + 18}+{lab.winfo_rooty() + 20}")
        tip["w"] = w
        lab.config(fg=GOLD)

    def hide(_e):
        if tip.get("w"):
            tip.pop("w").destroy()
        lab.config(fg=DIM)
    lab.bind("<Enter>", show)
    lab.bind("<Leave>", hide)
    return lab


def hover_card(widget, text_fn):
    """Show a small card next to `widget` while the pointer is over it; text_fn() gives the text."""
    tip = {}

    def show(_e):
        if tip.get("w"):
            return
        text = text_fn()
        if not text:
            return
        w = tk.Toplevel(widget)
        w.wm_overrideredirect(True)
        w.configure(bg=GOLD_DIM)
        tk.Label(w, text=text, justify="left", bg=PANEL, fg=TEXT, wraplength=320, padx=10, pady=6,
                 font=font(9)).pack(padx=1, pady=1)
        w.wm_geometry(f"+{widget.winfo_rootx() + 20}+{widget.winfo_rooty() + widget.winfo_height() + 2}")
        tip["w"] = w

    def hide(_e):
        if tip.get("w"):
            tip.pop("w").destroy()
    widget.bind("<Enter>", show, add="+")
    widget.bind("<Leave>", hide, add="+")


def fix_scroll(canvas, body, top=False):
    """11/2: re-measure a canvas+frame scroll box after its contents were rebuilt. Keeps the scroll position when it
    still makes sense, else clamps it (a shorter list used to leave the view below its end = blank area)."""
    try:
        body.update_idletasks()
        bh = max(body.winfo_reqheight(), 1)
        ch = max(canvas.winfo_height(), 1)
        first = 0.0 if top else canvas.yview()[0]
        canvas.configure(scrollregion=(0, 0, canvas.winfo_width(), bh))
        canvas.yview_moveto(max(0.0, min(first, 1.0 - ch / bh)) if bh > ch else 0.0)
    except tk.TclError:
        pass


class ThinScrollbar(tk.Canvas):
    """11/9 (owner: "i dont like the white scroll bar on the side"): a thin dark scrollbar drawn on a canvas -- dark
    track, rounded grey thumb (gold while hovered/dragged), hidden when everything fits. Same interface as
    tk.Scrollbar for what we use: command=widget.yview, widget.configure(yscrollcommand=bar.set)."""
    def __init__(self, parent, command=None, bg=BG, width=10, **kw):
        super().__init__(parent, width=width, bg=bg, highlightthickness=0, bd=0, **kw)
        self.command, self.first, self.last, self.hot, self._grab = command, 0.0, 1.0, False, None
        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Enter>", lambda e: self._hover(True))
        self.bind("<Leave>", lambda e: self._hover(False))
        self.bind("<Button-1>", self._press)
        self.bind("<B1-Motion>", self._drag)
        self.bind("<ButtonRelease-1>", lambda e: self._release())

    def set(self, first, last):
        self.first, self.last = float(first), float(last)
        self._draw()

    def _hover(self, on):
        self.hot = on
        self._draw()

    def _thumb(self):
        h = max(self.winfo_height(), 1)
        top, bot = self.first * h, self.last * h
        if bot - top < 24:                              # keep a thumb you can grab
            mid = (top + bot) / 2
            top, bot = max(0, mid - 12), min(h, mid + 12)
        return top, bot

    def _draw(self):
        self.delete("all")
        if self.last - self.first >= 0.999:            # everything fits -> no bar at all
            return
        w = max(self.winfo_width(), 1)
        top, bot = self._thumb()
        col = GOLD if (self.hot or self._grab is not None) else mix(LINE, "#ffffff", 0.18)
        r = (w - 4) / 2
        x1, x2 = 2, w - 2
        self.create_oval(x1, top + 1, x2, top + 1 + 2 * r, fill=col, outline=col)
        self.create_oval(x1, bot - 1 - 2 * r, x2, bot - 1, fill=col, outline=col)
        self.create_rectangle(x1, top + 1 + r, x2, bot - 1 - r, fill=col, outline=col)

    def _press(self, e):
        if self.last - self.first >= 0.999 or not self.command:
            return
        top, bot = self._thumb()
        if top <= e.y <= bot:
            self._grab = (e.y, self.first)
        else:                                           # click on the track: jump there
            h = max(self.winfo_height(), 1)
            self.command("moveto", max(0.0, e.y / h - (self.last - self.first) / 2))
        self._draw()

    def _drag(self, e):
        if self._grab is None or not self.command:
            return
        y0, f0 = self._grab
        h = max(self.winfo_height(), 1)
        self.command("moveto", max(0.0, f0 + (e.y - y0) / h))

    def _release(self):
        self._grab = None
        self._draw()


def scroll_area(parent, bg=BG):
    """Canvas + scrollbar; returns the inner frame. The wheel scrolls it while the pointer is over it."""
    outer = tk.Frame(parent, bg=bg)
    canvas = tk.Canvas(outer, bg=bg, highlightthickness=0)
    sb = ThinScrollbar(outer, command=canvas.yview, bg=bg)
    canvas.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y", padx=(4, 0))
    canvas.pack(side="left", fill="both", expand=True)
    body = tk.Frame(canvas, bg=bg)
    body_id = canvas.create_window((0, 0), window=body, anchor="nw")
    body.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>", lambda e: canvas.itemconfigure(body_id, width=e.width))

    def wheel(e):
        if canvas.yview() != (0.0, 1.0):
            canvas.yview_scroll(int(-e.delta / 120) or (-1 if e.delta > 0 else 1), "units")
    canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", wheel))
    canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
    def reset(top=True):
        """11/2: after the body was rebuilt shorter (a search), re-measure and jump to the top -- otherwise the view
        stays where the long list was scrolled to and the few matches sit above it (blank list)."""
        fix_scroll(canvas, body, top)
    outer.body = body
    outer.canvas = canvas
    outer.reset = reset
    return outer
