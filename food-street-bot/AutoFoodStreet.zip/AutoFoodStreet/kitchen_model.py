"""Kitchen model -- step 2/3 of the simulator plan (10/20, owner: "I love the simulation ... start with log-only").

Plan: https://sandybpatterson.github.io/lab-7q4k/  (snapshot -> choices -> play forward -> score -> act).
This first piece is WATCH-ONLY: it gathers what the bot already knows into one picture of the kitchen and logs it
every SNAPSHOT_SEC as `[sim]` lines -- what is cooking where and until when, which crops are growing, the stock it
last saw, storage -- plus the first forecasts ("storage likely full", "<crop> runs out"). Taps nothing, changes
nothing; later steps check these forecasts against what really happened before anything is allowed to steer.
"""
import time

SNAPSHOT_SEC = 600
_last = 0.0


def _fmt_left(t, now):
    s = int(t - now)
    return "ready" if s <= 0 else (f"{s // 60}m" if s < 3600 else f"{s // 3600}h{s % 3600 // 60:02d}m")


def snapshot(now=None):
    """dict: stations {name: [(dish, ready_at)]}, crops {name: ready_at}, stock {name: (n, seen_at)}, storage."""
    import event_orders as eo
    import order_fulfill as of
    now = now or time.time()
    stations = {}
    for (where, dish), readies in eo._my_batches.items():
        for r in readies:
            if r > now - 300:
                stations.setdefault(where, []).append((dish, r))
    try:
        import recipe_book as rb
        items = rb.load()["items"]
        for dish, finishes in of._cooking_state().items():
            st = items.get(dish, {}).get("station", "clipboard station")
            for f in finishes:
                stations.setdefault(st, []).append((dish, f))
    except Exception:                                  # noqa: BLE001
        pass
    crops = {k: v for k, v in eo._crop_ready.items() if v > now - 300}
    stock = {v[2]: (v[0], v[1]) for v in eo._stock_seen.values() if now - v[1] < 3600}
    storage = eo._storage.get("last")
    storage_age = now - eo._storage.get("last_t", 0) if storage else None
    return {"t": now, "stations": stations, "crops": crops, "stock": stock, "storage": storage,
            "storage_age": storage_age}


def forecasts(snap):
    """First, simple forecasts (checked against reality later)."""
    out = []
    st = snap["storage"]
    if st:
        used, cap = st
        incoming = sum(len(v) for v in snap["stations"].values()) + len(snap["crops"]) * 2
        if used + incoming >= cap:
            out.append(f"storage {used}/{cap} + about {incoming} on the way -> FULL likely within the hour")
    for name, (n, seen) in snap["stock"].items():
        if n == 0:
            out.append(f"{name} is at 0 (seen {int((snap['t'] - seen) // 60)} min ago)")
    return out


# --- Step 3: forecasts checked against reality (log-only) ----------------------------------------------------
# Storage in CHECK_AHEAD_SEC: what is there now + every batch/crop due before then (each collected batch or harvest
# adds to storage; cooking uses ingredients up again, so this is an upper guess). When the time comes, the real
# reading is compared and `[forecast check]` says how far off it was; running score in the line.
CHECK_AHEAD_SEC = 1800
_pending = []                  # (due time, predicted used, capacity, made at)
_score = {"n": 0, "abs_err": 0, "full_hit": 0, "full_miss": 0}


def _predict_storage(s):
    st = s["storage"]
    if not st or s["storage_age"] is None or s["storage_age"] > 600:
        return None
    due = s["t"] + CHECK_AHEAD_SEC
    incoming = sum(1 for v in s["stations"].values() for _d, r in v if r <= due)
    incoming += sum(2 for r in s["crops"].values() if r <= due)
    return min(st[0] + incoming, st[1]), st[1]


def _check_due(log, now):
    import event_orders as eo
    st, t = eo._storage.get("last"), eo._storage.get("last_t", 0)
    for item in list(_pending):
        due, pred, cap, made = item
        if now < due:
            continue
        if not st or abs(t - due) > 600:              # no reading near the due time -> can't grade it
            if now - due > 900:
                _pending.remove(item)
                log(f"[forecast check] storage at {time.strftime('%H:%M', time.localtime(due))}: no reading near "
                    "that time -- not graded.")
            continue
        _pending.remove(item)
        err = st[0] - pred
        _score["n"] += 1
        _score["abs_err"] += abs(err)
        if pred >= cap:
            _score["full_hit" if st[0] >= cap - 1 else "full_miss"] += 1
        log(f"[forecast check] storage at {time.strftime('%H:%M', time.localtime(due))}: predicted {pred}/{cap}, "
            f"real {st[0]}/{st[1]} ({'+' if err >= 0 else ''}{err}) | so far {_score['n']} checked, average off by "
            f"{_score['abs_err'] / _score['n']:.1f}"
            + (f", 'full' calls right {_score['full_hit']} / wrong {_score['full_miss']}"
               if _score['full_hit'] or _score['full_miss'] else ""))


# Stations: the model says how many of OUR batches should still be cooking at a station; when the bot opens that
# station's panel, the slots it sees grade it. One check per station per 3 min.
_st_checked = {}
_st_score = {"right": 0, "wrong": 0, "unknown": 0}


def station_seen(where, occupied, slots_total, log):
    if not where:
        return
    import event_orders as eo
    now = time.time()
    if now - _st_checked.get(where, 0) < 180:
        return
    _st_checked[where] = now
    ours = sorted(r for (st, _d), rs in eo._my_batches.items() if st == where for r in rs if r > now)
    if ours and occupied == 0:
        verdict, why = "wrong", f"model said {len(ours)} still cooking (until {time.strftime('%H:%M', time.localtime(ours[-1]))}), station empty"
    elif ours:
        verdict, why = "right", f"model said {len(ours)} cooking, saw {occupied}/{slots_total} busy"
    elif occupied:
        verdict, why = "unknown", f"model knew nothing cooking, saw {occupied}/{slots_total} busy (not ours, or from before Start)"
    else:
        verdict, why = "right", "model said free, station free"
    _st_score[verdict] += 1
    log(f"[forecast check] {where}: {verdict.upper()} -- {why} | stations so far: right {_st_score['right']}, "
        f"wrong {_st_score['wrong']}, unknown {_st_score['unknown']}")


def tick(log):
    """Called once per cycle; logs a snapshot at most every SNAPSHOT_SEC. Never raises."""
    global _last
    now = time.time()
    try:
        _check_due(log, now)
    except Exception as e:                             # noqa: BLE001
        log(f"[forecast check] skipped: {e!r}")
    if now - _last < SNAPSHOT_SEC:
        return
    _last = now
    try:
        s = snapshot(now)
        busy = "; ".join(f"{st}: " + ", ".join(f"{d} {_fmt_left(r, now)}" for d, r in sorted(v, key=lambda x: x[1]))
                         for st, v in s["stations"].items()) or "nothing the bot queued is cooking"
        crops = ", ".join(f"{c} {_fmt_left(r, now)}" for c, r in s["crops"].items()) or "none tracked"
        stock = ", ".join(f"{k} {n}" for k, (n, _t) in sorted(s["stock"].items())) or "nothing read recently"
        stg = (f"{s['storage'][0]}/{s['storage'][1]} ({int(s['storage_age'] // 60)} min ago)"
               if s["storage"] else "not read yet")
        log(f"[sim] cooking: {busy}")
        log(f"[sim] growing: {crops} | storage {stg}")
        log(f"[sim] stock seen: {stock}")
        for f in forecasts(s):
            log(f"[sim forecast] {f}")
        try:                                           # 11/9 S.O.U.P.S. advisor (log only)
            import soups
            soups.tick(s, log)
        except Exception as e:                         # noqa: BLE001
            log(f"[soups] skipped: {e!r}")
        p = _predict_storage(s)
        if p:
            _pending.append((now + CHECK_AHEAD_SEC, p[0], p[1], now))
            log(f"[sim forecast] storage in {CHECK_AHEAD_SEC // 60} min: about {p[0]}/{p[1]} (checked then)")
    except Exception as e:                             # noqa: BLE001 -- a test must never break the run
        log(f"[sim] skipped: {e!r}")
