@echo off
rem Starts AFSD without a console window. Uses the Python the installer put in ..\python.
cd /d "%~dp0\.."
if exist "python\pythonw.exe" (
  start "" "python\pythonw.exe" "autofoodstreet.py"
) else (
  echo Python not found -- run tools\Install AFSD.bat first.
  pause
)
