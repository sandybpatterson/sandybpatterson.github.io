@echo off
rem 11/28: connect this AutoFoodStreet folder to the afsd repo the OLD way (Git + your GitHub sign-in),
rem so Send logs and Update go through GitHub like the first PC did. Your files and settings stay as they are.
setlocal
cd /d "%~dp0\.."
echo.
echo  Connect AutoFoodStreet to GitHub
echo  Folder: %CD%
echo.
where git >nul 2>nul
if errorlevel 1 (
  echo [1/3] Installing Git (a Windows box may ask Yes/No -- click Yes^)...
  winget install --id Git.Git -e --silent --accept-package-agreements --accept-source-agreements
  set "PATH=%PATH%;C:\Program Files\Git\cmd"
)
where git >nul 2>nul
if errorlevel 1 (
  echo Git did not install. Install it from git-scm.com, then run this again.
  pause
  exit /b 1
)
echo [2/3] Connecting this folder to GitHub...
if not exist ".git" (
  git init -q
  git remote add origin https://github.com/sandybpatterson/afsd.git
)
git config user.name "AFSD bot"
git config user.email "afsd-bot@users.noreply.github.com"
echo       A GitHub sign-in window opens now -- sign in and press Authorize.
echo       (The first download can take several minutes.)
git fetch --depth 1 origin main
if errorlevel 1 (
  echo.
  echo  Could not reach the repo. Sign in with the GitHub account that owns sandybpatterson/afsd and run this again.
  pause
  exit /b 1
)
git reset -q origin/main
git branch -M main
echo [3/3] Switching Send logs and Update to GitHub...
if exist ".shared" del ".shared"
echo.
echo  Done. Close AFSD and open it again, then Start and Stop -- the logs go to GitHub.
pause
exit /b 0
