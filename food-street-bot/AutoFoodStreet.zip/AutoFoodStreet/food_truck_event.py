"""Food Truck event automation. Basic scaffold only, per explicit request
9/26 to wire up an option for this event "so we can run tests on it later"
-- NOT functional yet. See CLAUDE.md for full context.

What we know from the reference PDF (`OneDrive\\Desktop\\walpapers\\food
truck event.pdf`) and the earlier Food Truck order documented elsewhere in
this project: the event is a single large order card (e.g. Whipped Cream
x16, French Toast x15, Raw Ham x10) with a countdown until the truck
leaves, and a tiered voucher reward system (Bronze/Blue/Silver/Gold).

What we do NOT know yet, confirmed unresolved live 9/26: where the actual
in-game entry point is. Two candidates were ruled out this session:
- The chef-hat bottom-nav icon opens a *different* event ("Chef Challenge"),
  not this one.
- A starburst world-map marker that visually resembles a food truck/stand
  is actually a real-money ($8.99) purchase offer, not the event panel.
The globe/plane bottom-nav icon (~1400,790, "11d 5h" as of 9/26) and the
truck-parked-on-a-road-with-a-"?"-sign shown in the PDF are both still
unchecked candidates for next session.

Until the real entry point and a live screenshot of its panel are
confirmed, this module intentionally does nothing but log that fact --
per this project's hard rule of never acting/tapping blind. Fill in
NAV_ICON_TEMPLATE / panel detection / the order-reading logic once that
screenshot exists, following the same pattern as delivery_event.py.
"""
import os
import sys
import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from find_and_center import StopRequested, close_any_open_panel, check_stop

LOG = os.path.join(BASE_DIR, "run_log.txt")

# No templates yet -- entry point not confirmed live (see module docstring
# and CLAUDE.md). Deliberately left unset rather than guessing a
# coordinate/crop, since a wrong tap here risks landing on the $8.99
# purchase offer discovered at the visually-similar map marker 9/26.
NAV_ICON_TEMPLATE_PATH = os.path.join(BASE_DIR, "templates", "food_truck_nav_icon.png")


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] [food_truck_event] {msg}\n")
    try:
        print(f"[{ts}] [food_truck_event] {msg}")
    except (AttributeError, OSError):
        pass


def main(stop_flag=None):
    log("=== food truck event run start ===")
    try:
        close_any_open_panel()
        check_stop(stop_flag)
        if not os.path.exists(NAV_ICON_TEMPLATE_PATH):
            log("No nav icon template yet -- the Food Truck event's real entry "
                "point hasn't been confirmed live (the chef-hat icon is a "
                "different event, Chef Challenge, and a visually similar map "
                "marker turned out to be a $8.99 purchase offer). Doing nothing "
                "this run rather than guessing a tap location. Next step: check "
                "the globe/plane nav icon, capture a real screenshot of the Food "
                "Truck panel, then build detection the same way delivery_event.py "
                "did for the Delivery Event.")
            log("=== food truck event run end (not yet implemented) ===")
            return
        # TODO once NAV_ICON_TEMPLATE_PATH exists: mirror delivery_event.py's
        # pattern -- find the icon, tap it, confirm the real panel opened via
        # its own banner template (not just "something opened"), read the
        # order's ingredient requirements the same way order_fulfill.py reads
        # recipe-card ingredients, and log status. Never tap a green
        # real-money price button or a gem-cost skip button.
        log("=== food truck event run end (stub reached unexpectedly) ===")
    except StopRequested:
        log("=== food truck event run stopped early by user ===")
        raise


if __name__ == "__main__":
    main()
