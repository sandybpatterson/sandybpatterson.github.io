"""B.U.S.Y. -- Best Use of Stoves & Yards (owner 11/9-11/10). STEP 1, LOG ONLY: the price test.

One item per turn (the one priced longest ago): open My Trades, pick a free slot, choose the item, press the price "+"
to the max, READ the price, back out WITHOUT Put on Sale (trade_sell.sell(dry_run="price")). Prices go to
.busy_prices.json; every hour the log gets the coins-per-minute table (max price for 1 / its own cook or grow time).
Never sells, never gems, never saws (only trade_sell.SELLABLE items are ever opened).
"""
import json
import os
import time

BASE = os.path.dirname(os.path.abspath(__file__))
PRICES = os.path.join(BASE, ".busy_prices.json")
PRICE_GAP_SEC = 10 * 60          # one price look per 10 min
REPRICE_SEC = 24 * 3600          # a price is good for a day
RETRY_SEC = 2 * 3600             # 11/10: an item with no price yet is tried again after 2 h (not a day)
TABLE_GAP_SEC = 3600
_last = {"price": 0.0, "table": 0.0}


def load():
    try:
        with open(PRICES, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:                                  # noqa: BLE001
        return {}


def save(d):
    try:
        with open(PRICES, "w", encoding="utf-8") as fh:
            json.dump(d, fh, indent=1)
    except Exception:                                  # noqa: BLE001
        pass


def next_item(items, prices, now=None):
    """Pure: the item priced longest ago (never priced first), or None when all are fresh."""
    now = now or time.time()
    def wait(i):
        return REPRICE_SEC if prices.get(i, {}).get("price") else RETRY_SEC
    due = [(prices.get(i, {}).get("t", 0), i) for i in items if now - prices.get(i, {}).get("t", 0) >= wait(i)]
    return min(due)[1] if due else None


def coins_per_min(price, secs):
    if not price or not secs:
        return None
    return price / max(secs / 60.0, 1.0)


def table(prices, cook_of):
    """Pure: [(item, price, secs, coins/min)] best first; items without a price or time go last."""
    rows = []
    for item, d in prices.items():
        p = d.get("price")
        s = cook_of(item)
        rows.append((item, p, s, coins_per_min(p, s)))
    return sorted(rows, key=lambda r: -(r[3] or -1))


def _cook_of(item):
    try:
        import recipe_book as rb
        return rb.load()["items"][rb.resolve(item)].get("cook_sec")
    except Exception:                                  # noqa: BLE001
        return None


def tick(log, stop=None, can_price=True):
    """From the Busy Mode job. Never raises (StopRequested excepted)."""
    import find_and_center
    now = time.time()
    try:
        if can_price and now - _last["price"] >= PRICE_GAP_SEC:
            _last["price"] = now
            import trade_sell
            prices = load()
            item = next_item(sorted(trade_sell.SELLABLE), prices, now)
            if item:
                r = trade_sell.sell(item, 1, stop, dry_run="price")
                if r.get("price"):
                    prices[item] = {"price": r["price"], "t": now, "stock": r.get("stock")}
                    log(f"[busy] price test: {item} sells for at most {r['price']} coins (stock {r.get('stock')}); "
                        "nothing listed (log only).")
                else:
                    prices.setdefault(item, {})["t"] = now           # do not retry it every turn
                    log(f"[busy] price test: {item} -- no price read ({r.get('reason')}); next item next time.")
                save(prices)
        if now - _last["table"] >= TABLE_GAP_SEC:
            _last["table"] = now
            rows = [r for r in table(load(), _cook_of) if r[1]]
            if rows:
                log("[busy] coins per minute (max price / own time): " + "; ".join(
                    f"{i} {p}c/{(s or 0) // 60}m = {c:.1f}/min" if c else f"{i} {p}c/time ?"
                    for i, p, s, c in rows[:8]))
    except find_and_center.StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001
        log(f"[busy] price test skipped: {e!r}")


# ---- 11/15 LIVE (owner: "sell anything that takes less than 15 minutes to make and then queue one of everything
# else so it can have one to try and sell ... making coins and not just wasting time") ----------------------------
FAST_SEC = 15 * 60               # makes in under this -> keep making and selling it
FAST_KEEP = 2                    # quick items: stock up to this many (one on the stall, one ready)
SLOW_KEEP = 1                    # unpriced slow items: one, so it can be priced / tried on the stall
CROP_SELL = 5                    # at most this many of one crop per listing
SELL_GAP_SEC = 3 * 60            # stalls sell in 2-5 min (owner) -> look every 3 min
SELL_TRIES = 4                   # items tried per sell turn (each opens the picker)
EMPTY_REST_SEC = 15 * 60         # an item found empty is not tried again for this long
BUSY_FILE = os.path.join(BASE, ".busy_prep.json")
MISSING_REST_SEC = 2 * 3600      # 11/17: not in the picker / preview never matches -> leave it alone this long
_live = {"sell": 0.0, "empty": {}, "missing": {}}


def _book():
    import recipe_book as rb
    return rb.load()["items"]


def make_list(sellable, book, prices, crop_keep):
    """Pure: {key: stock-up-to} for the Busy Mode make step. Quick items (own time < FAST_SEC) up to FAST_KEEP
    (crops: crop_keep + FAST_KEEP); slower ones SLOW_KEEP only while they have no price yet. Unknown times skipped."""
    out = {}
    for k in sellable:
        it = book.get(k) or {}
        secs = it.get("cook_sec")
        if not secs:
            continue
        crop = it.get("kind") == "crop"
        if secs < FAST_SEC:
            out[k] = crop_keep + FAST_KEEP if crop else FAST_KEEP
        elif not (prices.get(k) or {}).get("price"):
            out[k] = SLOW_KEEP
    return out


def sell_order(sellable, book, prices, empty, now, missing=None):
    """Pure: items to try selling, best first -- priced quick items by coins/min, then other quick items, then slow
    items with no price yet (one sale = one price). Items found empty in the last EMPTY_REST_SEC are left out."""
    rows = []
    for k in sellable:
        if now - empty.get(k, 0) < EMPTY_REST_SEC or now - (missing or {}).get(k, 0) < MISSING_REST_SEC:
            continue
        secs = (book.get(k) or {}).get("cook_sec")
        p = (prices.get(k) or {}).get("price")
        quick = bool(secs) and secs < FAST_SEC
        if not quick and p:
            continue                                   # slow and already priced: not worth the stove time
        cpm = coins_per_min(p, secs) or 0
        rows.append((0 if (quick and p) else 1 if quick else 2, -cpm, k))
    return [k for _a, _b, k in sorted(rows)]


def sell_turn(log, stop, keep_for, now=None):
    """Collect sold slots and list what sells best, at the max price. Returns the number of listings."""
    import trade_sell
    now = now or time.time()
    if now - _live["sell"] < SELL_GAP_SEC:
        return 0
    _live["sell"] = now
    book, prices = _book(), load()
    made = 0
    for k in sell_order(sorted(trade_sell.SELLABLE), book, prices, _live["empty"], now,
                        _live["missing"])[:SELL_TRIES]:
        crop = (book.get(k) or {}).get("kind") in ("crop", "fruit")
        keep = max(0, int(keep_for(k)))
        r = trade_sell.sell(k, CROP_SELL if crop else 1, stop, keep=keep, want_price=not crop)
        if r.get("ok"):
            made += 1
            if r.get("price"):
                prices[k] = {"price": r["price"], "t": now, "stock": r.get("stock")}
                save(prices)
            log(f"[busy] LISTED {r['sold']} {k} at the max price" + (f" ({r['price']} coins)" if r.get("price") else "")
                + f" -- kept {keep}.")
            continue
        why = r.get("reason", "")
        log(f"[busy] {k}: not listed -- {why}")
        if "no free sale slot" in why or "could not open" in why:
            break
        if "not found in the picker" in why or "preview did not match" in why:
            _live["missing"][k] = now                  # 11/17: was retried every 15 min, a minute each, never sold
        elif "in stock" in why or "nothing to sell" in why:
            _live["empty"][k] = now
    return made


def make_turn(app, stop, log):
    """One Prep-engine turn on Busy Mode's own list (.busy_prep.json): the same routes, stock reads, collecting and
    never-gems rules as Prep work, but its own file, so the owner's Prep list is untouched."""
    import trade_sell
    import order_fulfill as of
    import prep_engine as pe
    want = make_list(sorted(trade_sell.SELLABLE), _book(), load(), of.CROP_RESERVE)
    try:
        with open(BUSY_FILE, encoding="utf-8") as fh:
            order = json.load(fh)
    except Exception:                                  # noqa: BLE001
        order = {}
    if order.get("items") != want:
        order["items"] = want
        order.pop("done", None)
    order.update(placed=True, asap=True)
    with open(BUSY_FILE, "w", encoding="utf-8") as fh:
        json.dump(order, fh, indent=1)
    old = pe.PREP_FILE
    pe.PREP_FILE = BUSY_FILE
    try:
        msg = pe.run(app, stop)
    finally:
        pe.PREP_FILE = old
    return str(msg).replace("Prep work", "Busy Mode", 1)


def live_tick(app, log, stop, keep_for, express=False):
    """From the Busy Mode job: sell (every 3 min), then make one thing. Never during an express."""
    import find_and_center
    if express:
        return "Busy Mode: an express is on -- waiting."
    try:
        sell_turn(log, stop, keep_for)
        tick(log, stop)                                # crops etc. still get a price look (never sells)
    except find_and_center.StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001
        log(f"[busy] sell turn failed (ignored): {e!r}")
    try:
        msg = make_turn(app, stop, log)
        log(f"[busy] make: {msg}")
        return msg
    except find_and_center.StopRequested:
        raise
    except Exception as e:                             # noqa: BLE001
        log(f"[busy] make turn failed (ignored): {e!r}")
        return "Busy Mode: make turn failed"
