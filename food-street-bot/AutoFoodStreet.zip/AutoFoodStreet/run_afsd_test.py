"""Headless one-cycle test of the Auto Fulfill Orders path exactly as the
AFSD GUI runs it (close leftover panel -> serve ready orders -> process the
whole Orders board -> readable report). Takes the session lock like every
other ad-hoc script; releases it even on error. Output also goes to
run_log.txt via order_fulfill's own logging."""
import os
import sys
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import session_lock
if not session_lock.check_and_warn("run_afsd_test.py"):
    sys.exit(1)
session_lock.acquire(owner="run_afsd_test")

import order_fulfill as of
from find_and_center import close_any_open_panel

try:
    t0 = time.time()
    close_any_open_panel(quiet=True, thorough=True)
    served = of.serve_ready_orders(stop_flag=None)
    results = of.process_all_visible(stop_flag=None)
    print(f"\n=== test cycle done in {time.time() - t0:.0f}s ===")
    print(of.format_run_report(results, served=served))
finally:
    session_lock.release()
