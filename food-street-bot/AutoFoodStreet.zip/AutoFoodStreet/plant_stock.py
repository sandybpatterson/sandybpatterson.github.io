"""Reads the stock number under a crop on the PLANT BAR (10/10). READ-ONLY.

Each crop card on the "Tap crops to plant them" bar has a white stock box at the bottom right: a dark digit (or two), or the word "Free" in a wider box. "Free" means stock 0 AND none of that crop is
growing -> one free seed (owner, confirmed live 10/10, no gems). A plain 0 means planting more would ask for gems.
 * stock_box(img, x): the white box under the card whose column is x (digit boxes ~65 px wide, the "Free" box ~107 px).
 * read_stock(img, x): "free" | int | None (None = could not read: unknown digit shape -- never guessed; the glyph picture is kept in templates/plant_stock_pending/ so it can be labelled).
Digit templates (templates/plant_stock_digits/<digit>_<n>.png) were cut from live pictures on 10/10: 0 2 3 4 6 7 8 so far; 1 5 9 are missing until one is seen.
"""
import glob
import os
import time

import cv2
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
TPL_DIR = os.path.join(BASE, "templates", "plant_stock_digits")
PENDING_DIR = os.path.join(BASE, "templates", "plant_stock_pending")
FREE_MIN_WIDTH = 90
MATCH_MIN = 0.80
_templates = None


def stock_box(img, x):
    """(x, y, w, h) of the white stock box in the card column x, or None."""
    if img is None or img.shape[:2] != (900, 1600):
        return None
    x0 = max(0, x + 20)
    reg = img[322:402, x0:x + 160]
    if reg.size == 0:
        return None
    white = (reg.min(axis=2) > 225).astype(np.uint8)
    white = cv2.morphologyEx(white, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
    n, _lab, st, _ = cv2.connectedComponentsWithStats(white, 8)
    best = None
    for i in range(1, n):
        xx, yy, w, h, a = st[i]
        if 40 <= w <= 160 and 28 <= h <= 60 and a >= 0.5 * w * h and (best is None or a > best[4]):
            best = (int(xx + x0), int(yy + 322), int(w), int(h), int(a))
    return best[:4] if best else None


def _norm(c):
    h, w = c.shape
    nw = max(1, int(round(w * 28.0 / h)))
    if nw > 22:                                        # wider than any single digit (two touching digits / noise): squash -> it will simply not match
        nw = 22
    r = cv2.resize(c, (nw, 28), interpolation=cv2.INTER_AREA).astype(np.float32)
    can = np.zeros((28, 22), np.float32)
    x0 = (22 - nw) // 2
    can[:, x0:x0 + nw] = r
    return can


def glyphs(img, box):
    """Dark digit shapes inside the stock box, left to right, as normalised 28x22 float images (255 = ink)."""
    x, y, w, h = box
    reg = img[y + 3:y + h - 3, x + 3:x + w - 3]
    dark = (reg.max(axis=2) < 130).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(dark, 8)
    out = []
    for i in range(1, n):
        gx, gy, gw, gh, a = st[i]
        if gh >= 14 and gw >= 4 and a >= 25:
            out.append((int(gx), _norm((lab[gy:gy + gh, gx:gx + gw] == i).astype(np.uint8) * 255)))
    return [g for _x, g in sorted(out, key=lambda t: t[0])]


def _load():
    global _templates
    if _templates is None:
        _templates = []
        for f in glob.glob(os.path.join(TPL_DIR, "*.png")):
            _templates.append((int(os.path.basename(f).split("_")[0]), cv2.imread(f, 0).astype(np.float32)))
    return _templates


def classify(g):
    best, bs = None, 0.0
    for d, t in _load():
        s = float(cv2.matchTemplate(g, t, cv2.TM_CCOEFF_NORMED)[0][0])
        if s > bs:
            best, bs = d, s
    return (best, bs) if bs >= MATCH_MIN else (None, bs)


def _save_pending(g, tag):
    try:
        os.makedirs(PENDING_DIR, exist_ok=True)
        if len(os.listdir(PENDING_DIR)) < 40:
            cv2.imwrite(os.path.join(PENDING_DIR, f"{int(time.time())}_{tag}.png"), np.clip(g, 0, 255).astype(np.uint8))
    except OSError:
        pass


def read_stock(img, x, save_unknown=True):
    """'free' (the free-seed label), an int, or None when the box is missing or a digit shape is unknown."""
    box = stock_box(img, x)
    if box is None:
        return None
    if box[2] >= FREE_MIN_WIDTH:
        return "free"
    gl = glyphs(img, box)
    if not gl:
        return _backup(img, box)
    digits = []
    for g in gl:
        d, _s = classify(g)
        if d is None:
            if save_unknown:
                _save_pending(g, f"x{x}")
            return _backup(img, box)
        digits.append(str(d))
    return int("".join(digits))


def _backup(img, box):
    """11/6: the plant-bar digit shapes (templates/plant_stock_digits) were never in the repo and lacked 1/5/9, so
    restock_all_crops logged 'stock unreadable' ~235x in 3 days and planted nothing. The station stock-box reader
    (stock_digits, same white box + game font, all 10 digits) reads 1659 of 1874 saved plant-bar boxes; spot-checked
    by eye (9 3 2 0 0 / 2 2 12 3 0 / 1 5 11 10 15) -- all right. None stays None (never guessed)."""
    try:
        import stock_digits
        bx, by, bw, bh = box
        return stock_digits.read_box(img[by:by + bh, bx:bx + bw])
    except Exception:                                  # noqa: BLE001
        return None
