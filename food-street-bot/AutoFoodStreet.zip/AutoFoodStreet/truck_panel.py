"""truck_panel.py -- 11/8 (owner: "golden food truck event ... the gold icon we can use to fast travel to the menu ...
i want to work on getting the food truck tab to work").

The truck has its own icon in the bottom bar during a truck event (gold truck + a timer, left of the chef hat). Tapping
it opens the "Food Truck" panel: up to 9 order slots in a 3x3 grid (a dish picture + how many it wants, or a green
check when that slot is done), "Leaving in: 7h 10m 46s" top right, the selected slot's dish on the right (green check
= hand in; the BLUE HAND and "Dismiss Truck" are never tapped -- street_truck.py does the tapping).

This module only LOOKS: find the icon, read the panel, keep what was read in .food_truck.json for the Food Truck tab.
Slot spots are street_truck.SLOT_CENTERS (from the 10/4 recording) -- the same on the owner's 11/8 golden truck panel.
"""
import json
import os
import re
import time

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATE = os.path.join(BASE_DIR, ".food_truck.json")
ICON_PATH = os.path.join(BASE_DIR, "templates", "food_truck", "gold_truck_icon.png")
ICON_REGION = (900, 700, 1260, 900)       # x1, y1, x2, y2 -- the bottom bar, left of the chef hat
ICON_MIN = 0.55                           # real icons 0.57-0.95 on 330 saved screens (the map behind it changes),
                                          # nothing else above 0.40 on 2,655 bright map screens
ICON_TIMER_BOX = (-75, 40, 75, 80)        # the "13h 22m" under the icon, relative to its centre
LEAVING_BOX = (880, 125, 1260, 175)       # "Leaving in: 7h 10m 46s"
GREEN_DONE = 600                          # green-check pixels in a slot: done slots 1,426-1,430, order slots 0
EMPTY_V = 80                              # an unused grid spot is the dark panel background (mean V 49)
_icon = []
LAST_LEAVING_TEXT = [None]                # what OCR saw in the "Leaving in" box last time (for the log)


def _tpl():
    if not _icon:
        t = cv2.imread(ICON_PATH)
        _icon.append(None if t is None else cv2.resize(t, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA))
    return _icon[0]


def find_icon(img):
    """(x, y) centre of the gold truck icon in the bottom bar, score -- or (None, score)."""
    t = _tpl()
    if t is None or img is None or img.shape[:2] != (900, 1600):
        return None, 0.0
    x1, y1, x2, y2 = ICON_REGION
    reg = cv2.resize(img[y1:y2, x1:x2], ((x2 - x1) // 2, (y2 - y1) // 2), interpolation=cv2.INTER_AREA)
    _mn, v, _ml, loc = cv2.minMaxLoc(cv2.matchTemplate(reg, t, cv2.TM_CCOEFF_NORMED))
    if v < ICON_MIN:
        return None, float(v)
    return (x1 + (loc[0] + t.shape[1] // 2) * 2, y1 + (loc[1] + t.shape[0] // 2) * 2), float(v)


def _digits(box):
    """White game digits (with their dark outline) in a small crop -> int or None (coin_digits shapes)."""
    try:
        import coin_digits as cd
        m = (box.min(axis=2) > 200).astype(np.uint8)
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        parts = [i for i in range(1, n) if st[i][4] >= 20 and 14 <= st[i][3] < box.shape[0] - 2]
        if not parts:
            return None
        tall = max(st[i][3] for i in parts)
        parts = sorted((i for i in parts if st[i][3] >= 0.6 * tall), key=lambda i: st[i][0])
        shapes = cd._HUD_T + cd._TEMPLATES
        out = ""
        for i in parts:
            x, y, w, h, _a = st[i]
            f = cd._feat(lab[y:y + h, x:x + w] == i)
            d, s = max(((d, float(f @ t)) for d, t in shapes), key=lambda z: z[1])
            if s < cd.HUD_MIN:
                return None
            out += str(d)
        return int(out) if out else None
    except Exception:                                  # noqa: BLE001
        return None


DONE_CHECK_PATH = os.path.join(BASE_DIR, "templates", "food_truck", "done_check.png")
DONE_MIN = 0.85                           # done slots 0.93-1.00 on the owner's 11/8 recording; anything else <= 0.66
_check = []


def done_score(img, cx, cy):
    """11/8 (owner: "it said it was handed in but it didn't submit it"): how much the slot's green looks like the
    game's big check mark (green-mask shape match). The old rule (>= 600 green pixels) also fired on green dishes."""
    if not _check:
        _check.append(cv2.imread(DONE_CHECK_PATH, cv2.IMREAD_GRAYSCALE))
    t = _check[0]
    c = img[cy - 90:cy + 85, cx - 85:cx + 85]
    if t is None or c.size == 0 or c.shape[0] < t.shape[0] or c.shape[1] < t.shape[1]:
        return 0.0
    m = cv2.inRange(cv2.cvtColor(c, cv2.COLOR_BGR2HSV), (40, 120, 100), (85, 255, 255))
    if not m.any():
        return 0.0
    return float(cv2.matchTemplate(m, t, cv2.TM_CCORR_NORMED).max())


def slot_state(img, cx, cy):
    """Pure-ish: {"state": done|order|none, "want": n|None} for the grid spot centred on (cx, cy)."""
    c = img[cy - 90:cy + 85, cx - 85:cx + 85]
    if c.size == 0:
        return {"state": "none", "want": None}
    hsv = cv2.cvtColor(c, cv2.COLOR_BGR2HSV)
    if done_score(img, cx, cy) >= DONE_MIN:
        return {"state": "done", "want": None}
    if float(hsv[..., 2].mean()) < EMPTY_V:
        return {"state": "none", "want": None}
    return {"state": "order", "want": _digits(img[cy + 35:cy + 88, cx - 45:cx + 45])}


PANE_COUNT_BOX = (1000, 525, 1155, 595)   # the "0/3" under the selected slot's dish (owner's 11/8 Let Me Play)


def read_have_need(img):
    """(have, need) from the right pane's white "0/3" (game digit shapes; the slash = the thin, sparse part), or None.
    Windows OCR read nothing there on the first live run (11/8)."""
    try:
        import coin_digits as cd
        x1, y1, x2, y2 = PANE_COUNT_BOX
        box = img[y1:y2, x1:x2]
        m = (box.min(axis=2) > 200).astype(np.uint8)
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        parts = sorted((i for i in range(1, n) if 25 <= st[i][3] <= 45 and st[i][2] <= 30 and st[i][4] >= 40),
                       key=lambda i: st[i][0])
        out, slash = "", False
        for i in parts:
            x, y, w, h, a = st[i]
            if a / float(w * h) < 0.35 and not slash:
                out += "/"
                slash = True
                continue
            f = cd._feat(lab[y:y + h, x:x + w] == i)
            d, s = max(((d, float(f @ t)) for d, t in cd._HUD_T + cd._TEMPLATES), key=lambda z: z[1])
            if s < cd.HUD_MIN:
                return None
            out += str(d)
        m2 = re.fullmatch(r"(\d{1,2})/(\d{1,2})", out)
        return (int(m2.group(1)), int(m2.group(2))) if m2 else None
    except Exception:                                  # noqa: BLE001
        return None


def dish_name_guess(icon):
    """A name for a slot's dish picture: what the bot learned from the game's tooltip, else the clipboard dish library
    (order_fulfill.identify_dish -> recipe-book name). None when neither knows it."""
    for k, v in _names().items():
        ref = _ref(k)
        if ref is not None and _same(icon, ref):
            return v
    try:
        import order_fulfill as of
        hit = of.identify_dish(icon)
        if hit and hit.get("confidence", 0) >= 0.8:
            try:
                import recipe_book as rb
                return rb.load()["items"][rb.resolve(hit["name"])]["name"]
            except Exception:                          # noqa: BLE001
                return hit["name"].replace("_", " ").title()
    except Exception:                                  # noqa: BLE001
        pass
    return None


def dish_icon(img, cx, cy):
    return img[cy - 50:cy + 35, cx - 55:cx + 55].copy()


def _same(a, b):
    try:
        a = cv2.resize(cv2.cvtColor(a, cv2.COLOR_BGR2GRAY), (48, 40)).astype(np.float32)
        b = cv2.resize(cv2.cvtColor(b, cv2.COLOR_BGR2GRAY), (48, 40)).astype(np.float32)
        return float(cv2.matchTemplate(a, b, cv2.TM_CCOEFF_NORMED)[0][0]) >= 0.85
    except Exception:                                  # noqa: BLE001
        return False


_UNITS = "dhms"
_SECS = {"d": 86400, "h": 3600, "m": 60, "s": 1}


def parse_leaving(text):
    """'Leaving in: 7h 10m 46s' -> seconds, or None.
    11/8 live: the tab said 16 min while the truck said 6+ hours -- OCR misread the 'h' ('6n 16m 30s'), and the old
    pattern then kept only '16m 30s'. Now every number counts: a number whose letter is not d/h/m/s gets the next
    bigger unit than the number after it (h before m, m before s)."""
    t = (text or "").lower()
    t = t.split(":", 1)[1] if ":" in t else t
    toks = re.findall(r"(\d+)\s*([a-z]?)", t)
    if not toks:
        return None
    units = [None] * len(toks)
    for k in range(len(toks) - 1, -1, -1):
        letter = toks[k][1]
        if letter and letter in _UNITS:
            units[k] = letter
        elif k + 1 < len(toks) and units[k + 1] and _UNITS.index(units[k + 1]) > 0:
            units[k] = _UNITS[_UNITS.index(units[k + 1]) - 1]
        else:
            units[k] = "s" if k == len(toks) - 1 else None
    if None in units or len(set(units)) != len(units):
        return None
    return sum(int(n) * _SECS[u] for (n, _), u in zip(toks, units))


LEAVING_JUMP_SEC = 15 * 60


def sane_leaving(new, prev, now=None):
    """Pure (11/8): the leaving time to keep. prev = the last saved state ({"leaving_sec", "t", "leaving_odd"}).
    A reading more than 15 min off what the clock says it should be now is kept back once (OCR slip, e.g. 6h 16m read
    as 16m); a second off reading in a row is believed (a new truck). Returns (seconds or None, odd_flag)."""
    now = time.time() if now is None else now
    exp = None
    if prev and prev.get("leaving_sec") and prev.get("t"):
        exp = prev["leaving_sec"] - (now - prev["t"])
        if exp <= 0:
            exp = None
    if new is None:
        return (int(exp) if exp else None), False
    if exp is None or abs(new - exp) <= LEAVING_JUMP_SEC or prev.get("leaving_odd"):
        return new, False
    return int(exp), True


LEAVING_DIGITS_BOX = (1045, 125, 1270, 178)   # just the "7h 24m 35s" after "Leaving in:" (white, dark outline)


def read_leaving_digits(img):
    """11/8: 'Leaving in' by the game's own digit shapes (coin_digits) -- Windows OCR dropped the hours every time
    (the tab counted 16 min down to 0 while the truck had 6 h left). Digits score ~0.95; the unit letters do not: a
    tall letter = h (d when it is the first of four groups), short + wide = m, short + narrow = s. Seconds or None."""
    try:
        import coin_digits as cd
        x1, y1, x2, y2 = LEAVING_DIGITS_BOX
        box = img[y1:y2, x1:x2]
        m = (box.min(axis=2) > 200).astype(np.uint8)
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        parts = sorted((i for i in range(1, n) if st[i][4] >= 40 and st[i][3] >= 12), key=lambda i: st[i][0])
        if not parts:
            return None
        tall = max(st[i][3] for i in parts)
        groups, cur = [], ""
        for i in parts:
            x, y, w, h, _a = st[i]
            f = cd._feat(lab[y:y + h, x:x + w] == i)
            d, sc = max(((d, float(f @ t)) for d, t in cd._HUD_T + cd._TEMPLATES), key=lambda z: z[1])
            if sc >= cd.HUD_MIN and h >= 0.85 * tall:
                cur += str(d)
                continue
            if not cur:                               # a letter with no number before it: not part of the time
                continue
            unit = "h" if h >= 0.85 * tall else ("m" if w >= 17 else "s")
            groups.append((int(cur), unit))
            cur = ""
        if cur or not groups:
            return None
        if len(groups) == 4:                          # 1d 2h 3m 4s
            groups[0] = (groups[0][0], "d")
        units = [u for _n, u in groups]
        if len(set(units)) != len(units):
            return None
        return sum(v * _SECS[u] for v, u in groups)
    except Exception:                                 # noqa: BLE001
        return None


def read_panel(img, ocr=None, slots=None):
    """{"leaving_sec", "slots": [{"i", "state", "want", "name"}]} from an open Food Truck panel.
    Names come from what the bot learned before (the tooltip it reads when it chases a dish), matched by picture."""
    if slots is None:
        import street_truck
        slots = street_truck.SLOT_CENTERS
    if ocr is None:
        try:
            import popup_ocr
            ocr = popup_ocr.read_text
        except Exception:                              # noqa: BLE001
            ocr = None
    leaving = read_leaving_digits(img)
    if leaving is None and ocr is not None:
        try:
            raw = ocr(img, LEAVING_BOX)
            leaving = parse_leaving(raw)
            LAST_LEAVING_TEXT[0] = raw
        except Exception:                              # noqa: BLE001
            leaving = None
    out, pics = [], []
    for i, (cx, cy) in enumerate(slots, 1):
        s = slot_state(img, cx, cy)
        s["i"] = i
        s["name"] = None
        if s["state"] == "order":
            icon = dish_icon(img, cx, cy)
            s["name"] = dish_name_guess(icon)
            s["g"] = picture_group(icon, pics)
        out.append(s)
    for s in out:                                      # a slot whose picture matched a named one gets its name
        if s.get("g") is not None and not s.get("name"):
            s["name"] = next((o["name"] for o in out if o.get("g") == s["g"] and o.get("name")), None)
    return {"leaving_sec": leaving, "slots": out}


SAME_PIC_MIN = 0.85


def _sat_icon(icon):
    """Saturation channel of a slot picture: the dish is colourful, the slot background grey -- so a selected (lighter)
    slot still matches its twins (11/9: grey match 0.13 for the selected Mac & Cheese, saturation 0.98)."""
    return cv2.resize(cv2.cvtColor(icon, cv2.COLOR_BGR2HSV)[:, :, 1], (48, 40)).astype(np.float32)


def picture_group(icon, pics):
    """11/9 (owner: "it is tapping on every order of apple pie"): slots showing the same dish picture share one group,
    so the bot taps ONE slot per dish even when it cannot name it. `pics` collects one picture per group."""
    try:
        a = _sat_icon(icon)
        for gi, b in enumerate(pics):
            if float(cv2.matchTemplate(a, b, cv2.TM_CCOEFF_NORMED)[0][0]) >= SAME_PIC_MIN:
                return gi
        pics.append(a)
        return len(pics) - 1
    except Exception:                                  # noqa: BLE001
        return None


def dish_groups(slots):
    """Pure (11/8): open order slots grouped by dish (name, else 'unknown' each on its own), board order kept."""
    groups, by = [], {}
    for s in slots:
        if s.get("state") != "order":
            continue
        k = (f"pic{s['g']}" if s.get("g") is not None else "") or (s.get("name") or "").lower() or f"#{s.get('i')}"
        if k not in by:
            by[k] = []
            groups.append(by[k])
        by[k].append(s)
    return groups


def dish_rows(slots):
    """Pure (11/8, owner: "mac and cheese 1/3 -- see the issue?"): one row per dish for the tab / summary. Every slot of a
    dish shows the same storage count, so 2 slots x 3 with 1 in storage = have 1 of 6, not '1/3' twice."""
    rows = []
    for g in dish_groups(slots):
        need = sum((s.get("need") or s.get("want") or 0) for s in g) or None
        have = g[0].get("have")
        each = g[0].get("need") or g[0].get("want")
        ready = (have // each) if (have is not None and each) else None
        rows.append({"name": g[0].get("name"), "slots": [s["i"] for s in g], "have": have, "need": need,
                     "ready": None if ready is None else min(ready, len(g))})
    return rows


def slot_shares(slots):
    """Pure (11/8, owner: "if we have 3 in stock we only have enough for one order to be submitted"): every slot of a
    dish shows the SAME storage count, so share it out in board order -- 3 in stock with two orders of 3 -> the first
    order 3/3, the second 0/3. Returns {slot number: (have for this order, need)} for the open order slots."""
    out = {}
    for g in dish_groups(slots):
        left = g[0].get("have")
        for s in g:
            need = s.get("need") or s.get("want")
            if left is None or not need:
                out[s["i"]] = (None, need)
                continue
            got = min(left, need)
            out[s["i"]] = (got, need)
            left -= got
    return out


def total_short(slots, name, have):
    """Pure (11/8): how many of `name` the WHOLE truck still wants beyond what we have -- every unfinished slot of
    that dish counts (each slot shows the same storage 'have'). None when nothing is known."""
    if not name:
        return None
    needs = [s.get("need") or s.get("want") for s in slots
             if s.get("state") == "order" and (s.get("name") or "").lower() == name.lower()]
    needs = [n for n in needs if n]
    if not needs:
        return None
    return max(0, sum(needs) - (have or 0))


# --- names: the picture of a slot's dish -> the name the game gave in its tooltip ---------------------------------
NAME_DIR = os.path.join(BASE_DIR, "templates", "food_truck", "dishes")


def _names():
    try:
        with open(os.path.join(NAME_DIR, "names.json"), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _ref(key):
    return cv2.imread(os.path.join(NAME_DIR, key + ".png"))


def learn_name(img, cx, cy, name):
    """Remember this slot's dish picture under the game's name (once per picture)."""
    if not name:
        return
    try:
        os.makedirs(NAME_DIR, exist_ok=True)
        ic = dish_icon(img, cx, cy)
        names = _names()
        for k in names:
            ref = _ref(k)
            if ref is not None and _same(ic, ref):
                return
        key = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_") or "dish"
        n = 1
        while key + (f"__{n}" if n > 1 else "") in names:
            n += 1
        key = key + (f"__{n}" if n > 1 else "")
        cv2.imwrite(os.path.join(NAME_DIR, key + ".png"), ic)
        names[key] = name
        with open(os.path.join(NAME_DIR, "names.json"), "w", encoding="utf-8") as fh:
            json.dump(names, fh, indent=1)
    except Exception:                                  # noqa: BLE001
        pass


# --- what the Food Truck tab shows ---------------------------------------------------------------------------------
EXTRA_KEYS = ("working", "cooking", "skipped", "order")    # set by street_truck between panel reads


def save(state):
    """Write what the panel showed; keeps the street_truck extras (working dish, cooking times, skipped dishes)."""
    try:
        prev = load()
        state = dict(state, t=time.time())
        for k in EXTRA_KEYS:
            if k not in state and k in prev:
                state[k] = prev[k]
        with open(STATE, "w", encoding="utf-8") as fh:
            json.dump(state, fh)
    except OSError:
        pass


def update(**fields):
    """Merge a few fields into the saved state without touching the panel read time (11/8 game-style tab)."""
    try:
        st = load()
        st.update(fields)
        with open(STATE, "w", encoding="utf-8") as fh:
            json.dump(st, fh)
    except OSError:
        pass


def picture_path(name):
    """The learned slot picture of a dish (templates/food_truck/dishes), or None."""
    if not name:
        return None
    for k, v in _names().items():
        if (v or "").lower() == name.lower():
            p = os.path.join(NAME_DIR, k + ".png")
            if os.path.exists(p):
                return p
    return None


def load():
    try:
        with open(STATE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def summary(state):
    """Pure: 'Leaving in 7h 10m -- 2 of 8 done; wants Mac & Cheese (2 slots) 1 of 6, Apple Pie (4 slots) 0 of 12'."""
    slots = [s for s in state.get("slots", []) if s.get("state") != "none"]
    done = sum(1 for s in slots if s["state"] == "done")
    parts = []
    for r in dish_rows(slots):
        n = len(r["slots"])
        nm = (r["name"] or "a dish") + (f" ({n} slots)" if n > 1 else "")
        if r["have"] is not None and r["need"]:
            parts.append(f"{nm} {r['have']} of {r['need']}")
        else:
            parts.append(f"{nm} wants {r['need'] or '?'}")
    left = state.get("leaving_sec")
    head = f"Leaving in {left // 3600}h {left % 3600 // 60}m -- " if left else ""
    return head + f"{done} of {len(slots)} done" + (f"; wants {', '.join(parts)}" if parts else "")
