"""Run trace (10/10): extra logging that explains what the bot did and why. READ-ONLY -- it never taps anything.

Everything here is observation only and every public function swallows its own errors (a trace problem must never stop a real run).
It writes to run_log.txt with the tag [trace]. Pieces:

 1. COUNTS / STOCK / CHECK  -- have/need counts under each ingredient read on a station panel, how a stock changed since the last look,
                               and whether it rose after a chase that reported progress (so "harvested 1" can be checked against reality).
 2. ORDER RESULT            -- one line per order: what happened, WHY it stopped, how long it took (reasons come from RULES below,
                               matched against the log lines order_fulfill already writes).
 3. fail pictures           -- a picture of the screen when a rule marked with a picture tag fires (rate limited) -> templates/fail_pictures/
 4. ARRIVED                 -- which station panel a quick-travel really landed on (Windows OCR of the panel title) vs the one expected.
 5. CYCLE SUMMARY           -- one line per AFSD cycle: served / queued / made / harvested / planted / chased / blocked + gems, coins, tickets change.
 6. timing                  -- phase timers inside one order (board, travel, panel, read, act).
 7. debug pictures          -- OPTIONAL: if a file named ".debug_pictures" exists in the bot folder, before/after pictures around the actions that
                               matter (queue a batch, harvest, plant) go to templates/debug_pictures/ (rolling, newest 200, nothing older than a day).
"""
import collections
import json
import os
import re
import time

BASE = os.path.dirname(os.path.abspath(__file__))
LOG_PATH = os.path.join(BASE, "run_log.txt")
FAIL_DIR = os.path.join(BASE, "templates", "fail_pictures")
DEBUG_DIR = os.path.join(BASE, "templates", "debug_pictures")
DEBUG_FLAG = os.path.join(BASE, ".debug_pictures")
FAIL_KEEP = 300
DEBUG_KEEP = 200
FAIL_COOLDOWN_SEC = 60
TEXT_Y = 522                                   # y of the have/need text under an ingredient icon on a station panel
TITLE_REGION = (500, 95, 1100, 175)            # station panel title (Windows OCR reads it cleanly)


def _log(msg):
    line = f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] [trace] {msg}"
    try:
        print(line)
    except (AttributeError, OSError):
        pass
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass


def _safe(fn):
    def wrapper(*a, **k):
        try:
            return fn(*a, **k)
        except Exception as e:                       # noqa: BLE001 -- tracing must never break a run
            try:
                _log(f"(trace error in {fn.__name__}: {e!r})")
            except Exception:                        # noqa: BLE001
                pass
            return None
    wrapper.__name__ = fn.__name__
    return wrapper


# ---------------------------------------------------------------------------------------------------------------
# 3 + 2. log rules: (regex on an order_fulfill log line, reason text, picture tag or None)
# ---------------------------------------------------------------------------------------------------------------
RULES = (
    (r"^No quick-travel '\?' found", "the quick-travel '?' tooltip never appeared (timing, or a different dialog)", "tooltip_missing"),
    (r"^No quick-travel tooltip", "the quick-travel '?' tooltip never appeared (timing, or a different dialog)", "tooltip_missing"),
    (r"triggered a gem-buy dialog", "the tap opened a gem-buy dialog (declined)", None),
    (r"COLLECTION BLOCKER still active", "a finished item is blocking the station and the centre taps did not open it", "blocker_stuck"),
    (r"^Travel completed but no station panel", "quick-travel landed on the map, no station panel opened", "no_panel"),
    (r"Orders board is still open after the", "quick-travel did not happen: the Orders board was still open", "still_on_board"),
    (r"station panel never auto-opened", "the station panel never opened after travel", "no_panel"),
    (r"Could not locate '.+''s own recipe card|has no legacy card_index", "its recipe card was not found by sight", "card_not_found"),
    (r"read as unclassifiable|unreadable", "the ingredient icons could not be read (position/scroll problem)", "unreadable"),
    (r"no free \(EMPTY\) queue slot", "every queue slot on that station is busy", "queue_full"),     # pass 78: picture, to see what fills the slots
    (r"already queued \d+ batch", "already queued the limit for this pass", None),
    (r"max recursion depth", "chain too deep (recursion limit)", None),
    (r"Couldn't get the plant-crops bar open", "the plot is still growing / the plant bar did not open", "bar_not_open"),
    (r"out of stock with nothing to replant", "crop out of stock (gem-buy dialog declined)", None),
    (r"No ripe '.+' clusters visible", "no ripe fruit visible at the grove", None),
    (r"have no automated way forward", "the missing ingredient is not in the chase list (or was already tried this pass)", None),
    (r"Dish not yet in the trained library", "the dish icon is not trained yet", None),
    (r"isn't in the known plant-bar column list", "that crop has no plant-bar position", None),
    (r"Chasing '.+' made no progress", "chasing that ingredient made no progress", None),
)
_RULES = [(re.compile(p), r, t) for p, r, t in RULES]
# stats taken from log lines the bot already writes
_STAT_RULES = (
    (re.compile(r"^Harvested (\d+) '(.+?)' cluster"), "harvested"),
    (re.compile(r"^Planted '(.+?)' from current stock"), "planted"),
    (re.compile(r"^'(.+?)' ingredients all sufficient -- tapping its action button"), "made at stations"),
)

_reasons = []                                    # reasons seen since reset_order()
_last_fail_pic = {}                              # tag -> time


def reset_order():
    del _reasons[:]
    _phase_reset()


@_safe
def note_log(msg):
    """Called by order_fulfill.log for EVERY line. Collects reasons, stats and (rate limited) fail pictures."""
    for rx, reason, tag in _RULES:
        if rx.search(msg):
            if not _reasons or _reasons[-1] != reason:
                _reasons.append(reason)
            if tag:
                fail_picture(tag, reason)
            break
    for rx, kind in _STAT_RULES:
        m = rx.search(msg)
        if m:
            if kind == "harvested":
                stat(kind, m.group(2), int(m.group(1)))
            else:
                stat(kind, m.group(1), 1)
            break


@_safe
def fail_picture(tag, note=""):
    """Save what is on screen NOW (a read-only screenshot), at most one per tag per minute."""
    now = time.time()
    if now - _last_fail_pic.get(tag, 0) < FAIL_COOLDOWN_SEC:
        return None
    _last_fail_pic[tag] = now
    import adb_helper
    img = adb_helper.screenshot()
    path = _write_picture(FAIL_DIR, f"{int(now)}_{tag}", img, FAIL_KEEP)
    if path:
        _log(f"PICTURE [{tag}]: {os.path.relpath(path, BASE)} -- {note}")
    return path


def _write_picture(folder, name, img, keep, max_age_sec=None):
    import cv2
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, name + ".png")
    cv2.imwrite(path, img)
    try:
        files = sorted((os.path.join(folder, f) for f in os.listdir(folder) if f.endswith(".png")), key=os.path.getmtime)
        for old in files[:-keep]:
            os.remove(old)
        if max_age_sec:
            cutoff = time.time() - max_age_sec
            for f in files:
                if os.path.exists(f) and os.path.getmtime(f) < cutoff:
                    os.remove(f)
    except OSError:
        pass
    return path


# ---------------------------------------------------------------------------------------------------------------
# 6. timing
# ---------------------------------------------------------------------------------------------------------------
_phase_t = [time.time()]
_phase_done = collections.OrderedDict()


def _phase_reset():
    _phase_t[0] = time.time()
    _phase_done.clear()


@_safe
def mark(name):
    """Record the time since the previous mark (or the order start) under `name`."""
    now = time.time()
    _phase_done[name] = _phase_done.get(name, 0.0) + (now - _phase_t[0])
    _phase_t[0] = now


def _fmt_sec(s):
    s = int(round(s))
    return f"{s // 60}m{s % 60:02d}s" if s >= 60 else f"{s}s"


def phase_report(total):
    parts = [f"{k} {_fmt_sec(v)}" for k, v in _phase_done.items() if v >= 1]
    used = sum(_phase_done.values())
    if total - used >= 1:
        parts.append(f"act/other {_fmt_sec(total - used)}")
    return ", ".join(parts)


# ---------------------------------------------------------------------------------------------------------------
# 2. one line per order
# ---------------------------------------------------------------------------------------------------------------
_DEFAULT_WHY = {
    "queued": "all ingredients were green -- the action button was tapped",
    "nothing_to_do": "no red (missing) items anywhere on the board",
    "travel_failed": "the quick-travel '?' tooltip was missed",
    "panel_not_opened": "the station panel did not open",
    "crop_growing": "the missing item is a crop that is still growing (grow-timer card closed)",
    "not_trained": "the dish icon is not in the trained library",
    "dish_card_not_found": "its recipe card was not found by sight",
    "ingredients_unreadable": "the ingredient icons could not be read",
    "blocked_on_ingredient": "an ingredient is missing and could not be chased",
    "recursed_ingredient": "went to fetch the missing ingredient and made progress",
    "retry_next_ingredient": "that ingredient made no progress; the next one will be tried",
    "collected_blocker": "collected a finished item that was blocking the station; the board is rechecked next",
}


@_safe
def order_result(index, result, elapsed):
    status = result.get("status", "?")
    dish = result.get("dish") or "-"
    miss = result.get("missing_ingredients")
    why = " <- ".join(reversed(_reasons[-3:])) if _reasons else _DEFAULT_WHY.get(status, "")
    if status == "queued":
        stat("queued", dish, 1)
    elif status in ("blocked_on_ingredient", "retry_next_ingredient", "ingredients_unreadable", "dish_card_not_found"):
        stat("blocked", f"{dish}" + (f" ({', '.join(miss)})" if miss else ""), 1)
    elif status == "collected_blocker":
        stat("collected finished items", dish if dish != "-" else "an item", 1)
    _log(f"ORDER RESULT #{index}: {dish} -> {status}" + (f" [board order {result.get('order')}]" if result.get("order") else "") + (f" (missing: {', '.join(miss)})" if miss else "")
         + f" in {_fmt_sec(elapsed)}" + (f" | why: {why}" if why else "") + (f" | timing: {phase_report(elapsed)}" if _phase_done else ""))


# ---------------------------------------------------------------------------------------------------------------
# 1. counts
# ---------------------------------------------------------------------------------------------------------------
_stock = {}                                      # ingredient -> (have, time, need)
_chased = {}                                     # ingredient -> (time, progressed)
_dish_rise = {}                                  # 10/22: dish label -> last time one of its ingredients' stock rose


def dish_rose_since(dish, t):
    return bool(dish) and _dish_rise.get(dish, 0) > t


@_safe
def log_counts(label, img, ingredients):
    """ingredients: [(color, x, y, name)] as read_ingredients returns. Logs have/need per named ingredient and any stock change."""
    import event_digits
    now = time.time()
    shown = []
    for color, x, y, name in ingredients:
        if not name:
            continue
        c = event_digits.read_count(img, x, TEXT_Y, save_unknown=False)
        if not c:
            shown.append(f"{name} ?")
            continue
        shown.append(f"{name} {c['have']}/{c['need']}" + (" SHORT" if c["color"] == "red" else ""))
        prev = _stock.get(name)
        ch = _chased.get(name)
        if prev and prev[0] != c["have"]:
            ago = _fmt_sec(now - prev[1])
            _log(f"STOCK {name}: {prev[0]} -> {c['have']} ({c['have'] - prev[0]:+d}) since the last look {ago} ago")
            if c["have"] > prev[0] and prev[0] < (prev[2] or 0):   # 10/27: only a SHORT ingredient rising is progress
                _dish_rise[label] = now                            # (mushroom 5 -> 11 kept a whipped-cream-blocked order alive)
        if ch and prev and ch[0] > prev[1]:
            rose = c["have"] > prev[0]
            if ch[1]:
                _log(f"CHECK {name}: the last chase reported PROGRESS; stock was {prev[0]}, now {c['have']} -- "
                     + ("rose, as expected." if rose else "did NOT rise (still cooking/growing, used by another dish, or the log was wrong)."))
                if not rose:                         # 10/22: a fake bush harvest -> order_fulfill stops counting it
                    try:
                        import sys
                        _of = sys.modules.get("order_fulfill")
                        if _of is not None:
                            _of.harvest_no_rise(name)
                    except Exception:                # noqa: BLE001
                        pass
            else:
                _log(f"CHECK {name}: the last chase reported NO progress; stock was {prev[0]}, now {c['have']}"
                     + (" -- it rose anyway (a late harvest/collect?)." if rose else "."))
            _chased.pop(name, None)
        _stock[name] = (c["have"], now, c["need"])
    if shown:
        _log(f"COUNTS {label}: " + ", ".join(shown))


@_safe
def note_chase(name, progressed):
    _chased[name] = (time.time(), bool(progressed))
    stat("chased", f"{name} {'ok' if progressed else 'no progress'}", 1)


# ---------------------------------------------------------------------------------------------------------------
# 4. where did the trip land
# ---------------------------------------------------------------------------------------------------------------
_STATIONS = None


def _station_of(item):
    global _STATIONS
    if _STATIONS is None:
        d = json.load(open(os.path.join(BASE, "recipes.json"), encoding="utf-8"))
        items = d.get("items", d)
        _STATIONS = {k: v.get("station") for k, v in items.items() if isinstance(v, dict)}
        _STATIONS.update({"mystery_catch": "Fisherman's Boat", "chicken": "Chicken Coop"})
    return _STATIONS.get(item)


def _words(s):
    return {w for w in re.findall(r"[a-z]+", (s or "").lower()) if len(w) > 2}


@_safe
def arrived(img, item, label=""):
    """Log which station panel is on screen (title read with Windows OCR) vs the one `item` is made at. A mismatch also saves a picture."""
    import popup_ocr
    title = (popup_ocr.read_text(img, TITLE_REGION) or "").strip()
    title = re.sub(r"\d+\s*[hms]\b.*$", "", re.sub(r"(\d+[hms]\s*)+$", "", title)).strip()
    expected = _station_of(item)
    if not title:
        _log(f"ARRIVED {label}: no panel title read (expected {expected or '?'} for {item})")
        return None
    if not expected:
        _log(f"ARRIVED {label}: panel '{title}' (no expected station known for {item})")
        return title
    ok = bool(_words(title) & _words(expected)) or title.lower() in expected.lower()
    _log(f"ARRIVED {label}: panel '{title}' -- expected '{expected}' for {item}: " + ("OK" if ok else "MISMATCH (wrong landing?)"))
    if not ok:
        fail_picture("wrong_landing", f"landed on '{title}', expected '{expected}' for {item}")
    return title


# ---------------------------------------------------------------------------------------------------------------
# 5. cycle summary
# ---------------------------------------------------------------------------------------------------------------
_stats = collections.OrderedDict()               # kind -> Counter


@_safe
def stat(kind, name, n=1):
    _stats.setdefault(kind, collections.Counter())[name] += n


@_safe
def cycle_summary(cycle, started_at):
    parts = []
    for kind in ("served", "event completed", "queued", "made at stations", "harvested", "planted", "chased",
                 "collected finished items", "blocked"):
        c = _stats.get(kind)
        if c and kind in ("served", "event completed"):
            if sum(c.values()):
                parts.append(f"{kind} {sum(c.values())}")
        elif c:
            parts.append(f"{kind}: " + ", ".join(f"{k} x{v}" if v > 1 else str(k) for k, v in c.items()))
    cur = ""
    try:
        import currency_log
        cur = currency_log.cycle_delta() or ""
    except Exception:                                # noqa: BLE001
        cur = ""
    _log(f"CYCLE {cycle} SUMMARY (took {_fmt_sec(time.time() - started_at)}): " + (" | ".join(parts) if parts else "nothing done")
         + (f" | {cur}" if cur else ""))
    _stats.clear()


# ---------------------------------------------------------------------------------------------------------------
# 7. debug pictures (switch: create / delete the file .debug_pictures in the bot folder)
# ---------------------------------------------------------------------------------------------------------------
def debug_on():
    try:
        return os.path.exists(DEBUG_FLAG)
    except OSError:
        return False


@_safe
def dbg(img, tag):
    """Save `img` as a debug picture when debug mode is on (no screenshot is taken here)."""
    if not debug_on() or img is None:
        return None
    path = _write_picture(DEBUG_DIR, f"{time.strftime('%H%M%S')}_{tag}", img, DEBUG_KEEP, max_age_sec=86400)
    _log(f"DEBUG picture: {os.path.relpath(path, BASE)}")
    return path


@_safe
def dbg_after(tag):
    """Debug mode only: take a screenshot now and save it (used right after an action tap)."""
    if not debug_on():
        return None
    import adb_helper
    return dbg(adb_helper.screenshot(), tag)
