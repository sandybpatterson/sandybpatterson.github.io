"""Reusable navigation routine: locate a target (via multi-scale template
match), then iteratively pan so it's centered on screen, then zoom in for
a final precise fix. This replaces the old "extrapolate an offset across
whatever zoom level we happened to land at" approach, which drifted badly
at extreme zoom levels (confirmed during testing — it landed on nearby
decorations and even a gem-spend Unlock button instead of the intended
target). Centering-then-zooming means the final tap coordinate always
comes from a fresh, high-confidence, near-center detection instead of
extrapolated math.

Heavily logged per the user's request, since this is exactly the part
that needs to be trustworthy before anything gets scheduled unattended.
"""
import os
import sys
import time
import datetime
import math
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from adb_helper import screenshot, tap, swipe, pinch
import world_map

CLOSE_X_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "close_x.png"))
CLOSE_X_LOC = (1541, 124)  # fixed screen-space position, same for every panel

SECOND_DEVICE_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "second_device_dialog.png"))
SECOND_DEVICE_OK_LOC = (797, 728)  # fixed screen-space position

BUY_MISSING_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "buy_missing_dialog.png"))
BUY_MISSING_NO_LOC = (630, 520)  # fixed screen-space position — the "No" button

LOG = os.path.join(BASE_DIR, "run_log.txt")
SCREEN_CENTER = (800, 450)
CENTER_TOLERANCE = 60       # px — close enough to "centered"
MAX_CENTER_HOPS = 8

# Fixed HUD zones where a real world-space station can never actually be —
# confirmed 9/23: a Dairy false positive landed at (1532,124)/(1412,175),
# right where fixed event-countdown badges and the top icon bar live.
# A genuine match there is implausible and should be rejected rather than
# trusted, since this is exactly the kind of wrong-but-just-above-threshold
# match that led to accidentally opening the "Expand your Land" panel.
HUD_EXCLUSION_ZONES = [
    (0, 0, 1600, 70),      # top icon/resource bar
    (1400, 70, 1600, 320),  # top-right event-countdown badge cluster
]


def in_hud_zone(loc):
    x, y = loc
    return any(x1 <= x <= x2 and y1 <= y <= y2 for (x1, y1, x2, y2) in HUD_EXCLUSION_ZONES)
HOP_CAP_PX = 170            # controlled drag distance, avoids fling
MAX_SEARCH_STEPS = 40
SEARCH_HOP_PX = 160
PROBE_THRESHOLD = 0.3  # Tried raising to 0.42 on 9/23 after a false-positive probe
                        # (a boardwalk/grill scene scored 0.34-0.42 against the Pig
                        # Pen template) — but that broke Dairy entirely: its genuine
                        # signal typically sits at 0.33-0.39, so at 0.42 a real run
                        # went through all 40 steps with ZERO probes and failed
                        # outright (146s wasted, target was very likely there the
                        # whole time). Reverted to 0.3. The right mental model: a
                        # false-positive probe just costs ~8-10s (the zoom-in
                        # confirmation step already prevents any wrong action from
                        # it) — that's far cheaper than missing a real target and
                        # failing the whole search. Don't raise this again without
                        # a smarter discriminator (e.g. requiring the zoomed-in
                        # confidence to *improve* by some margin, not just testing
                        # the raw initial confidence) — see the confidence-jump
                        # idea in the "ideas for improvement" section below.


class StopRequested(Exception):
    """Raised to unwind out of a search/centering/zoom loop immediately
    when the user hits Stop, instead of waiting for the current find_fn
    call (which can legitimately take 60-140s) to finish on its own."""
    pass


def check_stop(stop_flag):
    if stop_flag is not None and stop_flag.is_set():
        raise StopRequested()


def interruptible_sleep(seconds, stop_flag):
    """time.sleep that wakes up early (in <=0.1s granularity) if Stop is
    requested mid-wait, instead of blocking the full duration regardless."""
    end = time.time() + seconds
    while time.time() < end:
        check_stop(stop_flag)
        time.sleep(min(0.1, max(0.0, end - time.time())))
    check_stop(stop_flag)


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] {msg}\n")
    try:
        print(f"[{ts}] {msg}")
    except (AttributeError, OSError):
        pass  # no console attached (e.g. launched via pythonw.exe) — log file still gets it


def frame_diff(before, after):
    """Downsampled grayscale mean absolute difference between two frames —
    cheap and fast. Empirically: a real pan/zoom scores 50+, a boundary/
    zoom-limit no-op scores ~2-4 (just animation noise: water shimmer,
    swaying trees, floating ready-icons)."""
    a = cv2.cvtColor(cv2.resize(before, (160, 90)), cv2.COLOR_BGR2GRAY).astype(np.float32)
    b = cv2.cvtColor(cv2.resize(after, (160, 90)), cv2.COLOR_BGR2GRAY).astype(np.float32)
    return float(np.mean(np.abs(a - b)))


def frame_changed(before, after, threshold=3.0):
    """Cheap check for whether a swipe actually moved the camera, or hit
    a hard map boundary and did nothing."""
    return frame_diff(before, after) > threshold


def dismiss_second_device_dialog():
    """The 'your game is open on a second device' dialog — a centered
    modal with no close-X, so close_any_open_panel() doesn't catch it.
    Explicitly confirmed safe to auto-dismiss by the user (9/23): unlike
    the gem-spend dialogs, always tap OK here. This dialog fully blocks
    all touch input (confirmed: even a zoom-out pinch registered 0 frame
    diff while it was up), which looks identical to "stuck in a map
    corner" if you don't check for it specifically — cost real debugging
    time before being identified. Returns True if it was found and
    dismissed."""
    img = screenshot()
    region = img[330:460, 590:1000]
    res = cv2.matchTemplate(region, SECOND_DEVICE_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    if max_val < 0.75:
        return False
    log(f"Second-device session dialog detected (confidence {max_val:.2f}) "
        "— dismissing (user confirmed always safe to auto-tap OK here).")
    tap(*SECOND_DEVICE_OK_LOC)
    time.sleep(1)
    return True


ERROR_WHOOPS_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                          "templates", "error_whoops_dialog.png")
ERROR_WHOOPS_OK_LOC = (800, 730)
OUT_OF_CROP_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                        "templates", "out_of_crop_dialog.png")
OUT_OF_CROP_NO_LOC = (630, 580)      # grey No; Yes (1 gem) is the green button at ~(968,580)
GREAT_BUTTON_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                          "templates", "great_button.png")
EVENT_BADGE_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                         "templates", "event_badge_dialog.png")
EVENT_BADGE_OK_LOC = (800, 727)      # the green "Great!" button
NOT_ENOUGH_TOKENS_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                              "templates", "not_enough_tokens_dialog.png")
NOT_ENOUGH_TOKENS_OK_LOC = (575, 830)    # green OK (the blue "Get more tokens" is at ~(1025,830))
DISCARD_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                     "templates", "discard_order_dialog.png")
DISCARD_NO_LOC = (630, 520)          # the grey "No" (Yes is the green button at ~(968,520))
PRIZE_TENT_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                       "templates", "prize_tent_title.png")
PRIZE_TENT_CLOSE_LOC = (1540, 130)   # the red X (standard close template matched here at 0.994)
MYSTERY_BOX_TAP_LOC = (800, 400)     # middle of the closed box
COLLECT_REWARD_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                           "templates", "collect_reward_button.png")
ANR_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "templates", "android_anr_rows.png")
# template = the "Close app" + "Wait" rows; the "Wait" centre sits at this
# offset from the match's top-left (Wait was at (528,543), template origin (410,440)).
ANR_WAIT_OFFSET = (118, 103)


def match_multiscale(region, tpl, scales=(0.9, 1.0, 1.1, 1.15, 1.2, 1.3)):
    """cv2.matchTemplate at several template sizes, with SEPARATE width and height
    scales. Returns (best_score, (cx, cy) centre of the best match inside `region`,
    (fx, fy)). Some popups reuse the same button art at another size: the "Milestone
    Reached!" Collect Reward button is ~1.13x wider and ~1.2x taller than the mystery-box
    one (a fixed-size match scored 0.56, uniform scaling 0.72)."""
    best = (-1.0, (0, 0), (1.0, 1.0))
    for fx in scales:
        for fy in scales:
            t = cv2.resize(tpl, None, fx=fx, fy=fy, interpolation=cv2.INTER_CUBIC)
            if t.shape[0] > region.shape[0] or t.shape[1] > region.shape[1]:
                continue
            r = cv2.matchTemplate(region, t, cv2.TM_CCOEFF_NORMED)
            _, v, _, l = cv2.minMaxLoc(r)
            if v > best[0]:
                best = (float(v), (l[0] + t.shape[1] // 2, l[1] + t.shape[0] // 2), (fx, fy))
    return best


def reward_button_loc(img):
    """The 'Collect Reward' screens (mystery-box reward, 'Milestone Reached!' ...). The
    button art/size varies between them (a fixed image match failed on the bigger
    'Milestone Reached!' variant, 10/2), so detect STRUCTURE instead: a dimmed screen
    (nav clipboard p90 < 120) + an opened gift box (>= 20000 strongly saturated non-lime pixels
    in the middle) + a lime button 250-420 px wide centred under it. The 'Great!' popups
    have a lime button but no box. Returns the button centre (x, y) or None."""
    nav = cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2]
    if float(np.percentile(nav, 90)) >= 120:
        return None
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mid = hsv[380:700, 560:1040]
    h, sat, v = mid[:, :, 0], mid[:, :, 1], mid[:, :, 2]
    # box colour varies per reward (red, orange, teal...): count ANY strongly saturated,
    # bright pixel that is not the lime button hue
    box = (sat > 170) & (v > 120) & ~((h >= 35) & (h <= 60))
    if int(box.sum()) < 20000:
        return None
    lime = cv2.inRange(hsv[690:850, 500:1100], (35, 150, 140), (60, 255, 255))
    lime = cv2.morphologyEx(lime, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(lime)
    best = None
    for i in range(1, n):
        w, hh = int(st[i][2]), int(st[i][3])
        cx = int(cen[i][0]) + 500
        if 250 <= w <= 420 and 50 <= hh <= 110 and abs(cx - 800) <= 120:
            if best is None or w * hh > best[2]:
                best = (cx, int(cen[i][1]) + 690, w * hh)
    return (best[0], best[1]) if best else None


def is_mystery_box_screen(img):
    """The closed gift-box reveal, ANY box colour (red, teal... -- the teal one stalled the bot
    ~60 cycles overnight 10/2 because only red was known). The box bobs/spins so an image
    match only scores ~0.5; the signature is: a large mass of strongly saturated non-lime
    pixels (38k-54k) centred at x~800, a dimmed nav bar (clipboard p90 < 100; the open
    board reads 110), NO lime button (the opened box / 'Collect Reward' screen has one) and
    no pale-blue dialog panel (rules out dialogs such as 'Upgrade Event Recipe')."""
    reg = img[100:640, 520:1100]
    hsv = cv2.cvtColor(reg, cv2.COLOR_BGR2HSV)
    h, sat, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
    mass = (sat > 170) & (v > 120) & ~((h >= 35) & (h <= 60))
    area = int(mass.sum())
    if not (25000 <= area <= 58000):
        return False
    if abs(int(np.nonzero(mass)[1].mean()) + 520 - 800) > 90:
        return False
    nav = cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2]
    if float(np.percentile(nav, 90)) >= 100:
        return False
    lime = cv2.inRange(cv2.cvtColor(img[650:790, 560:1040], cv2.COLOR_BGR2HSV), (35, 150, 140), (60, 255, 255))
    if int(lime.sum() // 255) >= 3000:
        return False
    pale_blue = (h >= 95) & (h <= 118) & (sat >= 30) & (sat <= 130) & (v > 200)
    return int(pale_blue.sum()) < 8000


def _tpl(name):
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", name)
    return cv2.imread(path)


def _best(region, name):
    t = _tpl(name)
    if t is None or region.shape[0] < t.shape[0] or region.shape[1] < t.shape[1]:
        return 0.0, (0, 0)
    r = cv2.matchTemplate(region, t, cv2.TM_CCOEFF_NORMED)
    _, v, _, l = cv2.minMaxLoc(r)
    return float(v), (l[0] + t.shape[1] // 2, l[1] + t.shape[0] // 2)


def _focused_window():
    """The focused Android window text (package/activity), '' when it cannot be read."""
    try:
        import adb_helper
        r = adb_helper._run(["shell", "dumpsys window | grep mCurrentFocus"])
        return (r.stdout or b"").decode("utf-8", "ignore")
    except Exception:                                  # noqa: BLE001
        return ""


_LAUNCHER_AD_X = cv2.imread(os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "launcher_ad_x.png"), 0)


def launcher_ad_x_loc(img):
    """The small light X in the top-right corner of an LDPlayer launcher ad poster (seen live 10/5: a big
    poster for another game over the Android home screen). Matched as a WHITE-STROKE SHAPE (the box behind
    it is a translucent dark square whose colour follows the poster art), only in the corner zone where such
    posters put it. Returns the X's centre or None. Callers must ALSO confirm the Android launcher is the
    focused window before tapping (see dismiss_error_dialog)."""
    if _LAUNCHER_AD_X is None:
        return None
    gray = cv2.cvtColor(img[100:300, 1050:1450], cv2.COLOR_BGR2GRAY)
    zone = ((gray > 150) * 255).astype(np.uint8)
    res = cv2.matchTemplate(zone, _LAUNCHER_AD_X, cv2.TM_CCOEFF_NORMED)
    _, v, _, l = cv2.minMaxLoc(res)
    if v < 0.7:
        return None
    x, y = 1050 + l[0] + _LAUNCHER_AD_X.shape[1] // 2, 100 + l[1] + _LAUNCHER_AD_X.shape[0] // 2
    # the X sits on a DARK translucent square: the ring just outside the glyph must be dark
    ring = gray[max(0, y - 100 - 18):y - 100 + 18, max(0, x - 1050 - 18):x - 1050 + 18]
    return (x, y) if ring.size and float(np.median(ring)) < 130 else None


def is_android_home(img):
    """The emulator's Android launcher ("Search games" bar at the top, an app grid). Reached when
    the game crashed / the emulator restarted (seen live 10/3 14:54). NOT the game: no HUD."""
    v, _ = _best(img[40:130, 480:1120], "launcher_search_bar.png")
    return v >= 0.85


def food_street_icon_loc(img):
    """Centre of the Food Street icon on the launcher, or None. ONLY this icon is ever tapped:
    the rest of the launcher is ads / other games / the store."""
    v, (x, y) = _best(img[150:330, 440:760], "launcher_food_street_icon.png")
    return (440 + x, 150 + y) if v >= 0.85 else None


def is_tablet_starting(img):
    """Black "Tablet is starting..." boot screen: just wait."""
    if float(img[300:600, 300:1300].mean()) > 90:
        return False
    v, _ = _best(img[330:580, 520:1080], "tablet_starting_text.png")
    return v >= 0.8


def is_game_splash(img):
    """The Food Street loading screen (logo + progress bar, rotating tip text): just wait."""
    v, _ = _best(img[300:640, 520:1120], "game_splash_logo.png")
    return v >= 0.8


def ribbon_button_loc(img):
    """"Thank you! Rewards: ..." popup -> centre of its [Collect Rewards] button, else None.
    Matched by TEMPLATES of the title ribbon AND the button label, both required. (A first
    colour-only version also matched the Premium Pass popup's $12.99 purchase button -- never
    use a generic "one lime button" rule for tapping.)"""
    vt, _ = _best(img[130:320, 440:1160], "thankyou_title.png")
    if vt < 0.8:
        return None
    vb, (x, y) = _best(img[620:780, 560:1040], "thankyou_collect_btn.png")
    return (560 + x, 620 + y) if vb >= 0.8 else None


_last_popup_save = {}


def storage_full_dialog_x(img):
    """"Your Food Club Storage is full! Get more space by upgrading the Food Club Storage
    [Upgrade Now!]" popup (seen live 10/4 over an Oz Stove panel; it made close_any_open_panel
    tap the stove panel's own X forever). Returns the dialog's red X (the ONLY safe tap -- never
    Upgrade Now) or None. Matched by the message text template, X found by the close-X template."""
    v, _ = _best(img[380:620, 540:1060], "storage_full_dialog.png")
    if v < 0.85:
        return None
    x_tpl = _tpl("close_x.png")
    region = img[120:260, 940:1110]
    if x_tpl is not None and region.shape[0] >= x_tpl.shape[0] and region.shape[1] >= x_tpl.shape[1]:
        r = cv2.matchTemplate(region, x_tpl, cv2.TM_CCOEFF_NORMED)
        _, mv, _, ml = cv2.minMaxLoc(r)
        if mv >= 0.7:
            return (940 + ml[0] + x_tpl.shape[1] // 2, 120 + ml[1] + x_tpl.shape[0] // 2)
    return (1033, 185)


def log_popup_message(img, tag, region=None):
    """Logs a popup's FULL text (Windows OCR) and keeps a picture, at most once per 5 min per
    tag, so every popup we close leaves a readable record in run_log.txt."""
    if time.time() - _last_popup_save.get(tag, 0) < 300:
        return
    _last_popup_save[tag] = time.time()
    try:
        import popup_ocr
        text = popup_ocr.read_text(img, region)
        folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "popup_messages")
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, f"{int(time.time())}_{tag}.png")
        cv2.imwrite(path, img)
        log(f"POPUP MESSAGE [{tag}]: \"{text}\" (picture: {path})")
    except Exception as e:                      # noqa: BLE001
        log(f"POPUP MESSAGE [{tag}]: could not read/save ({e})")


def dismiss_error_dialog():
    """The game's own 'Whoops! Something went wrong! Please try again
    later!' dialog (a server/connection hiccup). Found live 10/2: it sat
    over the event board for over an hour while every pass reported
    board_not_opened, because nothing knew to tap its OK. Harmless to
    dismiss (no cost, no purchase). Returns True if found and dismissed."""
    try:
        tpl = cv2.imread(ERROR_WHOOPS_TEMPLATE_PATH)
        if tpl is None:
            return False
        img = screenshot()
        # --- an LDPlayer LAUNCHER ad (a poster for another game over the Android home screen) ---
        ax = launcher_ad_x_loc(img)
        if ax is not None and "launcher" in _focused_window().lower():
            log(f"LDPlayer launcher ad poster detected -- closing it with its X at {ax} "
                "(only ever done while the Android launcher, not the game, is in front).")
            tap(*ax)
            time.sleep(1.5)
            return True
        # --- the emulator / game is not on the map at all (restart, crash, launch) ---
        if is_android_home(img):
            loc = food_street_icon_loc(img)
            if loc is not None:
                log(f"Android home screen detected -- launching Food Street (icon at {loc}); "
                    "nothing else on this screen is ever tapped.")
                tap(*loc)
                time.sleep(8)
                return True
            log("Android home screen detected but the Food Street icon was not found -- not tapping.")
            return False
        if is_tablet_starting(img):
            log("'Tablet is starting...' -- the emulator is booting; waiting.")
            time.sleep(8)
            return True
        if is_game_splash(img):
            log("Food Street loading screen -- the game is starting; waiting.")
            time.sleep(8)
            return True
        # "Your Food Club Storage is full!" -- tap ITS red X only; never "Upgrade Now!".
        sx = storage_full_dialog_x(img)
        if sx is not None:
            log("'Food Club Storage is full' popup -- closing it with its X (never Upgrade Now).")
            log_popup_message(img, "storage_full", (560, 175, 1040, 725))
            tap(*sx)
            time.sleep(1.5)
            return True
        # Celebration popup: blue ribbon + one lime button (Great! / Collect Rewards ...)
        rb = ribbon_button_loc(img)
        if rb is not None:
            log(f"'Thank you! Rewards' popup detected -- tapping Collect Rewards at {rb}.")
            tap(*rb)
            time.sleep(2)
            return True
        # "Whoops! Unable to connect to server. Please check your connection and try again!" [OK]
        uc, _ = _best(img[100:330, 480:1120], "unable_to_connect_dialog.png")
        if uc >= 0.85:
            log(f"'Unable to connect to server' dialog detected (confidence {uc:.2f}) -- tapping OK.")
            tap(800, 730)
            time.sleep(2)
            return True
        # "You are out of <crop>! You need at least one to replant it. Buy and plant one
        # now? [No] [Yes <gems>]" (seen live 10/2 after tapping a 0-stock crop card; it
        # blocked every cycle). The "Buy and plant one now?" line is constant. ALWAYS No.
        oc = cv2.imread(OUT_OF_CROP_TEMPLATE_PATH)
        if oc is not None:
            ro = cv2.matchTemplate(img[440:540, 560:1040], oc, cv2.TM_CCOEFF_NORMED)
            _, ov, _, _ = cv2.minMaxLoc(ro)
            if ov >= 0.85:
                log(f"'Out of crop -- buy and plant?' dialog detected (confidence {ov:.2f}) -- "
                    "tapping No (never the gem Yes).")
                tap(*OUT_OF_CROP_NO_LOC)
                time.sleep(1.5)
                return True
        # Any single-button celebration popup whose button reads "Great!" (Event Badge
        # Unlocked, "Event Milestone N! Unlocks: Extra Slot / Extra Event Plot / Recipe
        # Upgrade" -- seen live 10/2). Requires a DIMMED screen (a modal) so the button
        # image on a plain map can never trigger it. Free; just acknowledges.
        gb = cv2.imread(GREAT_BUTTON_TEMPLATE_PATH)
        if gb is not None and float(np.percentile(cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2], 90)) < 120:
            rg = cv2.matchTemplate(img[640:800, 560:1040], gb, cv2.TM_CCOEFF_NORMED)
            _, gv, _, gl = cv2.minMaxLoc(rg)
            if gv >= 0.80:
                gx = 560 + gl[0] + gb.shape[1] // 2
                gy = 640 + gl[1] + gb.shape[0] // 2
                log(f"'Great!' popup detected (confidence {gv:.2f}) -- tapping Great! at ({gx},{gy}).")
                tap(gx, gy)
                time.sleep(2)
                return True
        # "Event Badge Unlocked!" celebration (single green "Great!" button; animated
        # confetti). Seen live 10/2 covering the nav bar. Free, just tap Great!.
        eb = cv2.imread(EVENT_BADGE_TEMPLATE_PATH)
        if eb is not None:
            re_ = cv2.matchTemplate(img[90:230, 480:1120], eb, cv2.TM_CCOEFF_NORMED)
            _, ev_, _, _ = cv2.minMaxLoc(re_)
            if ev_ >= 0.8:
                log(f"'Event Badge Unlocked' popup detected (confidence {ev_:.2f}) -- tapping Great!.")
                tap(*EVENT_BADGE_OK_LOC)
                time.sleep(2)
                return True
        # "Not enough tokens! Here's how to get more:" (OK / Get more tokens). Seen
        # live 10/2: a blind tap landed on a station's cyan Unlock button (token
        # cost). Just close it with OK -- never "Get more tokens".
        nt = cv2.imread(NOT_ENOUGH_TOKENS_TEMPLATE_PATH)
        if nt is not None:
            rn = cv2.matchTemplate(img[90:240, 380:1220], nt, cv2.TM_CCOEFF_NORMED)
            _, nv, _, _ = cv2.minMaxLoc(rn)
            if nv >= 0.85:
                log(f"'Not enough tokens' popup detected (confidence {nv:.2f}) -- tapping OK "
                    "(never 'Get more tokens').")
                tap(*NOT_ENOUGH_TOKENS_OK_LOC)
                time.sleep(1.5)
                return True
        # "Are you sure you want to discard this order?" (No / Yes). A stray tap on
        # an order card's red trash button opens it (found live 10/2); Yes would
        # black the order out for 30 min. ALWAYS tap No.
        dc = cv2.imread(DISCARD_TEMPLATE_PATH)
        if dc is not None:
            rd = cv2.matchTemplate(img[300:620, 440:1160], dc, cv2.TM_CCOEFF_NORMED)
            _, dv, _, _ = cv2.minMaxLoc(rd)
            if dv >= 0.85:
                log(f"'Discard this order?' dialog detected (confidence {dv:.2f}) -- tapping No.")
                tap(*DISCARD_NO_LOC)
                time.sleep(1.5)
                return True
        # The Prize Tent (Tokens/Treasure/Voucher boxes + Seasonal Pets): its lime
        # "Open" buttons SPEND tokens or GEMS (Treasure Box = 25 gems). It gets
        # opened by a stray centre-tap on the tent building (found live 10/2).
        # Only ever close it with the red X -- never touch Open.
        pt = cv2.imread(PRIZE_TENT_TEMPLATE_PATH)
        if pt is not None:
            rp = cv2.matchTemplate(img[60:180, 560:1040], pt, cv2.TM_CCOEFF_NORMED)
            _, pv, _, _ = cv2.minMaxLoc(rp)
            if pv >= 0.85:
                log(f"Prize Tent panel detected (confidence {pv:.2f}) -- closing it with the X "
                    "(never tapping Open: those spend tokens/gems).")
                tap(*PRIZE_TENT_CLOSE_LOC)
                time.sleep(1.5)
                return True
        # The CLOSED mystery gift box reveal (event milestone reward; no button, you tap
        # the box). Seen live 10/2 stuck here overnight; opening it is free and leads to
        # the "Collect Reward" screen below.
        if is_mystery_box_screen(img):
            log("Closed mystery box reveal detected -- tapping the box to open it.")
            tap(*MYSTERY_BOX_TAP_LOC)
            time.sleep(2.5)
            return True
        # A free "Collect Reward" screen (mystery box / "Milestone Reached!" ...): tap the
        # lime button. Detected structurally (see reward_button_loc) -- the button size varies.
        rb = reward_button_loc(img)
        if rb is not None:
            log(f"'Collect Reward' screen detected -- tapping the button at {rb}.")
            tap(*rb)
            time.sleep(2)
            return True
        # Android's own "<app> isn't responding" dialog (Close app / Wait) can
        # sit over the game (seen live 10/2: "System UI isn't responding").
        # ALWAYS tap Wait, never Close app.
        anr = cv2.imread(ANR_TEMPLATE_PATH)
        if anr is not None:
            r = cv2.matchTemplate(img[250:750, 300:1300], anr, cv2.TM_CCOEFF_NORMED)
            _, av, _, aloc = cv2.minMaxLoc(r)
            if av >= 0.85:
                wx = 300 + aloc[0] + ANR_WAIT_OFFSET[0]
                wy = 250 + aloc[1] + ANR_WAIT_OFFSET[1]
                log(f"Android 'isn't responding' dialog detected (confidence {av:.2f}) "
                    f"-- tapping Wait at ({wx},{wy}).")
                tap(wx, wy)
                time.sleep(2)
                return True
        res = cv2.matchTemplate(img[120:320, 480:1120], tpl, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, _ = cv2.minMaxLoc(res)
        if max_val < 0.8:
            return False
        log(f"'Whoops! Something went wrong' dialog detected (confidence {max_val:.2f}) "
            "-- tapping OK.")
        tap(*ERROR_WHOOPS_OK_LOC)
        time.sleep(1.5)
        return True
    except cv2.error:
        return False


def dismiss_buy_missing_dialog():
    """'Buy missing ingredients? [No] [Yes, N gems]' — appears when a
    Produce/Make tap runs into an insufficient ingredient. Discovered
    live 9/24 during map-based navigation testing: this is a real,
    previously-unhandled dialog that would otherwise sit there blocking
    everything, exactly like the other blocking-overlay types. ALWAYS
    tap No — this is a direct gem-spend prompt, covered by the hard
    'never spend gems' rule, no exceptions. Returns True if dismissed."""
    img = screenshot()
    region = img[380:430, 610:1000]
    res = cv2.matchTemplate(region, BUY_MISSING_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    if max_val < 0.75:
        return False
    log(f"'Buy missing ingredients?' gem-spend prompt detected (confidence "
        f"{max_val:.2f}) — tapping No. Never spending gems, no exceptions.")
    tap(*BUY_MISSING_NO_LOC)
    time.sleep(1)
    return True


def close_any_open_panel(max_attempts=3, quiet=False, thorough=False):
    """Check for a leftover open panel (from a previous run that crashed,
    got interrupted, or otherwise didn't clean up) and close it. Real bug
    found 9/23: a panel left open silently blocks every subsequent search
    — swipes do nothing while a modal dialog is showing, so the whole map
    looks like a dead-end corner in every direction. Call this at the
    start of every script's main() before searching for anything, and
    (quiet=True, no "not found" logging) inside the search loop whenever
    a hop looks like a boundary — it might actually be this.

    thorough=True adds a full-screen fallback search when the normal
    bounded-region check finds nothing. Added 9/27 for a real leftover
    case: a crop's grow-timer info card (e.g. "Carrot, 14m 4s, Skip [3
    gems]") is a WORLD-SPACE tooltip anchored near wherever the plot was
    tapped, not a fixed-corner dialog like every other panel type this
    function was built around — its close-X can land anywhere on screen
    depending on camera position, not just the bounded top-right region
    every other popup type uses. Only opt into this for callers that
    specifically expect this card type (e.g. Garden Plot flows) — a
    full-screen template search is real extra cost to pay on every single
    call otherwise, most of which find nothing to close at all.
    Returns True if anything was found and closed."""
    if dismiss_second_device_dialog():
        return True
    if dismiss_error_dialog():
        return True
    if dismiss_buy_missing_dialog():
        return True
    closed_any = False
    # Search a wide region, not one fixed point — confirmed 9/23 that
    # different popup types (a standard station panel vs. a promotional
    # "Premium Pass"/purchase-offer dialog) put their X at genuinely
    # different positions depending on the dialog's own size. A fixed
    # (1541,124) check missed a Premium Pass popup whose X sat at
    # roughly (1287,137), leaving it open and silently blocking
    # everything exactly like the original leftover-panel bug.
    th, tw = CLOSE_X_TEMPLATE.shape[:2]
    for attempt in range(1, max_attempts + 1):
        img = screenshot()
        region = img[50:250, 1150:1580]
        res = cv2.matchTemplate(region, CLOSE_X_TEMPLATE, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val < 0.8:   # genuine X scores 0.90+, the HUD false match 0.71 (pass 2, 10/4)
            if thorough:
                res2 = cv2.matchTemplate(img, CLOSE_X_TEMPLATE, cv2.TM_CCOEFF_NORMED)
                _, max_val2, _, max_loc2 = cv2.minMaxLoc(res2)
                if max_val2 >= 0.7:
                    x = max_loc2[0] + tw // 2
                    y = max_loc2[1] + th // 2
                    log(f"Leftover panel found via full-screen fallback search at ({x},{y}) "
                        f"(confidence {max_val2:.2f}) -- outside the normal bounded region, "
                        "likely a world-space info card (e.g. a crop grow-timer tooltip). "
                        f"Closing it (attempt {attempt}).")
                    tap(x, y)
                    time.sleep(1)
                    closed_any = True
                    continue
            if attempt == 1 and not quiet:
                log("No leftover panel detected at startup.")
            return closed_any
        x = 1150 + max_loc[0] + tw // 2
        y = 50 + max_loc[1] + th // 2
        log(f"Leftover open panel detected at ({x},{y}) (confidence "
            f"{max_val:.2f}) — closing it (attempt {attempt}).")
        tap(x, y)
        time.sleep(1)
        closed_any = True
    log("Still detecting a panel after max close attempts — proceeding anyway.")
    return closed_any


def close_any_open_panel_quiet():
    return close_any_open_panel(quiet=True)


def spiral_moves(max_steps):
    directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    moves = []
    seg_len = 1
    d = 0
    while len(moves) < max_steps:
        for _ in range(2):
            dx, dy = directions[d % 4]
            for _ in range(seg_len):
                moves.append((dx, dy))
                if len(moves) >= max_steps:
                    return moves
            d += 1
        seg_len += 1
    return moves


def find_and_center(find_fn, label="target", zoom_in_after=True, stop_flag=None):
    """find_fn(img, fast=False) -> (loc, confidence) or (None, confidence).
    Returns (final_loc, final_confidence) — final_loc is None if the
    whole process failed. Logs every step, including timing, since the
    match itself turned out to be the real bottleneck (~4.2s/call at
    full resolution) — search/centering use fast=True (downsampled,
    coarser scale list) to keep each hop to well under a second; only
    the final post-zoom-in confirmation uses full precision.

    stop_flag, if given (a threading.Event), is checked at the top of
    every loop iteration and every sleep — raises StopRequested to
    unwind immediately instead of finishing the current multi-second
    search/centering pass first. Callers should catch StopRequested."""
    raw_find_fn = find_fn

    def find_fn(img, fast=False):
        """Wraps the caller's find_fn: rejects any match landing in a
        fixed HUD zone before it can be trusted. A real world-space
        station can never actually be there — confirmed 9/23, a Dairy
        false positive at (1532,124)/(1412,175) (right where event-
        countdown badges live) got treated as real and opened the wrong
        panel entirely. Applied once here so every call site in this
        function gets the filter automatically."""
        loc, conf = raw_find_fn(img, fast=fast)
        if loc is not None and in_hud_zone(loc):
            log(f"  (rejecting match at {loc} — inside a fixed HUD zone, "
                f"not a plausible world-space location; conf was {conf:.2f})")
            return None, conf
        return loc, conf

    log(f"--- find_and_center({label}) start ---")
    t_start = time.time()
    check_stop(stop_flag)

    # First draft of map-based navigation (9/24): try the cached position
    # from the last time this station was confirmed, before paying for a
    # full search. Always re-confirmed with a real detection — a stale
    # cache just falls through to the normal flow below, it never blocks it.
    hint_result = world_map.try_hint(find_fn, label)
    if hint_result is not None:
        loc, conf = hint_result
        log(f"Skipping search — map cache hit for {label} at {loc} (confidence {conf:.2f}).")
    else:
        img = screenshot()
        loc, conf = find_fn(img, fast=True)
        log(f"Initial check: {label} {'found at ' + str(loc) if loc else 'not found'} (confidence {conf:.2f})")

    last_zoom_diff = None
    if loc is None:
        log(f"Zooming out to widen the search for {label}...")
        # Measured 9/23: one pinch reliably maxes out zoom when starting
        # from a "just zoomed in" state (diff ~54), but a single relative
        # pinch isn't guaranteed sufficient from an arbitrary starting
        # zoom. Keep zooming out until the frame stops changing much
        # (i.e. we've hit the game's zoom-out limit), instead of assuming
        # one call is always enough — bounded to avoid looping forever.
        for zoom_attempt in range(1, 4):
            check_stop(stop_flag)
            before = screenshot()
            pinch(800, 450, 350, 80, steps=15)
            interruptible_sleep(1, stop_flag)
            after = screenshot()
            d = frame_diff(before, after)
            last_zoom_diff = d
            log(f"  zoom-out attempt {zoom_attempt}: frame diff {d:.1f}")
            if d < 15.0:
                log(f"  Reached max zoom-out after {zoom_attempt} attempt(s).")
                break
        img = after
        loc, conf = find_fn(img, fast=True)
        log(f"After zoom-out: {label} {'found at ' + str(loc) if loc else 'not found'} (confidence {conf:.2f})")

    probe_zoomed = False
    if loc is None:
        log(f"Spiral-searching for {label} (up to {MAX_SEARCH_STEPS} hops)...")
        cx, cy = 900, 450
        exhausted_directions = set()  # directions that hit a map edge (no-op hop)
        skipped = 0
        prev_img = img
        conf_trail = []  # every real (non-skipped) step's confidence -- added
                          # 9/27 after a log review of a bad unattended stretch
                          # found ~90 full-search failures with no way to tell,
                          # after the fact, whether a given failure was "close
                          # the whole time" (steadily near-threshold) or
                          # "totally lost" (near-zero throughout) without
                          # rereading every single step line by hand
        for i, (dx, dy) in enumerate(spiral_moves(MAX_SEARCH_STEPS), 1):
            check_stop(stop_flag)
            if (dx, dy) in exhausted_directions:
                skipped += 1
                continue
            t0 = time.time()
            swipe(cx, cy, cx + dx * SEARCH_HOP_PX, cy + dy * SEARCH_HOP_PX, 500)
            interruptible_sleep(0.7, stop_flag)
            img = screenshot()
            if not frame_changed(prev_img, img):
                # Could be a genuine map boundary — but could also be the
                # second-device dialog, the buy-missing-ingredients gem
                # prompt, or a leftover panel silently blocking ALL input,
                # which looks identical (0 frame diff in every direction).
                # close_any_open_panel_quiet() checks for all of those.
                # Check and dismiss before concluding it's a real boundary,
                # so one blocking dialog doesn't get misread as being
                # cornered on all 4 sides at once.
                if close_any_open_panel_quiet():
                    log(f"  step {i}/{MAX_SEARCH_STEPS} dir=({dx:+d},{dy:+d}) — "
                        "was actually a blocking dialog, not a boundary. "
                        "Dismissed, retrying this direction.")
                    prev_img = screenshot()
                    continue
                exhausted_directions.add((dx, dy))
                log(f"  step {i}/{MAX_SEARCH_STEPS} dir=({dx:+d},{dy:+d}) — "
                    "no visual change, hit a map boundary. Skipping this "
                    "direction for the rest of the search.")
                continue
            prev_img = img
            loc, conf = find_fn(img, fast=True)
            conf_trail.append(conf)
            log(f"  step {i}/{MAX_SEARCH_STEPS} dir=({dx:+d},{dy:+d}) "
                f"conf={conf:.2f} ({time.time()-t0:.1f}s)")
            if loc is not None:
                log(f"Found {label} on search step {i}/{MAX_SEARCH_STEPS} "
                    f"at {loc} (confidence {conf:.2f})")
                break
            if conf >= PROBE_THRESHOLD:
                # A partial match this strong is likely the real thing,
                # just too small/distant to clear full threshold, or
                # transiently blocked by a walking NPC/animation. Worth a
                # closer look before writing this spot off — wait briefly
                # (lets NPCs move on) and re-check, then zoom in for a
                # clearer view if it's still promising.
                log(f"  step {i}/{MAX_SEARCH_STEPS}: partial match "
                    f"(conf={conf:.2f}) — probing closer before moving on.")
                interruptible_sleep(1.2, stop_flag)
                recheck_img = screenshot()
                recheck_loc, recheck_conf = find_fn(recheck_img, fast=True)
                if recheck_loc is None and recheck_conf >= PROBE_THRESHOLD:
                    log(f"  Still promising after wait (conf={recheck_conf:.2f}) "
                        "— zooming in to verify.")
                    pinch(800, 450, 80, 300, steps=15)
                    interruptible_sleep(1, stop_flag)
                    zoomed_img = screenshot()
                    zoom_loc, zoom_conf = find_fn(zoomed_img, fast=False)
                    if zoom_loc is not None:
                        log(f"  Probe confirmed {label} after zoom-in "
                            f"(confidence {zoom_conf:.2f}).")
                        loc, conf = zoom_loc, zoom_conf
                        probe_zoomed = True
                        break
                    log(f"  Probe zoom-in didn't confirm it (conf={zoom_conf:.2f}) "
                        "— zooming back out and continuing the search.")
                    pinch(800, 450, 350, 80, steps=15)
                    interruptible_sleep(1, stop_flag)
                    prev_img = screenshot()
                elif recheck_loc is not None:
                    log(f"  Resolved on recheck without needing to zoom "
                        f"(confidence {recheck_conf:.2f}).")
                    loc, conf = recheck_loc, recheck_conf
                    break
        else:
            if conf_trail:
                trail_str = ",".join(f"{c:.2f}" for c in conf_trail)
                trail_summary = (f"trail: [{trail_str}] (min={min(conf_trail):.2f} "
                                  f"max={max(conf_trail):.2f})")
            else:
                trail_summary = "trail: (no real steps -- every direction was skipped/exhausted)"
            log(f"{label} not found after {MAX_SEARCH_STEPS} search steps "
                f"({skipped} skipped as exhausted directions: "
                f"{exhausted_directions}) (best confidence {conf:.2f}). {trail_summary} "
                f"Giving up after {time.time()-t_start:.0f}s total.")
            return None, conf

    # --- Centering phase ---
    for hop_i in range(1, MAX_CENTER_HOPS + 1):
        check_stop(stop_flag)
        dx = SCREEN_CENTER[0] - loc[0]
        dy = SCREEN_CENTER[1] - loc[1]
        dist = math.hypot(dx, dy)
        log(f"Centering hop {hop_i}: {label} at {loc}, offset from center "
            f"({dx:+.0f},{dy:+.0f}), distance {dist:.0f}px")
        if dist <= CENTER_TOLERANCE:
            log(f"{label} is close enough to center (within {CENTER_TOLERANCE}px). Done centering.")
            break
        hop = min(dist, HOP_CAP_PX)
        ux, uy = dx / dist, dy / dist
        start = (900, 450)
        end = (int(900 + ux * hop), int(450 + uy * hop))
        swipe(start[0], start[1], end[0], end[1], 500)
        interruptible_sleep(0.8, stop_flag)
        img = screenshot()
        new_loc, new_conf = find_fn(img, fast=True)
        if new_loc is None:
            log(f"Lost {label} after centering hop {hop_i} (was at {loc}, "
                f"tried to shift by ({ux*hop:+.0f},{uy*hop:+.0f})). "
                "Stopping centering, will use last known position.")
            break
        loc, conf = new_loc, new_conf
    else:
        log(f"Reached max centering hops ({MAX_CENTER_HOPS}) without fully "
            f"centering {label} — proceeding with best-effort position {loc}.")

    if not zoom_in_after:
        world_map.record_sighting(label, loc, conf, last_zoom_diff)
        log(f"--- find_and_center({label}) end (no zoom-in requested), "
            f"{time.time()-t_start:.0f}s total ---")
        return loc, conf

    # --- Zoom-in phase: same relative zoom every time, from a now-
    # centered view, so the final scale is far more consistent than
    # whatever arbitrary zoom we started the whole process at. This
    # final check uses full precision (fast=False). Skipped if a probe
    # during the search already zoomed in — doing it twice would
    # over-zoom past a usable view. ---
    check_stop(stop_flag)
    if probe_zoomed:
        log(f"Already zoomed in during the probe — doing a final "
            "full-precision confirmation without zooming again.")
        img = screenshot()
        final_loc, final_conf = find_fn(img, fast=False)
    else:
        log(f"Zooming in for a precise final fix on {label}...")
        pinch(800, 450, 80, 300, steps=15)
        interruptible_sleep(1, stop_flag)
        img = screenshot()
        final_loc, final_conf = find_fn(img, fast=False)
    if final_loc is None:
        world_map.record_sighting(label, loc, conf, last_zoom_diff)
        log(f"Lost {label} after zooming in — falling back to the last "
            f"centered (pre-zoom) position {loc} instead.")
        log(f"--- find_and_center({label}) end (fallback), "
            f"{time.time()-t_start:.0f}s total ---")
        return loc, conf
    world_map.record_sighting(label, final_loc, final_conf, last_zoom_diff)
    log(f"Final position after zoom-in: {final_loc} (confidence {final_conf:.2f})")
    log(f"--- find_and_center({label}) end, {time.time()-t_start:.0f}s total ---")
    return final_loc, final_conf
