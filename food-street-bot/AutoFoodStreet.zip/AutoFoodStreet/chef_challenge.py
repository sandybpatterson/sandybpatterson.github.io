"""Chef Challenge event automation. Built 9/26 from the user's live
walkthrough: tap the chef-hat icon (fixed bottom-nav position, "almost
always there"), confirm the Chef Challenge screen actually opened, then
tap "Collect Reward" on any task that's already earned one.

Scope, deliberately narrow per the user's own framing ("this is the first
step but there will be more"): only the free, already-earned
"Collect Reward" button is ever tapped. The OTHER buttons on this screen
are NOT touched by this module:
  - The green "Complete [ruby cost]" button on an incomplete task is a
    gem-spend skip -- never tap it, same rule as every other gem-cost
    button in this project.
  - The red trash/discard button re-rolls a task -- not automated here,
    no instruction to do so yet.
  - The milestone track's own reward chest (top of the screen) is a
    separate mechanic, not handled by this module yet.
"""
import os
import time
import sys
import cv2

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from adb_helper import screenshot, tap
from find_and_center import (
    StopRequested, close_any_open_panel, check_stop, interruptible_sleep,
    CLOSE_X_LOC,
)

LOG = os.path.join(BASE_DIR, "run_log.txt")

NAV_ICON_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "chef_challenge_nav_icon.png"))
TITLE_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "chef_challenge_title.png"))
# Its OWN file: 10/2 the shared "collect_reward_button.png" was re-saved from the green
# mystery-box reward button, which silently broke this screen's YELLOW Collect Reward button
# (a ready task sat unclaimed on 10/3). Never share this file with the popup handlers.
COLLECT_REWARD_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "chef_collect_reward_button.png"))

# Fixed bottom-nav position, same fixed-HUD pattern as the Orders
# clipboard and Delivery Event scooter icons -- confirmed live 9/26.
NAV_ICON_LOC = (1237, 790)
NAV_MATCH_THRESHOLD = 0.6
TITLE_MATCH_THRESHOLD = 0.7
COLLECT_REWARD_MATCH_THRESHOLD = 0.8
MAX_COLLECTS_PER_RUN = 5  # safety ceiling -- this screen has at most a
                           # handful of task slots, never an unbounded list


NO_CLAIM_PIC_SEC = 3 * 3600                 # one 'nothing to collect' photo per 3 h is plenty for training
_no_claim_saved = 0.0

def log(msg):
    import datetime
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] [chef_challenge] {msg}\n")
    try:
        print(f"[{ts}] [chef_challenge] {msg}")
    except (AttributeError, OSError):
        pass


def _match(img, template, threshold):
    if template is None:
        return None, 0.0
    res = cv2.matchTemplate(img, template, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)
    if max_val < threshold:
        return None, max_val
    th, tw = template.shape[:2]
    return (max_loc[0] + tw // 2, max_loc[1] + th // 2), max_val


NAV_ICON_READY_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "chef_challenge_nav_icon_ready.png"))
NAV_ICON_PLAIN_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "chef_challenge_nav_icon_plain.png"))
NAV_REGION = (880, 720, 1600, 900)          # x1, y1, x2, y2 -- the bottom-right nav bar only
# (template, offset from the match's top-left to the middle of the hat -- the tap point)
#  * original template = the hat top + "1" badge crop, matched at (1323,737) when the hat is at (1365,822)
#  * ready template    = hat + green check, 145x93, centre is the tap point
NAV_TEMPLATES = (
    ("ready", NAV_ICON_READY_TEMPLATE, (72, 46)),
    ("plain", NAV_ICON_PLAIN_TEMPLATE, (72, 46)),
    ("normal", NAV_ICON_TEMPLATE, (42, 85)),
)


def _nav_is_bright(img):
    """Only trust the nav bar on a PLAIN, undimmed screen (popups dim the Orders clipboard)."""
    import numpy as np
    v = cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2]
    return float(np.percentile(v, 90)) >= 240


def find_nav_icon(img):
    """Finds the Chef Challenge icon in the nav bar by IMAGE (it moves when other events
    start/end -- on 10/2 the globe took its old fixed spot, and the old code, though it
    found the icon, tapped the fixed point anyway). Tries the 'ready' look (hat + green
    check) and the normal look. Returns ((x, y) tap point or None, best confidence)."""
    if not _nav_is_bright(img):
        return None, 0.0
    x1, y1, x2, y2 = NAV_REGION
    region = img[y1:y2, x1:x2]
    best = (None, 0.0)
    for name, tpl, (dx, dy) in NAV_TEMPLATES:
        if tpl is None:
            continue
        res = cv2.matchTemplate(region, tpl, cv2.TM_CCOEFF_NORMED)
        _, v, _, l = cv2.minMaxLoc(res)
        if v >= NAV_MATCH_THRESHOLD and v > best[1]:
            best = ((x1 + l[0] + dx, y1 + l[1] + dy), float(v))
        elif best[0] is None and v > best[1]:
            best = (None, float(v))
    return best


def screen_is_open(img):
    loc, conf = _match(img, TITLE_TEMPLATE, TITLE_MATCH_THRESHOLD)
    return loc is not None, conf


def _find_yellow_button(img):
    """Fallback: the ready task's big YELLOW button (the green 'Complete [gems]' skip
    buttons are a different hue and are never matched). Returns (x, y) or None."""
    import numpy as np
    hsv = cv2.cvtColor(img[230:900, 760:1420], cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, (20, 170, 170), (34, 255, 255))
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    best = None
    for i in range(1, n):
        w, h = int(st[i][2]), int(st[i][3])
        if 260 <= w <= 420 and 80 <= h <= 150 and (best is None or w * h > best[2]):
            best = (int(cen[i][0]) + 760, int(cen[i][1]) + 230, w * h)
    return (best[0], best[1]) if best else None


def find_collect_reward_button(img):
    """Searches the whole screen (not a fixed task-row position) since a
    ready task can be in any of the visible task slots. Returns (loc,
    confidence); loc is None if no ready reward is currently visible."""
    loc, conf = _match(img, COLLECT_REWARD_TEMPLATE, COLLECT_REWARD_MATCH_THRESHOLD)
    if loc is not None:
        return loc, conf
    y = _find_yellow_button(img)
    if y is not None:
        return y, 0.5
    return None, conf


_LAST_SAVE = {}


def save_screen(img, tag):
    """Keep a PHOTO of the screen in the log folder (templates/chef_pending/) whenever the
    Chef Challenge run cannot do its job, so a miss can be trained from the real image
    (10/3: a ready reward was missed and no picture existed). At most one per tag per 10 min."""
    import time as _t
    if _t.time() - _LAST_SAVE.get(tag, 0) < 600:
        return None
    _LAST_SAVE[tag] = _t.time()
    d = os.path.join(BASE_DIR, "templates", "chef_pending")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{int(_t.time())}_{tag}.png")
    cv2.imwrite(path, img)
    log(f"Saved a photo of the screen to {path} ({tag}) -- send/train from it.")
    return path


# 10/24 (owner: "if you are confident the ocr is working ... make it try to make however many we need"): cook a
# "Produce and collect this dish (x/y)" task. LOCKED until the Tests job's "Chef task fast travel" test has PASSED
# (the picture was named AND its "?" really led to that dish's station). Then, with the Chef Challenge screen open:
# tap the task's PICTURE (never Complete / trash), tap "?", and hand over to the clipboard bot's own find-card /
# chase / queue step (order_fulfill.cook_after_travel) for y - x. Once per dish per COOK_GAP_SEC.
COOK_GAP_SEC = 10 * 60
PROGRESS_GAP_SEC = 45                                         # after a trip that made progress (an ingredient fetched)
_cook_next = {}


def _travel_test_passed():
    try:
        import tests_job
        return str(tests_job._load().get("chef_travel", {}).get("result", "")).startswith("PASS")
    except Exception:                                         # noqa: BLE001
        return False


def _check_arrival(dish, stop_flag=None):
    import difflib
    import order_fulfill as of
    import popup_ocr
    import recipe_book as rb
    import run_trace
    img = screenshot()
    no, _c = of.find_no_button(img)
    if no is not None:
        tap(*no)
        return False, "the '?' opened a gem question (answered No)"
    if not of.panel_is_open(img):
        save_screen(img, "chef_trip")
        return False, "the '?' did not open a station panel (picture saved)"
    title = (popup_ocr.read_text(img, run_trace.TITLE_REGION) or "").strip()
    try:
        station = rb.load()["items"][rb.resolve(dish)]["station"]
    except Exception:                                         # noqa: BLE001
        station = None
    same = bool(station) and difflib.SequenceMatcher(None, title.lower(), station.lower()).ratio() >= 0.5
    if not same:
        save_screen(img, "chef_trip")
    return same, f"{dish}: arrived at '{title}', recipe book says {station or '?'}"


def _remember_travel(ok, why):
    try:
        import time
        import tests_job
        st = tests_job._load()
        st.setdefault("chef_travel", {}).update(date=tests_job._today(), t=time.time(),
                                                result=("PASS -- " if ok else "FAIL -- ") + why)
        tests_job._save(st)
    except Exception:                                         # noqa: BLE001
        pass


def _cook_task(rows, stop_flag=None):
    """True when it travelled away from the Chef Challenge screen (the caller then must not close anything)."""
    import time
    import order_fulfill as of
    import chef_tasks
    row = next((r for r in rows or [] if r.get("dish") and r.get("kind") == "dish"
                and r.get("done") is not None and r.get("total") and r["done"] < r["total"]), None)
    if row is None:
        return False
    proven = _travel_test_passed()
    if time.time() < _cook_next.get(row["dish"], 0):
        return False
    _cook_next[row["dish"]] = time.time() + COOK_GAP_SEC
    left = row["total"] - row["done"]
    x1, y1, x2, y2 = chef_tasks.ICON_BOX
    top = chef_tasks.ROW_TOPS[row["n"] - 1]
    log(f"[chef cook] task {row['n']}: {row['dish']} {row['done']}/{row['total']} -- travelling from its picture to "
        f"make {left}.")
    tap(chef_tasks.X0 + (x1 + x2) // 2, top + (y1 + y2) // 2)
    interruptible_sleep(0.3, stop_flag)
    img = screenshot()
    q, qconf = of.find_question_button(img, retry=1)
    if q is None:
        no, _c = of.find_no_button(img)
        if no is not None:
            tap(*no)
        log(f"[chef cook] no travel '?' after tapping the picture (best {qconf:.2f}) -- trying again later.")
        return False
    tap(*q)
    interruptible_sleep(1.5, stop_flag)
    if not proven:
        # 10/24 (live: the Tests job runs one test per cycle, the travel test never got its turn): the first trip IS
        # the check -- a station panel must be open and its title must match the dish's station in the recipe book.
        # Right -> remembered as PASS (cooking from now on); wrong -> close, FAIL, no cooking.
        ok, why = _check_arrival(row["dish"], stop_flag)
        _remember_travel(ok, why)
        log(f"[chef cook] first trip check: {'PASS' if ok else 'FAIL'} -- {why}")
        if not ok:
            close_any_open_panel(quiet=True, thorough=True)
            return True
    r = of.cook_after_travel({"tap_loc": None, "icon": None, "slot_key": None, "deficit": left}, stop_flag,
                             still_open=lambda im: screen_is_open(im)[0], dish_name=row["dish"])
    log(f"[chef cook] {row['dish']}: {r.get('status')}.")
    if r.get("status") in ("recursed_ingredient", "collected_blocker", "retry_next_ingredient", "learned_icon"):
        # 10/24 (Muse, live 21:01-21:04): after fetching beans it sat out the full 10 min before chasing the milk --
        # progress was made, so come back on the next Chef turn instead.
        _cook_next[row["dish"]] = time.time() + PROGRESS_GAP_SEC
    close_any_open_panel(quiet=True, thorough=True)
    return True


TAKEOUT_GAP_SEC = 15 * 60
TAKEOUT_PICS_PER_RUN = 3
_takeout = {"next": 0.0, "pics": 0}


def takeout_row(rows, now=None, next_at=0.0):
    """Pure (11/6): the unfinished "Complete takeout orders (x/y)" row to work on, or None (also while resting)."""
    if (now or time.time()) < next_at:
        return None
    return next((r for r in rows or [] if r.get("kind") == "takeout" and r.get("total")
                 and (r.get("done") or 0) < r["total"]), None)


def _takeout_task(rows, stop_flag=None):
    """11/6 (owner: "when the Chef Challenge has a Complete takeout orders task, fast travel to the takeout customers
    from the task picture and serve them"). Taps the task PICTURE, then its travel '?', and lets the known takeout
    popup handler decide (find_and_center: Accept when the dish is in stock -> a gem question is answered No;
    short -> Decline). Pictures of where the trip lands (first 3 per run, templates/tests/*_takeout_trip_*) so the
    route can be learned. True when it travelled away from the Chef Challenge screen."""
    import order_fulfill as of
    import chef_tasks
    import find_and_center as fac
    row = takeout_row(rows, next_at=_takeout["next"])
    if row is None:
        return False
    _takeout["next"] = time.time() + TAKEOUT_GAP_SEC
    x1, y1, x2, y2 = chef_tasks.ICON_BOX
    top = chef_tasks.ROW_TOPS[row["n"] - 1]
    log(f"[chef takeout] task {row['n']}: takeout orders {row.get('done')}/{row['total']} -- travelling from its "
        "picture to the takeout customers.")
    tap(chef_tasks.X0 + (x1 + x2) // 2, top + (y1 + y2) // 2)
    interruptible_sleep(0.3, stop_flag)
    img = screenshot()
    q, qconf = of.find_question_button(img, retry=1)
    if q is None:
        no, _c = of.find_no_button(img)
        if no is not None:
            tap(*no)
        log(f"[chef takeout] no travel '?' after tapping the picture (best {qconf:.2f}) -- trying again in "
            f"{TAKEOUT_GAP_SEC // 60} min.")
        return False
    tap(*q)
    interruptible_sleep(2.0, stop_flag)
    img = screenshot()
    if _takeout["pics"] < TAKEOUT_PICS_PER_RUN and img is not None:
        _takeout["pics"] += 1
        try:
            d = os.path.join(BASE_DIR, "templates", "tests")
            os.makedirs(d, exist_ok=True)
            cv2.imwrite(os.path.join(d, time.strftime("%Y%m%d_%H%M%S") + "_takeout_trip.jpg"),
                        cv2.resize(img, None, fx=0.5, fy=0.5), [cv2.IMWRITE_JPEG_QUALITY, 70])
        except Exception:                              # noqa: BLE001
            pass
    if img is not None and fac.takeout_popup(img) is not None:
        log("[chef takeout] a takeout customer popup is up -- the takeout rule decides (Accept if in stock, else "
            "Decline; a gem question is always No).")
        fac.dismiss_error_dialog()
    else:
        no, _c = of.find_no_button(img) if img is not None else (None, 0)
        if no is not None:                             # a buy-with-gems question -- never
            tap(*no)
            log("[chef takeout] the trip asked for gems -- answered No.")
        else:
            log("[chef takeout] travelled, no takeout popup on screen -- picture saved to learn where it lands.")
    close_any_open_panel(quiet=True, thorough=True)
    return True


def main(stop_flag=None):
    log("=== chef challenge run start ===")
    try:
        close_any_open_panel()

        img = screenshot()
        loc, conf = find_nav_icon(img)
        if loc is None:
            log(f"Chef Challenge nav icon not found on current screen (best {conf:.2f}) -- "
                "it's a fixed HUD icon so it should always be visible; giving up this run.")
            save_screen(img, "no_icon")
            log("=== chef challenge run end (icon not found) ===")
            return

        check_stop(stop_flag)
        log(f"Chef Challenge nav icon found at {loc} (confidence {conf:.2f}) -- tapping it there.")
        tap(*loc)
        interruptible_sleep(1, stop_flag)

        img = screenshot()
        open_ok, title_conf = screen_is_open(img)
        if not open_ok:
            log(f"Chef Challenge screen not confirmed after tapping the icon "
                f"(best {title_conf:.2f}) -- something else may have opened instead. "
                "Closing whatever's open and giving up this run rather than acting blind.")
            save_screen(img, "not_confirmed")
            close_any_open_panel()
            log("=== chef challenge run end (screen not confirmed) ===")
            return
        log(f"Chef Challenge screen confirmed open (confidence {title_conf:.2f}).")
        rows = []
        try:                                                  # 10/24: reading of the 3 tasks
            import chef_tasks
            rows = chef_tasks.log_tasks(img, log)
        except Exception as e:                                # noqa: BLE001
            log(f"[chef test] skipped: {e!r}")

        collected = 0
        first_check = True
        for _ in range(MAX_COLLECTS_PER_RUN):
            check_stop(stop_flag)
            img = screenshot()
            loc, conf = find_collect_reward_button(img)
            if loc is None and first_check:
                # Confirmed live 9/26: a real, visible Collect Reward button
                # can still be missed on the very first check after the
                # screen opens (a fixed extra sleep here wasn't enough on
                # its own), the same class of timing flakiness main()
                # already works around for a station panel via a short
                # retry loop instead of a longer fixed wait -- do the same
                # here rather than guessing a bigger fixed delay.
                for attempt in range(3):
                    interruptible_sleep(0.8, stop_flag)
                    img = screenshot()
                    loc, conf = find_collect_reward_button(img)
                    if loc is not None:
                        log(f"Collect Reward found on retry {attempt + 1} (confidence {conf:.2f}) "
                            "-- first check right after opening was too early.")
                        break
            first_check = False
            if loc is None:
                break
            log(f"Collect Reward button found at {loc} (confidence {conf:.2f}) -- tapping it.")
            tap(*loc)
            interruptible_sleep(1, stop_flag)
            collected += 1

        if collected == 0:
            log("No ready 'Collect Reward' button found this run -- nothing to collect.")
            global _no_claim_saved
            if time.time() - _no_claim_saved > NO_CLAIM_PIC_SEC:    # 10/24: was a photo EVERY run (50 a night)
                _no_claim_saved = time.time()
                save_screen(screenshot(), "no_claim")
        else:
            log(f"Collected {collected} ready task reward(s) this run.")

        check_stop(stop_flag)
        if _cook_task(rows, stop_flag):                       # 10/24: travelled from the task picture and cooked
            log("=== chef challenge run end (task dish worked on) ===")
            return
        if _takeout_task(rows, stop_flag):                    # 11/6: travelled to the takeout customers
            log("=== chef challenge run end (takeout task worked on) ===")
            return
        close_any_open_panel(quiet=True, thorough=True)       # look first, never a blind corner tap
        log("=== chef challenge run end ===")
    except StopRequested:
        log("=== chef challenge run stopped early by user ===")
        raise


if __name__ == "__main__":
    main()
