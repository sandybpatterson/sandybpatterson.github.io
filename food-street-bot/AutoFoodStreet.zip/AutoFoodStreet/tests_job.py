"""Tests job (10/20, owner: "do we need a new job called TESTS ... to expedite things that we know we need to test").

A job in the checklist like the others (runs only when ticked, in its place in the list, never during an express).
Each turn it runs ONE test that has not run today and logs one plain line: "[tests] <name>: PASS/FAIL -- why".
Tests only look, read, open and close -- never gems / Buy / Unlock / Open / Skip / trash, never exchange or upgrade.
Pictures of what each test saw go to templates/tests/ (Send logs). Results per day in .tests.json.

  stock    -- travel to up to 3 stations from the clipboard, read every card's white stock box (stock_digits)
  back     -- open a station, press Android Back, check the panel closed (rung 1 of the unstuck ladder)
  farmer   -- reach the event crop plots from the Food Club board, pan up-left, find the Crop Farmer by sight,
              open it, read the cards, close it (picture cut 10/20 -- the farmer changes every season)
  apples   -- reach the fruit trees via the clipboard, count the ripe apples in view (find_ripe_apples), tap none
  chef     -- (10/21) open the Chef Challenge screen, save its picture, OCR the missions' text and any timers, close it
10/21 (owner): every test runs once per Start (afsd_core.run_loop calls reset_today), not once a day.
"""
import base64
import glob
import datetime
import json
import os
import time

import cv2
import numpy as np

import order_fulfill as of
from order_fulfill import log
from adb_helper import screenshot, tap
from find_and_center import check_stop, interruptible_sleep

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATE_FILE = os.path.join(BASE_DIR, ".tests.json")
PIC_DIR = os.path.join(BASE_DIR, "templates", "tests")
TESTS = (("sell_apple_juice", "Sell Apple Juice"), ("daily_wheel", "Daily prize wheel (scout)"), ("pier_prize", "Pier prize screen (scout)"), ("trades_stock", "Pantry + fridge stock take"), ("stock", "Stock reader"), ("back", "Back key"), ("farmer", "C.R.O.P.S. route to the Crop Farmer"), ("apples", "Apples"),
         ("cow_shed_shot", "Cow Shed pictures"), ("chef", "Chef Challenge missions"), ("chef_travel", "Chef task fast travel"))
ENABLED = {k: True for k, _ in TESTS}           # Settings switches (afsd_core._apply_settings)
# 10/28 (owner, before a 10-h run: "if any tests run over and over and don't need to"): DONE tests are skipped
# (proven live: stock reader, Back key, apples, chef reader + chef travel; farmer waits for the next event).
DONE = {"stock", "back", "apples", "chef", "chef_travel", "daily_wheel", "trades_stock", "cow_shed_shot"}   # 11/15: stock take + Cow Shed pictures retired   # 11/2: "farmer" = C.R.O.P.S. scout, runs again   # daily_wheel: a feature since 10/31
# After a PASS these wait this long before running again (a FAIL still retries next round, to learn faster).
PASS_GAP = {"daily_wheel": 4 * 3600, "pier_prize": 2 * 3600, "trades_stock": 4 * 3600, "cow_shed_shot": 24 * 3600}
ENABLED["sell_apple_juice"] = False             # 10/25: its own Settings switch, off unless the owner turns it on
FAIL_GAP = {"pier_prize": 30 * 60}           # 11/15: a failing scout waits 30 min (it looped every 40 s)
RETRY_SEC = 15 * 60                              # a test that could not start (no route ...) waits this long
_FARMER_JPG = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCADcAIwDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7lVm70/OO2ainlitLeW6ZWZYUaRgOSQBninhjv2OoQ+5rhq4ilRdqjsepClOorxQpPpWd4j1h/D3h7VNe+zC4/s2ynvPK37fM8tC+3dg4zjGcHHpXQxw6T5ameeXf32sMfyrP1t/BurWV3o12I5La7hktbmH7QQWR1KsuQcjIJHBBrgr5xhaCvKVr+i/Nm9PB1JytY/OK9kAQjNcRqseqXPiCys9LtZry6llSOC3iQu8sjEBUVRyzEkAAckmv1A03wr8KorqC+07wDoEVzbyLNDNHo8KSRupyrK2wEEEAgjkEV1cLXt6P9FsypI4EmP6Zr5lZ9gIfDVjK/Z3/ACuevUpyS97Q/P34d/Dz4uz6tawR/DzxBbvJkn7XYSW0YwCTmSUKi8A4yeTgDkgV9BQeENYWyksPEvh66g8oKGkaPKLkDGJFyh6gcHrx1r6HXSNXx88SIf8AZUt/hUV34e1cgvBcJu/uupX9eazWd4WtOyb/APAZfqjD2lluvvPlW4+HNtZXjMkYeNjlcjp7Vr6Z4Wt4wT9nBIHHFe5an4duZdx1fQPtADA+ZFyx4x1X5sVjN4Z0l2ZLSee0kLcrIoYKPQDg+nUmuyniKVb+HJP5lqbauzwLxrYBFEbxKFQ7hxWTqy2t7pVu8BXIXBxXs/in4Wa1qcEgsmtrwOxVVSQI+3n5juwB9Mnr3614l4x8BeLfC8LC40y+traOTyVZ4mEbPzwH+63AJGDyBmuhaWuFufVHL3tkZLRrcgPnIx7Vxd9qWn6betaXXhvUYVjfdutrvcrj12t6gev6it02niK5m8qS5EEecEDrWVf2iWN48bXLSOcbt5/lXVHMsVl9OUsM1fez1CjluEx9aMMUnba60IE8bayCR4X8PWemA8C4lTzp/ruf+WDWc1lqV5fR6rrGpz3V1G4kQs2QrA5GB06itE8DinBSRmvncXneOxjftJtLstF/wfmfZYLIMvwKXsqab7vV/jt8hHm8yTLH5m5oqlqLNblJBkZPXHerKyP5ENxJBJGlwhkjLDAdQxUlT3G5WGR3BHasMVBVIxxENnv6muBqOlOWEnvHbzXT7j9CvEt9a6dot1cSIxRlEPycnMjBB+GWGfal1ecXEFrfQh0WeFJFB4OCoPPvXMfFnWrfSPDMFvMkhfU9QtrSEoBhXDeaS3PA2xMOM8ke5HQNcRXXh7T5IjlUhWPOCOV+U/qDX1OaTvXUOy/U/PsJC1Hn7v8ARHGaNp/2lGnknwSxLMzEsxPUkmu18O2ujROfNmDEDOSa4iLcLq4ijZY40lYY6ADPYVt6XPBEwcybsV/L6/2bES5ldptXfWx9zjKcq8Lp2T7HftLZoRLHIERe5q/putWMxEYlz9K8+vNZe82wBsKvAAq/pitb4ccV62DzSpTxCnGKt1PCrZcnT996nqBv7URDDg8VD58csDMh5FcrbXxfCl61IbpY4mG4civuqWdPFay2seJLB+y23NO31KFj5NxGP94cGkvtGtr6LcZFde29Qa5m4vyk+Var/wDasixKVcjj1rClndGtGVPER5uXZ7P70aSw1SDUoO1zL1HQZrNi0ZKrn7yHI/LoKhgi1BGBW6jZf9tiP6VoTX90qG4gkBJ4ZW5BrBvdatHY+ZH5D/xbTwa8mXEGKwXv4erK38stdPJtP9PI76NGdVWa+aMDWfCngDxNPLbat4UtFumm86WSOIwSu53ZYyR4L5ySeTzgnmvkD9rD4XxfC3xJpGpaJdyNpWvxzukU0xeSGaJwXUfKP3e2WILlmbIfJ6E/YEd9E2roEcNuBCnrnv8A0NeIf8FANIs2+GfhjxY80wurDV20+JAw8sx3EDO5YYzuBtY8YIGC2QcjH6Nwrm085wUa9VJSu07eX5O1vz02IxlH6tU5ejVz530i+XUrFJx98fK/1Fa8EaSKPmrzr4d3V7qeoTfYreeaOC2Z7hY0ZwiLyZGA6Aep4AJrqNR1Ke2ysLYBHBFZZhhXh63Ktnqj7bJ8asXQUpbrR/5/M6fR9d0rwz4n0nWdSsFv4NPuo7kwbypJU5DAgg5BwQOhxg8E17hrXw38BfF26j8a2Gv6o0NxEsYFteRKqbc/KUlBKMM8hcDPOMk5+V9L0/xD4kvHttG0u+1OeOMzPHaW7zOsYIBYhQSFBIGenIrvfG3w88QeANQs9Mvr6WGe9sIL6SKGR4/KkcFXjO07WKujKGUsGUKQecDXCYiVCi1Uhz07/c/U8vPKaWIhVo1OSpZrTtvsfTX7Qut20MPhPQykv2i71c3cbADYEhjKMCc5yTOmOMcNyOM+jeHJYX0CC1uJIGXaSq5KupLMTk8g54xwPxzx4p+0RqdvN8Q/Bnh9Ek+0WkU147EDYUldFUA5znMD547jrzjuZYNUtoY5o4pdjIrAjpjFfR49c2Jk36fkfJYd2w8Y/P8AFm9f+CZ7iaa40/UYE8xtwjYnGT1+YZ9z0qGLwd4ktYyYxbzn+7HJyf8AvoAVyk3ivULAnzPNXHqDRa/Ff7PIFkuCD6E18Xi+CsoxdSVXlcZSvs+r62d18tvI9eGb4qnBQuml3X9f5nTvofiK1PnTabLj/YIc/kpJrUSa6ghDzxyxgDncpGKy9P8AirbzgBrkHPqa6K08a6bdqN7wtn1FeNX8O8L/AMuK8l62evyt934jlm9Spb2kF8v6ZVt9cjjYZlH51oDxHbOAvnjP1qwdR0K8jMc9vC6t1B5B/Cq8lv4QA3myhH0wP5VxLgfG0ly08QmvNNfqxPGYeesoNMebuOQhxID+NWf7Qj8nGeQPWs6XWvDUA2R20GaWHX7FiBbWsX4Vph+BsWpNzrxSfaLf6o56mKp/Zi2Rx+JohviaQcHvWTq8d5eNutrOdz/sxsf6V2FndSXWNsKAfStD+07Oz+S4kiUj1IFdcOAoVE418Q36Rt+bZrTzJUp80Kdvnf8ARHmFhY63DqMG7Sb0xs20t5DYXPGSccDnmuZ/bJsbe9/Zo8Sm70+OWexksJrd5YcmCQ3kKF0Yj5WKPIuRztdh0Jz7dN418P23+su4Rj/poK+ev21/ilYN8FZfD+jvZzjW9UtbO63ZZkhTdPuTBADb4Ixk5G0sMZII+s4fySlkNJ0KU3JOXNqktbJfojHG4r69NScbaWPiD4S+J5/AWtReIGj8yIMUmhLsqyRsMEHHJwcMPdQeoFfWOkaR8BfiBEni3xAyWU8Dsb21ku5IhcOygfvVUgsRgsGjaMlj84bnPgvwP/Z98U/GPVre51CG80bwfF+9utUaIr9pQOymK1LDbI5ZGUsMrHglsnaj+jfFn4a+HPBvi19H8PKo0swxzWcRlaRoo8FfLZm5O1lYDJY7duSTmvZzGc8PSVecFKN9n36P9DDDNOp7OlNxnbdduq/XyO11j43+B/AGmr4d+DXhq1kmjUAXrxAIrbFTzOPvuVRMseWKgkk815HrviTxt4uvzq/iDVzc3JXywzIvyoCSFHHAGT+dQW9htfbGgArRFoUAU8GvmMTmFbFe7J2j2Wi+49GlhqdF8y1k929X957J8covM+PnhuMc/wDEniP/AJHn/wAK+gNH8QaDe6ZbWb3duWjhSM5HoAK8d+MXh3y/i34T8RG53/a9PntfJ2fc8h927dnnd9oxjAxs6nPHkFt411PTmGHlGPRq+vxq/fyPHwy56MbH17qfhHTNVjJt5bdifRhXAeIPhJd7vMghDDrwM15Hpfxqv7NgJZpcD1ya7HTv2grEIBd3RB92rls+hq4yiMvfAGtWLFktDx6ZqkIPENi4AtbjA9DXTD9oDwuU/f6kB7Eg1DJ8dvAzKxbUIM47oKevYWpnJq+vbQClwuKmgu9YuMCWecL7nFYWp/H7wpGW+z3ls3/AFrz3xJ+0labmhsbiJSeBsAH8qFCT6Ae0m7tLFfOu5mbHXJqCT4t6DooPAbH+1Xy/qfxT1jXGKJeSHd0AqitrrWqYeRpSD6sapU7blKN9T6G1/wDaZFuCmnwfiG/+vXm2tfHnxVq0zSQmRVP+3XKWfhHdhp48n3rYt/DUCKFEIFPlS2LikjPuPiH4tvGOZ5Bn/poa9V+B/wAN/D/xc03Xbn4o6BPqlnYS2wsGN3cwRCUrJ5ozE6h2A8vrkqG7bueJi8NW4GSoH4V9IfATSUsvhzcxwXVvKbjUZpWSJ9zQnZGuyQfwthQ2P7rqe9dmCgp1lc58bNwovl0IvHXjVPDemJpOjxQWVtaxLBbwQoEjijUbVRVGAqgAAAcACvm7xX4rvdZvBLeTF/LJwxPTPX+Qr2r4peGryZpJlRz17V8/a3pdzFJLCyMpOQCR39a9PHYb61hZ0Vu1p69PxPEw9f2GIjUeyevp1/A0NJ1O2k/dyFQw5z61pPqNirY8wfnXn/8AZ90pyL7BHcR8/wA6kGnyON01/OX7lcAfkQf518EuG8wm9Y2+a/Rs+plm+BjqpX+T/U+2PjRoN5e3Oha7BMqR2SXlocMRJ5kyxlGXA6DyWycg5K4zzjw6/wDBQck7SDX014+t5LzS7RY4iVivFkcgZCqEcZPpyQPqRXns+kLJJkJ39K+nzDSu/kedg5P2SPB73wpNb5wjce1cF4rhvLZ2iiDKw6cV9VanpEEEJdrdTgdxXl+q6HZ6jrsbNAgU5BGK5Iu7Omcm0fPB0vX7obvMwp9VqE+GdanYpwfwr3Xxp4Tgijkt7NVibnBWuah0OSztA8j7m7mrc5WujJct7NnkUvgbUmY7ouSfSrNl8PLgEFiqmvXdA+Gfjvx/dLD4U0aaWBZAk15J+7toeV3bpDwSA6sUXL45CmofF3gP4ieAYFu9e8J3sEEaLJJcqgmgjDNtG6WMsiktgYJzyOORnVT6dR6Hn1v4Xu9Hn+04ZlQdT0r0Xwtcx3SJFIRkDpVLS71tW0l5LsDqOKxdGuZU8RPDExEYAwB+NJ+8tS46HqKWsCjPy1HMY0b5etJaBpIQSegqNpY0bMjjisjUX943IOBXdfsr/EEp448V/DrWLpUa9dNS0uIhFVmRBFMASd7OUSJtoyMRyH5ec8A96sh2QsPrXIL4jl+G3xR8PePleZYtPvUN55KLI72r/LMqhvlLGNnAyRgnOQeR04ap7OopGGIh7Wm4n35rHhvTtQtyksakn15rzHxF8FLDUmZo4xz04r1i0uLfUbWG+sZ0ubW5jWWGeFg8cqMMqysOCpBBBHBBqxhVXa8X419CmfPuK6nzJqX7OMz5NuwXPTArLH7OGpY5cmvqtY1JJIJ9jTfKX+4KLk+ziUPEcbNo10I1LYCngdgwJP5V56buONsHqK9I1kTf2PfiBGkk+zS7FVcszbDgADqa8QGspNKGkP5V4mZxTqRl5HsYB3g15nQajL9tgKKOoxXl3iGx1DT9RS7tod8SnLeor2PRvCevaqAfsr2MIbDS3SFT2zhTyTg+w4611eneEPCWjIWvrOLU7hlw73SB07Zwh4AyMjqeSM15l1HY6247Hg2ieAPFXxMIutJ01obM5BvboGKD+IfK2Mv8yFTsDYOM4r1Pw78Bvh94cgR9f369dxusgM+Y4VKsSMRKcEEYDBywOOwJFdxe6/LKCsZ2rXG+IvHei6Gxivbtprn/AJ9oBvk7dR0XhgfmIyOma58TjqODpurXkoxXVuxeGwdfHVVSoQcpPolf+vU69tRtbaCKxsLaK3toEWKKKJAiIijCqoHAAGABVzTrm2kIEoB5rwfVPFvi7xEDHZkaVbHHywvmU9OsnBHI/hxwcHNZVn4Z1yO9GpwXdzHdbmf7QsjLJubO47gc5OTk+5r4LGeImDoVeTD03NdXfl+5NNv52PtMPwNVlS5sXXjTl2+L5NppL5XPdPFfwQ+E/j6O5fUNE/s29uxl7/TH8iXdvLs5XBjd2JYMzozEHrkAjwzXf2OtU8NXc2qeDNbXXYzI5S2uVWCdYyw2KHzskYKTuY+WPl4HOB3On+PvG2kYF/bx6im4licRvjHABUYAzzypPX2x3Xhv4mabfJGmoJNYTNwyXCnYCFySJB8uOoBJBOOnIr38u4yyvMbRhU5JPpLT8dvknc8LFcOY/Ae/Jc8e8Xdfdv8AhY+T/FOj+IfB7Laa/od5prs8kaGeIqkpQgNsf7rgZHKkjkHPIrlRcrMx3Nwa/QuWfS9W09opkgvLO8iKujgSRyxuOQRyGUg/Qg15N4v/AGZfhx4iEt1ocVzoV1J5r5s5N0JkflS0T5AVT0SMoMEjjjH00KikjyZPl3PkyW5jh4Rh+Fc54ugGq6VKrDcyKce4r174lfs6+OvAdpca3ZPHruj2yGWa5t12SwIAu5pISSQMluULgKhZtorx+W43qyE8Hg1smt0JWlsfZn7HHxGt/HXwa07Sb2+8/VvChOkXsbCNWESZ+zOEQ52GHYgZgCzRSdSCx9znS1lXBjzX5/8A7HPjyDwF8a7vwjql99m07xjai3iDCNY2vo23QFnYgjKtNGqqTueVBtPBX79z6CvocLU9pSTPBxVN06rSM+40w8tA3H90/wCNZ7blJUg5FbU11BBxJIC390cmsiZ/NkZwMZrdmMb9Rtef/BLw8tppl3favpMP9qRX80Cs7K7Kkf7tgpBIUhxKOMZ+mK9HJtNuAj59c15xYamfDmrTXVo3made3MtyCCTgySM5PPqWJ9s15OaWtF+p34J35kd7rU0qIGViEboa811/4leH9LQiC8Go3DDKR2zhx3xuf7oGRg9SMg4NeoTWmkeLdGltLy2ju7S7TbLE3RvQg9mHBBHoOhAI+bPiH8MtX8D6g8sKzXejyfNDdhCdgyBslwMKwJAzwG7c5UfnvFWY5jleHVbBQTj1lu4/Lt56ruu/3fCWV5Zm2IdHHVHGXSOyl5c3fyVnbZ72XWPGXiHxOz27XX2O0bI+z25I3LyMO3VuDgjhTjpVW00MHAUhPUk4rKs7sQqFQc1sWEct2cs2Fr8Qx2OxOOqOriZuT8/07H66sJSy6l7LCxUILsv6v8zotGj0/T3UPOsr+irmu103TZtVIkSMhO2eK4nTbNY5ATzXa6ZqE9qiiJjiuGEVJ+8fLZrzN81N3l5m/D4egjTFyVAH90bjVe40bRtpCvK3sEx/KrMV+zW5muTjI4FGmzi7mKFgBmur2VN2VkfMKdeN5yk9Oxz/ANgudOk8zQ7+9tBuLFNxMbEjGSh4Jx6+grRsfGut6cwXUrZLqJQAZIRtk4BySpOCScdNoHP0rpriBbNQ7Rq6n1FZdxDb3gLxQr+Ar1cDmmZZRJfVqzSX2XrH7ndfqROrQxy/2impLv1+9amtp/iu01W3S6tWIVuGVuGRu6kdj/npXyF+0J8FL7wVqNz418OQed4bv5zJIkUYX+zZXb/VlVAAiJOEYAAcIedpf369nk8PXjXMFuTFJjzVXqQO49xk11ElronizQrjw/r1jDf6ZqEWyaGTlXU4III5BBAIYEEEAgggGv2ThjiCnnmGvLSrHSS/Jryf4PTs387mWXyy+opw1py2f5p+a/H8F+cQ1v8A4RHxV4c8dpZfbD4e1W11FrfzPL84QyrJs34O3O3GcHGc4NfqHNfXE3AbYvov+Nfnd8efhRd/C/xPdeH5Fu59GvlMulX06KPPjwCykrwXjY7W6E/K21Q6ivub4bapqeufDrwrretXH2jUNQ0WxuruXYqeZNJAjO21QFGWJOAAB2Fff5dPRxPAx6T5Zo6Eg/WnB1Ax5f60UYFekeccz8SPE6+DvAmueI/tQtpLOykNvIY9+LhhshGMHrIyDkY554zXl/wq8YWni7RIraZx56rgoTV/9qO8aXwZY+HIpLhX1G7MzhGwjxRLyj88/PJGwGCMpnggV84+APEl34O1yJJZGWMvgHPT614mZS56nL2PVwdO1Pm7n2X4b1C58PXfksS1u5+6e1dzNHYa3ZywyxRzQTqVkjcAqwIwQQeOn5/y4Pw3d2vi/RI7q3kX7QEyCP4qm03XrjSp2tLrKsvBBrzdGrPY3ejutzyn4g/DaTwnfnUNNWR9Jkfo3LWzE/cb1HofwPYtkWVwqhVQ4r6A/tbS/ECyabfCMmVSvzgFXU/wnPUV4x8Q/AF/4LuW1KwVptJkYfMOTbknhW9ieh/DJ4Lfj/GHB7wd8fgVelvKK+z5r+7+Xpt+scMcUf2oo4DHy/e7Rk/teT/vfn672dKlDMMtXTW95BEByCR1rzXSdSdhktgfWuggviVwG61+cXcD2sdgG5WZ1txq/mnYrfhWpoVyFlV2bAz1rkLBd7b3b5e9X/t5iIWI8VUJu92eJiMHFxdKB6jceXcW4WWUBSOOa528tbixD3FrNwOoB6iuZk1+9iiw0pOOnNaGl60b61aKeQN79xXROqqm55EMurYWPNe8SveapDcApP8AODwQetR6FrlnpN0LczlLVzwH6RtnrnsDzn3545rLv2SK8ZZOAT+dRNZ29ywEZGT2NVluaYjKsVHFYd+9Hp0a6p+T/wCCetUwFDEUHRq35X+HmvNHf+N/Beg/FXwXf+D9cjhxdRMbW4ePebO52kRzoAVO5SegYbgWU/KxBzfg14C1n4ZfDTR/BevzWc19p5uTLJZuzwt5lxJINpZVJ4cZyBzmoPCmuyWtzFoV4wDgbbd16MqjO0gdCAOvcD16+h+Ys0Acn51HBr+lOHM9w+Z0Y4uk/dej7xel0/T8tUfl2a5bVwc3QnvuuzXdev56FbIpaOX5Ior7Q+ePDPjKRrXi8WivMYtNt0hKOfk8xsuWUZ7qyAngnb7CvCPG3hmSEG7t0wyc49a948Y6bdaf40v4L64eb7VJ9rhkc5JicnaOpICkFBnHCDgAiuX8a6GqaVLMVGApOa+crSbrS5u57tFJU4qPY4/4OfG0+F76HStQlYwM+xsnlK+r5INL8Z6ZFqVjMnmsu5XU/e9j71+f1/4em05RrjKVVsuD7Zr1P4T/ABsvfDDxWd1Mz2jEBlY/drGUOqHJX1Pfr3S9U02cyBHyh5x/StWw8ZXgC2upQLNEMfJKvp6Zp1j8U/CGqWkU15OhLDIYEZx7irUuu+DtSTdBcW757ZANZXaJ9TDvfhv4I11WuNDmk0S6dixVSZISScn5CeBjIAUgDPTjFczqfgDxZoTSSCz+22qcie2O7IzgZT72ehIAIHrXWXX2ZT5mmXBX27VY0/xXeWLCO4yR6g18pmnB2VZleSh7OXeOn3rb10Tfc+mwXFeZ4RKMp+0j2nq//At/S7aXY8xfX0tIgpfk9AKsWGtK53sck16hqWi+CfGcLnU9NiS4k5+0wARzBtuAdw64HY5HA44rjtY+DOpWrNP4V1WO8gClvIuG2TZAGACBtYk5/ugce5r88zLgPMcEnPD2qx8tH/4C/wBGz7DAcUZVjVyV70pvv8P/AIEv1SMK81tM7S3X1qG2157V98cuM9Rmue1u11HRrp7TWbWW1nTPySLjPJGR2IyDyODWXHdT3UqQWyO7yMERFBLMxOAAB1NfHPD1IzdOSaa0s9/uPs6OAoVKSnFpxfXp952d34jS5OyRhnsaqNrdyXWC23vK7BUVASzMeAAB1NbPhL4NeJNfMd5qxOnWrYb5+ZWHB6dFyCevII5WvVdN8K+Cfh9Ym8lWBWRcSXNywy3AzyfXbnaOM9BX2GU8B43HtVa/7uHnv8o/52PlM04myrK/3VD97NdFsvWX+V/keX+H/h7448UTR3knmaZCrBlnmyJQQTgqnBBBA6leoIzXrd3q+leGbILqeqNdTRoA2NoLEDqSAFBPsPwryT4hftNaTYxy6f4Via+ZAVLr8sQ/Hv8A54r5s8R/EXxl491U2t/qMyW5OTb2/wAoI9/QV+q5Hw/h8kpuGHu3K123vby2X3X7tn57m+dYjO5xlWSjGOyS2v57v77dkj7x8N69b+IdIi1a0kiNvO0gjEZyAFcqRnJycqf5dq0i61wXwI0ubSvhL4ftLi2eFhHPIFcEEq88jq3POCrAg9wQa73avpX6Fh1y0oryR8XW/iS9Web/ABq0vy9KtPFlrBmfTpVhuHBUZt3OPmzy2H2gAHjexx1I4fWGbXvCM7Wv7weUWOOoAGTXu+radDrGl3mk3LyJDe28ltI0ZAYK6lSRkEZweMg180+FNVn8P61feGNQmieS0uZbVypJjZ0Yqw5A4JBxkCvLzGlyzVRdT0cFU5oOPY5DW9G/trwpBBBHy7bMY7DrXmepaLLpUtysZIFvwD719DTaUug3yog3abeuTbbv+WMneMn+XqK8/wDGWjpaLIzoCbiU9utcaZ2Hltrf6zPEFttSlgbHADcflVpPGPjjw6d805mjH8QYitLV9N+zmNrW2wwGenWr40+TUtFkS7shG0Sly571WgGr4f8AjB4hhijlaZwCMlH6V3Wl/GW3nwL5fLbue1eQeGtP/tKMo21cMQv0rUu/DFzBkqOPUVlKCuVZH0DofxG0Wcr/AKSq57g13mjeLbC4ZXjug2O4avjNbLUbGTzIZJFA7A/0rZ0vxdrmnH9xLICvp/hWbVh+y5kfcLXeg+ILNrLVbW3uoZAA0cyB1OCCMg+4B/Csqz0D4afDmxl1dhYaZA+cTTSGSUjjIDMScZA+X1GcV8uD41eKrKyEFjbLPev8qEk4Ud2P+f5Vyer3PiHxRc/2j4012e6ftDvOxR6AdMVlLC0alRVpwTktnZXXo90VCdalTlRhNqEt0m7P1Wx7344/at0+N5NN+HmlPfTD5ftcwwg+g7jr/hXhviPxh4n8V3DXnivXJrpjnECvtiQegHSsi5vYrWHyrGARp0zXL6xe3Iiby3+Yjr6V1RgY2jFWiWNZ14M407TYw8j8ZXhVHrmpdOuzYRiCBEUk5baOp9SepPua4C0vLlbwnzcsDySa6ewufNbJbJrSUbKyFFn6CfCXVrfXfhr4cv7VZVRbCO2IkAB3w/unPBPBaMke2OnSut59K84/Z1bd8G/D7f8AX3/6VS16RX0FF3pxfkjw6qtOS82FfN/7Rui3Xh/xfY+MLS3ItNWiWC4kUu3+kxjA3E/Ku6PYFAPPluccEn6QriPjL4Ff4g+Ar7RrSPdqNvi9075sZuYwcLyyr86l48scLv3Y+UVniqXtqTitzTDVPZVE3seJ6H4x07U9LbTNdXzbWUBZDnBX0cHsQe9Z3imRrKddP1aza9jgOY7pBzIh5ViPXHXjrmvM/DetJNiKR8rINrf41vt45ktbeziv2aR7VzZyc5+UHKH8ifyr56J7ctCzd61owJ2W3mAfwMuGFY2teJRqFtJYaXbsu9NpUjmvSLe18Oa5YLcy2cTEgHcBg1nnRtFtrgKkS89CRyKd0Scb4V0S4s7ZW28qMkGugnuGaPY0WCB1q9dWiWwPlPhT0xWTPemIlJCD6Gjc02IWiQkFsU17aAAt5ag44qDzt75zTLiWTqQQO2aVrjvYQQwW4aQt8zclu5rOvbmM5xwKS5uS3U1lXcpweapIlu5T1fUNsZRTXI6nfXLxEYIFbV64JJJrHv7mARngEitIkM5BXuVvQ7sUVjg5rrdHuFWRQr7hXF6rcNNNtQ9DxitrQ5nhVd5wfStJq6M4b2R95fsjHPw41L/sNzf+k8Fe34FfNv7F+sX13pHifSZJ82lrPaXMUe0fLJKsiu2cZORDGME4G3jGTn6Rx6mvXwjvRieViVarJC0UUjDIxnFdBgfCvx08Et8LPijcQ2dsYdE1wtqGm7E2xx7j+9gXCKg2PnCLnbG8WTk1xHiOV2tv7SjJaNgFmA7MPut+XFfevxS+HOl/FPwVe+D9TuDbNPtltbxYVke0uEOUkUN+KsAVJR3UMu7NfAL22taXcap4J8V6dLp2sWW63ubabG5HxkEEZDKQQysCQwIIJBBrxMXh/Yz51sz2cLWVaHK90dJ4f8dXOn6cNwLRgDJB6Ut58TIpCGR8n68ivJ9L1G/ll/s9iV2nYw/xrbbwxch87jt6g9RXO4qL1No3lrE9T07xf/alqrbzkinzXqzDazciuL0aCbT4RETnHQitP7SScliDWehpZm19q2ng0+/1Lz41xgEDkCsU3Qxy3NJ9qDDk0gJJpuM1mXk/B5qW5uMjg1j3k7YIFUgM3UrojPNYlzIso2gmrt+TgljWO85DYUcVrEh26mVq5WLBiTBWp9Mmll2uMnFV9bkbaHVeO9M066mWLaEIT1rW3ukXtI+yv2ItdtU1jxL4edJTc3tnb3qMANgSB2RwTnOSbhMcYwG5HGfrWviH9huYyfE7VUJ6eH5z/wCTNvX29XpYP+EkeZjP4rYmQD6UpAIwaCAeoorqOUblU4zXz7+1d8FtS8a6ba/EXwRp0954l0OMQXFtFKS15pwLuUjiwQ8qO5ZQpUsrSD528ta+g2VW6im70j4H6VFSCqRcZFU5ypyUon5ZR2cV7P8A25YS4MxDMo9e9dQl7M0KqTyAOa9B/ah+ENv8J/EEXjTwhpsVl4V16UQyW0coC2eone5SOPA2ROiFlClgrLIPkXy1rxePxAjY+avBrU5U5csuh79GpGceaPU6cXjJ1NON7x1rnF1dX53ipBqCnoaxsaG79sDjryKcLg4+9WEb5eoarEdyGAIaiwzUNxuHJ6daoXkv90cU0XGHGTweKbdDdGSvajqLoY9++4EViyNyTitK+crkE1iTT7XJPSt4uxjJNsz9Wujs2MOKfpkrSWpVhjHSqGoSmeXaOfSr+mW99dz2+m6dZTXV5dyLDBBDGXklkYgKiqOWYkgADkk1fSxPW57Z+yNNu+PXhdM8/wCm/wDpFPX6LV8Zfsv/ALM/xT8O+MNI+J/if7H4ehst8sVhdxma6uEliCENGjKIcxyyAF23o6DdERX2YWAPQ16eEg4Qaa6nl4yanNcvYcRg4zmk5PaikYkdDiuo5gIB4NIIwpyKSnjpQBmeJfDWheMNCvfDPibTIdQ0zUIjFcW8w+V1zkEEcqwIDKwIZWAIIIBr5o8QfsB+E5/s/wDwiXxE1nTdu/7R/aNtFe+Z027PL8nZj5s53ZyOmOfqqlHWs50oVPiRpCrOn8LPgLxV+xP8atB8ybw7No/iSH7SYoY7a7+z3Bh+bbK6zhI14C5VZHILDG4AtXmviH4S/GbwfLepr/w58QQx6dF511dRWb3FrHGE3s5niDRFQvLENhcEHBBA/Udjk0lc8sFTex0xx1Rb6n5HQa3nhzWjb6mrfdev1A8Q+APAfiq8TUfFHgjQNYu44hCk+oabDcSLGCSEDOpIUFmOOmSfWvIdd/Yv+CGrNbnS7HWNA8jdv/s/UWfzs4xv+0iXG3Bxt2/eOc8Y5amBcVdM6aeOjJ2aPimO/LDG+rou/MhHzdetUfGmkweF/HXiLwxp800lrpGrXdhA8xBkaOKZkUsQAC2FGcADPYVUtJpCjKTxjNcLj0O9O6uGpvkEisOO2vNSvYdO0+0muru6lWCCCGMvJLIxAVFUcsxJAAHJJrtPB2h2nirxv4e8M6jJNHa6vqtnYzvCQJFjlmVGKkggMAxxkEZ7Gv0S+G3wa+HfwqtBF4P8OwQXbR+VPqM3728nGEDbpTyFYxqxRdse7kKK6cNQdZ7nJia6orY+NvhN+xF478WPb618Rbn/AIRbSn2Si1wJNQmQ+W2Nn3YMqzjLkujrhoiK+wvht8H/AIefCa0WDwd4dghumi8qfUZv3t5OMIG3SnkKxjVii7Y93IUV3m0elJ5a5zivWp0YU9lqeVUrTqbsVWyu48UuR2U1FtAyaejsBgGtrGR//9k="


def _today():
    return datetime.date.today().isoformat()


def _load():
    try:
        with open(STATE_FILE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _save(st):
    try:
        with open(STATE_FILE, "w", encoding="utf-8") as fh:
            json.dump(st, fh, indent=1)
    except OSError:
        pass


def reset_today():
    """Settings button "Run the tests again": forget today's results."""
    st = _load()
    for k in list(st):
        if not isinstance(st[k], dict):         # 10/27: "pier_prize_runs" is a list, kept across Starts
            continue
        st[k].pop("date", None)
        st[k].pop("retry_at", None)
    _save(st)
    try:
        _JUICE["sold"] = 0                      # 10/27: the juice count is per run
    except NameError:
        pass


def summary():
    """[(label, result text or None)] for the Settings tab."""
    st = _load()
    return [(lab, (st.get(k) or {}).get("result") if (st.get(k) or {}).get("date") == _today() else None)
            for k, lab in TESTS]


def _pic(img, name, jpg=False):
    try:
        os.makedirs(PIC_DIR, exist_ok=True)
        p = os.path.join(PIC_DIR, f"{time.strftime('%Y%m%d_%H%M%S')}_{name}.{'jpg' if jpg else 'png'}")
        cv2.imwrite(p, img, [cv2.IMWRITE_JPEG_QUALITY, 85] if jpg else [])   # 10/27: jpg ~0.3 MB vs png ~1.5 MB
        return os.path.relpath(p, BASE_DIR)
    except Exception:                               # noqa: BLE001
        return "?"


class _NotNow(Exception):
    """The test could not start (no route, no crop on the board ...) -- try again later, not a FAIL.
    wait = seconds until the retry (default RETRY_SEC)."""
    def __init__(self, msg, wait=None):
        super().__init__(msg)
        self.wait = wait


# ---------------------------------------------------------------------------------------------------------------
def _to_station(stop, skip=()):
    """Travel to the station of a clipboard item (0 hops) whose station is not in skip. -> (img, station) or raise."""
    import prep_engine as pe
    import prep_route
    img, _view = of.open_board_smart(stop)
    slots = pe._board_slots(img)
    for name, loc in slots:
        key = prep_route._key(name)
        st = prep_route.station_of(key) if key else None
        if not st or st in skip or st in ("Garden Plot", "Fruit trees and bushes", "Lemon Tree"):
            continue
        if not of.travel_to_missing_item({"tap_loc": loc}, stop):
            break
        panel = pe._wait_panel(stop)
        if panel is None:
            panel = pe._collect_here(stop, st)
        if panel is None:
            raise _NotNow(f"the {st} panel did not open")
        if "order" in (pe._panel_title(panel) or "").lower():   # 10/25 live: the trip did not land -- the clipboard
            of.close_any_open_panel(quiet=True, thorough=True)  # itself was read as "Orders: []" (stock test FAIL)
            raise _NotNow(f"the trip to the {st} did not land (the Orders board was still open)")
        return panel, st
    of.close_any_open_panel(quiet=True, thorough=True)
    raise _NotNow("no clipboard item leads to a new station right now")


def _test_stock(stop):
    import event_orders as eo
    import prep_engine as pe
    import stock_digits as sd
    if not sd._TEMPLATES:
        return False, "templates/stock_digits is missing on this PC -- press Update (twice, with a reopen between)"
    seen, lines, all_ok = [], [], True
    for _ in range(3):
        try:
            img, st = _to_station(stop, skip=seen)
        except _NotNow:
            break
        seen.append(st)
        btns = eo.station_buttons(img) or []
        reads = [sd.read_stock(img, b[0]) for b in btns]
        all_ok = all_ok and bool(reads) and all(r is not None for r in reads)
        lines.append(f"{pe._panel_title(img) or st}: {reads} ({_pic(img, 'stock')})")
        of.close_any_open_panel(quiet=True, thorough=True)
    if not lines:
        raise _NotNow("could not reach any station from the clipboard")
    return all_ok, "; ".join(lines)


def _test_back(stop):
    import adb_helper
    import event_orders as eo
    import prep_engine as pe
    img, st = _to_station(stop)
    title = pe._panel_title(img)
    if not of.panel_is_open(img) or "expand" in title.lower():
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow(f"no clean station panel to try it on ({title or 'nothing open'})")
    adb_helper.back()
    of.interruptible_sleep(1.5, stop)
    after = adb_helper.screenshot()
    if not of.panel_is_open(after) and eo.hud_is_bright(after):
        return True, f"Back closed the {title or st} panel; plain map after it"
    p = _pic(after, "back_after")
    of.close_any_open_panel(quiet=True, thorough=True)        # red X only
    if not eo.hud_is_bright(adb_helper.screenshot()):
        import find_and_center as fac
        fac.dismiss_error_dialog()
    still = "the panel was still open" if of.panel_is_open(after) else "something else came up"
    return False, f"after Back {still} (picture {p}); closed it with the red X"


def _farmer_tpl():
    buf = np.frombuffer(base64.b64decode(_FARMER_JPG), np.uint8)
    return cv2.imdecode(buf, cv2.IMREAD_COLOR)


def _find_farmer(img):
    t = _farmer_tpl()
    best = (0.0, None)
    for s in (0.8, 0.9, 1.0, 1.1, 1.25):
        tt = cv2.resize(t, None, fx=s, fy=s)
        r = cv2.matchTemplate(img[90:780, :1400], tt, cv2.TM_CCOEFF_NORMED)
        _mn, mx, _l, loc = cv2.minMaxLoc(r)
        if mx > best[0]:
            best = (mx, (loc[0] + tt.shape[1] // 2, loc[1] + 90 + tt.shape[0] // 2))
    return best


def _reach_event_plots(stop):
    """10/20 live: the Food Club orders are all dishes, so none travels straight to the crop plots. Go to an order's
    station, read the travel tooltip of each ingredient on its cards ("Grow Spices on your Event Plot") WITHOUT
    travelling, and tap the "?" only on a crop's tooltip. True = the camera is at the event plots."""
    import adb_helper
    import event_orders as eo
    import popup_ocr
    for _attempt in range(3):
        img = eo.open_board(stop)
        if img is None:
            raise _NotNow("the Food Club board did not open (event over?)")
        cards = eo.read_board(img)
        if _attempt >= len(cards) or not cards[_attempt]["slots"]:
            break
        if not eo.tap_item_and_travel(cards[_attempt]["slots"][0]["icon"], "tests farmer", stop):
            continue
        if eo._last_wanted.get("plot"):
            return True
        kind, _tapped = eo.arrive(stop)
        if kind == "plot":
            return True
        if kind != "station":
            of.close_any_open_panel(quiet=True, thorough=True)
            continue
        shot = adb_helper.screenshot()
        for bx, by in [(b[0], b[1]) for b in (eo.station_buttons(shot) or [])]:
            for x, _col in eo.count_blobs(shot, by - 70, by - 40, bx - 175, bx + 175):
                of.check_stop(stop)
                adb_helper.tap(x, by - 56)
                of.interruptible_sleep(0.3, stop)
                s2 = adb_helper.screenshot()
                q, _qc = eo.find_tooltip_question(s2)
                if q is None:
                    no, _nc = of.find_no_button(s2)
                    if no is not None:                 # a gem-buy dialog: always No
                        adb_helper.tap(*no)
                    continue
                x1, y1, x2, y2 = eo.TOOLTIP_BOX
                info = eo.parse_tooltip(popup_ocr.read_text(s2, (q[0] + x1, q[1] + y1, q[0] + x2, q[1] + y2)) or "")
                if info and info.get("plot"):
                    log(f"[tests] farmer: '{info.get('name')}' grows on the event plot -- travelling there.")
                    adb_helper.tap(*q)
                    of.interruptible_sleep(2.5, stop)
                    return True
                of.interruptible_sleep(4.0, stop)       # let this tooltip fade before the next tap
        of.close_any_open_panel(quiet=True, thorough=True)
    return False


def _test_farmer(stop):
    import adb_helper
    import event_orders as eo
    import prep_engine as pe
    if not _reach_event_plots(stop):
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("no Food Club order or station ingredient led to the event crop plots")
    of.close_any_open_panel(quiet=True, thorough=True)        # a grow card / plant bar may have opened
    shot = adb_helper.screenshot()
    score, loc = _find_farmer(shot)
    for _ in range(2):                              # owner: the Crop Farmer is "up and to the left a little"
        if score >= 0.7:
            break
        adb_helper.swipe(500, 330, 850, 560, 900)  # drag down-right = the view moves up-left
        of.interruptible_sleep(1.2, stop)
        shot = adb_helper.screenshot()
        score, loc = _find_farmer(shot)
    if score < 0.7:
        return False, f"Crop Farmer not found by sight (best {score:.2f}) -- picture {_pic(shot, 'farmer_miss')}"
    adb_helper.tap(*loc)
    of.interruptible_sleep(1.6, stop)
    panel = adb_helper.screenshot()
    title = pe._panel_title(panel)
    if not eo.station_panel_open(panel) or not any(w in title.lower() for w in ("crop", "farmer")):
        p = _pic(panel, "farmer_tap")
        of.close_any_open_panel(quiet=True, thorough=True)
        return False, f"found it at {loc} ({score:.2f}) but the tap opened '{title or 'nothing'}' (picture {p})"
    import stock_digits as sd
    reads = [sd.read_stock(panel, b[0]) for b in (eo.station_buttons(panel) or [])]
    p = _pic(panel, "farmer")
    of.close_any_open_panel(quiet=True, thorough=True)
    return True, f"found by sight at {loc} ({score:.2f}), opened '{title}', stock per card {reads} (picture {p})"


CROPS_UP = ((800, 250), (800, 650))      # finger top -> bottom = the view moves UP (owner: "scroll up two swipes")
CROPS_LEFT = ((450, 450), (1050, 450))
CROPS_SMALL_UP = ((800, 330), (800, 530))  # 11/14: 200-px steps, finger top -> bottom = the view moves up a little   # finger left -> right = the view moves LEFT (the farmer is left of storage)


def _test_crops_scout(stop):
    """11/2 PROJECT C.R.O.P.S. ("Crop-farmer Route Over the Plots, Scouted") -- owner: open the event board, travel to
    ANY event crop plot, scroll up two swipes -> the event board / the gondola (clubs) / a little "dog house" box = the
    Food Club storage; to its LEFT stands this season's Crop Farmer (new name each season, same card layout, always 3
    crops). Step 1 = scout: pictures after every drag (templates/tests/*_crops_*.jpg) so the storage box and the farmer
    can be cut as pictures; the old farmer picture is tried too. Taps nothing but the travel."""
    import adb_helper
    if not _reach_event_plots(stop):
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("no Food Club order or station ingredient led to the event crop plots")
    of.close_any_open_panel(quiet=True, thorough=True)
    of.interruptible_sleep(0.8, stop)
    shots = [_pic(adb_helper.screenshot(), "crops_0_plots", jpg=True)]
    best = (0.0, None, "")
    # 11/14 (owner): the farmer is CLOSE to the plots, next to the red-and-white Food Club storage box -- move the
    # view UP in small steps (a picture after each) so the box + farmer show up; the old 2x up + 2x left overshot.
    moves = [("up", CROPS_SMALL_UP)] * 5
    for i, (name, (a, b)) in enumerate(moves, 1):
        adb_helper.swipe(a[0], a[1], b[0], b[1], 700)
        of.interruptible_sleep(1.3, stop)
        shot = adb_helper.screenshot()
        shots.append(_pic(shot, f"crops_{i}_{name}", jpg=True))
        score, loc = _find_farmer(shot)
        if score > best[0]:
            best = (score, loc, f"after drag {i} ({name})")
    log(f"[tests] C.R.O.P.S. scout: {len(shots)} pictures {', '.join(os.path.basename(p) for p in shots if p)}; "
        f"old farmer picture best {best[0]:.2f} {best[2]}")
    return True, (f"scouted -- {len(shots)} pictures saved (plots + 5 small steps up); old farmer picture best "
                  f"{best[0]:.2f} {best[2]} (it is from another season -- cut the new one from these pictures)")


def _test_crops_route(stop):
    """11/15 C.R.O.P.S. step 2 (owner's event-area picture): event plots -> small drags up until the Food Club storage
    box shows (crops.find_box) -> tap the Crop Farmer at a fixed offset from it -> the panel title must say farmer/crop
    -> read its cards' stock -> red X. LOG ONLY: opens and closes the farmer, never trades."""
    import adb_helper
    import crops
    import event_orders as eo
    import prep_engine as pe
    if not _reach_event_plots(stop):
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("no Food Club order or station ingredient led to the event crop plots")
    of.close_any_open_panel(quiet=True, thorough=True)
    of.interruptible_sleep(0.8, stop)
    shot = adb_helper.screenshot()
    score, xy, sc = crops.find_box(shot)
    drags = 0
    while score < crops.BOX_MIN and drags < 5:
        a, b = CROPS_SMALL_UP
        adb_helper.swipe(a[0], a[1], b[0], b[1], 700)
        drags += 1
        of.interruptible_sleep(1.3, stop)
        shot = adb_helper.screenshot()
        score, xy, sc = crops.find_box(shot)
    if score < crops.BOX_MIN:
        return False, (f"storage box not found after {drags} drags up (best {score:.2f}) -- picture "
                       f"{_pic(shot, 'crops_nobox', jpg=True)}")
    spot = crops.farmer_spot(xy, sc, (shot.shape[1], shot.shape[0]))
    if spot is None:
        return False, (f"storage box at {xy} ({score:.2f}, scale {sc}) but the farmer spot is off the screen -- "
                       f"picture {_pic(shot, 'crops_offscreen', jpg=True)}")
    before = _pic(shot, "crops_box", jpg=True)
    adb_helper.tap(*spot)
    of.interruptible_sleep(1.6, stop)
    panel = adb_helper.screenshot()
    title = pe._panel_title(panel) or ""
    after = _pic(panel, "crops_farmer_tap", jpg=True)
    if not crops.is_farmer_title(title):
        no, _c = of.find_no_button(panel)
        if no is not None:
            adb_helper.tap(*no)
        of.close_any_open_panel(quiet=True, thorough=True)
        return False, (f"box {score:.2f} at {xy} (scale {sc}) -> tapped {spot}, but it opened '{title or 'nothing'}' "
                       f"(pictures {before}, {after})")
    import stock_digits as sd
    reads = [sd.read_stock(panel, bx[0]) for bx in (eo.station_buttons(panel) or [])]
    of.close_any_open_panel(quiet=True, thorough=True)
    log(f"[crops] Crop Farmer reached: box {score:.2f} at {xy} (scale {sc}), tapped {spot}, title '{title}', "
        f"stock per card {reads}")
    return True, f"opened '{title}' via the storage box ({score:.2f}); stock per card {reads} (picture {after})"


def _to_apple_trees(stop):
    """Clipboard route to the apple trees (live 10/26: Apple Juice '?' -> Smoothie Bar -> its Apple '?')."""
    import prep_engine as pe
    import prep_route
    img, _view = of.open_board_smart(stop)
    slots = pe._board_slots(img)
    route = prep_route.find_route("apple", [n for n, _ in slots])
    if route is None:
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("nothing on the clipboard leads to the apple trees right now")
    log("[tests] apples route: " + prep_route.describe("apple", route))
    loc = next(l for n, l in slots if pe._same(n, route[0][1]))
    if not of.travel_to_missing_item({"tap_loc": loc}, stop):
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("the clipboard tap gave no '?'")
    for step in route[1:]:
        if pe._wait_panel(stop) is None or not pe._hop(step[1], step[2], stop):
            of.close_any_open_panel(quiet=True, thorough=True)
            raise _NotNow(f"a hop on the way failed ({step[3]})")
    of.interruptible_sleep(1.5, stop)


def _test_cow_shed_shot(stop):
    """10/28 (owner): pictures of the Cow Shed on the map, to tap it by its picture instead of the blind centre tap
    (which sometimes opens the Pig Pen). Clipboard route to milk; red X on any menu; pictures of the map. Taps
    nothing else."""
    import adb_helper
    import prep_engine as pe
    import prep_route
    img, _view = of.open_board_smart(stop)
    slots = pe._board_slots(img)
    route = prep_route.find_route("milk", [n for n, _ in slots])
    if route is None:
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("nothing on the clipboard leads to the Cow Shed right now")
    log("[tests] cow shed route: " + prep_route.describe("milk", route))
    loc = next(l for n, l in slots if pe._same(n, route[0][1]))
    if not of.travel_to_missing_item({"tap_loc": loc}, stop):
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("the clipboard tap gave no '?'")
    for step in route[1:]:
        if pe._wait_panel(stop) is None or not pe._hop(step[1], step[2], stop):
            of.close_any_open_panel(quiet=True, thorough=True)
            raise _NotNow(f"a hop on the way failed ({step[3]})")
    of.interruptible_sleep(2.0, stop)
    shots = [_pic(adb_helper.screenshot(), "cowshed_1_arrived")]
    of.close_any_open_panel(quiet=True, thorough=True)      # red X only
    of.interruptible_sleep(1.5, stop)
    shots.append(_pic(adb_helper.screenshot(), "cowshed_2_map"))
    of.interruptible_sleep(2.0, stop)
    shots.append(_pic(adb_helper.screenshot(), "cowshed_3_map"))
    return True, "pictures " + ", ".join(shots)


def _test_apples(stop):
    import adb_helper
    _to_apple_trees(stop)
    shot = adb_helper.screenshot()
    found = of.find_ripe_apples(shot)
    p = _pic(shot, "apples")
    of.close_any_open_panel(quiet=True, thorough=True)
    if found:
        return True, f"{len(found)} ripe apple(s) in view at {[(x, y) for _a, x, y in found[:5]]} (picture {p})"
    return False, f"no ripe apple found in view (picture {p}) -- picked already, or the detector missed them"


def _test_chef(stop):
    """10/21 (owner): read the Chef Challenge missions -- text, time left, icons. Opens the screen, looks, closes.
    Never taps Complete (gems), trash (re-roll) or Collect Reward (the normal Chef job does that)."""
    import re
    import adb_helper
    import chef_challenge as cc
    import popup_ocr
    of.close_any_open_panel(quiet=True, thorough=True)
    img = adb_helper.screenshot()
    loc, conf = cc.find_nav_icon(img)
    if loc is None:
        raise _NotNow(f"Chef Challenge icon not found on the nav bar (best {conf:.2f})")
    adb_helper.tap(*loc)
    of.interruptible_sleep(1.5, stop)
    img = adb_helper.screenshot()
    ok, tconf = cc.screen_is_open(img)
    if not ok:
        of.interruptible_sleep(1.2, stop)
        img = adb_helper.screenshot()
        ok, tconf = cc.screen_is_open(img)
    pic = _pic(img, "chef")
    if not ok:
        of.close_any_open_panel(quiet=True, thorough=True)
        return False, f"the Chef Challenge screen did not open (title {tconf:.2f}; picture {pic})"
    text = popup_ocr.read_text(img, region=(240, 120, 1440, 880)) or ""
    times = re.findall(r"\d+\s*[dhms]\b(?:\s*\d+\s*[hms]\b)?", text, flags=re.I)
    ready = cc._find_yellow_button(img) is not None
    try:                                                      # 10/24: per-task read (title, x/y, timer, points)
        import chef_tasks
        chef_tasks.log_tasks(img, log)
    except Exception as e:                                    # noqa: BLE001
        log(f"[chef test] task read skipped: {e!r}")
    of.close_any_open_panel(quiet=True, thorough=True)
    return True, (f"screen read -- times seen {times or 'none'}; a ready Collect Reward {'IS' if ready else 'is not'} "
                  f"showing; text {text[:160]!r}; picture {pic}")


def _test_chef_travel(stop):
    """10/24 (owner: "it can use the image of the icon to fast travel to the table of that object just like on the
    clipboard ... test that out as soon as we are sure we know what to make"). Only when chef_tasks named the dish of a
    "produce this dish" task: tap that task's PICTURE (never Complete / trash), expect the travel bubble with a "?",
    tap "?", check a station panel opened and its title matches the dish's station in the recipe book, close it.
    Cooks nothing. A gem dialog anywhere -> No."""
    import difflib
    import adb_helper
    import chef_challenge as cc
    import chef_tasks
    import popup_ocr
    import recipe_book as rb
    import run_trace
    of.close_any_open_panel(quiet=True, thorough=True)
    img = adb_helper.screenshot()
    loc, conf = cc.find_nav_icon(img)
    if loc is None:
        raise _NotNow(f"Chef Challenge icon not found on the nav bar (best {conf:.2f})")
    adb_helper.tap(*loc)
    of.interruptible_sleep(1.5, stop)
    img = adb_helper.screenshot()
    ok, _t = cc.screen_is_open(img)
    if not ok:
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("the Chef Challenge screen did not open")
    rows = chef_tasks.log_tasks(img, log)
    row = next((r for r in rows if r["dish"] and r.get("kind") == "dish"), None)
    if row is None:
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("no 'produce this dish' task with a dish the bot can name yet")
    try:
        station = rb.load()["items"][rb.resolve(row["dish"])]["station"]
    except Exception:                               # noqa: BLE001
        station = None
    x1, y1, x2, y2 = chef_tasks.ICON_BOX
    top = chef_tasks.ROW_TOPS[row["n"] - 1]
    adb_helper.tap(chef_tasks.X0 + (x1 + x2) // 2, top + (y1 + y2) // 2)        # the picture, nothing else
    of.interruptible_sleep(0.3, stop)
    img = adb_helper.screenshot()
    q, qconf = of.find_question_button(img, retry=1)
    if q is None:
        no, _c = of.find_no_button(img)
        if no is not None:
            adb_helper.tap(*no)
        pic = _pic(img, "chef_travel")
        of.close_any_open_panel(quiet=True, thorough=True)
        return False, f"tapping task {row['n']}'s {row['dish']} picture showed no travel '?' (best {qconf:.2f}; {pic})"
    adb_helper.tap(*q)
    of.interruptible_sleep(1.8, stop)
    img = adb_helper.screenshot()
    no, _c = of.find_no_button(img)
    if no is not None:
        adb_helper.tap(*no)
        of.close_any_open_panel(quiet=True, thorough=True)
        return False, "the '?' opened a gem question (answered No)"
    pic = _pic(img, "chef_travel")
    if not of.panel_is_open(img):
        of.close_any_open_panel(quiet=True, thorough=True)
        return False, f"the '?' did not open a station panel ({pic})"
    title = (popup_ocr.read_text(img, run_trace.TITLE_REGION) or "").strip()
    of.close_any_open_panel(quiet=True, thorough=True)
    same = station and difflib.SequenceMatcher(None, title.lower(), station.lower()).ratio() >= 0.5
    return bool(same), (f"task {row['n']} ({row['dish']}): the picture's '?' travelled to '{title}'"
                        + (f" -- the recipe book says {station}" if station else " -- station unknown in the recipe book")
                        + f" ({pic})")


# ---------------------------------------------------------------------------------------------------------------
# 10/25 (owner): log-only STOCK TAKE through the sales menu -- open My Trades, tap an empty "Create a sale" box so the
# item picker opens, then read every tile on the Pantry and Fridge tabs (name by picture, count by the tile digits).
# Never taps Put on Sale, a price/quantity button, a sold slot, the gem Unlock slot or Remove; closes with the red X.
STOCK_TAKE_MAX_BLIND = 0.25                      # 10/30 (Muse): more unnamed / unread tiles than this = FAIL
TILE_COLS = (97, 280, 463)                      # trade_sell._snap_to_tile: tile columns, rows every 183 px
TILE_ROW = 183


def _tile_rows(img):
    strip = cv2.cvtColor(img[:, 20:560], cv2.COLOR_BGR2GRAY).astype(np.float32)
    prof = np.abs(np.diff(strip, axis=0)).mean(axis=1)
    phase = max(range(TILE_ROW), key=lambda p: sum(prof[y] for y in range(p, len(prof), TILE_ROW)))
    y0 = 100 + ((phase - 17) % TILE_ROW)
    return [y for y in range(y0 - 3 * TILE_ROW, 900, TILE_ROW) if y - 78 >= 0 and y + 80 <= 900]


def _icon_vec(icon):
    g = cv2.resize(icon, (48, 48), interpolation=cv2.INTER_AREA).astype(np.float32)
    g = (g - g.mean()) / (g.std() + 1e-6)
    return g.ravel() / (np.linalg.norm(g) + 1e-6)


_NAME_LIB = None


def _name_lib():
    global _NAME_LIB
    if _NAME_LIB is None:
        _NAME_LIB = []
        # 10/30 (Muse brief "fix the pantry", owner: fix now): stock_tiles first -- every Pantry + Fridge tile cut from
        # the 10/28 stock-take pages in this exact crop; the other libraries are drawn differently (strawberry -> apple)
        for sub in ("stock_tiles", "trade_tiles", "dishes", "plant_bar_library", "chef_icons_named"):
            for p in glob.glob(os.path.join(BASE_DIR, "templates", sub, "*.png")):
                im = cv2.imread(p)
                if im is not None and im.shape[0] >= 24 and not os.path.basename(p).startswith("ref_"):
                    nm = os.path.basename(p)[:-4].split("__")[0]
                    for pre in ("icon_", "card_"):
                        nm = nm[len(pre):] if nm.startswith(pre) else nm
                    _NAME_LIB.append((nm, _icon_vec(im)))
    return _NAME_LIB


def _name_icon(icon):
    v = _icon_vec(icon)
    best, bs = None, 0.0
    for name, t in _name_lib():
        s = float(v @ t)
        if s > bs:
            best, bs = name, s
    return (best if bs >= 0.75 else None), bs


_STOCK_TPL = None
STOCK_TILE_MIN = 0.8


def _stock_tpls():
    global _STOCK_TPL
    if _STOCK_TPL is None:
        _STOCK_TPL = []
        for p in glob.glob(os.path.join(BASE_DIR, "templates", "stock_tiles", "*.png")):
            im = cv2.imread(p)
            if im is not None:
                _STOCK_TPL.append((os.path.basename(p)[:-4], im))
    return _STOCK_TPL


def _name_by_stock_tile(img, x, y):
    """10/30: the row grid can sit ~20 px off on scrolled pages (Muse: half-icon crops) -- slide each Pantry/Fridge tile
    picture over a window 40 px taller than the cell and take the best match (>= STOCK_TILE_MIN)."""
    win = img[max(0, y - 78 - 40):min(img.shape[0], y + 20 + 40), max(0, x - 78 - 8):x + 78 + 8]
    best, bs = None, 0.0
    for name, t in _stock_tpls():
        if win.shape[0] < t.shape[0] or win.shape[1] < t.shape[1]:
            continue
        sc = float(cv2.minMaxLoc(cv2.matchTemplate(win, t, cv2.TM_CCOEFF_NORMED))[1])
        if sc > bs:
            best, bs = name, sc
    return (best, bs) if bs >= STOCK_TILE_MIN else (None, bs)


def _read_page(img, tab, seen, unknown, names=None):
    import trade_sell as ts
    out = []
    for y in _tile_rows(img):
        for x in TILE_COLS:
            icon = img[y - 78:y + 20, x - 78:x + 78]
            if icon.size == 0 or float(icon.std()) < 18 or float(icon.mean()) < 140:  # empty / dark locked cell (dark ~91, real tiles 200+)
                continue
            v = _icon_vec(icon)
            if any(float(v @ w) > 0.97 for w in seen):           # already counted on the page before (scroll overlap)
                continue
            seen.append(v)
            name, score = _name_by_stock_tile(img, x, y)
            if name is None:
                name, score = _name_icon(icon)
            if names is not None and name is not None:
                if name in names:                                  # 10/30: same tile again after a scroll (the crop
                    continue                                       # shifted a little, so the picture check missed it)
                names.add(name)
            n = ts.read_number(img, ts.tile_box(x, y), save_unknown=False)
            if name is None:
                unknown.append(icon.copy())
                name = f"unknown#{len(unknown)}"
            out.append((name, n, round(score, 2)))
    return out


def _sheet(icons):
    """One numbered picture of all unknown tiles (so a single Send logs picture shows them all)."""
    cells = []
    for i, ic in enumerate(icons, 1):
        c = cv2.resize(ic, (156, 98))
        cv2.putText(c, str(i), (4, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        cells.append(c)
    while len(cells) % 6:
        cells.append(np.zeros((98, 156, 3), np.uint8))
    rows = [np.hstack(cells[i:i + 6]) for i in range(0, len(cells), 6)]
    return np.vstack(rows)


def _test_trades_stock(stop):
    import trade_sell as ts
    if not ts.open_trades(stop):
        raise _NotNow("My Trades did not open")
    report, pics = {}, []
    try:
        img = screenshot()
        fr = ts.free_slots(img)
        if not fr:
            pic = _pic(img, "trades_no_free_slot")
            raise _NotNow(f"no empty sale box to open the item list with ({pic})")
        tap(ts.SLOT_X[fr[0]], ts.SLOT_Y)
        interruptible_sleep(2.5, stop)
        img = screenshot()
        if not ts.picker_open(img):
            return False, f"tapped sale box {fr[0] + 1} but the item list did not open ({_pic(img, 'trades_picker')})"
        unknown = []
        for tab in ("pantry", "fridge"):
            ts._goto_tab(tab, stop)
            for _ in range(3):
                ts._drag(False, stop)                       # to the top of the list
            seen, items, prev, names = [], [], None, set()
            for page in range(12):
                check_stop(stop)
                img = screenshot()
                if prev is not None and float(np.abs(img[:, :ts.PANEL_W].astype(np.int16)
                                                     - prev[:, :ts.PANEL_W].astype(np.int16)).mean()) < 1.0:
                    break                                   # the list did not move: that was the end
                if page < 3:
                    pics.append(_pic(img, f"stocktake_{tab}_{page + 1}"))
                items += _read_page(img, tab, seen, unknown, names)
                prev = img
                ts._drag(True, stop)
            report[tab] = items
            log(f"[stock take] {tab.upper()} ({len(items)} items): " + ", ".join(
                f"{n} {c if c is not None else '?'}" for n, c, _s in items))
        if unknown:
            pics.append(_pic(_sheet(unknown), "stocktake_unknown_sheet"))
            log(f"[stock take] {len(unknown)} tile(s) not recognised -- numbered in the unknown sheet picture.")
        tap(*ts.CLOSE_X)                                    # close the item list (red X), never Put on Sale
        interruptible_sleep(1.5, stop)
    finally:
        ts.close_trades(stop)
    try:
        with open(os.path.join(BASE_DIR, ".stock_take.json"), "w", encoding="utf-8") as fh:
            json.dump({"t": time.time(), "tabs": {k: [[n, c] for n, c, _s in v] for k, v in report.items()}}, fh)
    except OSError:
        pass
    total = sum(len(v) for v in report.values())
    unread = sum(1 for v in report.values() for _n, c, _s in v if c is None)
    unnamed = sum(1 for v in report.values() for n, _c, _s in v if str(n).startswith("unknown#"))
    # 10/30 (Muse): a take that could not name or count most tiles is a FAIL, not a PASS
    ok = total > 0 and unnamed <= STOCK_TAKE_MAX_BLIND * total and unread <= STOCK_TAKE_MAX_BLIND * total
    return ok, (f"{unnamed} of {total} not named, " f"pantry {len(report.get('pantry', []))} items, fridge {len(report.get('fridge', []))} items, "
                f"{unread} count(s) unreadable; pictures {', '.join(pics[:3])}")


WHEEL_MIN = 0.6                                  # wheel.png at half size, grey: 1.00 on the wheel, <= 0.30 elsewhere


def find_wheel(img):
    """Centre (x, y) of the prize wheel on a 1600x900 screen, and the match score -- (None, score) when not seen.
    Template cut 10/25 from fail_pictures/1792937195_unreadable.png (Muse P20)."""
    if img is None or img.shape[:2] != (900, 1600):
        return None, 0.0
    g = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), (800, 450))
    best, loc = 0.0, None
    # 10/25 20:37 live: the game was zoomed further IN and the wheel had turned (best 0.31) -- a second picture cut
    # from that screen (wheel_2.png), each tried a little smaller and bigger
    for name, scales in (("wheel.png", (0.5, 0.42, 0.6)), ("wheel_2.png", (0.5, 0.4, 0.3, 0.6)),
                         ("wheel_3.png", (0.5, 0.4, 0.6, 0.7))):   # 10/26 Muse: zoomed in further (0.49)
        t = cv2.imread(os.path.join(BASE_DIR, "templates", "daily_wheel", name), 0)
        if t is None:
            continue
        for sc in scales:
            tt = cv2.resize(t, None, fx=sc, fy=sc)
            if tt.shape[0] >= g.shape[0] or tt.shape[1] >= g.shape[1]:
                continue
            _mn, mx, _ml, ml = cv2.minMaxLoc(cv2.matchTemplate(g, tt, cv2.TM_CCOEFF_NORMED))
            if mx > best:
                best, loc = mx, (int((ml[0] + tt.shape[1] / 2) * 2), int((ml[1] + tt.shape[0] / 2) * 2))
    return (loc if best >= WHEEL_MIN else None), round(best, 2)


def _wheel_open(stop, loc, sc, n, pics):
    """10/25 (owner: ok) step 2: tap the wheel and read what opens. "Spin again" / a gem price = already used today
    -> close with the red X, never the gem button. Anything else = probably today's free spin: picture + close,
    NO swipe yet (the spin swipe is taught from that picture / a Let Me Play recording first)."""
    import adb_helper
    import popup_ocr
    of.tap(*loc)                                                 # the wheel itself, on the map
    of.interruptible_sleep(2.0, stop)
    shot = adb_helper.screenshot()
    no_loc, _nc = of.find_no_button(shot)
    if no_loc is not None:                                       # a gem question of any kind -> No
        of.tap(*no_loc)
        of.interruptible_sleep(1.0, stop)
        shot = adb_helper.screenshot()
    pics.append(_pic(shot, "wheel_4_after_tap"))
    text = " ".join((popup_ocr.read_text(shot, (250, 80, 1350, 860)) or "").split())
    low = text.lower()
    log(f"[tests] daily wheel: tapped it, the screen says: '{text[:200]}'")
    used = "again" in low or "gem" in low
    spun = ""
    if not used:
        spun = _wheel_spin(stop, pics)
    of.close_any_open_panel(quiet=True, thorough=True)           # red X only
    of.interruptible_sleep(1.0, stop)
    pics.append(_pic(adb_helper.screenshot(), "wheel_5_after_close"))
    if used:
        return True, (f"wheel found (drag {n}, match {sc}) and tapped: ALREADY USED today ('Spin again' / gem) -- "
                      "closed with the red X, gem button never touched. Pictures: " + ", ".join(pics))
    return (not spun.startswith("NOT")), (f"wheel found (drag {n}, match {sc}) and tapped: free spin -- " + spun +
                                          " Pictures: " + ", ".join(pics))


# 10/27: the 10/26 swipe ran down the orange RIM (x 800) and the wheel never moved (wheel_6 still said "Spin the
# wheel!"). Wheel on the 10/26 pictures: centre (530,510), slices out to ~r 300. Swipes now cross the slices; each one
# is checked (the wheel must change within 0.7 s) before the next is tried.
WHEEL_CENTRE = (530, 510)
WHEEL_SPIN_SWIPES = (((720, 300), (720, 760), 200),          # right half, top -> bottom, quick flick
                     ((340, 760), (340, 300), 200),          # left half, bottom -> top (the same turn)
                     ((720, 300), (720, 760), 450))          # right half again, slower


def _wheel_moved(a, b):
    x, y = WHEEL_CENTRE
    ca = cv2.cvtColor(a[y - 260:y + 260, x - 260:x + 260], cv2.COLOR_BGR2GRAY).astype(np.int16)
    cb = cv2.cvtColor(b[y - 260:y + 260, x - 260:x + 260], cv2.COLOR_BGR2GRAY).astype(np.int16)
    return float(np.mean(np.abs(ca - cb)))


def _wheel_spin(stop, pics):
    """10/26 (owner: "it is ready to claim and spin"): the free spin -- swipe across the wheel, wait for it to stop,
    read the prize, then let the normal popup closer take a reward popup (Collect / Great -- never gems). Only called
    when the screen does NOT say "Spin again" / gem. Any gem question -> No."""
    import adb_helper
    import find_and_center as fac
    import popup_ocr
    moved = None
    for n, ((x1, y1), (x2, y2), ms) in enumerate(WHEEL_SPIN_SWIPES, start=1):
        before = adb_helper.screenshot()
        adb_helper.swipe(x1, y1, x2, y2, ms)
        of.interruptible_sleep(0.7, stop)
        diff = _wheel_moved(before, adb_helper.screenshot())
        log(f"[tests] daily wheel: swipe {n} ({x1},{y1})->({x2},{y2}) {ms} ms -- wheel change {diff:.1f}.")
        if diff > 6:
            moved = n
            break
    if moved is None:
        shot = adb_helper.screenshot()
        pics.append(_pic(shot, "wheel_6_did_not_spin"))
        # 10/27 Muse: OCR read '' and the screen was "Spin Again? [gem] 1" -- the free spin was already used today
        return "ALREADY USED -- the wheel did not turn on any swipe (today's free spin is spent; gem spin never tapped)."
    of.interruptible_sleep(9.0, stop)                            # the wheel turns for a few seconds
    shot = adb_helper.screenshot()
    no_loc, _nc = of.find_no_button(shot)
    if no_loc is not None:                                       # a gem question appeared -> No, never Yes
        of.tap(*no_loc)
        of.interruptible_sleep(1.0, stop)
        pics.append(_pic(shot, "wheel_6_gem_question"))
        return "the swipe brought up a gem question -- tapped No, nothing spent."
    pics.append(_pic(shot, "wheel_6_after_spin"))
    text = " ".join((popup_ocr.read_text(shot, (250, 80, 1350, 860)) or "").split())
    log(f"[tests] daily wheel: SPUN (swipe {moved}) -- the screen now says: '{text[:200]}'")
    for _ in range(3):                                           # reward popup: Collect / Great (never gems)
        if not fac.dismiss_error_dialog():
            break
        of.interruptible_sleep(1.5, stop)
    pics.append(_pic(adb_helper.screenshot(), "wheel_7_after_collect"))
    return f"SPUN (screen after: '{text[:120]}')."


def _to_lighthouse(stop, pics, tag="wheel"):
    """Clipboard route to the Fisherman's Lighthouse, close its menu (red X only) -> the map by the pier."""
    import adb_helper
    import prep_engine as pe
    import prep_route
    img, _view = of.open_board_smart(stop)
    slots = pe._board_slots(img)
    route = prep_route.find_route("fishing_hook", [n for n, _ in slots])
    if route is None:
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("nothing on the clipboard leads to the Fisherman's Lighthouse right now")
    log("[tests] daily wheel route: " + prep_route.describe("fishing_hook", route))
    loc = next(l for n, l in slots if pe._same(n, route[0][1]))
    if not of.travel_to_missing_item({"tap_loc": loc}, stop):
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("the clipboard tap gave no '?'")
    for step in route[1:]:
        if pe._wait_panel(stop) is None or not pe._hop(step[1], step[2], stop):
            of.close_any_open_panel(quiet=True, thorough=True)
            raise _NotNow(f"a hop on the way failed ({step[3]})")
    panel = pe._wait_panel(stop)
    if panel is not None:
        pics.append(_pic(panel, f"{tag}_0_lighthouse_panel"))
    of.close_any_open_panel(quiet=True, thorough=True)           # the Lighthouse menu -- its red X only
    of.interruptible_sleep(1.5, stop)
    pics.append(_pic(adb_helper.screenshot(), f"{tag}_1_lighthouse_map"))


def _drag_to_wheel(stop, pics):
    """Drag along the pier until the wheel shows. -> (loc, score, drags) or (None, best, drags)."""
    import adb_helper
    sc = 0
    for n in (1, 2):                                             # owner 10/25: "swipe left" = finger moves RIGHT ("your other left")
        of.check_stop(stop)
        adb_helper.swipe(550, 470, 1150, 470, 600)               # a drag, never a tap -- the map moves right, the pier to the left comes in
        of.interruptible_sleep(1.8, stop)
        shot = adb_helper.screenshot()
        pics.append(_pic(shot, f"wheel_{n + 1}_after_drag_{n}"))
        loc, sc = find_wheel(shot)
        log(f"[tests] daily wheel after drag {n}: " + (f"WHEEL FOUND at {loc} (match {sc})" if loc else f"no wheel (best {sc})"))
        if loc:
            return loc, sc, n
    return None, sc, 2


# 10/27 (owner): a second prize screen on the pier, "to the left of the hairdresser" -- "swipe down the pier to that
# screen; normally clickable, now it's not because it's redeemed"; check it TWICE a day. Step 1 = SCOUT: from the
# wheel, drag further along the pier and photograph each view (named *_wheel_pier_* so Send logs carries them first).
# Taps nothing but the route and the Lighthouse menu's red X. The prize screen gets its own picture + tap once seen.
# 10/27 Muse run 10:26: sideways drags left the pier for the farm. The deck runs from the wheel DOWN-LEFT past the
# hairdresser (clothes rack) -- follow it: finger lower-left -> upper-right, the camera walks down the pier.
PIER_DRAGS = (((450, 760), (950, 410), "along"), ((450, 760), (950, 410), "along"),   # 10/27 owner: in pier picture 4
              ((450, 760), (950, 410), "along"),                                       # (after 3 "along") the prize
              ((450, 250), (1050, 650), "screen"),                                     # screen's yellow corner + black
              ((600, 300), (900, 500), "screen2"))                                     # frame peek in at top-left
PIER_RUNS_PER_DAY = 10 ** 6       # 10/27 (owner): run it every round until it is right
PIER_GAP_SEC = 0


def _test_pier_prize(stop):
    import adb_helper
    st = _load()
    runs = [t for t in st.get("pier_prize_runs", []) if datetime.date.fromtimestamp(t).isoformat() == _today()]
    now = time.time()
    if len(runs) >= PIER_RUNS_PER_DAY:
        tomorrow = datetime.datetime.combine(datetime.date.today() + datetime.timedelta(days=1), datetime.time())
        raise _NotNow(f"already checked {len(runs)}x today", wait=max(600, int(tomorrow.timestamp() - now)))
    if runs and now - max(runs) < PIER_GAP_SEC:
        raise _NotNow("checked less than 6 h ago", wait=int(PIER_GAP_SEC - (now - max(runs))))
    pics = []
    _to_lighthouse(stop, pics, tag="wheel_pier")
    loc, sc, n = _drag_to_wheel(stop, pics)
    log(f"[tests] pier prize: wheel {'at ' + str(loc) if loc else 'not seen'} -- now scouting along the pier.")
    found = None
    for k, ((x1, y1), (x2, y2), way) in enumerate(PIER_DRAGS, start=1):
        of.check_stop(stop)
        adb_helper.swipe(x1, y1, x2, y2, 600)                    # drags only
        of.interruptible_sleep(1.8, stop)
        img = adb_helper.screenshot()
        pics.append(_pic(img, f"wheel_pier_{k + 1}_{way}", jpg=True))
        found = find_pier_screen(img)
        if found:
            break
    st = _load()
    st["pier_prize_runs"] = runs + [now]
    _save(st)
    if not found:
        return False, "prize screen NOT found along the pier -- pictures: " + ", ".join(pics)
    (x, y), sc = found
    log(f"[tests] pier prize: SCREEN FOUND at ({x},{y}) (match {sc:.2f}) -- tapping it.")
    adb_helper.tap(x, y)                                         # 10/31 (owner): find out if it can be collected
    of.interruptible_sleep(3.0, stop)
    img = adb_helper.screenshot()
    pics.append(_pic(img, "wheel_pier_7_after_tap", jpg=True))
    no, _nc = of.find_no_button(img)
    if no is not None:                                           # never buy anything
        adb_helper.tap(*no)
        return True, "the screen asked for gems -- said No. Pictures: " + ", ".join(pics)
    try:
        import popup_ocr
        said = (popup_ocr.read_text(img, (250, 80, 1350, 860)) or "").strip()[:120]
    except Exception:                                            # noqa: BLE001
        said = ""
    import find_and_center as fac
    closed = 0
    for _ in range(3):                                           # a reward popup: Collect / Great / OK (never gems)
        if not fac.dismiss_error_dialog():
            break
        closed += 1
        of.interruptible_sleep(1.5, stop)
    pics.append(_pic(adb_helper.screenshot(), "wheel_pier_8_after_collect", jpg=True))
    of.close_any_open_panel(quiet=True, thorough=True)
    return True, (f"tapped the prize screen; it said '{said}'; closed {closed} popup(s). Pictures: " + ", ".join(pics))


PIER_SCREEN_MIN = 0.6


def find_pier_screen(img):
    """10/31: the pier prize billboard (gold face with a gift, cut from the 10/30 pier picture 5) -> ((x, y), score)
    of its middle, or None. Grey, half size, a few scales (the game zoom drifts)."""
    try:
        tpl = cv2.imread(os.path.join(of.BASE_DIR, "templates", "pier_prize", "screen.png"), cv2.IMREAD_GRAYSCALE)
        if tpl is None or img is None:
            return None
        g = cv2.resize(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), None, fx=0.5, fy=0.5)
        best = (0.0, None)
        for sc in (0.4, 0.5, 0.6):
            t = cv2.resize(tpl, None, fx=sc, fy=sc)
            if t.shape[0] >= g.shape[0] or t.shape[1] >= g.shape[1]:
                continue
            r = cv2.matchTemplate(g, t, cv2.TM_CCOEFF_NORMED)
            _, m, _, (x, y) = cv2.minMaxLoc(r)
            if m > best[0]:
                best = (m, (int((x + t.shape[1] / 2) * 2), int((y + t.shape[0] / 2) * 2)))
        return (best[1], best[0]) if best[0] >= PIER_SCREEN_MIN else None
    except Exception:                                            # noqa: BLE001
        return None


def _test_daily_wheel(stop):
    """10/25 (owner): the daily reward is a PRIZE WHEEL on the ocean pier next to the Fisherman's Lighthouse --
    fast travel to the Lighthouse, swipe left, the wheel is on the pier; open it and swipe to spin. Already used today:
    the worker sits on the edge of the pier and the wheel shows "Spin again [1 gem]" (NEVER tap that).
    Step 1 = SCOUT, nothing is tapped but the route, the panel's red X and map drags: pictures of the pier after each
    swipe so the wheel (and its used / ready look) can be cut as templates. Spinning comes after that."""
    pics = []
    _to_lighthouse(stop, pics)
    loc, sc, n = _drag_to_wheel(stop, pics)
    if loc:
        return _wheel_open(stop, loc, sc, n, pics)
    return False, ("wheel NOT found after 2 drags; nothing tapped -- pictures: " + ", ".join(pics))


WHEEL_RETRY_SEC = 30 * 60       # 10/31: the daily wheel feature tries again this long after a miss / no route


def daily_wheel_feature(stop, hours=24):
    """10/31 (owner: the wheel test "is good enough to be a feature"): once a day, while the bot works, travel to the
    pier and spin the free daily wheel (_test_daily_wheel: never the 'Spin again' gem button). A used wheel counts as
    done for today; no route (no fish order on the clipboard) or a miss -> again in WHEEL_RETRY_SEC.
    Returns a log line when it ran, None when nothing was due."""
    st = _load()
    e = st.setdefault("wheel_feature", {})
    now = time.time()
    if e.get("retry_at", 0) > now:
        return None
    last = e.get("t_ok") or 0                           # 10/31: every `hours` (Settings) since the last spin / used wheel
    if last and now - last < hours * 3600:
        return None
    try:
        ok, why = _test_daily_wheel(stop)
    except _NotNow as nn:
        ok, why = None, f"not now -- {nn}"
    except Exception as ex:                             # noqa: BLE001
        if type(ex).__name__ == "StopRequested":
            raise
        ok, why = False, f"error {ex!r}"
        try:
            of.close_any_open_panel(quiet=True, thorough=True)
        except Exception:                               # noqa: BLE001
            pass
    st = _load()
    e = st.setdefault("wheel_feature", {})
    if ok:
        e.update(date=_today(), result=why, t=now, t_ok=now)
        e.pop("retry_at", None)
    else:
        e.update(retry_at=now + WHEEL_RETRY_SEC, result=why, t=now)
    _save(st)
    msg = f"[daily wheel] {f'done -- next visit in {hours} h' if ok else 'try again in 30 min'} -- {why}"
    log(msg)
    return msg


JUICE_BATCH = 2                  # 10/27 (owner): make two Apple Juices, then sell those two


def _juice_on_page(img):
    """(tap_loc, have) of an Apple Juice item on the visible clipboard page, else None. The board's own count is
    what is in storage -- no Smoothie Bar trip needed to know the stock."""
    for o in of.read_orders_page(img):
        for it in o["items"]:
            if it["name"] and "apple_juice" in str(it["name"]).lower().replace(" ", "_"):
                return (o["cx"] + of.SLOT_DX[it["col"]], of.SLOT_ROWS[it["row"]][0]), it.get("have")
    return None


def _test_sell_apple_juice(stop):
    """10/25 (owner): make Apple Juice and put one up for sale (coins only, max price, trade_sell.sell).
    10/27 rewrite (owner: "the fast travel is right there on the menu"): the old way travelled, then tapped the
    station to open it and hit 'Expand your Land' every time. Now: the clipboard Apple Juice item says how many we
    have. Have one -> sell it, no trip. None -> tap the item's '?' and let order_fulfill.cook_after_travel open the
    Smoothie Bar and queue one -- the same path the clipboard bot uses (live 10/26 13:13 'ARRIVED ... OK')."""
    import trade_sell
    img, _view = of.open_board_smart(stop)
    found = _juice_on_page(img)
    for go in (of.reset_orders_scroll, of.swipe_to_far_end):   # the other board page (10/27: the board was already
        if found is not None:                                  # on its far end, and only the far end was looked at)
            break
        go(stop)
        of.wait_for_screen_stable(stop)
        img = screenshot()
        found = _juice_on_page(img)
    if found is None:
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("no Apple Juice order on the clipboard right now")
    loc, have = found
    log(f"[tests] apple juice: the clipboard says we have {have}.")
    have = have or 0
    if have >= JUICE_BATCH:                             # 10/27 (owner): make two, sell those
        return _sell_juice(have, stop)
    if time.time() - _JUICE["picked_at"] > APPLE_PICK_GAP and not of._fruit_resting("apple"):
        # 10/27 (owner: "it needs to harvest them too"): pick every ripe apple in view, also while juice cooks
        of.close_any_open_panel(quiet=True, thorough=True)
        _JUICE["picked_at"] = time.time()
        _to_apple_trees(stop)
        got = of.harvest_fruit_here("apple", stop, max_harvests=APPLE_PICK_MAX)
        of.close_any_open_panel(quiet=True, thorough=True)
        log(f"[juice] apple trip: {'picked apples' if got else 'no ripe apples picked'}.")
        raise _NotNow("picked apples -- making juice next" if got else "no ripe apples to pick -- making juice next",
                      wait=30)
    if of.in_progress("apple_juice") or of.in_progress("Apple Juice"):   # 10/27: noted as 'apple_juice' 
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("Apple Juice is cooking -- selling it once it is made", wait=JUICE_COOK_WAIT)
    item = {"tap_loc": loc, "icon": None, "slot_key": None, "deficit": JUICE_BATCH - have}   # apples chased as usual
    if not of.travel_to_missing_item(item, stop):
        of.close_any_open_panel(quiet=True, thorough=True)
        raise _NotNow("the clipboard tap gave no '?'")
    r = of.cook_after_travel(item, stop, dish_name="Apple Juice")
    of.close_any_open_panel(quiet=True, thorough=True)
    st = r.get("status")
    if st == "queued" or st == "already_cooking":
        raise _NotNow(f"have {have} -- making {JUICE_BATCH - have} more; selling {JUICE_BATCH} when ready",
                      wait=JUICE_COOK_WAIT)
    if st in ("recursed_ingredient", "collected_blocker", "retry_next_ingredient", "learned_icon"):
        raise _NotNow(f"have {have} -- went for apples ({st.replace('_', ' ')}); cooking next", wait=JUICE_STEP_WAIT)
    try:                                                # 10/27 bug check: a full Pantry refuses every apple pick --
        import find_and_center as _fac                  # that is not "out of apples"
        if st == "blocked_on_ingredient" and _fac.pantry_full_recent():
            raise _NotNow("the Pantry is full, so no apples can be picked -- trying again later", wait=RETRY_SEC)
    except ImportError:
        pass
    if st == "blocked_on_ingredient":                   # 10/27 (owner): "sell Apple juice till there's no more apples"
        if have:
            return _sell_juice(have, stop, last=True)
        return True, f"OUT OF APPLES -- sold {_JUICE['sold']} Apple Juice this run; stopping until the next Start"
    # 10/27: anything else (station full, card not found, travel failed ...) is a retry, not the end of the loop
    raise _NotNow(f"have {have} -- this trip ended '{st}' (picture {_pic(screenshot(), 'apple_juice')}); trying again",
                  wait=JUICE_COOK_WAIT)


JUICE_COOK_WAIT = 330            # 10/27: Apple Juice cooks 5 min (was 240 -- came back before it was ready)
JUICE_STEP_WAIT = 90             # after an apple trip: cook right away
_JUICE = {"sold": 0, "picked_at": 0}
APPLE_PICK_GAP = 10 * 60         # 10/27: an apple-picking trip at most every 10 min (trees take a while to refill)
APPLE_PICK_MAX = 8               # taps per trip (each ripe apple is one tap)


def _sell_juice(have, stop, last=False):
    """List what we have (2 at a time; the last few when apples ran out). Keeps going until the apples are gone."""
    import trade_sell
    n = have if last else JUICE_BATCH
    of.close_any_open_panel(quiet=True, thorough=True)
    r = trade_sell.sell("apple_juice", n, stop)
    if not r["ok"]:
        raise _NotNow(f"had {have} Apple Juice but the sale did not go through ({r['reason']})")
    _JUICE["sold"] += n
    log(f"[juice] listed {n} Apple Juice at the max price (had {have}; {_JUICE['sold']} sold this run).")
    if last:
        return True, f"OUT OF APPLES -- listed the last {n}; {_JUICE['sold']} Apple Juice sold this run"
    raise _NotNow(f"listed {n} Apple Juice ({_JUICE['sold']} this run) -- making more", wait=JUICE_STEP_WAIT)


RUNNERS = {"pier_prize": _test_pier_prize, "daily_wheel": _test_daily_wheel, "trades_stock": _test_trades_stock, "stock": _test_stock, "back": _test_back, "farmer": _test_crops_route, "apples": _test_apples, "chef": _test_chef,
           "chef_travel": _test_chef_travel, "cow_shed_shot": _test_cow_shed_shot, "sell_apple_juice": _test_sell_apple_juice}


def run(app, stop):
    """One Tests turn: the first enabled test not done today (and not waiting to retry). Returns a status line."""
    st = _load()
    now = time.time()
    # 10/27 (owner: "run every test run, until we get it right ... faster improvement even if it hurts coins/h"):
    # no once-a-day limit -- when every test has had its turn, start the next round straight away.
    runnable = [k for k, _ in TESTS if ENABLED.get(k, True) and k not in DONE and st.get(k, {}).get("retry_at", 0) <= now]
    if runnable and all(st.get(k, {}).get("date") == _today() for k in runnable):
        for k in runnable:
            st[k].pop("date", None)
        _save(st)
        log("[tests] every test has had its turn -- starting the next round.")
    for key, label in TESTS:
        if not ENABLED.get(key, True) or key in DONE:
            continue
        e = st.setdefault(key, {})
        if e.get("date") == _today() or e.get("retry_at", 0) > now:
            continue
        log(f"[tests] {label}: starting.")
        try:
            app.set_status(f"Tests: {label}...")
        except Exception:                           # noqa: BLE001
            pass
        try:
            ok, why = RUNNERS[key](stop)
            st = _load()                            # 10/27: a test may save its own state (pier_prize_runs) --
            e = st.setdefault(key, {})              # don't overwrite it with the copy loaded before the test
        except _NotNow as nn:
            st = _load()
            e = st.setdefault(key, {})
            wait = getattr(nn, "wait", None) or RETRY_SEC
            e["retry_at"] = now + wait
            _save(st)
            when = f"{wait // 60} min" if wait >= 60 else f"{wait} s"
            log(f"[tests] {label}: could not run now -- {nn}; trying again in {when}.")
            return f"Tests: {label} -- not now ({nn})."
        except Exception as ex:                     # noqa: BLE001
            if type(ex).__name__ == "StopRequested":
                raise
            import traceback as _tb                 # 10/25 (Muse P19): the file + line, not only the message
            fr = _tb.extract_tb(ex.__traceback__)
            where = " <- ".join(f"{os.path.basename(f.filename)}:{f.lineno} {f.name}" for f in fr[-3:][::-1])
            ok, why = False, f"error {ex!r} at {where}"
            try:
                of.close_any_open_panel(quiet=True, thorough=True)
            except Exception:                       # noqa: BLE001
                pass
        e.update(date=_today(), result=("PASS -- " if ok else "FAIL -- ") + why, t=now)
        e.pop("retry_at", None)
        if ok and PASS_GAP.get(key):
            e["retry_at"] = now + PASS_GAP[key]
        elif not ok and FAIL_GAP.get(key):
            e["retry_at"] = now + FAIL_GAP[key]
        _save(st)
        log(f"[tests] {label}: {'PASS' if ok else 'FAIL'} -- {why}")
        return f"Tests: {label} {'PASS' if ok else 'FAIL'}."
    waits = [(st.get(k, {}).get("retry_at", 0), lbl) for k, lbl in TESTS
             if ENABLED.get(k, True) and k not in DONE and st.get(k, {}).get("retry_at", 0) > now]
    if waits:                                   # 10/31: say when the next test is due instead of "all done" every 5 s
        t, lbl = min(waits)
        return f"Tests: nothing due -- next is {lbl} in {max(1, int(t - now) // 60)} min."
    return "Tests: all of today's tests are done."


def idle_seconds():
    """10/31: seconds until the next test is due (0 = one is due now / nothing is waiting)."""
    st, now = _load(), time.time()
    waits = [st.get(k, {}).get("retry_at", 0) - now for k, _ in TESTS
             if ENABLED.get(k, True) and k not in DONE and st.get(k, {}).get("retry_at", 0) > now]
    return max(0, int(min(waits))) if waits else 0
