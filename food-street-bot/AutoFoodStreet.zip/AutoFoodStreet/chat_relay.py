"""11/14 (owner): CHAT RELAY -- read the game's club chat from a phone without interrupting the bot.

Hidden feature: Settings > Experimental > "Chat relay" shows the "Chat update" job and starts a small web page on
the PC (LAN only: http://<pc-ip>:8765). Logging in needs a 6-digit code that changes every 30 s (authenticator
style, shown in Settings). The job opens the chat (bubble icon, left of the map) every few minutes or when its
unread badge changes, saves a picture for the page, and closes it again. Messages typed on the page are queued;
SENDING IS LOG-ONLY until the chat screen's text box has been seen ("[chat] would send: ...").
Pure parts (TOTP, sessions, outbox) are tested in tests/test_chat_relay.py.
"""
import base64
import hashlib
import hmac
import html
import json
import os
import secrets
import socket
import struct
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
STATE_FILE = os.path.join(HERE, ".chat_relay.json")     # secret + phone sessions + outbox (gitignored)
SHOT_FILE = os.path.join(HERE, ".chat_last.jpg")        # latest chat picture (gitignored)
BUBBLE = os.path.join(HERE, "templates", "chat", "chat_bubble.png")
SEND_BTN = os.path.join(HERE, "templates", "chat", "send_button.png")      # 11/14: green Send (chat open)
EMPTY_BOX = os.path.join(HERE, "templates", "chat", "write_box_empty.png")  # "Write a message" placeholder
SEND_REGION = (60, 240, 560, 880)                       # y0, y1, x0, x1 where the Send button sits
WRITE_XY = (415, 143)                                   # the "Write a message" box
SEND_XY = (727, 143)                                    # the green Send button
BOX_REGION = (90, 200, 200, 620)
SETTLE_MAX_SEC = 12                                     # wait for the chat to finish loading
_fails = []                                             # failed logins (time) -- max 5 a minute
PORT = 8765
STEP = 30                                               # code changes every 30 s
SESSION_SEC = 7 * 24 * 3600
CHECK_SEC = 180                                         # open the chat at least this often
BADGE_CHECK_SEC = 30                                    # ... or sooner when the unread badge changed
BUBBLE_MIN = 0.75
BUBBLE_REGION = (300, 600, 0, 300)                      # y0, y1, x0, x1 (1600x900)
BADGE_BOX = (340, 420, 95, 200)
_lock = threading.Lock()
_server = [None]
LOG = [print]


# ---- pure: codes, sessions, outbox ------------------------------------------------------------------------------
def new_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")


def code_at(secret, t):
    """6-digit time code (RFC 6238 / authenticator apps: HMAC-SHA1, 30-s steps)."""
    key = base64.b32decode(secret + "=" * (-len(secret) % 8))
    mac = hmac.new(key, struct.pack(">Q", int(t // STEP)), hashlib.sha1).digest()
    o = mac[-1] & 15
    return "%06d" % ((struct.unpack(">I", mac[o:o + 4])[0] & 0x7FFFFFFF) % 1000000)


def code_ok(secret, code, t):
    code = "".join(c for c in str(code) if c.isdigit())
    return len(code) == 6 and any(hmac.compare_digest(code, code_at(secret, t - d)) for d in (0, STEP))


def seconds_left(t):
    return STEP - int(t) % STEP


def load():
    try:
        with open(STATE_FILE, encoding="utf-8") as f:
            st = json.load(f)
    except Exception:                                    # noqa: BLE001
        st = {}
    if not st.get("secret"):
        st["secret"] = new_secret()
    st.setdefault("sessions", {})
    st.setdefault("outbox", [])
    return st


def save(st):
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f)
    os.replace(tmp, STATE_FILE)


def new_session(st, t):
    tok = secrets.token_urlsafe(24)
    st["sessions"] = {k: v for k, v in st["sessions"].items() if v > t}
    st["sessions"][tok] = t + SESSION_SEC
    return tok


def session_ok(st, tok, t):
    return bool(tok) and st["sessions"].get(tok, 0) > t


def queue_message(st, text, t):
    text = " ".join(str(text).split())[:200]
    if not text:
        return None
    m = {"id": int(t * 1000), "t": t, "text": text, "status": "waiting"}
    st["outbox"] = (st["outbox"] + [m])[-30:]
    return m


def pending(st):
    return [m for m in st["outbox"] if m.get("status") == "waiting"]


def current_code(t=None):
    with _lock:
        st = load()
        save(st)
    t = time.time() if t is None else t
    return code_at(st["secret"], t), seconds_left(t)


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:                                    # noqa: BLE001
        return "127.0.0.1"


def all_ips():
    """Every IPv4 address of this PC (LAN + VPNs such as Tailscale)."""
    ips = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except Exception:                                    # noqa: BLE001
        pass
    lan = lan_ip()
    if lan not in ips and not lan.startswith("127."):
        ips.insert(0, lan)
    return ips


def is_tailscale(ip):
    """Tailscale hands out 100.64.0.0/10 addresses -- reachable from the owner's phone anywhere."""
    try:
        a, b = (int(x) for x in ip.split(".")[:2])
        return a == 100 and 64 <= b <= 127
    except ValueError:
        return False


def links(ips=None):
    """[(label, url)]: 'Away from home' for a Tailscale address, 'Home Wi-Fi' for the LAN one."""
    ips = all_ips() if ips is None else ips
    out = [("Away from home", f"http://{ip}:{PORT}") for ip in ips if is_tailscale(ip)]
    home = [ip for ip in ips if not is_tailscale(ip)]
    if home:
        out.append(("Home Wi-Fi", f"http://{home[0]}:{PORT}"))
    return out or [("This PC", f"http://127.0.0.1:{PORT}")]


def url():
    return links()[0][1]


# ---- web page ---------------------------------------------------------------------------------------------------
CSS = ("body{margin:0;background:#141414;color:#e8e8e8;font-family:system-ui,sans-serif}"
       ".w{max-width:720px;margin:0 auto;padding:14px}h1{color:#c9a84c;font-size:20px;margin:6px 0 12px}"
       "img{width:100%;border-radius:10px;background:#222}input,button{font-size:17px;border-radius:10px;"
       "border:1px solid #444;background:#222;color:#e8e8e8;padding:10px}button{background:#c9a84c;color:#141414;"
       "border:0;font-weight:600}.row{display:flex;gap:8px;margin:12px 0}.row input{flex:1;min-width:0}"
       ".dim{color:#999;font-size:13px}li{margin:4px 0}")


def page_login(msg=""):
    return (f"<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>AFSD chat"
            f"</title><style>{CSS}</style><div class=w><h1>AFSD chat</h1><p class=dim>Type the 6-digit code from "
            f"AFSD (Settings &gt; Experimental &gt; Chat relay).</p><form method=post action=/login class=row>"
            f"<input name=code inputmode=numeric autocomplete=one-time-code placeholder=123456 autofocus>"
            f"<button>Log in</button></form><p style='color:#e06060'>{html.escape(msg)}</p></div>")


PAGE_MAIN = ("<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>AFSD chat"
             "</title><style>" + CSS + "</style><div class=w><h1>AFSD chat</h1><div class=dim id=info>...</div>"
             "<p><img id=shot alt='no chat picture yet'></p><form class=row onsubmit='return send()'>"
             "<input id=msg maxlength=200 placeholder='Message to the club'><button>Send</button></form>"
             "<ul id=out class=dim></ul></div><script>"
             "var last=-1;function esc(s){var d=document.createElement('div');d.textContent=s;return d.innerHTML}"
             "function load(){fetch('/state').then(r=>{if(r.status==401){location='/';throw 0}return r.json()})"
             ".then(s=>{document.getElementById('info').textContent=s.shot_t?('Chat read '+s.shot_age+' ago'+"
             "(s.running?'':' -- the bot is STOPPED, messages wait until Start')):(s.running?'No chat picture yet.':'The bot is stopped -- press Start in AFSD.');"
             "if(s.shot_t!=last){last=s.shot_t;document.getElementById('shot').src='/shot.jpg?'+s.shot_t}"
             "document.getElementById('out').innerHTML=s.outbox.map(m=>'<li>'+esc(m.text)+' &mdash; '+esc(m.status)"
             "+'</li>').join('')}).catch(()=>{})}"
             "function send(){var i=document.getElementById('msg');if(!i.value)return false;fetch('/send',{method:"
             "'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'text='+encodeURIComponent("
             "i.value)}).then(load);i.value='';return false}load();setInterval(load,10000);</script>")

STATUS = {"job_on": lambda: False, "running": lambda: True}
SERVER_ERR = [None]     # why the page could not start (shown in Settings)


def _age(sec):
    sec = int(max(0, sec))
    return f"{sec} s" if sec < 90 else f"{sec // 60} min"


class _Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):                           # keep the console quiet
        pass

    def _tok(self):
        for part in (self.headers.get("Cookie") or "").split(";"):
            k, _, v = part.strip().partition("=")
            if k == "afsd_chat":
                return v
        return ""

    def _ok(self):
        with _lock:
            return session_ok(load(), self._tok(), time.time())

    def _send(self, code, body, ctype="text/html; charset=utf-8", extra=()):
        data = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for k, v in extra:
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = self.path.split("?")[0]
        if not self._ok():
            return self._send(401 if path != "/" else 200, page_login())
        if path == "/":
            return self._send(200, PAGE_MAIN)
        if path == "/shot.jpg":
            try:
                with open(SHOT_FILE, "rb") as f:
                    return self._send(200, f.read(), "image/jpeg")
            except OSError:
                return self._send(404, "no picture yet")
        if path == "/state":
            with _lock:
                st = load()
            shot_t = os.path.getmtime(SHOT_FILE) if os.path.exists(SHOT_FILE) else 0
            body = json.dumps({"shot_t": int(shot_t), "shot_age": _age(time.time() - shot_t) if shot_t else "",
                               "job": bool(STATUS["job_on"]()), "running": bool(STATUS["running"]()),
                               "outbox": [{"text": m["text"], "status": m["status"]} for m in st["outbox"][-8:]]})
            return self._send(200, body, "application/json")
        return self._send(404, "not found")

    def do_POST(self):
        n = min(int(self.headers.get("Content-Length") or 0), 4000)
        form = parse_qs(self.rfile.read(n).decode("utf-8", "replace"))
        path = self.path.split("?")[0]
        if path == "/login":
            t = time.time()
            _fails[:] = [f for f in _fails if t - f < 60]
            if len(_fails) >= 5:
                return self._send(429, page_login("Too many tries -- wait a minute."))
            with _lock:
                st = load()
                if code_ok(st["secret"], (form.get("code") or [""])[0], t):
                    tok = new_session(st, t)
                    save(st)
                    LOG[0]("[chat] a phone logged in to the chat page.")
                    return self._send(303, "", extra=(("Location", "/"), ("Set-Cookie",
                                      f"afsd_chat={tok}; Max-Age={SESSION_SEC}; HttpOnly; SameSite=Strict; Path=/")))
            _fails.append(t)
            return self._send(200, page_login("Wrong or old code -- try the one showing now."))
        if not self._ok():
            return self._send(401, "log in first")
        if path == "/send":
            with _lock:
                st = load()
                m = queue_message(st, (form.get("text") or [""])[0], time.time())
                save(st)
            if m:
                LOG[0](f"[chat] message queued from the phone: {m['text']!r}")
            return self._send(200, "ok", "text/plain")
        return self._send(404, "not found")


def start(log=None):
    """Start the web page (once). Returns the URL or None."""
    if log:
        LOG[0] = log
    if _server[0]:
        return url()
    try:
        srv = ThreadingHTTPServer(("0.0.0.0", PORT), _Handler)
    except OSError as e:
        LOG[0](f"[chat] could not start the chat page on port {PORT}: {e!r}")
        SERVER_ERR[0] = f"the phone page could not start (port {PORT} busy? {e.strerror or e})"
        return None
    SERVER_ERR[0] = None
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True, name="chat_relay").start()
    _server[0] = srv
    LOG[0]("[chat] chat page running at " + ", ".join(f"{a}: {u}" for a, u in links()) + " (code in Settings > Experimental).")
    return url()


def stop_server():
    srv, _server[0] = _server[0], None
    if srv:
        threading.Thread(target=srv.shutdown, daemon=True).start()


# ---- the job ----------------------------------------------------------------------------------------------------
_job = {"last_open": 0.0, "last_badge_look": 0.0, "badge": None, "pics": 0}


def find_bubble(img):
    import cv2
    tpl = cv2.imread(BUBBLE)
    if img is None or tpl is None:
        return None
    y0, y1, x0, x1 = BUBBLE_REGION
    r = cv2.matchTemplate(img[y0:y1, x0:x1], tpl, cv2.TM_CCOEFF_NORMED)
    _, best, _, loc = cv2.minMaxLoc(r)
    if best < BUBBLE_MIN:
        return None
    return (x0 + loc[0] + tpl.shape[1] // 2, y0 + loc[1] + tpl.shape[0] // 2, best)


def badge_sig(img):
    import cv2
    y0, y1, x0, x1 = BADGE_BOX
    g = cv2.cvtColor(img[y0:y1, x0:x1], cv2.COLOR_BGR2GRAY)
    return cv2.resize(g, (16, 12), interpolation=cv2.INTER_AREA).astype("int16")


def badge_changed(old, new, limit=6.0):
    return old is None or float(abs(old - new).mean()) > limit


def run(stop, log, screenshot, tap, back, close_question, close_panels, type_text=None):
    """One Chat update turn. Opens the chat only when due; returns quickly otherwise."""
    import cv2
    LOG[0] = log
    now = time.time()
    due = now - _job["last_open"] >= CHECK_SEC or (type_text is not None and bool(pending(load())))
    if not due and now - _job["last_badge_look"] < BADGE_CHECK_SEC:
        return
    img = screenshot()
    _job["last_badge_look"] = now
    hit = find_bubble(img)
    if not hit:
        if due:
            log("[chat] chat bubble not on screen (map covered?) -- trying again later.")
            _job["last_open"] = now - CHECK_SEC + 60
        return
    sig = badge_sig(img)
    if not due and not badge_changed(_job["badge"], sig):
        return
    x, y, score = hit
    log(f"[chat] opening the chat (bubble {score:.2f} at {x},{y}{'' if due else '; unread badge changed'}).")
    tap(x, y)
    try:
        _read_open_chat(stop, log, screenshot, tap, type_text)
    finally:                                              # 11/14: never leave the chat open (it blocked the bot)
        back()
        time.sleep(1.0)
        close_question()
        close_panels()
    after = screenshot()
    if after is not None and find_bubble(after) is not None:
        _job["badge"] = badge_sig(after)
    _job["last_open"] = time.time()


def _match(img, path, region):
    import cv2
    tpl = cv2.imread(path)
    if img is None or tpl is None or img.shape[0] < region[1] or img.shape[1] < region[3]:
        return 0.0
    y0, y1, x0, x1 = region
    return float(cv2.matchTemplate(img[y0:y1, x0:x1], tpl, cv2.TM_CCOEFF_NORMED).max())


def chat_is_open(img):
    return _match(img, SEND_BTN, SEND_REGION) >= 0.8


def box_is_empty(img):
    return _match(img, EMPTY_BOX, BOX_REGION) >= 0.85


def _msg_strip(img):
    import cv2
    g = cv2.cvtColor(img[200:900, 0:840], cv2.COLOR_BGR2GRAY)
    return cv2.resize(g, (84, 70), interpolation=cv2.INTER_AREA).astype("int16")


def settled(a, b, limit=1.0):
    return a is not None and b is not None and float(abs(a - b).mean()) < limit


def wait_loaded(stop, screenshot, sleep=time.sleep, max_looks=SETTLE_MAX_SEC):
    """11/14 (owner: "it didn't wait long enough"): look every second until the chat is open and its messages stop
    changing between two looks (min 3 looks), max SETTLE_MAX_SEC looks."""
    prev, shot = None, None
    for n in range(1, max_looks + 1):
        if stop():
            break
        sleep(1.0)
        shot = screenshot()
        if shot is None or not chat_is_open(shot):
            prev = None
            continue
        cur = _msg_strip(shot)
        if n >= 3 and settled(prev, cur):
            return shot, True
        prev = cur
    return shot, False


BAD_CHARS = set("'\\\"`$&|;<>()*?~#%")


def safe_text(text):
    """What adb 'input text' can type: plain ASCII only (no emoji), no shell characters."""
    out = "".join(c for c in str(text) if 32 <= ord(c) < 127 and c not in BAD_CHARS)
    return " ".join(out.split())[:200]


def send_message(text, tap, type_text, screenshot, sleep=time.sleep):
    """Type one message into the open chat and press Send. True when the box went back to empty."""
    t = safe_text(text)
    if not t:
        return False, "nothing typeable (emoji / special characters only)"
    tap(*WRITE_XY)
    sleep(1.0)
    type_text(t)
    sleep(0.8)
    tap(*SEND_XY)
    sleep(2.0)
    after = screenshot()
    if after is not None and chat_is_open(after) and box_is_empty(after):
        return True, "sent" + ("" if t == " ".join(str(text).split()) else " (emoji / odd characters left out)")
    return False, "the text box did not empty after Send"


def _read_open_chat(stop, log, screenshot, tap=None, type_text=None):
    import cv2
    shot, ok = wait_loaded(stop, screenshot)
    if shot is not None and chat_is_open(shot):
        cv2.imwrite(SHOT_FILE, shot, [cv2.IMWRITE_JPEG_QUALITY, 80])
        if _job["pics"] < 3:                               # for teaching: what the chat screen looks like
            _job["pics"] += 1
            d = os.path.join(HERE, "templates", "tests")
            os.makedirs(d, exist_ok=True)
            cv2.imwrite(os.path.join(d, time.strftime("%Y%m%d_%H%M%S") + "_chat_open.jpg"), shot,
                        [cv2.IMWRITE_JPEG_QUALITY, 70])
        log("[chat] chat picture saved for the phone page.")
        if not ok:
            log("[chat] (the chat was still changing after 12 s -- saved what was there)")
    else:
        log("[chat] the chat did not open -- nothing saved.")
        return
    with _lock:
        todo = [dict(m) for m in pending(load())]
    for m in todo:
        if stop() or tap is None or type_text is None:
            break
        sent, why = send_message(m["text"], tap, type_text, screenshot)
        log(f"[chat] {'SENT' if sent else 'could NOT send'} {m['text']!r} -- {why}")
        with _lock:
            st = load()
            for x in st["outbox"]:
                if x.get("id") == m["id"]:
                    x["status"] = "sent" if sent else "not sent: " + why
            save(st)
        if sent:
            shot2 = screenshot()
            if shot2 is not None:
                cv2.imwrite(SHOT_FILE, shot2, [cv2.IMWRITE_JPEG_QUALITY, 80])
