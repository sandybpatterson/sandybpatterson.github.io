"""One-off runner: process_all_visible() with the signature-fix in place,
to check whether the whole Orders board (now correctly reaching page 2+)
can be walked unattended. Locks the session first like every other
manual/ad-hoc script in this project should.
"""
import os
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import session_lock
if not session_lock.check_and_warn("run_process_all.py"):
    sys.exit(1)
session_lock.acquire(owner="run_process_all")

import order_fulfill as of

try:
    results = of.process_all_visible(stop_flag=None, max_items=15)
    print(f"\n=== {len(results)} item(s) processed ===")
    for i, r in enumerate(results):
        print(f"{i+1}. status={r['status']} dish={r.get('dish')} item_loc={r.get('item_loc')}")
finally:
    session_lock.release()
