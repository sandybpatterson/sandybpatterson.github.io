"""Prep work engine (10/19, owner: "I want to see it start working").

Makes the items on the Prep work list (.prep.json, saved by the Prep work tab) by fast-travel routes that start
from the clipboard (prep_route.find_route): tap a clipboard item, its "?" travels to its station; on a station
panel, tap an ingredient of one of its dishes, that "?" travels on -- until the station that makes the item.
There the clipboard bot's own tested code takes over (order_fulfill.cook_after_travel): find the card, chase a
missing ingredient, queue the batches. Same safety rules as everywhere: coins only, a gem dialog is declined.

ONE item per Prep turn, so a turn stays short and the jobs above it in the list keep their turns. Progress is
kept in .prep.json under "progress": {item: {"queued": n, "status": text, "t": when}}.
"""
import json
import os
import time

import order_fulfill as of
import prep_route
import recipe_book as rb
from order_fulfill import log

PREP_FILE = prep_route.PREP_FILE
EV = "ev:"                          # 11/13: list key of a Food Club EVENT item ("ev:Cheese Burger") -- kept by Food Club
BOARD_EMPTY_WAIT_SEC = 10 * 60      # the clipboard showed no order cards: look again after this
NO_ROUTE_RETRY_SEC = 15 * 60        # an item with no route now is tried again after this (the clipboard changes)
FAIL_RETRY_SEC = 5 * 60             # a failed trip (travel/panel/card) waits this long before the next try


def _load():
    try:
        with open(PREP_FILE, encoding="utf-8") as fh:
            order = json.load(fh)
    except (OSError, ValueError):
        return {}
    try:                                       # 10/31: an alias on the list ("cream") means the book's item (whipped_cream)
        aliases = rb.load().get("aliases", {})
        items = order.get("items") or {}
        if any(k in aliases for k in items):
            order["items"] = {aliases.get(k, k): q for k, q in items.items()}
    except Exception:                          # noqa: BLE001
        pass
    return order


def _save(order):
    tmp = PREP_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(order, fh, indent=1)
    os.replace(tmp, PREP_FILE)


def _name(key):
    if str(key).startswith(EV):
        return key[len(EV):]
    return rb.load()["items"].get(key, {}).get("name", key.replace("_", " "))


def _same(a, b):
    def k(x):
        try:
            return rb.resolve(x)
        except Exception:                            # noqa: BLE001
            return "".join(ch for ch in str(x or "").lower() if ch.isalnum())
    return bool(a and b) and k(a) == k(b)


def status_lines():
    """[(item name, qty, status)] for the Prep work tab."""
    order = _load()
    prog = order.get("progress") or {}
    return [(_name(k), q, EVENT_STATUS if str(k).startswith(EV) else (prog.get(k) or {}).get("status", "waiting"))
            for k, q in (order.get("items") or {}).items()]


EVENT_STATUS = "Food Club keeps it in stock (while Food Club is ticked)"


# --- 10/20 (owner): "total up all it needs, check stock, start with the things with the lowest times, then go up to
# stuff like beef". The list is expanded through the recipe book into everything it takes (milk for cheese and
# lattes, cabbage for milk and beef ...), stock the bot has SEEN is subtracted, and the next job is the quickest
# thing whose ingredients are already there. Stock is remembered from every station Prep opens (the white box under
# the card + the have/need counts under its ingredients) for STOCK_FRESH_SEC; older or never-seen stock counts as
# 0, and the real number is read again at the station before anything is queued.
STOCK_FRESH_SEC = 2 * 3600
CAN_DO = {"dish", "made", "animal", "crop"} | {"fruit"}          # fruit = picking (apple, lemon, coffee beans only)


def _stock_known(order, key, now=None):
    v = (order.get("stock") or {}).get(key)
    if v and (now or time.time()) - v[1] < STOCK_FRESH_SEC:
        return int(v[0])
    return None


def _remember_stock(order, key, n):
    if key and isinstance(n, int) and n >= 0:
        order.setdefault("stock", {})[key] = [n, time.time()]


def plan(order, cooking=None, now=None):
    """[(key, want_total, make, ready, blocked_by)] for everything the list needs, best first.
    want_total = how many should exist, make = how many are missing, ready = its ingredients are there."""
    items = rb.load()["items"]
    now = now or time.time()
    cooking = cooking or {}
    top = {k: int(q) for k, q in (order.get("items") or {}).items() if k in items}
    order_keys, seen = [], set()

    def visit(k):                                  # parents before ingredients
        if k in seen or k not in items:
            return
        seen.add(k)
        order_keys.append(k)
        for ing, _n in items[k]["ingredients"]:
            visit(_key(ing))
    for k in top:
        visit(k)
    depth = {k: 0 for k in order_keys}
    for _ in range(len(order_keys)):               # deepest place each item sits in the tree
        for k in order_keys:
            for ing, _n in items[k]["ingredients"]:
                ik = _key(ing)
                if ik in depth:
                    depth[ik] = max(depth[ik], depth[k] + 1)
    want = dict(top)
    make = {}
    for k in sorted(order_keys, key=lambda x: depth[x]):
        have = _stock_known(order, k, now) or 0
        m = max(0, want.get(k, 0) - have - cooking.get(k, 0))
        make[k] = m
        if m:
            batches = -(-m // max(1, items[k].get("yield", 1) or 1))
            for ing, cnt in items[k]["ingredients"]:
                ik = _key(ing)
                if ik:
                    want[ik] = want.get(ik, 0) + batches * int(cnt or 1)
    out = []
    for k in order_keys:
        if not make.get(k):
            continue
        short = [_key(ing) for ing, _n in items[k]["ingredients"] if make.get(_key(ing))]
        out.append((k, want[k], make[k], not short, short))
    # 1) look first: a station item whose stock was never seen (the visit reads it and its ingredients' counts);
    # 2) ready ones, quickest first; long ones (beef, 20 min) last
    def unseen(k):
        return items[k]["kind"] not in ("crop", "fruit") and _stock_known(order, k, now) is None
    out.sort(key=lambda t: (not unseen(t[0]), not t[3], items[t[0]].get("cook_sec") or 0, -depth[t[0]]))
    return out


def _key(name):
    return prep_route._key(name) if name else None


def _pick(order):
    """The next thing to make: (key, want_total, p), or None. Skips what is still cooking or failed a moment ago."""
    prog = order.setdefault("progress", {})
    now = time.time()
    cooking = {}
    for k, it in rb.load()["items"].items():
        try:
            c = of.in_progress(it["name"])
            if c:
                cooking[k] = c
        except Exception:                            # noqa: BLE001
            pass
    steps = plan(order, cooking, now)
    items = rb.load()["items"]
    for k, wanted, missing, ready, short in steps:
        if items[k]["kind"] not in CAN_DO or (items[k]["kind"] == "fruit" and k not in of.BUSH_INGREDIENTS):
            continue
        p = prog.setdefault(k, {"queued": 0, "status": "waiting", "t": 0})
        if p.get("wait_until", 0) > now:
            continue                                  # its batches are still cooking / growing
        wait = NO_ROUTE_RETRY_SEC if p["status"].startswith(("no route", "not trained")) else FAIL_RETRY_SEC
        if p.get("failed") and now - p.get("t", 0) < wait:
            continue
        return k, wanted, p
    return None


def _note_parents(order, steps):
    """Status of each list item that waits on an ingredient: "needs Milk first"."""
    prog = order.setdefault("progress", {})
    by = {k: short for k, _w, _m, ready, short in steps if not ready}
    for k in order.get("items") or {}:
        p = prog.setdefault(k, {"queued": 0, "status": "waiting", "t": 0})
        if k in by and not p.get("failed") and not p["status"].startswith("cooking"):
            p["status"] = "needs " + ", ".join(_name(x) for x in by[k]) + " first"
        elif k not in {s[0] for s in steps}:
            have = _stock_known(order, k)
            p.update(done=True, status=f"done (have {have})" if have is not None else "done")


def _board_slots(img):
    """[(item key or name, tap_loc)] for every readable item on the visible clipboard page."""
    out = []
    for o in of.read_orders_page(img):
        for it in o["items"]:
            if not it["name"]:
                continue
            x = o["cx"] + of.SLOT_DX[it["col"]]
            out.append((it["name"], (x, of.SLOT_ROWS[it["row"]][0])))
    return out


def _wait_panel(stop):
    for _ in range(5):
        img = of.screenshot()
        if of.panel_is_open(img):
            return img
        of.interruptible_sleep(0.7, stop)
    return None


def _hop(dish_key, ing_key, stop):
    """On the open station panel: find dish_key's card, tap its ing_key ingredient, then the '?'. True = travelled."""
    dish = of.dish_by_name(dish_key) or {"name": dish_key}
    cx, conf = of.locate_dish_card(dish["name"], stop)
    if cx is None and dish.get("card_index") is not None:     # 10/25 (Muse P12): same fallback as order_fulfill.main
        cx = of.RECIPE_CARD_X[dish["card_index"]]               # -- the Pizza Oven pictures score 0.00 every time
        log(f"[prep] hop: {_name(dish_key)} card not found by sight (best {conf:.2f}) -- using its fixed spot x={cx}.")
    if cx is None:
        log(f"[prep] hop: could not find the {_name(dish_key)} card on this station (best {conf:.2f}).")
        return False
    img = of.screenshot()
    ings = of.read_ingredients(img, cx, dish_name=dish["name"])
    spot = next(((x, y) for _c, x, y, nm in ings if _same(nm, ing_key)), None)
    if spot is None:
        log(f"[prep] hop: the {_name(dish_key)} card's ingredients read as {[nm for *_r, nm in ings]} -- "
            f"no {_name(ing_key)} among them to tap.")
        return False
    of.tap(*spot)
    of.interruptible_sleep(0.3, stop)
    img = of.screenshot()
    q, qc = of.find_question_button(img, retry=1)
    if q is None:
        no, _nc = of.find_no_button(img)
        if no is not None:
            log(f"[prep] hop: tapping {_name(ing_key)} opened a gem dialog -- declining (never gems).")
            of.tap(*no)
        else:
            log(f"[prep] hop: no '?' after tapping {_name(ing_key)} (best {qc:.2f}).")
        return False
    of.tap(*q)
    of.interruptible_sleep(1, stop)
    return True


def _fail(order, p, status, short=None):
    p.update(status=short or "retrying soon (see log)", failed=True, t=time.time())
    _save(order)
    log(f"[prep] {status}")


# 11/28 (owner): "prep work dismisses orders it isn't going to use, so a new order can reach that station".
# 11/28 later (owner: "it doesn't make stuff fast enough, mostly no route -- I don't want it to do one every 30 min"):
# on a no-route turn it dismisses EVERY order that leads nowhere useful, and does the same on each later batch. When
# none are left and the stuck dish already has all its ingredients, it also dismisses useful orders it is DONE with
# (every item they lead to is already cooking / growing), so new orders can bring a route.
CLIPBOARD_JOB = "Auto Fulfill Orders"


def _ready(o):
    items = o.get("items") or []
    return bool(items) and all(it.get("have") is not None and it.get("need") is not None and it["have"] >= it["need"]
                               for it in items)


def _names(o):
    return [it.get("name") for it in o.get("items") or [] if it.get("name")]


def pick_dismiss_all(orders, targets, route_fn, done_with=(), key_ready=False):
    """Pure: [orders to dismiss]. Never a ready order or one with no readable header.
    1) every order whose items lead to none of the Prep targets ("useless");
    2) only when there is no useless one AND key_ready: orders whose targets are all in `done_with` (already started)."""
    useless, done = [], []
    for o in orders:
        names = _names(o)
        if not names or o.get("sig") is None or _ready(o):
            continue
        hits = [t for t in targets if route_fn(t, names) is not None]
        if not hits:
            useless.append(o)
        elif all(t in done_with for t in hits):
            done.append(o)
    def doneness(o):
        its = [it for it in o.get("items") or [] if it.get("need")]
        need = sum(it["need"] for it in its) or 1
        return sum(min(it.get("have") or 0, it["need"]) for it in its) / need
    if useless:
        return sorted(useless, key=doneness)          # least done first
    return sorted(done, key=doneness) if key_ready else []


def pick_dismiss(orders, targets, route_fn):
    """Old single pick (kept for callers/tests): the first useless order, or None."""
    got = pick_dismiss_all(orders, targets, route_fn)
    return got[0] if got else None


def _dismiss_useless(app, stop, steps, orders, key=None, order=None):
    """No route this turn: dismiss every clipboard order Prep can't use (and, see above, ones it is done with)."""
    try:
        if not app.prep_dismiss_var.get():
            return 0
    except Exception:                                  # noqa: BLE001
        pass
    try:
        import job_order
        if CLIPBOARD_JOB in (job_order.ORDER or []):
            return 0                                   # the clipboard job needs its orders
    except Exception:                                  # noqa: BLE001
        pass
    targets = sorted({k for k, *_rest in steps} | {s for *_x, short in steps for s in (short or ())})
    if not targets:
        return 0
    now = time.time()
    prog = (order or {}).get("progress") or {}
    done_with = {t for t in targets if t != key and float((prog.get(t) or {}).get("wait_until") or 0) > now}
    key_ready = any(k == key and ready for k, _w, _m, ready, _s in steps)
    picks = pick_dismiss_all(orders, targets, prep_route.find_route, done_with, key_ready)
    if not picks:
        why = []
        for od in orders:
            nm = _names(od)
            hit = next((t for t in targets if prep_route.find_route(t, nm) is not None), None)
            why.append(f"{'/'.join(nm) or '?'} -> " + (f"leads to {_name(hit)}" if hit else "ready or unreadable"))
        log("[prep] no route, but no clipboard order is worth dismissing: " + "; ".join(why) + ".")
        return 0
    for o in picks:
        names = ", ".join(_names(o))
        kind = "can't use" if not any(prep_route.find_route(t, _names(o)) for t in targets) else "is done with"
        log(f"[prep] dismissing a clipboard order Prep {kind} ({names}) so a new order can open a way to "
            f"{', '.join(_name(t) for t in targets[:4])}.")
        of.DISMISS_REQUESTS.append(("prep", o["sig"], f"Prep work {kind} it ({names})"))
    of.run_dismiss_requests(stop)
    return len(picks)


def run(app, stop):
    """One Prep turn. Returns a short text for the status line."""
    _IN_RUN[0] = True
    try:
        return _run(app, stop)
    finally:
        _IN_RUN[0] = False


def _run(app, stop):
    order = _load()
    if not order.get("placed"):
        return "Prep work: no order placed (Prep work tab -> Save list)."
    if not order.get("asap") and time.time() < float(order.get("start") or 0):
        when = time.strftime("%a %I:%M %p", time.localtime(float(order["start"])))
        return f"Prep work: starts {when}."
    left = float(order.get("board_empty_until") or 0) - time.time()
    if left > 0:
        return f"Prep work: the clipboard had no orders -- next look in {int(left // 60) + 1} min."
    for k in order.get("items") or {}:
        (order.setdefault("progress", {}).get(k) or {}).pop("done", None)
    steps = plan(order)
    _note_parents(order, steps)
    _save(order)
    pick = _pick(order)
    if pick is None:
        if not steps:
            if not order.get("done"):
                order["done"] = True
                _save(order)
                log(f"[prep] ALL DONE: everything on the Prep list is in stock ({order['items']}).")
            return "Prep work: everything on the list is in stock."
        return "Prep work: waiting (things are cooking, or failed a moment ago)."
    order.pop("done", None)
    key, qty, p = pick
    for_ = [_name(k) for k, _w, _m, _r, short in steps if key in short]
    log(f"[prep] working on {_name(key)}: stock it up to {qty}" + (f" (for {', '.join(for_)})." if for_ else "."))
    try:
        app.set_status(f"Prep work: {_name(key)} (up to {qty})")
    except Exception:                                # noqa: BLE001
        pass

    of.close_any_open_panel(quiet=True)
    # 10/19 live: these "this run" memories are cleared by the clipboard job's own loop, never by Prep -- so once
    # milk was marked a dead end, Coffee Latte said "blocked on milk" for the rest of the session. Fresh each turn.
    for memo in (of._DEAD_END_INGREDIENTS, of._ALREADY_QUEUED_THIS_RUN, of._QUEUE_COUNT_THIS_RUN, of._INGR_LEARN_TRIED):
        memo.clear()
    img, view = of.open_board_smart(stop)
    if not of.read_orders_page(img):
        # 10/20: overnight 10/19-20 the clipboard showed no cards for 7 h (a panel stuck on top of it, or no orders);
        # Prep cycled through all 12 items every ~30 s, each opening the board for nothing. Now: one look, then rest.
        of.close_any_open_panel(quiet=True, thorough=True)
        order["board_empty_until"] = time.time() + BOARD_EMPTY_WAIT_SEC
        _save(order)
        log(f"[prep] the clipboard shows no orders -- Prep work waits {BOARD_EMPTY_WAIT_SEC // 60} min "
            "(it travels only through clipboard items).")
        return "Prep work: the clipboard shows no orders -- waiting 10 min."
    slots = _board_slots(img)
    seen_orders = list(of.read_orders_page(img))
    route = prep_route.find_route(key, [n for n, _ in slots])
    if route is None and not (view.get("at_start") and view.get("at_end")):
        of.swipe_to_far_end(stop) if not view.get("at_end") else of.reset_orders_scroll(stop)
        img = of.screenshot()
        seen_orders += of.read_orders_page(img)
        slots = _board_slots(img)
        route = prep_route.find_route(key, [n for n, _ in slots])
    if route is None:
        _dismiss_useless(app, stop, steps, seen_orders, key=key, order=order)
        of.tap(*of.CLOSE_X_LOC)
        _fail(order, p, f"no route to {_name(key)}: nothing on the clipboard leads to "
                        f"{prep_route.station_of(prep_route._key(key) or key) or 'its station'} right now.",
              "no route from the clipboard yet (retry in 15 min)")
        return f"Prep work: no route to {_name(key)} yet."
    log("[prep] route: " + prep_route.describe(key, route))

    start = route[0]
    loc = next(l for n, l in slots if _same(n, start[1]))
    if not of.travel_to_missing_item({"tap_loc": loc}, stop):
        of.tap(*of.CLOSE_X_LOC)
        _fail(order, p, f"{_name(key)}: tapping {_name(start[1])} on the clipboard gave no '?' -- trying again later.")
        return "Prep work: travel failed."
    for i, step in enumerate(route[1:], start=1):
        of.check_stop(stop)
        here = route[i - 1][-1]                      # the station we are standing at (the panel the hop starts from)
        if _wait_panel(stop) is None and _open_blocked(stop, here) is None:
            of.close_any_open_panel(quiet=True, thorough=True)
            _fail(order, p, f"{_name(key)}: the {here} panel did not open on the way to {step[3]}.")
            return "Prep work: a station did not open."
        if not _hop(step[1], step[2], stop):
            of.close_any_open_panel(quiet=True, thorough=True)
            _fail(order, p, f"{_name(key)}: could not hop via {_name(step[1])}'s {_name(step[2])}.")
            return "Prep work: a hop failed."

    kind = rb.load()["items"].get(key, {}).get("kind")
    if kind in ("crop", "fruit"):
        return _grow_or_pick(order, key, qty, p, kind, stop)
    target = of.dish_by_name(key)
    if target is not None and of.dish_by_name(_name(key)) is None:   # 11/16 (Muse): key ok, display name not ("Ham / Pork")
        target = None
    if target is None:
        of.close_any_open_panel(quiet=True, thorough=True)
        _fail(order, p, f"{_name(key)}: reached its station, but its card is not in the bot's dish library yet.",
              "not trained yet")
        return f"Prep work: {_name(key)} is not trained yet."
    # 10/19 (owner): arriving through ANOTHER dish's ingredient '?' opens the menu straight away, so finished
    # batches are never collected -- the stock looked empty and it made 8 more cheese with 8 waiting. Collect first.
    station = rb.load()["items"].get(key, {}).get("station")
    # 10/25 (Muse P8): at the Cow Shed the centre tap opens the Pig Pen, at the Smoothie Bar 'Expand your Land' --
    # 11 failed turns in a row, same spot each time. A station where that happened is not collected for
    # NO_COLLECT_SEC: the menu the '?' opened stays open and Prep cooks straight away.
    nc = order.setdefault("no_collect", {})
    if station and nc.get(station, 0) > time.time():
        img = _wait_panel(stop)                      # (never "a or b" on a numpy picture)
        if img is None:
            img = _open_blocked(stop, station)
    else:
        img = _collect_here(stop, station)
        if isinstance(img, str):                      # "wrong" -- never compare a numpy picture with ==
            nc[station] = time.time() + NO_COLLECT_SEC
            _save(order)
            log(f"[prep] the {station}'s centre tap lands on a neighbour -- not collecting there for "
                f"{NO_COLLECT_SEC // 3600} h (Prep will cook from the menu the '?' opens) -- even after waiting for the "
                "map to stop moving.")
            img = None
    if img is None:
        of.close_any_open_panel(quiet=True, thorough=True)
        _fail(order, p, f"{_name(key)}: the station did not open after collecting.")
        return "Prep work: the station did not open."
    cx, _conf = of.locate_dish_card(target["name"], stop)
    shot = of.screenshot()
    stock = _read_stock(shot, cx) if cx is not None else None
    cooking = of.in_progress(target["name"])
    if cx is not None:
        _remember_panel(order, key, shot, cx)
    if stock is None:
        # 10/20: the old fallback counted everything Prep had ever made as "have" -- milk used up by the Cow Shed
        # still counted as 3. Unreadable now means 0 (it reads correctly almost always since the digit reader).
        stock = 0
        log(f"[prep] {_name(key)}: stock number not readable -- counting it as 0.")
    need = qty - stock - cooking
    log(f"[prep] {_name(key)}: have {stock}, cooking {cooking}, want {qty} -> make {max(0, need)}.")
    if need <= 0:
        of.close_any_open_panel(quiet=True)
        p.update(done=True, failed=False, status=f"done (have {stock}" + (f", {cooking} cooking)" if cooking else ")"),
                 t=time.time())
        _save(order)
        return f"Prep work: {_name(key)} is stocked ({stock}/{qty})."
    before = cooking
    r = of.cook_after_travel({"tap_loc": None, "icon": None, "slot_key": None, "deficit": qty - stock}, stop,
                             dish_name=_name(key))
    st = r.get("status")
    of.close_any_open_panel(quiet=True)
    if st == "queued":
        made = max(1, of.in_progress(target["name"]) - before)
        p["queued"] = p.get("queued", 0) + made
        p.update(status=f"cooking (have {stock}, +{made + cooking} on the way, want {qty})", failed=False,
                 t=time.time(), wait_until=time.time() + min(max(60, of._cook_secs(target["name"])), 900))
        _save(order)
        log(f"[prep] {_name(key)}: queued {made}.")
        return f"Prep work: {_name(key)} -- queued {made}."
    if st in ("recursed_ingredient", "collected_blocker", "retry_next_ingredient", "learned_icon"):
        p.update(status=f"working ({st.replace('_', ' ')})", failed=False, t=time.time())
        _save(order)
        log(f"[prep] {_name(key)}: {st} -- progress made, back next turn.")
        return f"Prep work: {_name(key)} -- making an ingredient first."
    _fail(order, p, f"{_name(key)}: at its station the result was '{st}'.")
    return f"Prep work: {_name(key)} -- {st}."


def _remember_panel(order, key, img, cx):
    """Remember the stock seen on this card: its own box, and the have/need counts under its ingredients (slot order
    = the recipe book's ingredient order when the card shows that many)."""
    try:
        _remember_stock(order, key, _read_stock(img, cx))
        import event_digits
        ings = rb.load()["items"].get(key, {}).get("ingredients") or []
        slots = of.read_ingredients(img, cx, dish_name=_name(key))
        reads = [(nm, event_digits.read_count(img, x, of.INGREDIENT_TEXT_Y, save_unknown=False))
                 for _c, x, _y, nm in slots]
        reads = [(nm, r) for nm, r in reads if r]
        seen = []
        for i, (nm, r) in enumerate(reads):
            # the slot's own picture name, else the recipe's order -- only when exactly that many counts showed
            ik = _key(nm) if nm else (_key(ings[i][0]) if len(reads) == len(ings) else None)
            if ik:
                _remember_stock(order, ik, int(r["have"]))
                seen.append(f"{_name(ik)} {r['have']}")
        if seen:
            log(f"[prep] stock seen at the {_name(key)} card: " + ", ".join(seen) + ".")
    except Exception as e:                           # noqa: BLE001
        log(f"[prep] reading the ingredient counts failed (ignored): {e!r}")


def _grow_or_pick(order, key, qty, p, kind, stop):
    """Crops (carrot, cabbage ...): the route ended at the Garden Plot -- harvest what is ready and plant from stock
    (never gems). Fruit (apple, lemon, coffee beans): the route ended at the trees -- pick what is ripe."""
    have = _stock_known(order, key) or 0
    missing = max(1, qty - have)
    if kind == "crop":
        of.LAST_CROP_STOCK.clear()
        ok = of._work_crop_plots(key, stop, want=of._plants_wanted(missing), stop_at=qty)
        what = "harvested / planted" if ok else "nothing ready to harvest and nothing planted"
        seen = of.LAST_CROP_STOCK.get("n")
        if of.LAST_CROP_STOCK.get("name") == key and isinstance(seen, int):
            # 10/31: the plant bar shows the crop's real count -- remember it, so a stocked crop is DONE (was: 74 wheat turns)
            _remember_stock(order, key, seen)
            if seen >= qty:
                p.update(status=f"stocked ({seen}/{qty})", failed=False, t=time.time())
                _save(order)
                log(f"[prep] {_name(key)}: {seen} in stock, {qty} wanted -- stocked.")
                of.close_any_open_panel(quiet=True, thorough=True)
                return f"Prep work: {_name(key)} is stocked ({seen}/{qty})."
        grow = int(rb.load()["items"].get(key, {}).get("cook_sec") or 900)
    else:
        ok = of.harvest_fruit_here(key, stop, max_harvests=min(5, missing))
        what = "picked ripe fruit" if ok else "no ripe fruit in view"
        grow = 600
    of.close_any_open_panel(quiet=True, thorough=True)
    if ok:
        p.update(status=f"growing (want {qty})" if kind == "crop" else f"picked (want {qty})", failed=False,
                 t=time.time(), wait_until=time.time() + min(grow, 900))
        if kind != "crop" or not isinstance(of.LAST_CROP_STOCK.get("n"), int):
            order.setdefault("stock", {}).pop(key, None)  # changed -- read it again next time it is seen
        _save(order)
        log(f"[prep] {_name(key)}: {what}.")
        return f"Prep work: {_name(key)} -- {what}."
    rest = 0
    if kind != "crop":                                # 10/25 Picked Tree Problem: trees picked -> wait out their rest
        try:
            import picked_trees
            rest = picked_trees.resting(key)
        except Exception:                             # noqa: BLE001
            rest = 0
    if rest:
        p["wait_until"] = time.time() + rest
        _fail(order, p, f"{_name(key)}: {what} -- trees picked, next look in {rest // 60 + 1} min.",
              f"trees picked (next look in {rest // 60 + 1} min)")
        return f"Prep work: {_name(key)} -- {what}."
    _fail(order, p, f"{_name(key)}: {what}.", "nothing ready yet (retry in 5 min)")
    return f"Prep work: {_name(key)} -- {what}."


COLLECT_TAPS_MAX = 6


def _panel_title(img):
    try:
        import popup_ocr
        import re
        import run_trace
        t = (popup_ocr.read_text(img, run_trace.TITLE_REGION) or "").strip()
        return re.sub(r"(\d+[hms]\s*)+$", "", t).strip()
    except Exception:                                # noqa: BLE001
        return ""


def _is_other_panel(img, station):
    """10/20 live: a centre tap next to the Smoothie Bar hit the land-expansion sign and opened 'Expand your Land'
    (gem buttons!) -- Prep took it for the station. True when the open panel's title clearly is not `station`."""
    import re
    title = _panel_title(img)
    if not title or not station:
        return False
    words = lambda s: {w for w in re.findall(r"[a-z]+", s.lower()) if len(w) > 2}      # noqa: E731
    if "expand" in title.lower():
        return True
    if words(title) & words(station):
        return False
    import difflib                                   # OCR slips ("Dairu" for Dairy) must not count as another panel
    return difflib.SequenceMatcher(None, title.lower(), station.lower()).ratio() < 0.5


NO_COLLECT_SEC = 6 * 3600                  # backup only -- the real fix is _wait_still (owner 10/25)
STILL_DIFF = 2.0                           # mean pixel change between two looks below this = the map has stopped
STILL_MAX_SEC = 4.0


def _wait_still(stop, first=None):
    """Owner 10/25: "the map is literally still moving when the tap happens" (Cow Shed tap opened the Pig Pen).
    Look until two screenshots in a row match (map done gliding), max STILL_MAX_SEC. Returns the last picture."""
    import numpy as np
    prev = first if first is not None else of.screenshot()
    t0 = time.time()
    while time.time() - t0 < STILL_MAX_SEC:
        of.interruptible_sleep(0.3, stop)
        cur = of.screenshot()
        try:
            d = float(np.abs(cur[90:, :].astype(np.int16) - prev[90:, :].astype(np.int16)).mean())
        except Exception:                            # noqa: BLE001 -- odd picture: just tap
            return cur
        if d < STILL_DIFF:
            return cur
        prev = cur
    log(f"[prep] the map was still moving after {STILL_MAX_SEC:.0f} s -- tapping anyway.")
    return prev


def _open_blocked(stop, station):
    """10/27 (Muse 15:05: "station did not open" in every Prep cycle): the '?' landed on the station but its menu did not
    open -- a finished batch sitting on it blocks the menu (milk at the Cow Shed, a coffee at Barista Coffee). The
    clipboard bot collects it with centre taps; Prep used to give up. Same taps here (with _collect_here's guards: wait
    for the map to stop, other panel -> red X, popup -> stop). -> panel screenshot or None."""
    log(f"[prep] the {station or 'station'} menu did not open -- probably a finished batch on it; collecting it.")
    img = _collect_here(stop, station, close_first=False)
    return img if not isinstance(img, str) else None


STATION_PICS = {"Cow Shed": ("cow_shed.png", (200, 180))}   # 10/31: picture + tap point inside it (the barn doors)
STATION_PIC_MIN = 0.7


def _station_spot(img, station):
    """10/31 (owner: the centre tap opens the Pig Pen): where the station's own picture is on screen, or None (then the
    old centre tap). Only stations with a cut picture in templates/station_pics."""
    try:
        import cv2
        name, (dx, dy) = STATION_PICS.get(station or "", (None, (0, 0)))
        if not name or img is None:
            return None
        tpl = cv2.imread(os.path.join(of.BASE_DIR, "templates", "station_pics", name), cv2.IMREAD_GRAYSCALE)
        if tpl is None:
            return None
        r = cv2.matchTemplate(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), tpl, cv2.TM_CCOEFF_NORMED)
        _, m, _, (x, y) = cv2.minMaxLoc(r)
        return (x + dx, y + dy) if m >= STATION_PIC_MIN else None
    except Exception:                                # noqa: BLE001
        return None


def _collect_here(stop, station=None, close_first=True):
    """Close the station menu and tap the station (quick-travel centred it) until its menu opens again: every tap
    that does NOT open the menu collected a finished batch. Returns the panel screenshot, or None.
    10/19 live: at the Cow Shed the menu never reopened and 12 blind centre taps hit the hot-dog ad mascot (a
    "Special Reward" popup). Now: at most COLLECT_TAPS_MAX taps, and the moment the map is dimmed by anything
    that is not the station menu (a popup), stop, keep a picture, close it with its red X -- never its buttons."""
    import event_orders as eo
    if close_first:
        of.tap(*of.CLOSE_X_LOC)
        of.interruptible_sleep(1.0, stop)
    collected = 0
    for _ in range(COLLECT_TAPS_MAX):
        of.check_stop(stop)
        _wait_still(stop)                            # 10/25: never tap while the camera is still gliding
        of.tap(*(_station_spot(of.screenshot(), station) or of.SCREEN_CENTER))
        of.interruptible_sleep(1.2, stop)
        img = of.screenshot()
        if of.panel_is_open(img):
            if _is_other_panel(img, station):
                log(f"[prep] a tap next to the station opened '{_panel_title(img)}' instead of the {station} -- "
                    "closing it with its red X (never its buttons) and trying again later.")
                of.close_any_open_panel(quiet=True, thorough=True)
                return "wrong"
            if collected:
                log(f"[prep] collected {collected} finished batch(es) sitting on the station.")
            return img
        if not eo.hud_is_bright(img):
            log("[prep] a tap on the station opened something else (popup) -- stopping, closing it with its X "
                "(picture saved).")
            try:
                eo.save_unknown_screen(img)
            except Exception:                        # noqa: BLE001
                pass
            of.close_any_open_panel(quiet=True, thorough=True)
            return None
        collected += 1
    log(f"[prep] tapped the station {COLLECT_TAPS_MAX} times and its menu never opened -- giving up here.")
    return None


_stock_pics = 0


def _save_stock_pic(img, cx, txt):
    """10/19: the stock read failed every time live -- keep a few pictures (card + stock box) to fix the spot."""
    global _stock_pics
    if _stock_pics >= 4:
        return
    _stock_pics += 1
    try:
        import cv2
        d = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "count_unknown")
        os.makedirs(d, exist_ok=True)
        cv2.imwrite(os.path.join(d, f"prepstock_{int(time.time())}_cx{cx}.png"), img)
        log(f"[prep] stock box read as {txt!r} -- full screen saved to templates/count_unknown/ (card at x={cx}).")
    except Exception:                                # noqa: BLE001
        pass


def _read_stock(img, cx):
    """The white stock box under a recipe card. 10/20: the game's own digit shapes first (stock_digits, 640/643 on
    saved panels) -- Windows OCR returned '' for a lone digit on every live read 10/19; OCR stays as a backup."""
    try:
        import stock_digits
        n = stock_digits.read_stock(img, cx)
        if n is not None:
            return n
    except Exception:                                # noqa: BLE001
        pass
    try:
        import re
        import cv2
        import popup_ocr
        box = img[405:465, cx + 86:cx + 136]
        big = cv2.copyMakeBorder(cv2.resize(box, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC),
                                 20, 20, 20, 20, cv2.BORDER_CONSTANT, value=(255, 255, 255))
        txt = popup_ocr.read_text(big)
        m = re.fullmatch(r"\s*(\d{1,3})\s*", txt.replace("O", "0").replace("o", "0"))
        if m:
            return int(m.group(1))
        _save_stock_pic(img, cx, txt)
        return None
    except Exception:                                # noqa: BLE001
        return None


# --- 11/13 (owner): "check each time ... if the bot is making that for another dish don't make just one, make 5".
# Any job that opens a card in the Prep tree reads its stock (seen_card); any job that queues a dish takes its
# ingredients off the remembered stock (used -- owner's pick: re-check only what was just used up); a job cooking a
# Prep-tree item for something else cooks enough to also reach the Prep amount (topup). Prep's own turns skip these
# (they already read and plan). Only while a Prep list is placed and the Prep work job is ticked.
_IN_RUN = [False]
TOPUP_MAX = 5                       # most batches one visit queues for a top-up


def _active_order():
    if _IN_RUN[0]:
        return None
    try:
        import job_order
        if "Prep work" not in (job_order.ORDER or []):
            return None
    except Exception:                                # noqa: BLE001
        return None
    order = _load()
    return order if order.get("placed") and order.get("items") else None


def _tree(order):
    """{key: want_total} for every book item the Prep list needs (the list and its ingredients, all levels)."""
    items = rb.load()["items"]
    want, stack = {}, [(k, int(q)) for k, q in (order.get("items") or {}).items() if k in items]
    while stack:
        k, q = stack.pop()
        want[k] = want.get(k, 0) + q
        for ing, cnt in items[k]["ingredients"]:
            ik = _key(ing)
            if ik in items and len(want) < 200:
                stack.append((ik, q * int(cnt or 1)))
    return want


def seen_card(dish_name, img, cx):
    """Another job located this dish's card: remember its stock + its ingredients' counts when Prep needs it."""
    try:
        order = _active_order()
        k = _key(dish_name)
        if order is None or img is None or k not in _tree(order):
            return
        _remember_panel(order, k, img, cx)
        _save(order)
    except Exception as e:                           # noqa: BLE001
        log(f"[prep] stock check at '{dish_name}' skipped: {e!r}")


def used(dish_name, batches):
    """`batches` of this dish were queued by any job: its ingredients left storage -- lower what Prep remembers."""
    try:
        order = _active_order()
        k = _key(dish_name)
        items = rb.load()["items"]
        if order is None or k not in items:
            return
        tree, now, low = _tree(order), time.time(), []
        for ing, cnt in items[k]["ingredients"]:
            ik = _key(ing)
            have = _stock_known(order, ik, now)
            if ik in tree and have is not None:
                left = max(0, have - int(cnt or 1) * max(1, int(batches)))
                order["stock"][ik] = [left, now]
                low.append(f"{_name(ik)} {have} -> {left}")
        if low:
            _save(order)
            log(f"[prep] '{_name(k)}' was queued -- its ingredients left storage: " + ", ".join(low)
                + " (checked again at the next visit).")
    except Exception as e:                           # noqa: BLE001
        log(f"[prep] stock update after '{dish_name}' skipped: {e!r}")


def topup_need(want, have, cooking, deficit):
    """Pure: batches to queue = what the other job wants + what Prep is still short of, 1..TOPUP_MAX."""
    d = max(1, int(deficit or 1))
    short = max(0, int(want) - int(have or 0) - int(cooking or 0))
    return max(1, min(TOPUP_MAX, d + short))


def topup(dish_name, deficit):
    """How many batches to queue when a job cooks `dish_name` (None = no Prep top-up, keep the job's own number)."""
    try:
        order = _active_order()
        k = _key(dish_name)
        if order is None:
            return None
        want = _tree(order).get(k)
        if not want:
            return None
        n = topup_need(want, _stock_known(order, k) or 0, of.in_progress(dish_name), deficit)
        if n > max(1, int(deficit or 1)):
            log(f"[prep] '{_name(k)}' is on the Prep list (keep {want}) -- cooking {n} batch(es) instead of "
                f"{max(1, int(deficit or 1))}.")
        return n
    except Exception as e:                           # noqa: BLE001
        log(f"[prep] top-up for '{dish_name}' skipped: {e!r}")
        return None


def event_targets():
    """{event item name: keep} for the "ev:" lines on a placed Prep list (Food Club prestock reads this)."""
    try:
        order = _load()
        if not order.get("placed"):
            return {}
        return {k[len(EV):]: int(q) for k, q in (order.get("items") or {}).items()
                if str(k).startswith(EV) and int(q) > 0}
    except Exception:                                # noqa: BLE001
        return {}
