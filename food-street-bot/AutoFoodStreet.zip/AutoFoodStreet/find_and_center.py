"""Reusable navigation routine: locate a target (via multi-scale template
match), then iteratively pan so it's centered on screen, then zoom in for
a final precise fix. This replaces the old "extrapolate an offset across
whatever zoom level we happened to land at" approach, which drifted badly
at extreme zoom levels (confirmed during testing — it landed on nearby
decorations and even a gem-spend Unlock button instead of the intended
target). Centering-then-zooming means the final tap coordinate always
comes from a fresh, high-confidence, near-center detection instead of
extrapolated math.

Heavily logged per the user's request, since this is exactly the part
that needs to be trustworthy before anything gets scheduled unattended.
"""
import os
import sys
import time
import datetime
import math
import re
import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
from adb_helper import screenshot, tap, swipe, pinch
import world_map

CLOSE_X_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "close_x.png"))
CLOSE_X_LOC = (1541, 124)  # fixed screen-space position, same for every panel

SECOND_DEVICE_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "second_device_dialog.png"))
SECOND_DEVICE_OK_LOC = (797, 728)  # fixed screen-space position

BUY_MISSING_TEMPLATE = cv2.imread(os.path.join(BASE_DIR, "templates", "buy_missing_dialog.png"))
BUY_MISSING_NO_LOC = (630, 520)  # fixed screen-space position — the "No" button

LOG = os.path.join(BASE_DIR, "run_log.txt")
SCREEN_CENTER = (800, 450)
CENTER_TOLERANCE = 60       # px — close enough to "centered"
MAX_CENTER_HOPS = 8

# Fixed HUD zones where a real world-space station can never actually be —
# confirmed 9/23: a Dairy false positive landed at (1532,124)/(1412,175),
# right where fixed event-countdown badges and the top icon bar live.
# A genuine match there is implausible and should be rejected rather than
# trusted, since this is exactly the kind of wrong-but-just-above-threshold
# match that led to accidentally opening the "Expand your Land" panel.
HUD_EXCLUSION_ZONES = [
    (0, 0, 1600, 70),      # top icon/resource bar
    (1400, 70, 1600, 320),  # top-right event-countdown badge cluster
]


def in_hud_zone(loc):
    x, y = loc
    return any(x1 <= x <= x2 and y1 <= y <= y2 for (x1, y1, x2, y2) in HUD_EXCLUSION_ZONES)
HOP_CAP_PX = 170            # controlled drag distance, avoids fling
MAX_SEARCH_STEPS = 40
SEARCH_HOP_PX = 160
PROBE_THRESHOLD = 0.3  # Tried raising to 0.42 on 9/23 after a false-positive probe
                        # (a boardwalk/grill scene scored 0.34-0.42 against the Pig
                        # Pen template) — but that broke Dairy entirely: its genuine
                        # signal typically sits at 0.33-0.39, so at 0.42 a real run
                        # went through all 40 steps with ZERO probes and failed
                        # outright (146s wasted, target was very likely there the
                        # whole time). Reverted to 0.3. The right mental model: a
                        # false-positive probe just costs ~8-10s (the zoom-in
                        # confirmation step already prevents any wrong action from
                        # it) — that's far cheaper than missing a real target and
                        # failing the whole search. Don't raise this again without
                        # a smarter discriminator (e.g. requiring the zoomed-in
                        # confidence to *improve* by some margin, not just testing
                        # the raw initial confidence) — see the confidence-jump
                        # idea in the "ideas for improvement" section below.


class StopRequested(Exception):
    """Raised to unwind out of a search/centering/zoom loop immediately
    when the user hits Stop, instead of waiting for the current find_fn
    call (which can legitimately take 60-140s) to finish on its own."""
    pass


def check_stop(stop_flag):
    if stop_flag is not None and stop_flag.is_set():
        raise StopRequested()


def interruptible_sleep(seconds, stop_flag):
    """time.sleep that wakes up early (in <=0.1s granularity) if Stop is
    requested mid-wait, instead of blocking the full duration regardless."""
    end = time.time() + seconds
    t0 = time.time()
    try:
        while time.time() < end:
            check_stop(stop_flag)
            time.sleep(min(0.1, max(0.0, end - time.time())))
        check_stop(stop_flag)
    finally:
        _note_sleep(time.time() - t0)


SLEEPS = {}                     # 11/1 FLASH step 3 (log-only): "module:line" -> [count, seconds] of fixed pauses


def _note_sleep(secs):
    try:
        f = sys._getframe(2)
        key = f"{os.path.basename(f.f_code.co_filename)[:-3]}:{f.f_lineno}"
        v = SLEEPS.setdefault(key, [0, 0.0])
        v[0] += 1
        v[1] += secs
    except Exception:                                   # noqa: BLE001
        pass


def log(msg):
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    with open(LOG, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{ts}] {msg}\n")
    try:
        print(f"[{ts}] {msg}")
    except (AttributeError, OSError):
        pass  # no console attached (e.g. launched via pythonw.exe) — log file still gets it


def frame_diff(before, after):
    """Downsampled grayscale mean absolute difference between two frames —
    cheap and fast. Empirically: a real pan/zoom scores 50+, a boundary/
    zoom-limit no-op scores ~2-4 (just animation noise: water shimmer,
    swaying trees, floating ready-icons)."""
    a = cv2.cvtColor(cv2.resize(before, (160, 90)), cv2.COLOR_BGR2GRAY).astype(np.float32)
    b = cv2.cvtColor(cv2.resize(after, (160, 90)), cv2.COLOR_BGR2GRAY).astype(np.float32)
    return float(np.mean(np.abs(a - b)))


def frame_changed(before, after, threshold=3.0):
    """Cheap check for whether a swipe actually moved the camera, or hit
    a hard map boundary and did nothing."""
    return frame_diff(before, after) > threshold


def second_device_region_ok(region):
    """Pure: the dialog has text on a light box -- a near-black or flat region (loading / dead screen) cannot be it."""
    try:
        g = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY) if region.ndim == 3 else region
        return float(g.mean()) > 40 and float(g.std()) > 12
    except Exception:                                  # noqa: BLE001
        return False


def dismiss_second_device_dialog(img=None):
    """The 'your game is open on a second device' dialog — a centered
    modal with no close-X, so close_any_open_panel() doesn't catch it.
    Explicitly confirmed safe to auto-dismiss by the user (9/23): unlike
    the gem-spend dialogs, always tap OK here. This dialog fully blocks
    all touch input (confirmed: even a zoom-out pinch registered 0 frame
    diff while it was up), which looks identical to "stuck in a map
    corner" if you don't check for it specifically — cost real debugging
    time before being identified. Returns True if it was found and
    dismissed."""
    if img is None:
        img = screenshot()
    region = img[330:460, 590:1000]
    if not second_device_region_ok(region):
        return False                             # 11/17: a black / flat loading screen scored 1.00 here
    res = cv2.matchTemplate(region, SECOND_DEVICE_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    if max_val < 0.75:
        return False
    log(f"Second-device session dialog detected (confidence {max_val:.2f}) "
        "— dismissing (user confirmed always safe to auto-tap OK here).")
    tap(*SECOND_DEVICE_OK_LOC)
    time.sleep(1)
    return True


ERROR_WHOOPS_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                          "templates", "error_whoops_dialog.png")
ERROR_WHOOPS_OK_LOC = (800, 730)
OUT_OF_CROP_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                        "templates", "out_of_crop_dialog.png")
COLLECT_FINISHED_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                             "templates", "collect_finished_dialog.png")
COLLECT_FINISHED_OK_LOC = (800, 692)        # the green OK of "Please collect finished items on <station> before you can produce more"
OUT_OF_CROP_NO_LOC = (630, 580)      # grey No; Yes (1 gem) is the green button at ~(968,580)
GREAT_BUTTON_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                          "templates", "great_button.png")
EVENT_BADGE_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                         "templates", "event_badge_dialog.png")
EVENT_BADGE_OK_LOC = (800, 727)      # the green "Great!" button
NOT_ENOUGH_TOKENS_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                              "templates", "not_enough_tokens_dialog.png")
NOT_ENOUGH_TOKENS_OK_LOC = (575, 830)    # green OK (the blue "Get more tokens" is at ~(1025,830))
DISCARD_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                     "templates", "discard_order_dialog.png")
DISCARD_NO_LOC = (630, 520)          # the grey "No" (Yes is the green button at ~(968,520))
PRIZE_TENT_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                       "templates", "prize_tent_title.png")
PRIZE_TENT_CLOSE_LOC = (1540, 130)   # the red X (standard close template matched here at 0.994)
MYSTERY_BOX_TAP_LOC = (800, 400)     # middle of the closed box
COLLECT_REWARD_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                           "templates", "collect_reward_button.png")
ANR_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "templates", "android_anr_rows.png")
# template = the "Close app" + "Wait" rows; the "Wait" centre sits at this
# offset from the match's top-left (Wait was at (528,543), template origin (410,440)).
ANR_WAIT_OFFSET = (118, 103)


def match_multiscale(region, tpl, scales=(0.9, 1.0, 1.1, 1.15, 1.2, 1.3)):
    """cv2.matchTemplate at several template sizes, with SEPARATE width and height
    scales. Returns (best_score, (cx, cy) centre of the best match inside `region`,
    (fx, fy)). Some popups reuse the same button art at another size: the "Milestone
    Reached!" Collect Reward button is ~1.13x wider and ~1.2x taller than the mystery-box
    one (a fixed-size match scored 0.56, uniform scaling 0.72)."""
    best = (-1.0, (0, 0), (1.0, 1.0))
    for fx in scales:
        for fy in scales:
            t = cv2.resize(tpl, None, fx=fx, fy=fy, interpolation=cv2.INTER_CUBIC)
            if t.shape[0] > region.shape[0] or t.shape[1] > region.shape[1]:
                continue
            r = cv2.matchTemplate(region, t, cv2.TM_CCOEFF_NORMED)
            _, v, _, l = cv2.minMaxLoc(r)
            if v > best[0]:
                best = (float(v), (l[0] + t.shape[1] // 2, l[1] + t.shape[0] // 2), (fx, fy))
    return best


def reward_button_loc(img):
    """The 'Collect Reward' screens (mystery-box reward, 'Milestone Reached!' ...). The
    button art/size varies between them (a fixed image match failed on the bigger
    'Milestone Reached!' variant, 10/2), so detect STRUCTURE instead: a dimmed screen
    (nav clipboard p90 < 120) + an opened gift box (>= 20000 strongly saturated non-lime pixels
    in the middle) + a lime button 250-420 px wide centred under it. The 'Great!' popups
    have a lime button but no box. Returns the button centre (x, y) or None."""
    nav = cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2]
    if float(np.percentile(nav, 90)) >= 120:
        return None
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mid = hsv[380:700, 560:1040]
    h, sat, v = mid[:, :, 0], mid[:, :, 1], mid[:, :, 2]
    # box colour varies per reward (red, orange, teal...): count ANY strongly saturated,
    # bright pixel that is not the lime button hue
    box = (sat > 170) & (v > 120) & ~((h >= 35) & (h <= 60))
    if int(box.sum()) < 20000:
        return None
    lime = cv2.inRange(hsv[690:850, 500:1100], (35, 150, 140), (60, 255, 255))
    lime = cv2.morphologyEx(lime, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(lime)
    best = None
    for i in range(1, n):
        w, hh = int(st[i][2]), int(st[i][3])
        cx = int(cen[i][0]) + 500
        if 250 <= w <= 420 and 50 <= hh <= 110 and abs(cx - 800) <= 120:
            if best is None or w * hh > best[2]:
                best = (cx, int(cen[i][1]) + 690, w * hh)
    return (best[0], best[1]) if best else None


LEVELUP_SAFE_WORDS = {"collect", "claim", "ok", "great", "continue", "awesome", "yay", "thanks", "next"}
LEVELUP_UNSAFE_WORDS = ("watch", "double", "buy", "purchase", "gem", "skip", "upgrade", "install")
_LEVELUP_LAST = [0.0]                                  # OCR costs 1-3 s: at most one look per minute


def _levelup_candidate(img):
    """pass 84: cheap structural test -- dimmed screen + exactly one lime button in the lower middle. Returns (cx, cy) or None."""
    if img is None or img.shape[:2] != (900, 1600):
        return None
    nav = cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2]
    if float(np.percentile(nav, 90)) >= 120:
        return None
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    x0, y0, x1, y1 = 400, 540, 1200, 880
    lime = cv2.inRange(hsv[y0:y1, x0:x1], (35, 150, 140), (60, 255, 255))
    lime = cv2.morphologyEx(lime, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(lime)
    found = []
    for i in range(1, n):
        w, hh = int(st[i][2]), int(st[i][3])
        if 120 <= w <= 560 and 45 <= hh <= 140:                          # pass 86: the real button is ~57% of the dialog width
            found.append((int(cen[i][0]) + x0, int(cen[i][1]) + y0))
    return found[0] if len(found) == 1 else None


LEVELUP_FUZZY_WORDS = ("collect", "claim", "continue", "awesome", "thanks", "rewards", "reward")


def _levelup_label_ok(tokens):
    """pass 86: a safe button label. Short words must match exactly; long ones may be one OCR letter off."""
    import difflib
    if tokens & LEVELUP_SAFE_WORDS:
        return True
    for t in tokens:
        if len(t) >= 5 and any(difflib.SequenceMatcher(None, t, w).ratio() >= 0.75 for w in LEVELUP_FUZZY_WORDS):
            return True
    return False


def level_up_button_loc(img, ocr=None, save=None):
    """pass 84: the one button to tap on a level-up rewards screen, or None (never guesses)."""
    cand = _levelup_candidate(img)
    if cand is None:
        return None
    if time.time() - _LEVELUP_LAST[0] < 60:
        return None
    _LEVELUP_LAST[0] = time.time()
    try:
        if ocr is None:
            import popup_ocr
            ocr = popup_ocr.read_text
        text = (ocr(img, None) or "").lower()
        if "level" not in text:
            return None
        x, y = cand
        label = (ocr(img, (max(0, x - 170), max(0, y - 50), min(1600, x + 170), min(900, y + 50))) or "").lower()
        import re
        tokens = set(re.findall(r"[a-z]+", label.replace("0", "o")))
        bad = (any(w in text for w in LEVELUP_UNSAFE_WORDS if w != "gem") or "$" in text          # pass 85: a reward LIST may mention gems
               or any(w in label for w in LEVELUP_UNSAFE_WORDS))                               # ...but the button label may not
        if _levelup_label_ok(tokens) and not bad:
            return cand
        if save is not None:
            save("levelup_unsure")
        return None
    except Exception:                                  # noqa: BLE001
        return None


def is_mystery_box_screen(img):
    """The closed gift-box reveal, ANY box colour (red, teal... -- the teal one stalled the bot
    ~60 cycles overnight 10/2 because only red was known). The box bobs/spins so an image
    match only scores ~0.5; the signature is: a large mass of strongly saturated non-lime
    pixels (38k-54k) centred at x~800, a dimmed nav bar (clipboard p90 < 100; the open
    board reads 110), NO lime button (the opened box / 'Collect Reward' screen has one) and
    no pale-blue dialog panel (rules out dialogs such as 'Upgrade Event Recipe')."""
    reg = img[100:640, 520:1100]
    hsv = cv2.cvtColor(reg, cv2.COLOR_BGR2HSV)
    h, sat, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
    mass = (sat > 170) & (v > 120) & ~((h >= 35) & (h <= 60))
    area = int(mass.sum())
    if not (25000 <= area <= 58000):
        return False
    if abs(int(np.nonzero(mass)[1].mean()) + 520 - 800) > 90:
        return False
    nav = cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2]
    if float(np.percentile(nav, 90)) >= 100:
        return False
    lime = cv2.inRange(cv2.cvtColor(img[650:790, 560:1040], cv2.COLOR_BGR2HSV), (35, 150, 140), (60, 255, 255))
    if int(lime.sum() // 255) >= 3000:
        return False
    pale_blue = (h >= 95) & (h <= 118) & (sat >= 30) & (sat <= 130) & (v > 200)
    if int(pale_blue.sum()) >= 8000:
        return False
    # 10/17: the street Food Truck panel (burger slot selected) passed every test above and the
    # bot tapped "the box" -- a truck slot. A reveal has no close X; panels do.
    xs = cv2.matchTemplate(img[50:250, 1150:1580], CLOSE_X_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    return float(xs.max()) < 0.8


def _tpl(name):
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", name)
    return cv2.imread(path)


def _best(region, name):
    t = _tpl(name)
    if t is None or region.shape[0] < t.shape[0] or region.shape[1] < t.shape[1]:
        return 0.0, (0, 0)
    r = cv2.matchTemplate(region, t, cv2.TM_CCOEFF_NORMED)
    _, v, _, l = cv2.minMaxLoc(r)
    return float(v), (l[0] + t.shape[1] // 2, l[1] + t.shape[0] // 2)


def _focused_window():
    """The focused Android window text (package/activity), '' when it cannot be read."""
    try:
        import adb_helper
        r = adb_helper._run(["shell", "dumpsys window | grep mCurrentFocus"])
        return (r.stdout or b"").decode("utf-8", "ignore")
    except Exception:                                  # noqa: BLE001
        return ""


_LAUNCHER_AD_X = cv2.imread(os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "launcher_ad_x.png"), 0)


def launcher_ad_x_loc(img):
    """The small light X in the top-right corner of an LDPlayer launcher ad poster (seen live 10/5: a big
    poster for another game over the Android home screen). Matched as a WHITE-STROKE SHAPE (the box behind
    it is a translucent dark square whose colour follows the poster art), only in the corner zone where such
    posters put it. Returns the X's centre or None. Callers must ALSO confirm the Android launcher is the
    focused window before tapping (see dismiss_error_dialog)."""
    if _LAUNCHER_AD_X is None:
        return None
    gray = cv2.cvtColor(img[100:300, 1050:1450], cv2.COLOR_BGR2GRAY)
    zone = ((gray > 150) * 255).astype(np.uint8)
    res = cv2.matchTemplate(zone, _LAUNCHER_AD_X, cv2.TM_CCOEFF_NORMED)
    _, v, _, l = cv2.minMaxLoc(res)
    if v < 0.7:
        return None
    x, y = 1050 + l[0] + _LAUNCHER_AD_X.shape[1] // 2, 100 + l[1] + _LAUNCHER_AD_X.shape[0] // 2
    # the X sits on a DARK translucent square: the ring just outside the glyph must be dark
    ring = gray[max(0, y - 100 - 18):y - 100 + 18, max(0, x - 1050 - 18):x - 1050 + 18]
    return (x, y) if ring.size and float(np.median(ring)) < 130 else None


def is_android_home(img):
    """The emulator's Android launcher ("Search games" bar at the top, an app grid). Reached when
    the game crashed / the emulator restarted (seen live 10/3 14:54). NOT the game: no HUD."""
    v, _ = _best(img[40:130, 480:1120], "launcher_search_bar.png")
    return v >= 0.85


def food_street_icon_loc(img):
    """Centre of the Food Street icon on the launcher, or None. ONLY this icon is ever tapped:
    the rest of the launcher is ads / other games / the store."""
    v, (x, y) = _best(img[150:330, 440:760], "launcher_food_street_icon.png")
    return (440 + x, 150 + y) if v >= 0.85 else None


def is_tablet_starting(img):
    """Black "Tablet is starting..." boot screen: just wait."""
    if float(img[300:600, 300:1300].mean()) > 90:
        return False
    v, _ = _best(img[330:580, 520:1080], "tablet_starting_text.png")
    return v >= 0.8


def is_game_splash(img):
    """The Food Street loading screen (logo + progress bar, rotating tip text): just wait."""
    v, _ = _best(img[300:640, 520:1120], "game_splash_logo.png")
    return v >= 0.8


def ribbon_button_loc(img):
    """"Thank you! Rewards: ..." popup -> centre of its [Collect Rewards] button, else None.
    Matched by TEMPLATES of the title ribbon AND the button label, both required. (A first
    colour-only version also matched the Premium Pass popup's $12.99 purchase button -- never
    use a generic "one lime button" rule for tapping.)"""
    vt, _ = _best(img[130:320, 440:1160], "thankyou_title.png")
    if vt < 0.8:
        return None
    vb, (x, y) = _best(img[620:780, 560:1040], "thankyou_collect_btn.png")
    return (560 + x, 620 + y) if vb >= 0.8 else None


_last_popup_save = {}
STORAGE_FULL_TIMES = []        # when the 'Food Club Storage is full' popup was closed (pass 8)


def storage_full_dialog_x(img):
    """"Your Food Club Storage is full! Get more space by upgrading the Food Club Storage
    [Upgrade Now!]" popup (seen live 10/4 over an Oz Stove panel; it made close_any_open_panel
    tap the stove panel's own X forever). Returns the dialog's red X (the ONLY safe tap -- never
    Upgrade Now) or None. Matched by the message text template, X found by the close-X template."""
    v, _ = _best(img[380:620, 540:1060], "storage_full_dialog.png")
    if v < 0.85:
        return None
    x_tpl = _tpl("close_x.png")
    region = img[120:260, 940:1110]
    if x_tpl is not None and region.shape[0] >= x_tpl.shape[0] and region.shape[1] >= x_tpl.shape[1]:
        r = cv2.matchTemplate(region, x_tpl, cv2.TM_CCOEFF_NORMED)
        _, mv, _, ml = cv2.minMaxLoc(r)
        if mv >= 0.7:
            return (940 + ml[0] + x_tpl.shape[1] // 2, 120 + ml[1] + x_tpl.shape[0] // 2)
    return (1033, 185)


PANTRY_FULL_X = (1033, 185)
UNABLE_TIMES = []                          # 10/31: when 'Unable to connect to server' was closed
PANTRY_FULL_AT = [0.0]                      # 10/25: last time the "Your Pantry is full!" popup was closed
PANTRY_FULL_HOLD_SEC = 10 * 60


RELIEF_TRIED_AT = [0.0]                     # 10/29: last time pantry relief started (afsd_core._pantry_relief)


def pantry_relief_wanted():
    """10/29 (owner: the full message "should actually stop the bot and go straight to storage relief"): the Pantry-full
    popup came AFTER the last relief attempt -> stop the current job and let relief run now."""
    return pantry_full_recent() and PANTRY_FULL_AT[0] > RELIEF_TRIED_AT[0]


def pantry_full_recent(sec=PANTRY_FULL_HOLD_SEC):
    """True while the Pantry was reported full in the last `sec` seconds (harvests then only bring the popup back)."""
    return time.time() - PANTRY_FULL_AT[0] < sec


def pantry_full_dialog_x(img):
    """10/25 (owner's screenshot): "Your Pantry is full! Get more space by upgrading the Pantry [Upgrade Now!]" --
    same box and red X as the Food Club one, different words. Returns the red X or None."""
    if img is None or img.shape[:2] != (900, 1600):
        return None
    v, _ = _best(img[400:510, 620:980], "pantry_full_dialog.png")
    return PANTRY_FULL_X if v >= 0.85 else None


def log_popup_message(img, tag, region=None):
    """Logs a popup's FULL text (Windows OCR) and keeps a picture, at most once per 5 min per
    tag, so every popup we close leaves a readable record in run_log.txt."""
    if time.time() - _last_popup_save.get(tag, 0) < 300:
        return
    _last_popup_save[tag] = time.time()
    try:
        import popup_ocr
        text = popup_ocr.read_text(img, region)
        folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "popup_messages")
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, f"{int(time.time())}_{tag}.png")
        cv2.imwrite(path, img)
        log(f"POPUP MESSAGE [{tag}]: \"{text}\" (picture: {path})")
    except Exception as e:                      # noqa: BLE001
        log(f"POPUP MESSAGE [{tag}]: could not read/save ({e})")


def collect_finished_dialog_ok(img):
    """OK button position of the "Please collect finished items on <station> before you can produce more" notice, or None."""
    t = cv2.imread(COLLECT_FINISHED_TEMPLATE_PATH)
    if t is None or img is None or img.shape[:2] != (900, 1600):
        return None
    r = cv2.matchTemplate(img[150:330, 560:1040], t, cv2.TM_CCOEFF_NORMED)
    if float(r.max()) < 0.85:
        return None
    b, g, _r = [int(v) for v in img[COLLECT_FINISHED_OK_LOC[1], COLLECT_FINISHED_OK_LOC[0] - 100]]
    if not (g > 200 and b < 90):                  # the OK button must really be lime there
        return None
    return COLLECT_FINISHED_OK_LOC


_last_stuck_save = 0.0


def _save_stuck_screen(tag):
    """Keep a picture of a screen the panel closer could not clear (1 per 5 min, newest 60 kept)."""
    global _last_stuck_save
    if time.time() - _last_stuck_save < 300:
        return
    _last_stuck_save = time.time()
    try:
        folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "unknown_screens")
        os.makedirs(folder, exist_ok=True)
        name = os.path.join(folder, f"{int(time.time())}_{tag}.png")
        cv2.imwrite(name, screenshot())
        log(f"Saved this screen to {name} (a notice the panel closer cannot clear -- needs a handler).")
    except Exception as e:                        # noqa: BLE001
        log(f"Could not save the stuck screen ({e}).")


GENERIC_OK_LABELS = ("ok", "great", "gotit", "continue")
GENERIC_OK_BLOCK = ("gem", "buy", "purchas", "spend", "unlock", "upgrad", "delet", "discard", "remov", "quit", "exit", "sell",
                    "premium", "pay", "cost", "$", "install", "open", "real money", "yes", "confirm", "skip")
_last_generic_ok = 0.0


def single_lime_button(img):
    """(x, y, w, h) of the ONE lime button of a dimmed modal screen, or None (no modal / no button / more than one)."""
    if img is None or img.shape[:2] != (900, 1600):
        return None
    if float(np.percentile(cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2], 90)) >= 120:
        return None
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv, (40, 150, 170), (80, 255, 255))
    m[:300] = 0
    m[820:] = 0
    m[:, :300] = 0
    m[:, 1300:] = 0
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
    n, lab, st, cen = cv2.connectedComponentsWithStats(m)
    boxes = [(int(st[i][0]), int(st[i][1]), int(st[i][2]), int(st[i][3])) for i in range(1, n)
             if 150 <= st[i][2] <= 450 and 55 <= st[i][3] <= 115 and st[i][4] / float(st[i][2] * st[i][3]) > 0.6]
    return boxes[0] if len(boxes) == 1 else None


def generic_ok_notice(img, ocr=None):
    """(x, y, label, body) of a safe single-button OK / Great! notice, or None. `ocr` = popup_ocr.read_text (injectable for tests)."""
    b = single_lime_button(img)
    if b is None:
        return None
    x, y, w, h = b
    hsv = cv2.cvtColor(img[y + 4:y + h - 4, x + 4:x + w - 4], cv2.COLOR_BGR2HSV)
    pink = ((hsv[:, :, 0] < 8) | (hsv[:, :, 0] > 165)) & (hsv[:, :, 1] > 120) & (hsv[:, :, 2] > 120)
    if float(pink.mean()) > 0.01:                                  # a gem / ticket icon on the button = a price, never tap
        return None
    if ocr is None:
        import popup_ocr
        ocr = popup_ocr.read_text
    label = "".join(ch for ch in ocr(img, (x, y, x + w, y + h)).lower().replace("0", "o") if ch.isalpha())
    if label not in GENERIC_OK_LABELS:
        return None
    body = ocr(img, (400, 140, 1200, max(160, y - 5)))
    low = body.lower()
    if not body.strip() or any(w_ in low for w_ in GENERIC_OK_BLOCK):
        return None
    return x + w // 2, y + h // 2, label, body


def try_generic_ok_notice():
    """Last resort (called only when the panel closer gave up): tap the OK of an unknown, safe, single-button notice. True if tapped."""
    global _last_generic_ok
    if time.time() - _last_generic_ok < 90:
        return False
    _last_generic_ok = time.time()
    try:
        img = screenshot()
        r = generic_ok_notice(img)
        if r is None:
            return False
        x, y, label, body = r
        log(f"UNKNOWN single-button notice (\"{label}\"): \"{body}\" -- tapping its OK at ({x},{y}) (no gem / purchase / unlock wording).")
        log_popup_message(img, "generic_ok", None)
        tap(x, y)
        time.sleep(1.5)
        return True
    except Exception as e:                                         # noqa: BLE001
        log(f"Generic OK-notice check failed ({e}).")
        return False


def reward_button_label_ok(img, rb, ocr=None):
    """(ok, label): True only when OCR reads the lime button at rb as Collect / Reward / Claim."""
    try:
        if ocr is None:
            import popup_ocr
            ocr = popup_ocr.read_text
        x, y = int(rb[0]), int(rb[1])
        label = ocr(img, (max(0, x - 170), max(0, y - 50), min(1600, x + 170), min(900, y + 50)))
        norm = "".join(ch for ch in label.lower().replace("0", "o") if ch.isalpha())
        return (("collect" in norm) or ("reward" in norm) or ("claim" in norm)), label
    except Exception:                                  # noqa: BLE001
        return False, ""


UPGRADE_DIALOG_TEMPLATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "upgrade_recipe_dialog.png")
UPGRADE_DIALOG_X_LOC = (1207, 208)          # the red X of "Upgrade Event Recipe" (Upgrade Now is the lime button below -- NEVER tapped)


def upgrade_dialog_x(img):
    """Position of the close X of the "Upgrade Event Recipe" dialog, or None."""
    t = cv2.imread(UPGRADE_DIALOG_TEMPLATE_PATH)
    if t is None or img is None or img.shape[:2] != (900, 1600):
        return None
    r = cv2.matchTemplate(img[120:240, 560:1040], t, cv2.TM_CCOEFF_NORMED)
    if float(r.max()) < 0.85:
        return None
    x, y = UPGRADE_DIALOG_X_LOC
    patch = cv2.cvtColor(img[y - 30:y + 30, x - 38:x + 38], cv2.COLOR_BGR2HSV)
    red = ((patch[:, :, 0] < 8) | (patch[:, :, 0] > 170)) & (patch[:, :, 1] > 140) & (patch[:, :, 2] > 140)
    if int(red.sum()) < 400:
        return None
    return UPGRADE_DIALOG_X_LOC


OFFER_X_REGION = (1100, 50, 1450, 260)          # pass 52: where the red close X of a real-money offer sits


def purchase_offer_x(img, ocr=None):
    """Centre of the red close X of a real-money OFFER popup (a lime button whose text is a price such as $5.99), or None.
    Only the X is ever returned -- the price button is never a tap target."""
    try:
        if img is None or img.shape[:2] != (900, 1600):
            return None
        if float(np.percentile(cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2], 90)) >= 120:
            return None                                     # not dimmed -> not a modal popup
        x1, y1, x2, y2 = OFFER_X_REGION                     # cheap check first: the offer's red X (station panels keep theirs at x~1540)
        res = cv2.matchTemplate(img[y1:y2, x1:x2], CLOSE_X_TEMPLATE, cv2.TM_CCOEFF_NORMED)
        _, v, _, loc = cv2.minMaxLoc(res)
        if float(v) < 0.8:
            return None
        th, tw = CLOSE_X_TEMPLATE.shape[:2]
        xpos = (x1 + loc[0] + tw // 2, y1 + loc[1] + th // 2)
        hsv = cv2.cvtColor(img[690:830, 480:1120], cv2.COLOR_BGR2HSV)
        m = ((hsv[:, :, 0] >= 36) & (hsv[:, :, 0] <= 62) & (hsv[:, :, 1] >= 150) & (hsv[:, :, 2] >= 170)).astype(np.uint8)
        n, _lab, st, cen = cv2.connectedComponentsWithStats(m, 8)
        btn = None
        for i in range(1, n):
            x, y, w, h, a = st[i]
            if 250 <= w <= 440 and 55 <= h <= 100 and a >= 0.6 * w * h:
                btn = (int(cen[i][0]) + 480, int(cen[i][1]) + 690)
                break
        if btn is None:
            return None
        if ocr is None:
            import popup_ocr
            ocr = popup_ocr.read_text
        label = ocr(img, (max(0, btn[0] - 200), max(0, btn[1] - 45), min(1600, btn[0] + 200), min(900, btn[1] + 45))) or ""
        if "$" not in label and not re.search(r"\d+[.,]\d{2}", label):
            return None                                     # a lime button that is not a price (Collect / Great / OK ...)
        return xpos
    except Exception:                                      # noqa: BLE001
        return None


def _leaderboard_okay(img):
    """Centre of the club leaderboard popup's Okay button, or None."""
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates")
    ok, lb = cv2.imread(os.path.join(base, "okay_button.png")), cv2.imread(os.path.join(base, "leaderboard_title.png"))
    if ok is None or lb is None or img is None or img.shape[0] < 900 or img.shape[1] < 1150:
        return None
    _, tv, _, _ = cv2.minMaxLoc(cv2.matchTemplate(img[170:270, 450:1150], lb, cv2.TM_CCOEFF_NORMED))
    if tv < 0.8:
        return None
    _, ov, _, ol = cv2.minMaxLoc(cv2.matchTemplate(img[700:900, 500:1100], ok, cv2.TM_CCOEFF_NORMED))
    if ov < 0.85:
        return None
    return 500 + ol[0] + ok.shape[1] // 2, 700 + ol[1] + ok.shape[0] // 2


# 10/20 live 16:19-16:49: "Facebook Login Success" (one green Okay) sat over the map after a game restart; every
# board open failed for ~45 min. Title + Okay cut from that screen (grey, embedded so no template file is needed).
_FB_TITLE_B64 = "iVBORw0KGgoAAAANSUhEUgAAAYYAAAA8CAAAAABHzUKeAAAcQUlEQVR4Ae3BC1taZ6Kw4eddJ2ABchBFEFQUYxLTNtPjtPvXTe1fm05nmpgmzcEkHhAQ5SgoLFjH9zNqItPZe1/NfHu3u7163+Iv/OHXJ/7CH3594i/84dcn/sIffn3iL/zh1ye+5g+/PvE1f/j1ia/5w69PfM3/eTKQEonQBP8rggtSCoSiKlwS/MLE1/xfF9h9x/N9EcqF+V9h9U5Hti+08MxcikuCX5j4mhsycNquJEAGUgJqOhHivfneWAKhCIL/Cf741SgIpJ4om/xvaLX7Y9sLhKKHU3MLChcEvzDxNTekO3w+loGUMggCQF/LJ3hvznkrANJzquA9WA4ESlzlp/zhgzMgMnsnxvuZ2C5GWBf8N/zx65MJ10Lp2zEVEPzCxBY3Am+wbYHkmr62mOA9SWE1n3nA6i1dEfx8L4/B0b8w+Sl/+P0ZEJm9E+f9HB61yS7Pafw3hi/bY8lb4aVCgguCX5bY4kbgDR5a3NDXFhO8JylGzWcusHpbVwQ/3+MqBNEvo/yUP/z+DIjM3onzPtzBftsmPLuR5L/Re2j5vKNG7i5yQfDLElvckN75Pyxu6Ou5BO9JilHzmQus3tYVwc+3XQFmvozyU/7w+zMgMnsnzvuwm/s9IPZRlv+a03roA+GI7k0sLnywrAOCX5bY4oaU59+NQCgCJKCv52K8Jyms5lMXWL2tK4Kfb7sCzHwZ5af84fdnQCRzO877sFv7XRCx+3P81wZHr31gPh8bt2pcKC/PAIJflthiihx9O4RwIo3vSymZS0d5T1LY7R8coHxbE4Kfb7sCzHwZ5aek9d0AiGbXo7wP7+xFE/TZj6L85yTQqR8GCMrratD4QQLLS3P88sQW087/NoRYvkggAySRkA5Irgj+heQNwQ0pnM62A6zfVRD8fNsVYObLKP9i/O0AiObWoryPwKm3ztXk/ILBf04C7VotQGgbt6Cx7UpYXMpxSXJF8FOSNwTvSN4Q/PvEFtPO/zaExMoa0ySBH6AoquCtwPdB0bkiuCGF09l2gI1N3st2BYh/FeVfjP82kBDNrUX5WWQgEQiF0WnHmE2jywuogp+QQKd+GCDC62U4+dHyIVco4roghK7whuCaDPwAVF1ySSD9IABNk1wS/PvEFtPO/zaExMoa0yTWaCJ009R4a2wNQZ/TuCSY5nS2HWBjk/eyXQHiX0X5F+O/n0qI5tai/Cy+bQsdQ0cGgVAEIvAcX4kq/IQEzo5e+wht4xY0nw59yBWK9DqgGHNh3hBcC6zRBGKzkksC3xrZkEhKLgn+fWKLacO/n0kSK2tMOW8Px46PoumpzIwC+OPG2dgHEZ6dTXJB+HZ/5ICenAmD09l2gI07E9sjYhhcc6z+xAcjmlQ0jQv2aDAJIBRNKqrGdgWIfxWFSfsEPRzKmlyZ/OPUh1huzWSaO+6PPdAjSV3VecOfTDyhG7LbmSjkcsrpKECEMkH3yDdmVuzhxPbV5IzJNQlYrSc+QqysRZXegQAS6aR1VAU9Wk5A8xRFaIsh8PrHIycA1ZxPRbngd5sjNwA9OpeKcEE4Vn/iQyw5I7jg24PBOSihRGKGNzy7PxiBGkomYvwzscW00YO+T2JljRuDVmPkBFxQktlszIDz5uHI443UQiGsgTvsnI4c0JOp2QROZ9sBSiudsUc4EkvoApBOtzOY+KBH06l4SBA47e7ZJAAjlpqNGmK7AsS/iiJPqkfoM7l8jCuT73s+xPMlkxvS7bf7Yw80M5WaiQjAGgwmntDjxunxOZTXqHQCtETZr78gnF45P53YvppIp2dUwRsS8NrbrhRkCjl90tcUMEKhwcEB6Il7KXhZRVHMD6LQaRzZAReU+dx8RCA79RNbckGfW5yNgJz0eoOJD7FUOhUG3zruD85BCSVS6RlDxRue9AcjUEPJVDpuKEwRW0wbPe45JFbWeEvKnfqQK4oILRaTBIevLIkACbGVfBS69QPJpUjxtup2th1gPnngAkb6dlwH6Z3unnDtTiEGzunLLlfUzYWo2K4A8a+iMnh8MkGZ/dDUuTL5vudDolA0eUfK08oh11ZLcSFkUKt2JZBO0hrC+trkRRNCcx859RfokfhgyBvh+Y2IxhuSC6cPLV+gp9fjusol2T+ogJG8m4Ine6AlPo7L4MfGBAESmF/Kq7iPWzYCJJBfyoF7fNjhkmp+MK8waj3xuaLHbs2GGR4945qRvJU0mCK2mGY97Lsklsu85ZzudnyuCBTjXoFWteGjRnAc0BObaTk+qE64oiQLBaWz7QC6NpGACM2W5sE7f9FzuBYrrqve6fOhwxURW11RHlWA+FfRSe9VP2CuUFQFVyYPux4klxfDvOPbz1sTrpkLm5pwa41TlwuahuvD+trkRRNCcx85R89RVeH5vKHECotx3pBcGO0fjwTCSBcyYS7J04NDCKXvJODJHmiJj+OT1n4/wDCYeGBmN3WrtXcuCely4kNs8S7u4PmZyyWhLBYWqB10JVeEvliYY7/a45oILxbSTBFbTLMe9D3CuSWCABQjqlmH9XMIx1PKsO0GcHvJ3DvqoSWK9E5cqWifzfvNShM9YnI+AiNxJ3q67XBDhNaKJsOT3bEEVXUliIWNmVFjz5WgKp4EUVxL/FAB4l8Zvf2eLfTVYkxwbfKw60FyqRDmHau9eyZB0d0ARGpzRgx3eg5T1tcmL5oQmvsoOHqCUHwU3Q0APXEvzSUJuGev2j4oeiozF9O5ILuVKoQzGzPwZA+0xMfx8/1jS+jzGY76Lurs53p/vzkRej4pa2ceav5Tzht7tqLHdP/Ug2hhTeweOKCkdPc0QKRXiu7zIwe0lGqfgpou55gitphmPeh7KDOz+AHo0UL47HlvArPFJa31/NyFQjHz7MQiuniP+uszHz7PeTvNIYm5DI1jF/TNzHDbAYQWEr4dSCgUc5zs91xJxAyNxg4kikvtw24gRSSqjcYuzBaLP1aA+Fde/SWomdUFwVuTB10fEsuFMO/0XvcmkrBpWiMbooUC7VcTUDQDx5VcKJcnL5pgzN0XR48QyLBpWiMbhP5pVnDjZX0YSCCen48ZikC2K3WIzJdn4MkeaImPY6fPBo4yU17iRW0IyT+H2jtnnprYyPnPGhZkP1ebuz3fSC6Yzt7Qh4Vbyn4VlPBadLQ3CURovXT+4gTU2Jox2PMCEb67zBSxxTTrQd9DFRJNhVByw+z/cO7Ccjmu9HbbNuQWU4+6kkxhlfbhsQv3FsV3A8lyIUPjsC1RVxb8bQcwUiVtULF8SBfKHDwNAsndXGi0ewThzN3abhBIfTOjjV62wMzeeXYIxL9qHJ5B5H7KUHhr8rDnQmKpEOGd44d+ICkXo8PqPhiJO95uz4NwJk+zaUtgbXXysgX67Mdq4yEXysXosLoPiC8WFG6cnxyMfUBoscW8qSDblTqY2bU4PNkDLfFxqLXtSzW3nOWw1oL4B7H2YymNXCkd7B91YfaDWO2pT7y0ELH3Ts4hXdTrJ2Bm16KjvaaFuLXe2u9AfGEtNNjtTBAflJkitphmPeh7CCSKgFBqM3a+63ievbSmifP6oQW5XPxxH5aW5jk7eW3D5pz3aAQfLoY5bez5qAuLykMXWFhJqePWwRCM/Mf2wQukqt+fV729ioUa+7Cxj1Sj91PC2zkao6Y/fVEBzHuNE494rhQRgrcmjzouJIrFCG85jUdA6E5Bd+uvxoGif+y+GAdQyM9y1jzwgbWS/bIFRua+dvQQROhOQXerL20Jn+R1bnhW7+R0zAUtmsonw7JdqYO5sBqHJ3ugJT5Wm48D9HIuSbtWgfhmpPkcIuWFuGweHkF606i/hNk/RTSvediEeC5x1IBYrmROGq0R+vJid7cNiXzJGDVaE6GVC0wRW0yzHvQ9ECCAUOqDqNORgTvJzMPoZG8IuYXQiwGsLSdxBlVXUDCHzyz4eAFGrVc+Snop9MAFync04Y+2e8DCF6PKLuiJe2k4PDiVhD5sViGc3ozDbrUPiS93KoCR7Z+j5tdmNG44j9oOJIpLYd4a1Z+BmtjIwfFuz4fP7Oe+hA8XI3it731gbXXysgWh+Y/UxvcgwveKUH859OGjxTA3ZOC2uv2RKwFjYWlWaVfqYOZLcXi8B1riE9l4EWDcXTCx2g0hIsXg+BVENzNhaTWbCrGCV9uHzGeCYHBwAmamWD+EcHopqQ3ObYxU4vzFMZiZYoKzM1foczNMEVtMsx70PRAXgFBqMwoSKaVAjk/2R5CbF7tDWFtOgnQVDTnuPLdgYxas7lGAiJWiD1zg1qZAen/rANlPzqpVMHOlGagftiShcvcE4vmSCZVqB+Kf7x5yLV4qM8153J7ATHEpwluntV3Q8yuz0NpveXDffgGIL/JA968esLY6edmCyPwHRuM7LtxfhcbuqQ93F+O8JfEDcE4Pzhze2FiOtit1iC6uxODxHmgznzpHuxLj7oIJvq8LaNcPILqZCYMX6ELKs4MDSN4RBGcnPTBSm7VdCWq2OK8AipD+46oEI7uUVkAo/BOxxTTrQd8DRVW5EErdNsE6748nDmH/bOJDbs6vjGBtJQFIAfSPDidg6uB7tkREVuMPHWBjE/C/b/ow96d+vQHxlUUTjqsNSWjptAPJlcUQ1KpNiH+6f8gVcauQYJrztDmGmeJShLda9QqEVxYT0DlsuLBp74IW+zADdP/qAeWSvdMCM7tpNL7jwv1VaO63PbhTiHNFOh6u40YMMT5o2VxIFcvNyhFEC8sxeLILauyLSf1AYtxdMAEpgGa1BtHNTBiQAoLjWgO0KEjP8UBP/Km7P5AIfSadToZRQO5WByCMZCqdNFD4J2KLadaDvgeh+KwGaJE5PZg0uiPH8dCFw4XcnFO1YG0lwbXTWtXhhoisxR46wMYmEDxoupD5oN9oQmJ9PgzNWk1iFPo9mC3PGdCoNiD+ycEhV8RH+TDTnGdNC2aKSxHeOq7VIbK+EIPTw7oDd+x9MBJ3Z4HuXz2gXLJ3WmBmN43Gd1y4vwrtg6YLG4UEV9xWF9/zzWya9vGxK0Ff/LhVqUO0sByDJ7sgYl9a9UOJcXfB5Npx9Qiim5kwV4J6rckUPfGn4KQ+8kCLxM1EMqbC6fGR5YMRjsdmklGFaWKLadaDvgfxXDnMFftkrw8IBQgk5DJ23YK1lQTXTmtVB1SuKWYp8tABcWsT8LebDsxuDhptSN5Jh6BdO5QY+cEpzG2kdDiu1yD+6f4hV8RmPsY053lzBDPFpQhvHdUaYN6ZM+G0VnXgzuQAjMTdWaD7Vw8ol+ydFpjZTaPxHRfur0Ln4MSFW4UkV8Yv9wFhrq1A59XABfKf9So1iBaWY/BkF0T0S6talxh3F0yuHdUaEN3MhLkS1GtNEArXQsl7sWGtPXQDCcwU81EFeVbtWJ7PhXQxF1aYIraYZj3oexDPlcNcGTw+cwDVBCwfcpnJkQVrKwmundaqDsQMroj4gnjogHrrDuD/o+XD7ObZcROSd9IhaNZqEqN42oO5jZQOjWoD4p/vHnItv5RnmvO0ZUGiWIzwVqN2BOadORNOD+sObI73wUjcnQW6f/WAcsneaYGZ3TSO/y4l3F+FzsGJC+uFFFfsnT1ARMurcH58MALmP7RrFYgWlmPwZBeE+dWoeiQx7i6YXKtXTyC6mQlzJajXmqDHuRZKlsLSO223znxAMTYWohB43Xb7PACU6EbGZIrYYpr1oO9BPFcOc8lpP7YlZLJRxR40JpCb8w5HsLKUYTKcCAXTPqk6sDQbBn8sUaLR0UMH9FsbEDjfdyRk7vePjiGxkQlD4/BEEip1OpBZz+hQrbYg8eVOBYwQtkNkcdVUuOE8bVmQKBYjvNWs1iCykY1C5+DEhQ9G+2Ckb6eB7rcuUC7ZL5tgZjeNkweuhPur0D5oulAuprhi7+wBIrpeArv37AyYva3WDiCaK8Xhx70AzC+dekVi3MrFGY4cDS162qiBeWvB5MxyNXSzddSE2EpEA9uBUDyhgjMe2d3OWCIypQIXbMtyWr0xqJlylilii2nWg74H8Vw5zKXh8XMf1PJaGOt4dwS5eWX3HPJLec6bHVTm9W7Vho3FGZxhN0CdDZ89dEBf21Bxh4/6QPaTXu0IZtbnI3B4cCqFWWo3YXZt3oDdah+R+vPzCpjJaGsAs0sFnRvO05YF8YV8SAZSIqUW79YqEL61EIPj3Z4vlA+Hr8GY2ZwFut+6QHnVedEEc/6e0Xxk+3B/FZp7HQ/KxRRX7Je7gIiul8A9+2EApNcj9V2IzJcTyOf7LkT+LI92JVqpkKLTOtUUY8FvHkB4ZTEhW60zTYlkh8cnkLiTCslx/xyiKdV1QY+o3aNjJ0Bdv+XZLoTCarN+4kmhbpYUbogtpln/GPgQz5XDXOof7fqI6HoJRie7I8gtGC/OIF1c4+x414ZyarQ/gZVChvZRNUBbn3ceOsDKelSxjvfPEeT+3KzWIF7OmrC7Z0k9vnRyAunVBQOe1SyM2Y+fVcCcL+3WJXryE5MbztOWBaFESvE93wv8IHbvvLYP4bXFGNR2RoEa2Tx7AYrxSRbofusC5VX3eRPM+XtG67Hlw/1VOH596sN6IcUVZ2dPgoiWV8EdPB4Ambuh6kswEnfSivuqYkPkc7X5IkDNrizQrlXAXDc7r8HIljKyeXgEiTInRxAvLZjuUbUHmZLSPoXZlah6/sPAgdXS6GQA88um0nk88uD2apgbYotpo7+fBRDPlcNcGtR3fVBvb8CgcjSBXD65fQrRwiadasOBzcz4qQXZYoH2Ud2X2t3ZyUMHiC8sRc92eg4ikv9wcLAPZr4Ul5OXhz7mXO6oBvHCshlMnjV8Ygt3fqyAmd1o15uIyHo2xjvO05YFiqYJ+QbMfOHWXoCxuJxmUnkZyNDs2uCZj9Du5UO4zW0PKK96z0/AnL9ntB5NfLi/CvWXQx/uFOJcCV6+9gC1uJJUzmo1C5j/SD94AUK/t6D39xoBhD8zOz/4KDPrRWrVJsTvma0fQU3cXpAH9Q6k74n6HkQWSjPuUb0rya6OT04hVcroo5ctC5aX+8dnML+UUfsvuxMor8a4IbaYNvp2KCGeK4e5dN7Y8YF8QffOjoce5ArzP7Rc9Nky3cbQh0/mx4/OJPGldWqVfoB2Pzl86ABaZC48aTgBIlMojSuvAqnH19KiWetAejldqfgYiXLCb1b7ML+cf1wBM3vXbuy6Uk2XcipvOU9bFtMS/yGOfgykGlvJ6q36McRXct3nEynEYi7tn7cOfaC8Kp8egzl/z2g+sn24vwq1nVEAm4sxru3tjSQQz6T9UXvogbrwsXKw40rIx7VR9xyIfBE//WHsC6O4QL09gsRn4daPdiBCKxlZ7Vow/2lQfRlII76ZtnfalpT5jVGtCdFcMTLa7YxhZWVY6cFMrmj0d3sO3CpFuSG2mDb8dgjEc+Uwl8YnP/oSDNOcWBMu5Ir5V42BJDzLcACK9tm89cOpg54vs38IIvRJvLftcEMopWLKr762AijOqodnDsriRuhwfyxRl5LB4chFXS5HH1XAzN7VOs+HLpRLcd5ynrYspiX+Q289tXzIzZmHPRtl9kOz86rvgzGXs097YwmUy8HTBpjz94zmI9uH+6tQ2xkFsLkY49pRpSW5oEZslzfM/IfUX5/5vCMif54ZvuqMJTNxemNQM5/rvdddW5KMyo4Dav6zoLozlop+Nz15MgJR3BzvVkGPLpvW4chFXVu1d47BmFk2zqqWL5Q7JZ0bYotpw2+HQHxhPcwl2X1gBxKhCBlIBOQKhV6t5kqhIn0wc6tx53XjHKHpuC6EZ+8anUcOqIHkkhq/lVfoHDZc0FThBpL40rpyXD0OEJoqvUCK+OqKsl0BM3s3dF5tDCXJwi3ecp62LKYl/iM8ODgeg6oJN5CY+U319LBhS4Qecr0g4ML6evCkAeb8PaP5yPbh/irUdkYBbC7GuNY/2vV5Q5GSNxaXcvTrFYd3ROjDjNLb77ooCr6EdKGkTrq7Aw9V4EuYK5RoHrQ8REiRdgCJ5dXR6woIRVMCL5AiVSpYzxogFF34npRqqpxnithi2ujv54EkvrAe5op12DiTXBCabgeQKxScVr3pcyk+vxTT/d7hiR9I3tDnSmm/9dhFGDGt4wPh1GLGBLu3c+ZzSdEX8/OMWy/HPpfUUH5xlu0KmNm7IXf4ouNhZO6aGlecJ+0JFyRXROKrsDt42XO5JPTsYp5Jd2fog1ACyaWNDe/xEZjz94zmI9uH+6tQ2xkFsLkY45rbeT7yeEeNlxYiOKfPzn3eiBn2JAhtzoWdWqPLJSWZz8WEbx8e97mkphfnY4xae5YveUPRV/MJ97jellLyhhpeWZjxakddpOQNNbaSjTFFbDHNfm0FvoykFw2u+KNaZ+xLVCNstBzIFQqMOkeWFwhF1TPzc4DbODqzfUDRU7llxWo+dRGxbLJmB2gzczmNC85e+8zhgh5JLKbDMNrvDh0uGGZyMRnidVMhnFjS4fnRSBHx1bkIV5xnrQkqV4QQzHwaQu6fDGwJaOFELmMSTF51Rj4XwvrYl4jbG87jIzCzm0Zz2/Hhw5LKyf7El2xkw7xlHZ6c+VzTYov5ODA56Fk+CG1Ob527oc05k37zxPaloqjh7PwMIHsnbTuQiqqa2bkY+OOD7tDhghaZLSUFVufQclwuGGZqZUZl2KqNHY8LRixdMlWmiC1+SnpS0XjH7rdGjmImI/6LIeQKBQjGrYGrhqLJqM4bzul+zwaM2fU0yujkuYtIrBWsoS2isTDX6odNLqRyi6bKGwe1Dhcy+XxYARedK51qIyJCiZUYV9y91pCIBgKEoqlB5JYONCsnPhDPLcZ0IBhV65YEiqkDy0e9vT550oBo9q7RfOgEsFEyOe/iehRjTNmpnXMtkS/rXOqeDkFLpewn525oc84Ed3RiBVokloioXHLOT+xAM+MzpuCCHNfrfS7M5G8pQoB7Wm+PuJBZWIiqgN2r9SwuZBeypsI0scW/kFII3gk825eomiqHPoTCYcB3vEAoqqYJ3ghcy3F9oegh0wBvPPARRizmewGaqnBtMh77UqihcFjl0tia+AgtFA6pgERwxZlMVBTNVLkiLcdDUbgkBKhRATjW2JNoRiisCS7447MOKMno5Knlo96+5fWGoJtpZdyVUvrpuIrvIAMiKlNGvfZw7KKHIonEjCm45Lo+YGjB0A2UuKGC9BxfClXTVK4Evh1IRdE0lUv+ZOz4gaIa4ajggnQn44kjVD0SMTQuBO5kMnYUVTfDIZV/Irb4HyEDXyiK4A0/kAihKPxU4IOqcCPwEarg3xUEElXhHaenKUpc6W6PfdTbG9L1QVF0pAcy0FX+c/ZgbHuoRjge1vj/EvigKrwT+C6qpgjeCjxXqJrKT4ktfh98G7xxMgR0/25L1Nsb/HaILX4fjl87UgZ/yoLX/t5DhG+t8dshtvh9qD2dSLhXMBk2Xvgo6VKR3w7xDb8P9eeWD7lsin7rOEAtLs3x2yG+4fehtdtxQRgmtu2Ddjsf57dDfMPvQ792aAOKShBI1NiHaY3fDvENvw+T7qtzT3JFi2dLJr8h4ht+J5xXbcsNuKAoseySqfIbIr7hd0JO+t3exAcRnpuLG4rgN0R8w++GbVmuBKHFojq/LeIb/vDrE9/wh1+f+IY//PrEN/zh1/f/ADCIg64VaDiKAAAAAElFTkSuQmCC"
_FB_OKAY_B64 = "iVBORw0KGgoAAAANSUhEUgAAAMgAAABGCAAAAACsiYTqAAAJG0lEQVRoBd3BiXOU9R3A4c/3fffdkE02B7shJIRDIhCSDdlkIQlKLVo76tRaaxVwqAd2pv9G/4dqVar1mN7UowoCoigEEkh2c3AEQzYEyAUYEpLNtdl99/11Q+qMTqvYfVOieR45x8IgZ1gYpI2FQVpYGCTEwiBNLAxygu80xbckDcwJxTyTBr6g+D6Ter4bFPbIcRYGOc7CIMf47hBSJ3UkCd97UsfcsCYtcDn4loQ5JnXYpxJxKzYQh4Is3RDmhdRh39jljoHRmAJnka8sg3khddh2JXzmysgUM3JWlJYuAxU7Mw6TSyu5beQoNiXGWprP8wXHkq2b3DD25lUYrXyO20aOYtPYydBlky+Itr6mWufG73pB1e7itpEj2BPrf7t3ki/JLn3CpY/8thek9jluG/kUewbb947xFSufWJYx8nwvSO0ubhv5FHvaj7VPAyIOTSUsC/DWVBeMPN8LUruL20Y+wZ4TB4ZMwJW/MX+i5WIEyFz58OrR53uBzc8yS7hJ8W/CnJPD2BKtOzBtAasCG3Knu49cjIIza2fpyAu9wOZn+QpFYiyakHTXIm6y4rE4mU7mgnyMHWr46CeWAqP6oRwd3m+9Cpr+XMXoi71A7TOgzNEpcTicbkGNT01ei8T07JyczEUGsYmxyclp1nogYYIVdxo6KZOPsENdrm9QIN4tPxKBM40tgDzlj77YB9Q8A/Hhg+fxeJbflU6i4bMrkwklmiNn87olXG4JWpqwsxRujMDY8NL8XFImh7BDnTvZAsiGmgqS+k4cIemxSv3FPqDmaRg+3nZNFpVVrzUGWz+7NpFQgJZeULp+RffJenSd58qhp7M7EY+XlS0nZXIIO6yW4FlAu69yFUmRhr0kPRDIeKkPqHmaqYvvDU5redW1WVOfHRyKcZOmsdx/38XGenSdXRsgHGw0cW7atIaUyYfYYTWFOgDtJ/58Zhzbo4B7qxa/1AfUPKV62uqmxbjXv5wLzXUgogkJBZT8uqexAV1nVzmEQ40mzk0b15AyOYgdVjDUAWiPlS9mxsl3pi3YGsh9uQ+o2Tl68sSIleb92eo0mprOw6IVviJ1tHsCih7UzjSg6zxbDuHmRhPnpsAaUiYHscMKhjoAbbsvixnB98YTsDWQ+3IfUL2jpakTCjYFcoWPm65A9paKAmv/qWuwZPOSjjo0PW2nD8LNjSbOyuq1pEwOYocVDHUA2pO+TGaE9kZM2BrIfbkPqHrk3QvjuMp/mu7QOBQas6zcx4tcVn1zN3gDd3QeBsO9fT10NTeaGBXV60mZHMSORCjUAWhP+jKZEdobMeGHgdzdfUBx9SeDFpUby0Sg7VJiasT5eI6m2oNt4A2sCh8Gw729BMItTSaGr6aUb0PxX8gB7LBCoQ5A2+HLZEbT3vEE3FuVs7sPcOcNRB0Z91fkkDQ8rsxpKTago6kFvIE7Og+D4d5eAp3NIROjtKaMlMkBbkHxDay24DlA2+HLYEbjOzELflzp3t3HrIx199zBTYno+PR0DN3R3dEN3kBx+BAY7u0l0BlqNjFKa8pImezHDuuzxlOAtqMskxn1e0h6yO/a3cesgscLXcxQE/3hgcFhc5FnKCrgDZR07gfDva0EOoOtJkZJrY+UyX5sULHek0FAe6TcS1LkxH6SHvPL7j5mFTxe6GLG0PkTk9GYaWnOmAXkBdaH94Hh3lYCncFWE6Ok1kfK5ANsUPHhhjpAu99fSFJ/Yx1JT1bEdvczy3NviZcZbaGzJKUZEJ8G78b14X1guLeVwPlQq4lRUuMjZbIPG5QVPfaRBVpt5Z0knQu1gqb9snz89/3g0DAt1+otxQ5Q5v7gBOiZizOI3RgEb6Cscx84Mravh/OhNhNjXY2PlMk+7FCq/mDUQopq7ibpREsXOLN/sTbySj/kZ1hXo5pzqz8fYoOHzlqQ+8CyDC6cOgveQGX4bUS0p8uhs6XZxFiz2UfKZC/2tB65GgfXhi15xtTnxy6MgvvOrcsjr/TDshX5x4aguGozTF06Eoa0op/nGXQEW8FbFQi/hQjPlEO4ucXEWFdTRsrkfezpbj49paCo9I60SHf7EGhL7i5ZHHm1Hwo3bPjg4iTpZQ+6HZOd9d2QvnJbNupM81nwVlVdeDcB7ChP41zobAKjdGMpqVAkyXvYM9L94UgCxOFxRIdQ4Fz9aLYReXUACqvuPtUchmXVvuzJruPdwNJf5WLVt10GT1VVzwcTFjxQkUfjiQELo2xjCd+e4ivkn9gT//xQzzggTknESVpattUpkdcGoLBqy/Wmlgm1yPvgSnqPngdcZR5t9PLwJHgqq659ctWEtSWrRk53RBVGeWANKZN3sWniTKiHL2ia4fMXa0ReG4CCqnvip0O9pjK2bMgfPXQmodBdmdr4hCmwuLJyItg+BVlLlkSuXldg+CuLSZm8g01W9HBbNKG4ycjIqS3XkcjrA1BQdQ+97cFJS8uv2aR/1BxRiiTRsMDj9+tdR24oZikwKitXkzJ5h/+d4susoe7QYJSbclf5C93A2OsDUFB5D/G+94di4qi4K7//dJNpAZqeE4uAx+/PvXGgZ5xZCoyN/pWkTN7CtkSkd3A4Mo2elu3JL0rXgFjLlE7mkiIYOdkxmsYKX0niate1yJTldOcuuhoGT4XfG+s6f+m6Qlwe/XICZ5V/JSmTt5gLkeGhCZzp3uxFupCkorqTm6JXOm64yFy61mlO9A5NJFw5efR0QNadxVkkLnX1xyzN44nXmzg3bVhByuQfzAWlFCCCMEsJs5SyABENVBKCoCwQTQQsZY1E9dzBcw0maT8oXUrKZA/zLJ4Q5+lgT4L0h4vdpEz2MN/M6Ejr2QnlyHm0yCBlsof5FI8rJq93dX+OZCx/II/UyR5So5gLF7pG1eTI9HQcfamvIouvo7gV+TtzQJGi9lP9VnyaJNfauz0GqZO/MZ/OtXZaJIlRWF7NDEVq5K/Mp85T7RZJzsXVa7L5Wopbkr8wny6dbUkgzrzlq/PcDuyQPzOfhnvPmWJk5BUu07BH/sS8ig3H9fQsHdvkj8wrZSoRXbBN3mRhkDdYGOR1FgZ5lYVB/sDCIG/wH4TvIXmBWxL+3wTb5DfcJHznCd/kX64erPxMKk1YAAAAAElFTkSuQmCC"
_fb_tpl = {}


def _facebook_okay(img):
    """Centre of the 'Facebook Login Success' popup's Okay button, or None (title AND button must match)."""
    try:
        if not _fb_tpl:
            import base64
            for k, b in (("t", _FB_TITLE_B64), ("o", _FB_OKAY_B64)):
                _fb_tpl[k] = cv2.imdecode(np.frombuffer(base64.b64decode(b), np.uint8), cv2.IMREAD_GRAYSCALE)
        if img is None or img.shape[:2] != (900, 1600):
            return None
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        _, tv, _, _ = cv2.minMaxLoc(cv2.matchTemplate(g[120:260, 450:1150], _fb_tpl["t"], cv2.TM_CCOEFF_NORMED))
        if tv < 0.8:
            return None
        _, ov, _, ol = cv2.minMaxLoc(cv2.matchTemplate(g[680:860, 550:1050], _fb_tpl["o"], cv2.TM_CCOEFF_NORMED))
        if ov < 0.8:
            return None
        th, tw = _fb_tpl["o"].shape[:2]
        return 550 + ol[0] + tw // 2, 680 + ol[1] + th // 2
    except Exception:                                   # noqa: BLE001
        return None


TAKEOUT_PLEASE_WAIT = (800, 732)    # 11/2: the cyan middle button of the takeout customer popup
_takeout_tpl = {}
TAKEOUT_SEEN = []                    # times the takeout popup was seen (log / Orders tab later)


TAKEOUT_ACCEPT = (800, 622)          # 11/2 (owner): green Accept -- only when the dish is in stock
TAKEOUT_DECLINE = (800, 840)         # red Decline -- when it is not
TAKEOUT_COUNT_BOX = (440, 500, 500, 660)   # y1, y2, x1, x2 of the white "have/need" under the dish


def takeout_count(img):
    """11/2: the white "5/7" under the takeout dish -> (have, need) or None. White digits read with the event
    count shapes (event_digits templates); right on all 3 saved popups (5/7, 0/1, 0/1)."""
    try:
        import event_digits as ed
        y1, y2, x1, x2 = TAKEOUT_COUNT_BOX
        box = img[y1:y2, x1:x2]
        m = (box.min(axis=2) > 200).astype(np.uint8) * 255
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        parts = [i for i in range(1, n) if st[i][4] >= 12 and st[i][3] >= 10]
        if parts:
            tall = max(st[i][3] for i in parts)
            parts = [i for i in parts if st[i][3] >= 0.6 * tall]
        labels = []
        for i in sorted(parts, key=lambda i: st[i][0]):
            x, y, w, h, _a = st[i]
            g = (lab[y:y + h, x:x + w] == i).astype(np.uint8) * 255
            lb, _sc = ed.classify(cv2.resize(g, ed.GLYPH_SIZE, interpolation=cv2.INTER_AREA))
            if lb is None:
                return None
            labels.append(lb)
        if labels.count("slash") != 1:
            return None
        k = labels.index("slash")
        a, b = labels[:k], labels[k + 1:]
        if not a or not b or any(not c.isdigit() for c in a + b):
            return None
        return int("".join(a)), int("".join(b))
    except Exception:                                   # noqa: BLE001
        return None


def takeout_choice(img):
    """(button, word): Accept when have >= need, Decline when have < need, Please wait when unreadable."""
    c = takeout_count(img)
    if c is None:                     # 11/2 owner: "just hit accept, hit No on buy-with-gems, then decline"
        return TAKEOUT_ACCEPT, "Accept (count unreadable -- a gem question gets No, then Decline)"
    have, need = c
    if have >= need:
        return TAKEOUT_ACCEPT, f"Accept (have {have}/{need})"
    return TAKEOUT_DECLINE, f"Decline (have {have}/{need})"


def takeout_popup(img):
    """11/2 (owner: fix the unknown stuck screen): "Hi, I'd like to order some food for takeout:" -- a visitor with
    Accept / Please wait / Decline. Nothing handled it; on 10/31 only an LDPlayer restart cleared it. Returns the
    Please-wait button centre, or None. The title text must match AND the button there must be cyan."""
    try:
        if "t" not in _takeout_tpl:
            _takeout_tpl["t"] = cv2.imread(os.path.join(BASE_DIR, "templates", "takeout_title.png"), cv2.IMREAD_GRAYSCALE)
        t = _takeout_tpl["t"]
        if img is None or t is None or img.shape[:2] != (900, 1600):
            return None
        g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        _, v, _, _ = cv2.minMaxLoc(cv2.matchTemplate(g[60:220, 300:1300], t, cv2.TM_CCOEFF_NORMED))
        if v < 0.75:
            return None
        x, y = TAKEOUT_PLEASE_WAIT
        hsv = cv2.cvtColor(img[y - 15:y + 15, x - 150:x + 150], cv2.COLOR_BGR2HSV)
        h, sat, val = (float(np.median(hsv[..., i])) for i in range(3))
        if not (80 <= h <= 105 and sat > 120 and val > 150):   # cyan button where "Please wait" should be
            return None
        return TAKEOUT_PLEASE_WAIT
    except Exception:                                   # noqa: BLE001
        return None


def dismiss_error_dialog(img=None):
    """The game's own 'Whoops! Something went wrong! Please try again
    later!' dialog (a server/connection hiccup). Found live 10/2: it sat
    over the event board for over an hour while every pass reported
    board_not_opened, because nothing knew to tap its OK. Harmless to
    dismiss (no cost, no purchase). Returns True if found and dismissed."""
    try:
        tpl = cv2.imread(ERROR_WHOOPS_TEMPLATE_PATH)
        if tpl is None:
            return False
        if img is None:
            img = screenshot()
        # --- an LDPlayer LAUNCHER ad (a poster for another game over the Android home screen) ---
        ax = launcher_ad_x_loc(img)
        if ax is not None and "launcher" in _focused_window().lower():
            log(f"LDPlayer launcher ad poster detected -- closing it with its X at {ax} "
                "(only ever done while the Android launcher, not the game, is in front).")
            tap(*ax)
            time.sleep(1.5)
            return True
        # --- the emulator / game is not on the map at all (restart, crash, launch) ---
        if is_android_home(img):
            loc = food_street_icon_loc(img)
            if loc is not None:
                log(f"Android home screen detected -- launching Food Street (icon at {loc}); "
                    "nothing else on this screen is ever tapped.")
                tap(*loc)
                time.sleep(8)
                return True
            log("Android home screen detected but the Food Street icon was not found -- not tapping.")
            return False
        if is_tablet_starting(img):
            log("'Tablet is starting...' -- the emulator is booting; waiting.")
            time.sleep(8)
            return True
        if is_game_splash(img):
            log("Food Street loading screen -- the game is starting; waiting.")
            time.sleep(8)
            return True
        ux = upgrade_dialog_x(img)                           # pass 36: "Upgrade Event Recipe" -- close with its X, NEVER Upgrade Now
        if ux is not None:
            log("'Upgrade Event Recipe' dialog -- closing it with its X (never Upgrade Now).")
            tap(*ux)
            time.sleep(1.5)
            return True
        # 10/19 live: the club "<Event> Leaderboard" popup (Club Ranking / Members tabs, one green "Okay") sat over
        # the map and every board open failed -- the red-X closer kept closing the panel BEHIND it. Okay only
        # closes it. Both the "Leaderboard" title word and the Okay button must match (Okay alone reaches 0.80 on
        # other screens); checked on 987 saved screens: 7 hits, all this popup.
        tw = takeout_popup(img)
        if tw is not None:                                  # 11/2 (owner): Accept when we have the dish, else
            TAKEOUT_SEEN.append(time.time())                # Decline; unreadable count -> Please wait
            tw, word = takeout_choice(img)
            log(f"Takeout customer popup -- tapping {word} at {tw}.")
            try:
                if len(TAKEOUT_SEEN) <= 3:
                    cv2.imwrite(os.path.join(BASE_DIR, "templates", "fail_pictures",
                                             f"{int(time.time())}_takeout.png"), img)
            except Exception:                               # noqa: BLE001
                pass
            tap(*tw)
            time.sleep(1.5)
            if tw == TAKEOUT_ACCEPT:                        # never pay gems: a gem question after Accept -> No
                try:
                    import order_fulfill
                    no, _ = order_fulfill.find_no_button(screenshot())
                    if no is not None:
                        log("Takeout Accept asked for gems -- answered No.")
                        tap(*no)
                        time.sleep(1.0)
                        if takeout_popup(screenshot()) is not None:     # still asking -> we don't have it
                            log(f"Takeout: not in stock -- tapping Decline at {TAKEOUT_DECLINE}.")
                            tap(*TAKEOUT_DECLINE)
                            time.sleep(1.0)
                except Exception:                           # noqa: BLE001
                    pass
            return True
        fo = _facebook_okay(img)
        if fo is not None:
            log(f"'Facebook Login Success' popup -- tapping its Okay at {fo}.")
            tap(*fo)
            time.sleep(1.5)
            return True
        lo = _leaderboard_okay(img)
        if lo is not None:
            log(f"Club leaderboard popup -- tapping its Okay at {lo}.")
            tap(*lo)
            time.sleep(1.5)
            return True
        # "Your Food Club Storage is full!" -- tap ITS red X only; never "Upgrade Now!".
        px = pantry_full_dialog_x(img)
        if px is not None:                                  # 10/25: "Your Pantry is full!" -- red X only, never Upgrade Now
            log("'Your Pantry is full!' popup -- closing it with its X (never Upgrade Now). The bot's ordinary "
                "storage is full: serve ready orders / sell extras.")
            log_popup_message(img, "pantry_full", (560, 175, 1040, 725))
            PANTRY_FULL_AT[0] = time.time()
            tap(*px)
            time.sleep(1.5)
            # 10/25 (Muse P23): the owner's first X tap did not close it -- look again, one more X tap if still up.
            again = screenshot()
            if again is not None and pantry_full_dialog_x(again) is not None:
                log("'Your Pantry is full!' popup still up after the X -- tapping its X once more.")
                tap(*px)
                time.sleep(1.5)
            return True
        sx = storage_full_dialog_x(img)
        if sx is not None:
            log("'Food Club Storage is full' popup -- closing it with its X (never Upgrade Now).")
            STORAGE_FULL_TIMES.append(time.time())
            del STORAGE_FULL_TIMES[:-50]
            log_popup_message(img, "storage_full", (560, 175, 1040, 725))
            try:                                            # 10/20 (owner): beeps + pop-up so they can free space
                import event_orders
                event_orders.storage_alarm()
            except Exception:                               # noqa: BLE001
                pass
            tap(*sx)
            time.sleep(1.5)
            return True
        # Celebration popup: blue ribbon + one lime button (Great! / Collect Rewards ...)
        rb = ribbon_button_loc(img)
        if rb is not None:
            log(f"'Thank you! Rewards' popup detected -- tapping Collect Rewards at {rb}.")
            tap(*rb)
            time.sleep(2)
            return True
        # "Whoops! Unable to connect to server. Please check your connection and try again!" [OK]
        uc, _ = _best(img[100:330, 480:1120], "unable_to_connect_dialog.png")
        if uc >= 0.85:
            log(f"'Unable to connect to server' dialog detected (confidence {uc:.2f}) -- tapping OK.")
            UNABLE_TIMES.append(time.time())        # 10/31: afsd_core.whoops_check acts on a run of these
            del UNABLE_TIMES[:-50]
            tap(800, 730)
            time.sleep(2)
            return True
        # "You are out of <crop>! You need at least one to replant it. Buy and plant one
        # now? [No] [Yes <gems>]" (seen live 10/2 after tapping a 0-stock crop card; it
        # blocked every cycle). The "Buy and plant one now?" line is constant. ALWAYS No.
        oc = cv2.imread(OUT_OF_CROP_TEMPLATE_PATH)
        if oc is not None:
            ro = cv2.matchTemplate(img[440:540, 560:1040], oc, cv2.TM_CCOEFF_NORMED)
            _, ov, _, _ = cv2.minMaxLoc(ro)
            if ov >= 0.85:
                log(f"'Out of crop -- buy and plant?' dialog detected (confidence {ov:.2f}) -- "
                    "tapping No (never the gem Yes).")
                tap(*OUT_OF_CROP_NO_LOC)
                time.sleep(1.5)
                return True
        # "Please collect finished items on <station> before you can produce more" [OK] (seen live 10/6 on the Merchant)
        ck = collect_finished_dialog_ok(img)
        if ck is not None:
            log("'Please collect finished items before you can produce more' notice -- tapping OK "
                "(the finished batch is collected by tapping the building on the map).")
            tap(*ck)
            time.sleep(1.5)
            return True
        # Any single-button celebration popup whose button reads "Great!" (Event Badge
        # Unlocked, "Event Milestone N! Unlocks: Extra Slot / Extra Event Plot / Recipe
        # Upgrade" -- seen live 10/2). Requires a DIMMED screen (a modal) so the button
        # image on a plain map can never trigger it. Free; just acknowledges.
        gb = cv2.imread(GREAT_BUTTON_TEMPLATE_PATH)
        if gb is not None and float(np.percentile(cv2.cvtColor(img[775:885, 1460:1570], cv2.COLOR_BGR2HSV)[:, :, 2], 90)) < 120:
            rg = cv2.matchTemplate(img[640:800, 560:1040], gb, cv2.TM_CCOEFF_NORMED)
            _, gv, _, gl = cv2.minMaxLoc(rg)
            if gv >= 0.80:
                gx = 560 + gl[0] + gb.shape[1] // 2
                gy = 640 + gl[1] + gb.shape[0] // 2
                log(f"'Great!' popup detected (confidence {gv:.2f}) -- tapping Great! at ({gx},{gy}).")
                tap(gx, gy)
                time.sleep(2)
                return True
        # "Event Badge Unlocked!" celebration (single green "Great!" button; animated
        # confetti). Seen live 10/2 covering the nav bar. Free, just tap Great!.
        eb = cv2.imread(EVENT_BADGE_TEMPLATE_PATH)
        if eb is not None:
            re_ = cv2.matchTemplate(img[90:230, 480:1120], eb, cv2.TM_CCOEFF_NORMED)
            _, ev_, _, _ = cv2.minMaxLoc(re_)
            if ev_ >= 0.8:
                log(f"'Event Badge Unlocked' popup detected (confidence {ev_:.2f}) -- tapping Great!.")
                tap(*EVENT_BADGE_OK_LOC)
                time.sleep(2)
                return True
        # "Not enough tokens! Here's how to get more:" (OK / Get more tokens). Seen
        # live 10/2: a blind tap landed on a station's cyan Unlock button (token
        # cost). Just close it with OK -- never "Get more tokens".
        nt = cv2.imread(NOT_ENOUGH_TOKENS_TEMPLATE_PATH)
        if nt is not None:
            rn = cv2.matchTemplate(img[90:240, 380:1220], nt, cv2.TM_CCOEFF_NORMED)
            _, nv, _, _ = cv2.minMaxLoc(rn)
            if nv >= 0.85:
                log(f"'Not enough tokens' popup detected (confidence {nv:.2f}) -- tapping OK "
                    "(never 'Get more tokens').")
                tap(*NOT_ENOUGH_TOKENS_OK_LOC)
                time.sleep(1.5)
                return True
        # "Are you sure you want to discard this order?" (No / Yes). A stray tap on
        # an order card's red trash button opens it (found live 10/2); Yes would
        # black the order out for 30 min. ALWAYS tap No.
        dc = cv2.imread(DISCARD_TEMPLATE_PATH)
        if dc is not None:
            rd = cv2.matchTemplate(img[300:620, 440:1160], dc, cv2.TM_CCOEFF_NORMED)
            _, dv, _, _ = cv2.minMaxLoc(rd)
            if dv >= 0.85:
                log(f"'Discard this order?' dialog detected (confidence {dv:.2f}) -- tapping No.")
                tap(*DISCARD_NO_LOC)
                time.sleep(1.5)
                return True
        # The Prize Tent (Tokens/Treasure/Voucher boxes + Seasonal Pets): its lime
        # "Open" buttons SPEND tokens or GEMS (Treasure Box = 25 gems). It gets
        # opened by a stray centre-tap on the tent building (found live 10/2).
        # Only ever close it with the red X -- never touch Open.
        pt = cv2.imread(PRIZE_TENT_TEMPLATE_PATH)
        if pt is not None:
            rp = cv2.matchTemplate(img[60:180, 560:1040], pt, cv2.TM_CCOEFF_NORMED)
            _, pv, _, _ = cv2.minMaxLoc(rp)
            if pv >= 0.85:
                log(f"Prize Tent panel detected (confidence {pv:.2f}) -- closing it with the X "
                    "(never tapping Open: those spend tokens/gems).")
                tap(*PRIZE_TENT_CLOSE_LOC)
                time.sleep(1.5)
                return True
        # The CLOSED mystery gift box reveal (event milestone reward; no button, you tap
        # the box). Seen live 10/2 stuck here overnight; opening it is free and leads to
        # the "Collect Reward" screen below.
        if is_mystery_box_screen(img):
            log("Closed mystery box reveal detected -- tapping the box to open it.")
            tap(*MYSTERY_BOX_TAP_LOC)
            time.sleep(2.5)
            return True
        # A free "Collect Reward" screen (mystery box / "Milestone Reached!" ...): tap the
        # lime button. Detected structurally (see reward_button_loc) -- the button size varies.
        ox = purchase_offer_x(img)                           # pass 52: a real-money offer popup -- close it with its X, NEVER the price
        if ox is not None:
            log(f"Real-money offer popup (price button) detected -- closing it with its X at {ox}, never the price.")
            _save_stuck_screen("offer")
            tap(*ox)
            time.sleep(1.5)
            return True
        try:                                                 # 10/25 Picked Tree Problem: Ask for Help, never Remove
            import picked_trees
            if picked_trees.handle(img, "popup check", tap=tap, sleep=time.sleep, screenshot=screenshot):
                return True
        except Exception as e:                               # noqa: BLE001
            log(f"picked-tree check failed (ignored): {e!r}")
        rb = reward_button_loc(img)
        if rb is not None:
            rb_ok, rb_label = reward_button_label_ok(img, rb)
            if rb_ok:
                log(f"'Collect Reward' screen detected -- tapping the button at {rb}.")
                tap(*rb)
                time.sleep(2)
                return True
            log(f"'Collect Reward'-looking screen but the button at {rb} reads '{rb_label}' -- NOT tapping (pass 33).")
            _save_stuck_screen("not_reward")
        lb = level_up_button_loc(img, save=_save_stuck_screen)          # pass 84: the level-up rewards screen
        if lb is not None:
            log(f"Level-up rewards screen detected -- tapping its button at {lb} (free reward claim).")
            tap(*lb)
            time.sleep(2)
            return True
        # Android's own "<app> isn't responding" dialog (Close app / Wait) can
        # sit over the game (seen live 10/2: "System UI isn't responding").
        # ALWAYS tap Wait, never Close app.
        anr = cv2.imread(ANR_TEMPLATE_PATH)
        if anr is not None:
            r = cv2.matchTemplate(img[250:750, 300:1300], anr, cv2.TM_CCOEFF_NORMED)
            _, av, _, aloc = cv2.minMaxLoc(r)
            if av >= 0.85:
                wx = 300 + aloc[0] + ANR_WAIT_OFFSET[0]
                wy = 250 + aloc[1] + ANR_WAIT_OFFSET[1]
                log(f"Android 'isn't responding' dialog detected (confidence {av:.2f}) "
                    f"-- tapping Wait at ({wx},{wy}).")
                tap(wx, wy)
                time.sleep(2)
                return True
        res = cv2.matchTemplate(img[120:320, 480:1120], tpl, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, _ = cv2.minMaxLoc(res)
        if max_val < 0.8:
            return False
        log(f"'Whoops! Something went wrong' dialog detected (confidence {max_val:.2f}) "
            "-- tapping OK.")
        tap(*ERROR_WHOOPS_OK_LOC)
        time.sleep(1.5)
        return True
    except cv2.error:
        return False


def dismiss_buy_missing_dialog(img=None):
    """'Buy missing ingredients? [No] [Yes, N gems]' — appears when a
    Produce/Make tap runs into an insufficient ingredient. Discovered
    live 9/24 during map-based navigation testing: this is a real,
    previously-unhandled dialog that would otherwise sit there blocking
    everything, exactly like the other blocking-overlay types. ALWAYS
    tap No — this is a direct gem-spend prompt, covered by the hard
    'never spend gems' rule, no exceptions. Returns True if dismissed."""
    if img is None:
        img = screenshot()
    region = img[380:430, 610:1000]
    res = cv2.matchTemplate(region, BUY_MISSING_TEMPLATE, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, _ = cv2.minMaxLoc(res)
    if max_val < 0.75:
        return False
    log(f"'Buy missing ingredients?' gem-spend prompt detected (confidence "
        f"{max_val:.2f}) — tapping No. Never spending gems, no exceptions.")
    tap(*BUY_MISSING_NO_LOC)
    time.sleep(1)
    return True


def landscape_ok(img):
    """11/12: True for a usable landscape game picture (>= 1580 x 250). A portrait one means an ad is in front."""
    try:
        return img is not None and img.ndim == 3 and img.shape[1] >= 1580 and img.shape[0] >= 250
    except Exception:                                   # noqa: BLE001
        return False


def close_any_open_panel(max_attempts=3, quiet=False, thorough=False):
    """Check for a leftover open panel (from a previous run that crashed,
    got interrupted, or otherwise didn't clean up) and close it. Real bug
    found 9/23: a panel left open silently blocks every subsequent search
    — swipes do nothing while a modal dialog is showing, so the whole map
    looks like a dead-end corner in every direction. Call this at the
    start of every script's main() before searching for anything, and
    (quiet=True, no "not found" logging) inside the search loop whenever
    a hop looks like a boundary — it might actually be this.

    thorough=True adds a full-screen fallback search when the normal
    bounded-region check finds nothing. Added 9/27 for a real leftover
    case: a crop's grow-timer info card (e.g. "Carrot, 14m 4s, Skip [3
    gems]") is a WORLD-SPACE tooltip anchored near wherever the plot was
    tapped, not a fixed-corner dialog like every other panel type this
    function was built around — its close-X can land anywhere on screen
    depending on camera position, not just the bounded top-right region
    every other popup type uses. Only opt into this for callers that
    specifically expect this card type (e.g. Garden Plot flows) — a
    full-screen template search is real extra cost to pay on every single
    call otherwise, most of which find nothing to close at all.
    Returns True if anything was found and closed."""
    # One screenshot shared by the three dialog checks and the first X check (10/17: they used to take
    # four screenshots in a row of the same unchanged screen -- about 3 s wasted on every call).
    shot = screenshot()
    if dismiss_second_device_dialog(shot):
        return True
    if dismiss_error_dialog(shot):
        return True
    if dismiss_buy_missing_dialog(shot):
        return True
    closed_any = False
    # Search a wide region, not one fixed point — confirmed 9/23 that
    # different popup types (a standard station panel vs. a promotional
    # "Premium Pass"/purchase-offer dialog) put their X at genuinely
    # different positions depending on the dialog's own size. A fixed
    # (1541,124) check missed a Premium Pass popup whose X sat at
    # roughly (1287,137), leaving it open and silently blocking
    # everything exactly like the original leftover-panel bug.
    th, tw = CLOSE_X_TEMPLATE.shape[:2]
    for attempt in range(1, max_attempts + 1):
        img, shot = (shot if shot is not None else screenshot()), None
        if not landscape_ok(img):
            # 11/12 (Muse): a portrait picture (an ad left in front turns LDPlayer portrait, 551x980) made the fixed
            # region empty and matchTemplate threw -> every cycle crashed for 3 auto-restart windows in a row.
            # No landscape panel can be open on such a screen.
            return closed_any
        region = img[50:250, 1150:1580]
        res = cv2.matchTemplate(region, CLOSE_X_TEMPLATE, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, max_loc = cv2.minMaxLoc(res)
        if max_val < 0.8:   # genuine X scores 0.90+, the HUD false match 0.71 (pass 2, 10/4)
            if thorough:
                res2 = cv2.matchTemplate(img, CLOSE_X_TEMPLATE, cv2.TM_CCOEFF_NORMED)
                _, max_val2, _, max_loc2 = cv2.minMaxLoc(res2)
                if max_val2 >= 0.8:     # 10/18: real X 0.96-1.00 on 50 saved screens; the HUD at (1327,90) 0.70-0.71
                    #                       cost 3 taps + a 2 MB stuck screenshot ~20x per run at the old 0.7
                    x = max_loc2[0] + tw // 2
                    y = max_loc2[1] + th // 2
                    log(f"Closing a leftover info card at ({x},{y}) (match {max_val2:.2f}).")
                    tap(x, y)
                    time.sleep(1)
                    closed_any = True
                    continue
            if attempt == 1 and not quiet:
                log("No leftover panel detected at startup.")
            return closed_any
        x = 1150 + max_loc[0] + tw // 2
        y = 50 + max_loc[1] + th // 2
        if attempt > 1 or not quiet:                   # 10/17 log diet: closing a station panel is routine
            log(f"Leftover open panel detected at ({x},{y}) (confidence "
                f"{max_val:.2f}) — closing it (attempt {attempt}).")
        tap(x, y)
        time.sleep(1)
        closed_any = True
    log("Still detecting a panel after max close attempts — proceeding anyway.")
    if try_generic_ok_notice():                    # pass 29: an unknown but plainly safe OK notice
        return True
    _save_stuck_screen("stuck_panel")
    return closed_any


def close_any_open_panel_quiet():
    return close_any_open_panel(quiet=True)


def spiral_moves(max_steps):
    directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
    moves = []
    seg_len = 1
    d = 0
    while len(moves) < max_steps:
        for _ in range(2):
            dx, dy = directions[d % 4]
            for _ in range(seg_len):
                moves.append((dx, dy))
                if len(moves) >= max_steps:
                    return moves
            d += 1
        seg_len += 1
    return moves


def find_and_center(find_fn, label="target", zoom_in_after=True, stop_flag=None, trail=None,
                    max_sec=None, probe_min=None, skip_zoom_at=None):
    # 11/9 (Muse truck-search proposal, truck only -- the defaults keep every other search as it was):
    # max_sec = give the spiral up after this long; probe_min = only probe partial matches this strong;
    # skip_zoom_at = no final zoom-in when the match is already this strong ("Lost after zooming in" 3 of 3).
    """find_fn(img, fast=False) -> (loc, confidence) or (None, confidence).
    Returns (final_loc, final_confidence) — final_loc is None if the
    whole process failed. Logs every step, including timing, since the
    match itself turned out to be the real bottleneck (~4.2s/call at
    full resolution) — search/centering use fast=True (downsampled,
    coarser scale list) to keep each hop to well under a second; only
    the final post-zoom-in confirmation uses full precision.

    stop_flag, if given (a threading.Event), is checked at the top of
    every loop iteration and every sleep — raises StopRequested to
    unwind immediately instead of finishing the current multi-second
    search/centering pass first. Callers should catch StopRequested.

    trail, if given (a list), records the camera moves made at max zoom-out: "zoomout" when the
    zoom-out happens, then (finger_dx, finger_dy) per search/centering swipe that moved the map.
    The street truck uses it to remember the way back from a fast-travel trip (10/17)."""
    raw_find_fn = find_fn

    def find_fn(img, fast=False):
        """Wraps the caller's find_fn: rejects any match landing in a
        fixed HUD zone before it can be trusted. A real world-space
        station can never actually be there — confirmed 9/23, a Dairy
        false positive at (1532,124)/(1412,175) (right where event-
        countdown badges live) got treated as real and opened the wrong
        panel entirely. Applied once here so every call site in this
        function gets the filter automatically."""
        loc, conf = raw_find_fn(img, fast=fast)
        if loc is not None and in_hud_zone(loc):
            log(f"  (rejecting match at {loc} — inside a fixed HUD zone, "
                f"not a plausible world-space location; conf was {conf:.2f})")
            return None, conf
        return loc, conf

    log(f"--- find_and_center({label}) start ---")
    t_start = time.time()
    check_stop(stop_flag)

    # First draft of map-based navigation (9/24): try the cached position
    # from the last time this station was confirmed, before paying for a
    # full search. Always re-confirmed with a real detection — a stale
    # cache just falls through to the normal flow below, it never blocks it.
    hint_result = world_map.try_hint(find_fn, label)
    if hint_result is not None:
        loc, conf = hint_result
        log(f"Skipping search — map cache hit for {label} at {loc} (confidence {conf:.2f}).")
    else:
        img = screenshot()
        loc, conf = find_fn(img, fast=True)
        log(f"Initial check: {label} {'found at ' + str(loc) if loc else 'not found'} (confidence {conf:.2f})")

    last_zoom_diff = None
    if loc is None:
        log(f"Zooming out to widen the search for {label}...")
        # Measured 9/23: one pinch reliably maxes out zoom when starting
        # from a "just zoomed in" state (diff ~54), but a single relative
        # pinch isn't guaranteed sufficient from an arbitrary starting
        # zoom. Keep zooming out until the frame stops changing much
        # (i.e. we've hit the game's zoom-out limit), instead of assuming
        # one call is always enough — bounded to avoid looping forever.
        for zoom_attempt in range(1, 4):
            check_stop(stop_flag)
            before = screenshot()
            pinch(800, 450, 350, 80, steps=15)
            interruptible_sleep(1, stop_flag)
            after = screenshot()
            d = frame_diff(before, after)
            last_zoom_diff = d
            log(f"  zoom-out attempt {zoom_attempt}: frame diff {d:.1f}")
            if d < 15.0:
                log(f"  Reached max zoom-out after {zoom_attempt} attempt(s).")
                break
        img = after
        if trail is not None:
            trail.append("zoomout")
        loc, conf = find_fn(img, fast=True)
        log(f"After zoom-out: {label} {'found at ' + str(loc) if loc else 'not found'} (confidence {conf:.2f})")

    probe_zoomed = False
    if loc is None:
        log(f"Spiral-searching for {label} (up to {MAX_SEARCH_STEPS} hops)...")
        cx, cy = 900, 450
        exhausted_directions = set()  # directions that hit a map edge (no-op hop)
        skipped = 0
        prev_img = img
        conf_trail = []  # every real (non-skipped) step's confidence -- added
                          # 9/27 after a log review of a bad unattended stretch
                          # found ~90 full-search failures with no way to tell,
                          # after the fact, whether a given failure was "close
                          # the whole time" (steadily near-threshold) or
                          # "totally lost" (near-zero throughout) without
                          # rereading every single step line by hand
        probe_at = PROBE_THRESHOLD if probe_min is None else probe_min
        for i, (dx, dy) in enumerate(spiral_moves(MAX_SEARCH_STEPS), 1):
            check_stop(stop_flag)
            if max_sec and time.time() - t_start > max_sec:
                log(f"{label}: spiral search timed out after {time.time()-t_start:.0f}s (limit {max_sec:.0f}s, step "
                    f"{i}/{MAX_SEARCH_STEPS}, best confidence {max(conf_trail or [0]):.2f}) -- giving up for now.")
                return None, max(conf_trail or [0])
            if (dx, dy) in exhausted_directions:
                skipped += 1
                continue
            t0 = time.time()
            swipe(cx, cy, cx + dx * SEARCH_HOP_PX, cy + dy * SEARCH_HOP_PX, 500)
            interruptible_sleep(0.7, stop_flag)
            img = screenshot()
            if not frame_changed(prev_img, img):
                # Could be a genuine map boundary — but could also be the
                # second-device dialog, the buy-missing-ingredients gem
                # prompt, or a leftover panel silently blocking ALL input,
                # which looks identical (0 frame diff in every direction).
                # close_any_open_panel_quiet() checks for all of those.
                # Check and dismiss before concluding it's a real boundary,
                # so one blocking dialog doesn't get misread as being
                # cornered on all 4 sides at once.
                if close_any_open_panel_quiet():
                    log(f"  step {i}/{MAX_SEARCH_STEPS} dir=({dx:+d},{dy:+d}) — "
                        "was actually a blocking dialog, not a boundary. "
                        "Dismissed, retrying this direction.")
                    prev_img = screenshot()
                    continue
                exhausted_directions.add((dx, dy))
                log(f"  step {i}/{MAX_SEARCH_STEPS} dir=({dx:+d},{dy:+d}) — "
                    "no visual change, hit a map boundary. Skipping this "
                    "direction for the rest of the search.")
                continue
            prev_img = img
            if trail is not None and not probe_zoomed:
                trail.append((dx * SEARCH_HOP_PX, dy * SEARCH_HOP_PX))
            loc, conf = find_fn(img, fast=True)
            conf_trail.append(conf)
            log(f"  step {i}/{MAX_SEARCH_STEPS} dir=({dx:+d},{dy:+d}) "
                f"conf={conf:.2f} ({time.time()-t0:.1f}s)")
            if loc is not None:
                log(f"Found {label} on search step {i}/{MAX_SEARCH_STEPS} "
                    f"at {loc} (confidence {conf:.2f})")
                break
            if conf >= probe_at:
                # A partial match this strong is likely the real thing,
                # just too small/distant to clear full threshold, or
                # transiently blocked by a walking NPC/animation. Worth a
                # closer look before writing this spot off — wait briefly
                # (lets NPCs move on) and re-check, then zoom in for a
                # clearer view if it's still promising.
                log(f"  step {i}/{MAX_SEARCH_STEPS}: partial match "
                    f"(conf={conf:.2f}) — probing closer before moving on.")
                interruptible_sleep(1.2, stop_flag)
                recheck_img = screenshot()
                recheck_loc, recheck_conf = find_fn(recheck_img, fast=True)
                if recheck_loc is None and recheck_conf >= probe_at:
                    log(f"  Still promising after wait (conf={recheck_conf:.2f}) "
                        "— zooming in to verify.")
                    pinch(800, 450, 80, 300, steps=15)
                    interruptible_sleep(1, stop_flag)
                    zoomed_img = screenshot()
                    zoom_loc, zoom_conf = find_fn(zoomed_img, fast=False)
                    if zoom_loc is not None:
                        log(f"  Probe confirmed {label} after zoom-in "
                            f"(confidence {zoom_conf:.2f}).")
                        loc, conf = zoom_loc, zoom_conf
                        probe_zoomed = True
                        break
                    log(f"  Probe zoom-in didn't confirm it (conf={zoom_conf:.2f}) "
                        "— zooming back out and continuing the search.")
                    pinch(800, 450, 350, 80, steps=15)
                    interruptible_sleep(1, stop_flag)
                    prev_img = screenshot()
                elif recheck_loc is not None:
                    log(f"  Resolved on recheck without needing to zoom "
                        f"(confidence {recheck_conf:.2f}).")
                    loc, conf = recheck_loc, recheck_conf
                    break
        else:
            if conf_trail:
                trail_str = ",".join(f"{c:.2f}" for c in conf_trail)
                trail_summary = (f"trail: [{trail_str}] (min={min(conf_trail):.2f} "
                                  f"max={max(conf_trail):.2f})")
            else:
                trail_summary = "trail: (no real steps -- every direction was skipped/exhausted)"
            log(f"{label} not found after {MAX_SEARCH_STEPS} search steps "
                f"({skipped} skipped as exhausted directions: "
                f"{exhausted_directions}) (best confidence {conf:.2f}). {trail_summary} "
                f"Giving up after {time.time()-t_start:.0f}s total.")
            return None, conf

    # --- Centering phase ---
    for hop_i in range(1, MAX_CENTER_HOPS + 1):
        check_stop(stop_flag)
        dx = SCREEN_CENTER[0] - loc[0]
        dy = SCREEN_CENTER[1] - loc[1]
        dist = math.hypot(dx, dy)
        log(f"Centering hop {hop_i}: {label} at {loc}, offset from center "
            f"({dx:+.0f},{dy:+.0f}), distance {dist:.0f}px")
        if dist <= CENTER_TOLERANCE:
            log(f"{label} is close enough to center (within {CENTER_TOLERANCE}px). Done centering.")
            break
        hop = min(dist, HOP_CAP_PX)
        ux, uy = dx / dist, dy / dist
        start = (900, 450)
        end = (int(900 + ux * hop), int(450 + uy * hop))
        swipe(start[0], start[1], end[0], end[1], 500)
        if trail is not None and not probe_zoomed:
            trail.append((end[0] - start[0], end[1] - start[1]))
        interruptible_sleep(0.8, stop_flag)
        img = screenshot()
        new_loc, new_conf = find_fn(img, fast=True)
        if new_loc is None:
            log(f"Lost {label} after centering hop {hop_i} (was at {loc}, "
                f"tried to shift by ({ux*hop:+.0f},{uy*hop:+.0f})). "
                "Stopping centering, will use last known position.")
            break
        loc, conf = new_loc, new_conf
    else:
        log(f"Reached max centering hops ({MAX_CENTER_HOPS}) without fully "
            f"centering {label} — proceeding with best-effort position {loc}.")

    if not zoom_in_after or (skip_zoom_at is not None and not probe_zoomed and conf >= skip_zoom_at):
        if zoom_in_after:
            log(f"{label} match is already strong ({conf:.2f}) -- skipping the final zoom-in.")
        world_map.record_sighting(label, loc, conf, last_zoom_diff)
        log(f"--- find_and_center({label}) end (no zoom-in requested), "
            f"{time.time()-t_start:.0f}s total ---")
        return loc, conf

    # --- Zoom-in phase: same relative zoom every time, from a now-
    # centered view, so the final scale is far more consistent than
    # whatever arbitrary zoom we started the whole process at. This
    # final check uses full precision (fast=False). Skipped if a probe
    # during the search already zoomed in — doing it twice would
    # over-zoom past a usable view. ---
    check_stop(stop_flag)
    if probe_zoomed:
        log(f"Already zoomed in during the probe — doing a final "
            "full-precision confirmation without zooming again.")
        img = screenshot()
        final_loc, final_conf = find_fn(img, fast=False)
    else:
        log(f"Zooming in for a precise final fix on {label}...")
        pinch(800, 450, 80, 300, steps=15)
        interruptible_sleep(1, stop_flag)
        img = screenshot()
        final_loc, final_conf = find_fn(img, fast=False)
    if final_loc is None:
        world_map.record_sighting(label, loc, conf, last_zoom_diff)
        log(f"Lost {label} after zooming in — falling back to the last "
            f"centered (pre-zoom) position {loc} instead.")
        log(f"--- find_and_center({label}) end (fallback), "
            f"{time.time()-t_start:.0f}s total ---")
        return loc, conf
    world_map.record_sighting(label, final_loc, final_conf, last_zoom_diff)
    log(f"Final position after zoom-in: {final_loc} (confidence {final_conf:.2f})")
    log(f"--- find_and_center({label}) end, {time.time()-t_start:.0f}s total ---")
    return final_loc, final_conf
