"""W.O.R.T.H. -- Watch Or Run Time Helper (owner 11/2: "a log only test to decide if we would save time by watching
the ad or if we need to wait and keep going on to other ingredients and stoves").

LOG ONLY. Whenever the bot meets a timer an ad could skip (a growing plot, a batch of ours cooking), it writes what it
WOULD do and why. Taps nothing, watches nothing. The pure parts (decide, pass_busy, summary) are tested offline."""
import time

ON = True
AD_COST_SEC = 120          # bot time one ad costs (live 11/2: 80-240 s with recovery; owner by hand 30-45 s)
EXPRESS_MIN_SEC = 60       # during an express an ad is worth it once the timer beats this
LOG_GAP_SEC = 300          # the same timer is logged (and counted) at most once per 5 min
SUMMARY_GAP_SEC = 900        # auto restart every 30 min reloads this module -- keep it under that

BUSY_WORDS = ("queued", "planted", "served", "collected", "learned", "harvest", "recursed:recursed")
_last_pass = {"t": 0.0, "busy": None}
_seen = {}
_tally = {"t0": time.time(), "timers": 0, "watch": 0, "watch_x": 0, "saved": 0.0, "skip_busy": 0, "skip_short": 0}
_summary_t = [time.time()]


def _log(msg):
    try:
        import event_orders
        event_orders.log(msg)
    except Exception:                                   # noqa: BLE001
        print(msg)


def pass_busy(results):
    """Did a board pass do useful work (queue / plant / collect / serve)? Pure."""
    return any(any(w in str(r.get("status", "")) for w in BUSY_WORDS) for r in results or [])


def note_pass(results, now=None):
    """End of every Food Club pass: remember whether there was other work to do."""
    _last_pass.update(t=time.time() if now is None else now, busy=pass_busy(results))


def decide(secs_left, express, other_work, ad_cost=AD_COST_SEC):
    """-> (verdict 'watch'/'skip', minutes saved, reason). Pure, tested."""
    if not secs_left or secs_left <= 0:
        return "skip", 0.0, "no time left to skip"
    if express:
        if secs_left >= EXPRESS_MIN_SEC:
            return "watch", max(0.0, secs_left - min(ad_cost, secs_left) / 2) / 60, "an express is waiting on it"
        return "skip", 0.0, f"express, but only {secs_left} s left"
    if other_work:
        return "skip", 0.0, "other stoves/ingredients had work -- the bot keeps busy while it cooks"
    if secs_left > ad_cost:
        return "watch", (secs_left - ad_cost) / 60, "nothing else to do while it cooks"
    return "skip", 0.0, f"the ad (~{ad_cost // 60}m{ad_cost % 60:02d}s) takes longer than the {secs_left} s left"


def note_timer(what, secs_left, express=False, now=None):
    """A timer the bot just saw. Logs at most once per LOG_GAP_SEC per timer."""
    if not ON or secs_left is None:
        return None
    now = time.time() if now is None else now
    if now - _seen.get(what, 0) < LOG_GAP_SEC:
        return None
    _seen[what] = now
    other = bool(_last_pass["busy"]) and now - _last_pass["t"] < 600
    verdict, saved, why = decide(int(secs_left), express, other)
    _tally["timers"] += 1
    if verdict == "watch":
        _tally["watch"] += 1
        _tally["watch_x"] += 1 if express else 0
        _tally["saved"] += saved
        _log(f"[worth] {what}: {int(secs_left) // 60}m{int(secs_left) % 60:02d}s left -- WOULD watch an ad: {why}, "
             f"saves ~{saved:.1f} min")
    else:
        _tally["skip_busy" if other else "skip_short"] += 1
        _log(f"[worth] {what}: {int(secs_left) // 60}m{int(secs_left) % 60:02d}s left -- would NOT watch: {why}")
    _maybe_summary(now)
    return verdict


def summary(t=None):
    t = _tally if t is None else t
    mins = max(1, int((time.time() - t["t0"]) // 60))
    return (f"[worth] last {mins} min: {t['timers']} timers seen, an ad WOULD have helped {t['watch']}x "
            f"({t['watch_x']} during expresses), saving ~{t['saved']:.0f} min; skipped {t['skip_busy']}x (other work) "
            f"+ {t['skip_short']}x (too short); ad cost assumed {AD_COST_SEC} s")


def _maybe_summary(now):
    if now - _summary_t[0] >= SUMMARY_GAP_SEC and _tally["timers"]:
        _summary_t[0] = now
        _log(summary())
        _tally.update(t0=now, timers=0, watch=0, watch_x=0, saved=0.0, skip_busy=0, skip_short=0)
