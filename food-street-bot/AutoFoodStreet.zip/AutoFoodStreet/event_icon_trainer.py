"""event_icon_trainer.py -- teach AFSD a new Food Club event icon (10/15).

Each new event (or season) draws a different icon in the bottom bar, and the bot finds the
event by a picture of it: templates/event_board_icon.png. This replaces that picture from a
fresh screenshot: the owner clicks the new icon in the "New event icon" window and the
70x68 crop around the click becomes the new template. The old picture is kept as a backup.

The crop is centred on the click, so event_orders.BOARD_ICON_TAP_OFFSET (35, 34) -- the
middle of a 70x68 template -- taps exactly where the owner clicked.
"""
import os
import time

import cv2

import event_orders

ICON_W, ICON_H = 70, 68
REGION = event_orders.BOARD_ICON_REGION            # x1, y1, x2, y2 of the bottom event-icon bar


def bar_picture(img):
    """The bottom-bar strip shown in the trainer window."""
    x1, y1, x2, y2 = REGION
    return img[y1:y2, x1:x2]


def crop_at(img, x, y):
    """70x68 crop centred on full-screen (x, y), or None if it would leave the event-icon bar."""
    left, top = x - ICON_W // 2, y - ICON_H // 2
    x1, y1, x2, y2 = REGION
    if left < x1 or top < y1 or left + ICON_W > x2 or top + ICON_H > y2:
        return None
    return img[top:top + ICON_H, left:left + ICON_W].copy()


def save_icon(img, x, y):
    """Saves the crop at (x, y) as the new event icon. Returns (ok, message)."""
    crop = crop_at(img, x, y)
    if crop is None:
        return False, "Too close to the edge of the bar -- click the middle of the event icon."
    path = event_orders.BOARD_ICON_TEMPLATE
    backup = None
    if os.path.exists(path):
        stem = path.replace(".png", time.strftime("_backup_%Y%m%d_%H%M%S"))
        backup, n = stem + ".png", 1
        while os.path.exists(backup):                      # two saves in one second: never overwrite a backup
            n += 1
            backup = f"{stem}_{n}.png"
        os.replace(path, backup)
    cv2.imwrite(path, crop)
    try:
        import event_icon_search
        event_icon_search.reset()                          # 11/12: a trained icon ends any rest of the auto search
    except Exception:                                      # noqa: BLE001
        pass
    # Check the bot now finds it: on this very screenshot the tap must land where the owner clicked.
    found = event_orders.find_board_icon(img)
    note = f" (old picture kept as {os.path.basename(backup)})" if backup else ""
    if found and abs(found[0] - x) <= 6 and abs(found[1] - y) <= 6:
        return True, f"New event icon saved{note}. The bot will tap it at {found}."
    if found is None:
        return True, (f"New event icon saved{note}, but the screen behind it looks dimmed (a popup?), so the bot "
                      "could not test it here. Close popups and try again if the bot cannot open the event.")
    return True, (f"New event icon saved{note}, but the test found it at {found}, not where you clicked. "
                  "If the bot taps the wrong icon, use the button again and click the event icon's middle.")
