"""unbuilt.py -- dishes whose station is not built yet (owner 10/25).

The game puts orders on the clipboard for dishes made at stations the owner has not bought (10/25: "Chicken
Enchiladas" from the Taqueria, 39,000 coins in the shop). Tapping the item shows "Get <dish> from the <station>"; its
"?" then opens the SHOP (the build menu, Stoves tab) instead of fast-travelling. Owner's rule: learn the dish by
itself (name from the tooltip, picture from the order), mark it impossible and dismiss the order right away; every
later order with that dish is dismissed on sight, without tapping. New stoves will keep adding dishes, so nothing is
hand-trained here. Owner 10/25 ("worried it will keep skipping the dish after I bought the stove"): a mark lasts
RECHECK_SEC (30 min) and every Start forgets all marks (forget_all); the next sighting then taps the "?" again -- if it
travels, the station has been built and the dish is left to the normal learning. Pictures and names are kept.
"""
import datetime
import json
import os
import re
import time

import cv2
import numpy as np

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(BASE_DIR, "run_log.txt")
TPL_DIR = os.path.join(BASE_DIR, "templates", "unbuilt")
STATE = os.path.join(BASE_DIR, ".unbuilt_dishes.json")
SHOP_TAB = "shop_stoves_tab.png"           # the shop's "Stoves" category button (cut 10/25, badge left out)
SHOP_REGION = (350, 0, 650, 250)           # x1, y1, x2, y2 it is searched in (live at 438-528, 58-150)
SHOP_MIN = 0.8                             # 1.00 on the shop, <= 0.43 on 586 other saved screens
SHOP_CLOSE_X = (505, 825)                  # the shop's red X (bottom of the category column)
ICON_MIN = 0.85                            # a board icon counts as a known unbuilt dish at this match
RECHECK_SEC = 30 * 60                      # owner 10/25: re-check every 30 min (and every Start, see forget_all)
TOOLTIP_THE_RE = re.compile(r"get\s+(.+)\s+fr\S{0,4}\s+(?:the|tne)\s+(.+)", re.I)
TOOLTIP_RE = re.compile(r"get\s+(.+?)\s+fr\S{0,4}\s+(?:the\s+)?(.+)", re.I)   # 10/26 live OCR: "fr\ufffdll the"


def log(msg):
    try:
        with open(LOG, "a", encoding="utf-8") as fh:
            fh.write(f"[{datetime.datetime.now().isoformat(timespec='seconds')}] [unbuilt] {msg}\n")
    except OSError:
        pass


def _load():
    try:
        with open(STATE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def _save(st):
    try:
        with open(STATE, "w", encoding="utf-8") as fh:
            json.dump(st, fh, indent=1)
    except OSError:
        pass


def _key(name):
    return re.sub(r"[^a-z0-9]+", "_", (name or "").lower()).strip("_")


def parse_tooltip(text):
    """'Get Chicken Enchiladas from the Taqueria' -> ('Chicken Enchiladas', 'Taqueria'), else None."""
    t = " ".join((text or "").split())
    # 10/28 live: "Get Vegetarian Stir Fry from the Wok Station" -> "Fry" passed as the from-word. Prefer a
    # from-word followed by "the" (the LAST one), fall back to the loose pattern only when there is none.
    m = TOOLTIP_THE_RE.search(t) or TOOLTIP_RE.search(t)
    if not m:
        return None
    return m.group(1).strip(" .,"), m.group(2).strip(" .,")


_tab = []


def is_shop(img):
    if img is None or img.shape[:2] != (900, 1600):
        return False
    if not _tab:
        _tab.append(cv2.imread(os.path.join(TPL_DIR, SHOP_TAB)))
    if _tab[0] is None:
        return False
    x1, y1, x2, y2 = SHOP_REGION
    return cv2.minMaxLoc(cv2.matchTemplate(img[y1:y2, x1:x2], _tab[0], cv2.TM_CCOEFF_NORMED))[1] >= SHOP_MIN


def _vec(icon):
    g = cv2.resize(icon, (48, 48), interpolation=cv2.INTER_AREA).astype(np.float32)
    g = (g - g.mean()) / (g.std() + 1e-6)
    return g.ravel() / (np.linalg.norm(g) + 1e-6)


def match_icon(icon):
    """The learned unbuilt dish this board icon shows (still inside its RECHECK_SEC), or None."""
    if icon is None or icon.size == 0:
        return None
    st = _load()
    v = _vec(icon)
    best, bs = None, 0.0
    for k, e in st.items():
        if e.get("until", 0) < time.time():
            continue
        for p in e.get("icons", []):
            t = cv2.imread(os.path.join(BASE_DIR, p))
            if t is not None:
                s = float(v @ _vec(t))
                if s > bs:
                    best, bs = e, s
    return best if bs >= ICON_MIN else None


def learn(dish, station, icon):
    """Remember `dish` as needing the unbuilt `station`; keep its order picture for matching later sightings."""
    st = _load()
    k = _key(dish)
    e = st.setdefault(k, {"name": dish, "station": station, "icons": [], "seen": 0})
    e.update(name=dish, station=station, until=time.time() + RECHECK_SEC, last=time.time())
    e["seen"] = e.get("seen", 0) + 1
    if icon is not None and icon.size and match_icon(icon) is None and len(e["icons"]) < 6:
        os.makedirs(TPL_DIR, exist_ok=True)
        p = os.path.join(TPL_DIR, f"{k}__{int(time.time())}.png")
        cv2.imwrite(p, icon)
        e["icons"].append(os.path.relpath(p, BASE_DIR))
    _save(st)
    log(f"LEARNED: '{dish}' needs the {station}, which is not built (its '?' opened the shop) -- orders with it are "
        f"dismissed on sight until {time.strftime('%a %H:%M', time.localtime(e['until']))}, then checked again.")
    return e


def forget_all():
    """Called at every Start: all marks expire, so each dish gets its '?' checked again (the pictures stay)."""
    st = _load()
    if st:
        for e in st.values():
            e["until"] = 0
        _save(st)
        log(f"Start: forgot the 'not built' marks ({', '.join(e['name'] for e in st.values())}) -- each will be "
            "checked again on its next order.")


def seen(e):
    st = _load()
    k = _key(e.get("name"))
    if k in st:
        st[k]["seen"] = st[k].get("seen", 0) + 1
        st[k]["last"] = time.time()
        _save(st)


def summary():
    st = _load()
    return ", ".join(f"{e['name']} ({e['station']}, seen {e.get('seen', 0)}x)" for e in st.values()) or "none"
