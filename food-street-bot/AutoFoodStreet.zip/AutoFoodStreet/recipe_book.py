"""The recipe book + order cost calculator (built 10/4). NOTHING here touches the game.

recipes.json is the book: every item (dish, crop, animal product, fruit, fish ...) with the station
that makes it, how long one batch takes (cook_sec), how many units a batch yields, and what one batch
consumes. `stations` says how many batches each station can run at once (slots).

Given an order (items + quantities) and what is already in stock, the calculator works out:
  * wall   - how long until the whole order could be finished (the longest chain of waiting, but never
             faster than the busiest station allows: busy time / slots)
  * work   - every batch of everything added up (total machine time)
  * to_make - how many batches of each item, and at which station
  * to_get  - the raw things (crops, fruit, ...) that have to come from the garden / trees / animals
  * unknown - True when some needed time is not recorded (it is counted as 0, so the result is "at least")
and a score = coins per minute of wall time.

Command line:
  python recipe_book.py list
  python recipe_book.py cost "pancakes:2,bread" --stock "wheat=3,egg=1" --coins 138
"""
import json
import math
import os
import re
import sys

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BOOK_PATH = os.path.join(BASE_DIR, "recipes.json")
_book = None


LEARNED_PATH = os.path.join(BASE_DIR, "recipes_learned.json")   # 10/28: dishes the bot learned by itself (PC only;
                                                                # an Update never overwrites this file)


MAX_LEARNED_COOK_SEC = 12 * 3600


def load(path=BOOK_PATH, force=False):
    global _book
    if _book is None or force:
        with open(path, encoding="utf-8") as f:
            _book = json.load(f)
        try:                                       # learned items fill gaps only -- the hand-made book always wins
            with open(LEARNED_PATH, encoding="utf-8") as f:
                aliases = _book.get("aliases", {})
                for k, it in json.load(f).get("items", {}).items():
                    if it.get("ingredients"):      # 10/31: learned "Cream" is the book's Whipped Cream (alias)
                        it = dict(it, ingredients=[[aliases.get(i, i), n] for i, n in it["ingredients"]])
                    if k not in _book["items"] and k not in aliases:
                        st = re.sub(r"^(?:fr\S{0,4}\s+)?(?:the|tne)\s+", "", (it.get("station") or "").strip(), flags=re.I)
                        it = dict(it, station=st or it.get("station"))   # 10/28: "from the Wok Station" was saved
                        if st and st not in _book["stations"]:     # 11/8: OCR slip "Pia Pen" -> the book's "Pig Pen"
                            import difflib
                            near = difflib.get_close_matches(st, list(_book["stations"]), n=1, cutoff=0.75)
                            if near:
                                it = dict(it, station=near[0])
                        if (it.get("cook_sec") or 0) > MAX_LEARNED_COOK_SEC:   # 11/6: a misread cook time
                            it = dict(it, cook_sec=None)                   # (pie ~357 h) = "not read", not believed
                        _book["items"][k] = dict(it, learned=True)
                        _book["stations"].setdefault(it.get("station") or "?", {"slots": 3})
        except (OSError, ValueError):
            pass
    return _book


def add_learned(key, item):
    """10/28: save a learned item to recipes_learned.json and reload the book."""
    try:
        with open(LEARNED_PATH, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {"items": {}}
    data.setdefault("items", {})[key] = item
    with open(LEARNED_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)
    load(force=True)


def resolve(name):
    """Item key from a key, a display name, or an alias (case/space/underscore insensitive)."""
    b = load()
    norm = re.sub(r"[^a-z0-9]+", "_", str(name).strip().lower()).strip("_")
    if norm in b["items"]:
        return norm
    if norm in b["aliases"]:
        return b["aliases"][norm]
    for key, it in b["items"].items():
        if re.sub(r"[^a-z0-9]+", "_", it["name"].lower()).strip("_") == norm:
            return key
    raise KeyError(f"unknown item: {name!r}")


def station_slots(station):
    return max(1, int(load()["stations"].get(station, {}).get("slots", 3)))


def cost(order, stock=None, use_slots=True):
    """order: {item: qty}; stock: {item: qty on hand}. Returns a dict (see module docstring)."""
    b = load()
    items = b["items"]
    stock = {resolve(k): int(v) for k, v in (stock or {}).items()}
    busy = {}                      # station -> seconds of batch time
    batches_by_item = {}
    got = {}                       # raw item -> units that must be obtained
    unknown = set()
    start_stock = dict(stock)
    detail = {}                    # item -> {needed, from_stock, produce, batches}  (first-visit order kept)

    def make(key, qty):
        key = resolve(key)
        have = stock.get(key, 0)
        use = min(have, qty)
        stock[key] = have - use
        need = qty - use
        d = detail.setdefault(key, {"needed": 0, "from_stock": 0, "produce": 0, "batches": 0})
        d["needed"] += qty
        d["from_stock"] += use
        if need <= 0:
            return 0
        it = items[key]
        yld = max(1, int(it.get("yield", 1)))
        n_batches = math.ceil(need / yld)
        d["produce"] += need
        d["batches"] += n_batches
        stock[key] = stock.get(key, 0) + n_batches * yld - need        # leftovers stay in stock
        ready = 0
        for ik, cnt in it["ingredients"]:
            ready = max(ready, make(ik, int(cnt) * n_batches))
        cook = it.get("cook_sec")
        if cook is None:
            unknown.add(key)
            cook = 0
        slots = station_slots(it["station"]) if use_slots else 10 ** 6
        rounds = math.ceil(n_batches / slots)
        busy[it["station"]] = busy.get(it["station"], 0) + n_batches * cook
        batches_by_item[key] = batches_by_item.get(key, 0) + n_batches
        if not it["ingredients"]:
            got[key] = got.get(key, 0) + n_batches * yld
        return ready + rounds * cook

    chain = 0
    for k, q in order.items():
        chain = max(chain, make(k, int(q)))
    station_floor = max((busy[s] / station_slots(s) for s in busy), default=0) if use_slots else 0
    wall = max(chain, station_floor)
    work = sum(busy.values())
    return {"wall": wall, "chain": chain, "work": work, "busy": busy,
            "to_make": {k: {"batches": n, "station": items[k]["station"], "cook_sec": items[k].get("cook_sec")}
                        for k, n in batches_by_item.items() if items[k]["ingredients"]},
            "to_get": got, "unknown": sorted(unknown), "detail": detail, "start_stock": start_stock}


def scratch(key, use_slots=False):
    """(all-at-once seconds, one-at-a-time seconds, has_unknown) for ONE unit of an item from nothing."""
    r = cost({key: 1}, use_slots=use_slots)
    return r["wall"], r["work"], bool(r["unknown"])


def score(coins, wall_sec):
    """Coins per minute of wall time (None if the time is zero, i.e. everything is already in stock)."""
    if not wall_sec:
        return None
    return coins / (wall_sec / 60.0)


def fmt(sec):
    sec = int(round(sec))
    if sec <= 0:
        return "0"
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    parts = ([f"{h}h"] if h else []) + ([f"{m}m"] if m else []) + ([f"{s}s"] if s and not h else [])
    return " ".join(parts) or "0"


def parse_pairs(text, sep):
    out = {}
    for part in [p for p in re.split(r"[,;]", text or "") if p.strip()]:
        if sep in part:
            k, v = part.rsplit(sep, 1)
            out[resolve(k)] = int(v)
        else:
            out[resolve(part)] = 1
    return out


def report(order, stock=None, coins=None):
    b = load()
    r = cost(order, stock)
    lines = []
    lines.append("Order: " + ", ".join(f"{b['items'][k]['name']} x{q}" for k, q in order.items()))
    star = ">= " if r["unknown"] else ""
    lines.append(f"Time to finish: {star}{fmt(r['wall'])}   (total machine time {star}{fmt(r['work'])})")
    if coins is not None:
        sc = score(coins, r["wall"])
        lines.append(f"Reward {coins} coins -> score " + ("n/a (nothing to make)" if sc is None else
                     f"{sc:.1f} coins/minute ({sc * 60:.0f}/hour)"))
    VERB = {"Garden Plot": "grow", "Fruit trees and bushes": "pick", "Lemon Tree": "pick",
            "Fisherman's Boat": "catch"}
    lines.append("")
    lines.append("Everything involved (need / already have / still to do):")
    for k, d in r["detail"].items():
        it = b["items"][k]
        verb = VERB.get(it["station"], "make")
        have_txt = f"have {d['from_stock']}" if d["from_stock"] else "have none used"
        if d["produce"]:
            ct = "time ?" if it.get("cook_sec") is None else fmt(it["cook_sec"])
            todo = f"{verb} {d['produce']} more ({d['batches']} batch{'es' if d['batches'] != 1 else ''} at {it['station']}, {ct} each)"
        else:
            todo = "covered by what you have"
        lines.append(f"  {it['name']:22s} need {d['needed']:>3}   {have_txt:14s}  ->  {todo}")
    random_items = [b["items"][k]["name"] for k in r["to_make"] if "random" in b["items"][k].get("note", "")]
    if random_items:
        lines.append("Careful: " + ", ".join(random_items) + " gives a RANDOM result, so the real time can be longer.")
    if r["unknown"]:
        lines.append("Time not recorded for: " + ", ".join(b["items"][k]["name"] for k in r["unknown"]))
    return "\n".join(lines)


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args or args[0] == "list":
        for k, it in load()["items"].items():
            ct = "?" if it["cook_sec"] is None else fmt(it["cook_sec"])
            print(f"{k:22s} {it['name']:26s} {it['station']:24s} {ct:>8s}  " +
                  ", ".join(f"{i}x{c}" for i, c in it["ingredients"]))
    elif args[0] == "cost":
        stock, coins = {}, None
        if "--stock" in args:
            stock = parse_pairs(args[args.index("--stock") + 1], "=")
        if "--coins" in args:
            coins = float(args[args.index("--coins") + 1])
        print(report(parse_pairs(args[1], ":"), stock, coins))
