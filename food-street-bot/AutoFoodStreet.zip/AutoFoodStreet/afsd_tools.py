"""Send logs / Update / update check, run inside AFSD instead of in black console windows (10/18, owner).

Same steps as tools/send_logs_to_claude.bat and tools/get_afsd_update.bat (those stay as a manual fallback).
Every function takes `progress(text, fraction)` and returns (ok, message). Never touches the game."""
import datetime
import hashlib
import os
import re
import shutil
import subprocess
import time

BOT = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(BOT, "run_log.txt")
# What an update installs: code, notes, tools, item library. NOT settings, trained icon, logs or screenshots.
UPDATE_PATHS = [":(glob)*.py", ".gitignore", "recipes.json",     # 10/25: the recipe book (Muse P7 fixes)
                "CLAUDE.md", ":(glob)SESSION_*.md", "tools",
                "templates/plant_bar_library", "templates/time_labels", "templates/station_pics", "templates/pier_prize",
                "templates/stock_digits", "templates/event_icons", "templates/crops",  # 11/12: event board icons; 11/15 C.R.O.P.S. box
                      # 10/20: the stock-box digit shapes -- never reached the PC before
                "templates/coin_digits", "templates/hud_digits",        # 10/23: order reward digit shapes (coin_digits.py)
                "templates/chef_letters",       # 10/24: d/h/m/s shapes for Chef Challenge timers (chef_tasks.py)
                "templates/chef_icons_named",   # 10/24: Chef task pictures named by hand (cloche = any dish, ...)
                "templates/picked_trees/ask_for_help_text.png", "templates/picked_trees/remove_text.png",  # 10/25
                "templates/orchard/red_hand.png", "templates/orchard/replant", "templates/food_truck/gold_truck_icon.png", "templates/food_truck/done_check.png",  # 11/8                                                         # 11/8
                "templates/unbuilt/shop_stoves_tab.png",   # 10/25: the shop's Stoves tab (unbuilt.py)
                "templates/pantry_full_dialog.png",        # 10/25: "Your Pantry is full!" words (find_and_center)
                "templates/daily_wheel/wheel.png", "templates/daily_wheel/wheel_2.png", "templates/daily_wheel/wheel_3.png",         # 10/25: prize wheel (tests_job.find_wheel)
                "templates/trade_tiles", "templates/skip_ad_icon.png", "templates/skip_ad_button.png",                   # 10/25: cabbage / corn / tomato tiles for pantry relief sales
                "templates/stock_tiles",                   # 10/30: every Pantry + Fridge tile by name (stock take)
                "templates/okay_button.png", "templates/leaderboard_title.png",
                "templates/whoops_title.png", "templates/takeout_title.png",
                "templates/ad_icons", "templates/ad_pill", "templates/chat", "templates/splash"]   # 10/20: leaderboard closer's pictures
# Files that load again at Start by themselves; any other .py needs AFSD closed and reopened.
RELOADABLE = {"adb_helper.py", "find_and_center.py", "pig_pen_check.py", "dairy_check.py", "run_trace.py",
              "order_fulfill.py", "garden_check.py", "delivery_event.py", "chef_challenge.py",
              "food_truck_event.py", "event_orders.py", "street_truck.py", "trade_sell.py", "fishing_topup.py",
              "afsd_core.py", "crops.py", "log_digest.py", "prep_engine.py", "prep_route.py", "kitchen_model.py", "stock_digits.py", "unstuck.py", "tests_job.py",
              "picked_trees.py", "unbuilt.py", "no_progress.py", "recipe_learner.py", "recipe_book.py", "flash.py", "ad_player.py", "worth.py", "sprout.py", "replant.py", "soups.py", "job_order.py", "truck_panel.py", "street_truck.py", "busy.py", "event_icon_search.py", "prize_watch.py", "cleanup.py"}
SENT_MARK = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".logs_sent.json")
LOG_LINES = 50000            # 10/21 (owner): 5000 (~0.5 MB) lost the start of a night; 50000 ~ 5 MB, git packs it ~8x smaller
PICS_MAX_MB = 8               # pictures per Send logs (the log is always sent)
# Shared copies (built by tools/build_share_zip.py) carry a .shared marker file and,
# when the DISCORD_WEBHOOK_URL secret is set, a discord_webhook.txt with the webhook
# URL. The owner's copy has neither file, so it always takes the git path below.
SHARED_MARKER = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".shared")
DISCORD_WEBHOOK_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "discord_webhook.txt")
DISCORD_SENT_MARK = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".discord_sent.json")
# The public download page. Shared copies check its version.json and download
# its zip; the owner's copy never touches it (it updates from the private repo).
SHARE_PAGE = "https://sandybpatterson.github.io/food-street-bot"
SHARE_VERSION_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "share_version.json")
VERSION_FILES = ("event_orders.py", "afsd_core.py", "order_fulfill.py")


def _ad_recording_pictures(files, since, max_frames=24):
    """11/1: a Record-ad session (templates/ad_training/rec_*/) saves full-size PNGs (~2 MB each), so none fitted the
    8 MB send. Make half-size JPEG copies (once) and send those: the marked tap pictures, the after-tap pictures and up
    to max_frames frames spread over the session. Never raises."""
    out = []
    try:
        import cv2
        # newest session, whatever its age: pictures already on GitHub are dropped later (git ls-files), so an old
        # session is sent once and then never again
        recs = sorted({os.path.dirname(f) for f in files if os.sep + "rec_" in f})
        for d in recs[-1:]:                                  # the newest session only
            names = sorted(os.listdir(d))
            pngs = [n for n in names if n.endswith(".png") and (n.startswith("f") or "_post" in n
                                                               or "_pre_marked" in n)]
            frames = [n for n in pngs if n.startswith("f")]
            if len(frames) > max_frames:
                step = len(frames) / max_frames
                frames = [frames[int(i * step)] for i in range(max_frames)]
            for n in frames + [n for n in pngs if "_post" in n or "_pre_marked" in n]:
                jpg = os.path.join(d, n[:-4] + "_small.jpg")
                if not os.path.exists(jpg):
                    img = cv2.imread(os.path.join(d, n))
                    if img is None:
                        continue
                    cv2.imwrite(jpg, cv2.resize(img, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA),
                                [cv2.IMWRITE_JPEG_QUALITY, 70])
                out.append(jpg)
            out += [os.path.join(d, n) for n in names if n.endswith("_pre_marked.jpg") or n == "lessons.jsonl"]
    except Exception:                                        # noqa: BLE001
        pass
    return out


def _git(*args, timeout=120, watch=None, cwd=None):
    """Runs git hidden and can never hang AFSD: no password prompt (there is no console to answer it), a slow
    connection is dropped after 20 s, and output goes to a temp file -- with pipes, a helper process that
    outlives a timed-out git keeps the pipe open and Python waits forever (10/18 review)."""
    import tempfile
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="never")
    if args[0] == "push":                          # 10/18: big picture sends died with HTTP 408 -- bigger buffer, no
        cmd = ["git", "-c", "http.postBuffer=524288000", *args]    # slow-speed cutoff (a slow upload is still progress)
    else:
        cmd = ["git", "-c", "http.lowSpeedLimit=1000", "-c", "http.lowSpeedTime=20", *args]
    fd, path = tempfile.mkstemp(prefix="afsd_git_")
    os.close(fd)

    def read_out():                                # 10/18 review: a SEPARATE handle -- never move git's own file position
        with open(path, "rb") as fh:
            return fh.read().decode("utf-8", "replace")
    try:
        with open(path, "wb") as out:
            return _git_run(cmd, out, read_out, args, timeout, watch, flags, env, cwd)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def _git_run(cmd, out, read_out, args, timeout, watch, flags, env, cwd=None):
    p = subprocess.Popen(cmd, cwd=cwd or BOT, stdin=subprocess.DEVNULL, stdout=out, stderr=out, env=env, creationflags=flags)
    start = time.time()
    while True:                                    # 10/18: poll, so a watcher can show git's live progress
        try:
            rc = p.wait(timeout=0.5)
            break
        except subprocess.TimeoutExpired:
            if time.time() - start > timeout:
                p.kill()
                return 1, f"git {args[0]} took longer than {timeout} s -- stopped it (internet slow or down?)"
            if watch is not None:
                try:
                    watch(read_out())
                except Exception:                  # noqa: BLE001
                    pass
    return rc, read_out().strip()


def code_version():
    """Short fingerprint of the main files (line endings ignored), the same as the "Code version" log line."""
    tags = []
    for f in VERSION_FILES:
        try:
            with open(os.path.join(BOT, f), "rb") as fh:
                h = hashlib.md5(fh.read().replace(b"\r\n", b"\n")).hexdigest()[:6]
        except OSError:
            h = "?"
        tags.append(f"{f.split('.')[0]} {h}")
    return ", ".join(tags)


def _git_why(out):
    """Last line of git's own message (or the time-out), so a failed fetch says WHY."""
    lines = [ln.strip() for ln in str(out or "").splitlines() if ln.strip()]
    return f" (git: {lines[-1][:160]})" if lines else ""


def _newer_files():
    rc, out = _git("diff", "--name-only", "origin/main", "--", *UPDATE_PATHS)
    if rc != 0:
        raise RuntimeError(out or "git diff failed")
    return [ln for ln in out.splitlines() if ln.strip()]


def _share_version():
    """The afsd commit this copy was built from, or None (the owner's copy has no file)."""
    try:
        import json
        with open(SHARE_VERSION_FILE, encoding="utf-8") as fh:
            return json.load(fh).get("sha") or None
    except (OSError, ValueError, TypeError):
        return None


def _fetch_share_version():
    """version.json from the download page. Returns (dict, '') or (None, reason)."""
    import json
    import urllib.request
    import urllib.error
    try:
        req = urllib.request.Request(SHARE_PAGE + "/version.json", headers={"User-Agent": "AutoFoodStreet"})
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.load(r), ""
    except urllib.error.HTTPError as e:
        return None, f"download page said {e.code}"
    except Exception as e:                                  # noqa: BLE001
        return None, repr(e)[:160]


def _zip_updates(rel):
    """True if a zip entry (repo-relative path) is one Update installs: the same
    set as UPDATE_PATHS, minus .gitignore, which the zip does not carry."""
    if rel in ("recipes.json", "share_version.json"):
        return True
    if "/" not in rel and rel.endswith(".py"):
        return True
    if rel == "tools" or rel.startswith("tools/"):
        return True
    for entry in UPDATE_PATHS:
        if entry.startswith("templates/") and (rel == entry or rel.startswith(entry + "/")):
            return True
    return False


def _check_share(progress):
    """Only looks: is the download page's version newer than this copy?"""
    progress("Update: checking the download page...", 0.3)
    mine = _share_version()
    live, err = _fetch_share_version()
    if live is None:
        return False, f"Update check: could not reach the download page. ({err})"
    if mine and live.get("sha") == mine:
        return True, "Update: ✓ up to date."
    if not mine:
        return True, "UPDATE WAITING: this copy has no version stamp -- press Update to refresh it."
    return True, "UPDATE WAITING: a new version is on the download page -- Stop, press Update, then reopen AFSD."


def _update_share(progress):
    """Downloads the newest share zip and installs the same files Update installs
    now, keeping old copies in backups/<time>/. Settings, logs and pictures are
    never touched."""
    import urllib.request
    import zipfile
    import tempfile
    progress("Update: checking the download page...", 0.15)
    mine = _share_version()
    live, err = _fetch_share_version()
    if live is None:
        return False, f"Update: could not reach the download page. Check the internet and try again. ({err})"
    if mine and live.get("sha") == mine:
        return True, "Update: ✓ already up to date."
    progress("Update: downloading the new version...", 0.3)
    tmp = os.path.join(tempfile.gettempdir(), "afsd_update.zip")
    try:
        req = urllib.request.Request(SHARE_PAGE + "/AutoFoodStreet.zip", headers={"User-Agent": "AutoFoodStreet"})
        with urllib.request.urlopen(req, timeout=300) as r, open(tmp, "wb") as fh:
            shutil.copyfileobj(r, fh, length=1 << 20)
    except Exception as e:                                  # noqa: BLE001
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False, f"Update: download failed ({e!r})"[:300]
    try:
        with zipfile.ZipFile(tmp) as zf:
            install = [n for n in zf.namelist()
                       if n.startswith("AutoFoodStreet/") and _zip_updates(os.path.relpath(n, "AutoFoodStreet"))]
    except Exception as e:                                  # noqa: BLE001
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False, f"UPDATE FAILED: the downloaded zip could not be read ({e!r})"[:300]
    if not install:
        try:
            os.remove(tmp)
        except OSError:
            pass
        return True, "Update: ✓ nothing to install."
    progress(f"Update: backing up {len(install)} file(s)...", 0.45)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    for n in install:
        rel = os.path.relpath(n, "AutoFoodStreet")
        src = os.path.join(BOT, rel)
        if os.path.isfile(src):
            dst = os.path.join(BOT, "backups", stamp, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
    progress(f"Update: installing {len(install)} file(s)...", 0.75)
    try:
        with zipfile.ZipFile(tmp) as zf:
            for n in install:
                rel = os.path.relpath(n, "AutoFoodStreet")
                dst = os.path.join(BOT, rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with zf.open(n) as src_fh, open(dst, "wb") as out_fh:
                    shutil.copyfileobj(src_fh, out_fh, length=1 << 20)
    except Exception as e:                                  # noqa: BLE001
        return False, f"UPDATE FAILED: {e!r}"[:300]
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    files = [os.path.relpath(n, "AutoFoodStreet") for n in install]
    restart = [f for f in files if f.endswith(".py") and "/" not in f and f not in RELOADABLE]
    msg = f"Update: ✓ installed {len(files)} file(s) (backups\\{stamp})."
    if restart:
        msg += f" {', '.join(restart)} changed: close AFSD and open it again."
    return True, msg


def check(progress):
    """Only looks: how many files on GitHub are newer than the ones here."""
    if os.path.exists(SHARED_MARKER):
        # Shared copies have no private repo: compare against version.json on the download page.
        return _check_share(progress)
    progress("Update: checking GitHub...", 0.3)
    rc, out = _git("fetch", "-q", "origin", "main", timeout=300)   # 10/21: 60 s was too short with many log pictures
    if rc != 0:
        return False, "Update check: could not reach GitHub." + _git_why(out)
    files = _newer_files()
    if not files:
        return True, "Update: ✓ up to date."
    return True, f"UPDATE WAITING: {len(files)} file(s) differ from GitHub -- Stop, press Update, then reopen AFSD."


def update(progress):
    """Installs the newer files (old copies kept in backups/<time>/). Returns (ok, message)."""
    if os.path.exists(SHARED_MARKER):
        # Shared copies have no private repo: download the newest share zip instead.
        return _update_share(progress)
    progress("Update: checking GitHub...", 0.15)
    rc, out = _git("fetch", "-q", "origin", "main", timeout=300)   # 10/21: 60 s was too short with many log pictures
    if rc != 0:
        return False, "Update: could not reach GitHub. Check the internet and try again." + _git_why(out)
    files = _newer_files()
    if not files:
        return True, "Update: ✓ already up to date."
    progress(f"Update: backing up {len(files)} file(s)...", 0.45)
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    for f in files:
        src = os.path.join(BOT, f)
        if os.path.isfile(src):
            dst = os.path.join(BOT, "backups", stamp, f)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
    progress(f"Update: installing {len(files)} file(s)...", 0.75)
    # 10/18 review: name the exact files (only those that exist on main) -- a pathspec that matches nothing on
    # main makes git refuse the WHOLE checkout (the .bat trap that blocked every update for a day).
    rc, listing = _git("ls-tree", "-r", "--name-only", "origin/main")
    on_main = set(listing.splitlines()) if rc == 0 else set()
    install = [f for f in files if f in on_main]
    if not install:
        return True, "Update: \u2713 nothing to install."
    rc, out = _git("checkout", "origin/main", "--", *install)
    if rc != 0:
        return False, f"UPDATE FAILED: {out[-300:]}"
    restart = [f for f in files if f.endswith(".py") and "/" not in f and f not in RELOADABLE]
    msg = f"Update: ✓ installed {len(files)} file(s) (backups\\{stamp})."
    if restart:
        msg += f" {', '.join(restart)} changed: close AFSD and open it again."
    return True, msg


def _note(line):
    """10/27: write one line into run_log.txt (AFSD's log) -- the next send carries it."""
    try:
        with open(LOG, "a", encoding="utf-8", errors="replace") as fh:
            fh.write(f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] [afsd] {line}\n")
    except OSError:
        pass


def _cap_pics(pics):
    """Newest pictures first under PICS_MAX_MB, with pictures asked for on purpose
    (daily wheel scout, Let Me Play, pier/cowshed/crops scouts, ad training) getting
    the first claim. Same rule the git send always used; the Discord send reuses it."""
    kept, total = [], 0
    # 10/25 (Muse P20): the wheel pictures were dropped by the cap (newer pictures filled it first).
    first = lambda q: 0 if ("_wheel_pier_" in q or "_cowshed_" in q or "_crops_" in q or "ad_training" in q) else 1 if ("_wheel_" in q or "let_me_play" in q) else 2   # 10/27: pier first
    for p in sorted(sorted(set(pics), key=os.path.getmtime, reverse=True), key=first):
        try:
            size = os.path.getsize(p)
        except OSError:
            continue
        if total + size <= PICS_MAX_MB * 1e6:
            kept.append(p)
            total += size
    return kept


def _shared_webhook():
    """Discord webhook URL for shared copies, or None. The owner's copy has no
    .shared marker, so it never takes this path."""
    try:
        if not os.path.exists(SHARED_MARKER):
            return None
        with open(DISCORD_WEBHOOK_FILE, encoding="utf-8") as fh:
            url = fh.read().strip()
        if url.startswith("https://discord.com/api/webhooks/") or url.startswith("https://discordapp.com/api/webhooks/"):
            return url
    except OSError:
        pass
    return None


def _discord_post(url, content, files):
    """One webhook POST: short text + up to 10 attached files. files is a list of
    (filename, bytes, mime). Returns (True, '') or (False, reason). No new libraries."""
    import urllib.request
    import urllib.error
    import uuid
    boundary = uuid.uuid4().hex
    body = bytearray()

    def field(name, value):
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        body.extend(value.encode("utf-8"))
        body.extend(b"\r\n")

    field("content", content)
    for i, (name, data, mime) in enumerate(files):
        body.extend(f"--{boundary}\r\n".encode())
        body.extend(f'Content-Disposition: form-data; name="file{i}"; filename="{name}"\r\n'.encode())
        body.extend(f"Content-Type: {mime}\r\n\r\n".encode())
        body.extend(data)
        body.extend(b"\r\n")
    body.extend(f"--{boundary}--\r\n".encode())
    req = urllib.request.Request(url, data=bytes(body), method="POST")
    req.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            r.read()
        return True, ""
    except urllib.error.HTTPError as e:
        return False, f"Discord said {e.code}"
    except Exception as e:                                  # noqa: BLE001
        return False, repr(e)[:200]


def _send_logs_discord(progress, end, pics):
    """Shared copies: post the log + pictures to the Discord webhook. Same trigger
    as the git send (Send logs button, 'Send logs at every Stop'), same log file,
    same picture set. Pictures are only sent once (last-send time is remembered);
    the log lines are tracked by .logs_sent.json, exactly like the git send."""
    import json
    url = _shared_webhook()
    if not url:
        return False, "Send logs: this test copy is not set up to send logs yet."
    progress("Send logs: step 4 of 4, posting to Discord...", 0.75)
    log_path = os.path.join(BOT, "logs", "latest_log.txt")
    try:
        with open(log_path, "rb") as fh:
            log_bytes = fh.read()
    except OSError:
        log_bytes = b"(no log file yet)\n"
    last = 0
    try:
        with open(DISCORD_SENT_MARK, encoding="utf-8") as fh:
            last = float(json.load(fh).get("t", 0))
    except (OSError, ValueError, TypeError):
        last = 0
    fresh = []
    for p in pics:
        try:
            if os.path.getmtime(p) > last:
                fresh.append(p)
        except OSError:
            pass
    pics = _cap_pics(fresh)
    mb = sum(os.path.getsize(p) for p in pics) / 1e6

    def mime(name):
        low = name.lower()
        if low.endswith(".png"):
            return "image/png"
        if low.endswith((".jpg", ".jpeg")):
            return "image/jpeg"
        if low.endswith(".jsonl"):
            return "application/json"
        return "application/octet-stream"

    def read_file(path):
        try:
            with open(path, "rb") as fh:
                return fh.read()
        except OSError:
            return None

    # 10 files per webhook message; the log file takes one slot in the first.
    chunks = [[log_path] + pics[:9]]
    for i in range(9, len(pics), 10):
        chunks.append(pics[i:i + 10])
    stamp = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())
    for ci, chunk in enumerate(chunks):
        files = []
        for path in chunk:
            data = log_bytes if path == log_path else read_file(path)
            if data is not None:
                files.append((os.path.basename(path), data, "text/plain" if path == log_path else mime(path)))
        if not files:
            continue
        progress(f"Send logs: step 4 of 4, posting to Discord ({ci + 1}/{len(chunks)})...", 0.75 + 0.25 * (ci + 1) / len(chunks))
        content = f"AFSD test logs -- {stamp} ({len(pics)} picture(s))" if ci == 0 else ""
        ok, err = _discord_post(url, content, files)
        if not ok:
            return False, f"Send logs: Discord post failed ({err}). Check the internet and try again."
    try:
        import json as _json
        with open(SENT_MARK, "w", encoding="utf-8") as fh:
            _json.dump({"pos": end, "t": time.time()}, fh)
        with open(DISCORD_SENT_MARK, "w", encoding="utf-8") as fh:
            _json.dump({"t": time.time()}, fh)
    except OSError:
        pass
    return True, (f"Send logs: ✓ sent to Discord ({len(pics)} picture(s), {mb:.1f} MB)."
                  if pics else "Send logs: ✓ sent the log to Discord.")


def send_logs(progress):
    """Newest LOG_LINES log lines + recent pictures -> one commit pushed to GitHub (same as the old .bat)."""
    progress("Send logs: step 1 of 4, copying the newest log lines...", 0.1)
    os.makedirs(os.path.join(BOT, "logs"), exist_ok=True)
    # 10/21 (owner): send everything since the last successful send (byte position kept in .logs_sent.json),
    # capped at LOG_LINES; a log that got shorter (new file) is sent from its start.
    start = 0
    try:
        import json
        with open(SENT_MARK, encoding="utf-8") as fh:
            start = int(json.load(fh).get("pos", 0))
    except (OSError, ValueError, TypeError):
        start = 0
    end = 0
    try:
        with open(LOG, "rb") as fh:
            fh.seek(0, 2)
            end = fh.tell()
            if start > end:
                start = 0
            fh.seek(start)
            lines = fh.read().decode("utf-8", errors="replace").splitlines(keepends=True)[-LOG_LINES:]
    except OSError:
        lines = []
    if start and lines:
        lines.insert(0, f"[send logs] everything since the last send (byte {start} of {end}).\n")
    try:                                        # 11/15: header + loops + spam cut (log_digest); raw stays on the PC
        import log_digest
        out = [ln + "\n" for ln in log_digest.digest(lines)]
    except Exception as e:                      # noqa: BLE001
        out = [f"[send logs] digest failed ({e!r}) -- raw lines below\n"] + lines
    with open(os.path.join(BOT, "logs", "latest_log.txt"), "w", encoding="utf-8") as fh:
        fh.writelines(out)
    since = datetime.datetime.now().timestamp() - 24 * 3600

    def files_in(folder, recursive=False):
        root = os.path.join(BOT, "templates", folder)
        found = []
        for d, _, names in os.walk(root):
            found += [os.path.join(d, n) for n in names]
            if not recursive:
                break
        return sorted(found, key=os.path.getmtime, reverse=True)

    pics = [p for f in ("event_pending", "unknown_screens") for p in files_in(f) if os.path.getmtime(p) > since]
    pics = sorted(pics, key=os.path.getmtime, reverse=True)[:25]
    pics += [p for p in files_in("event_tapfail") if os.path.getmtime(p) > since][:5]    # ~2 MB each: newest 5
    pics += [p for p in files_in("recover_debug") if os.path.getmtime(p) > since][:5]    # failed plant-bar re-opens
    pics += [p for p in files_in("time_labels_unknown") if os.path.getmtime(p) > since][:5]  # unreadable timers
    pics += [p for p in files_in("fail_pictures") if os.path.getmtime(p) > since][:4]
    pics += [p for p in files_in("unstuck") if os.path.getmtime(p) > since][:4]
    pics += [p for p in files_in("tests") if "_wheel_" in p and os.path.getmtime(p) > since][:5]   # 10/25: wheel scout first
    pics += [p for p in files_in("tests") if "_wheel_pier_" in p and os.path.getmtime(p) > since][:10]  # 10/27: pier scout
    pics += [p for p in files_in("tests") if "_cowshed_" in p and os.path.getmtime(p) > since][:3]   # 10/28: Cow Shed shots
    pics += [p for p in files_in("tests") if "_crops_" in p and os.path.getmtime(p) > since][:5]     # 11/2: C.R.O.P.S. scout
    pics += [p for p in files_in("tests") if os.path.getmtime(p) > since][:8]            # 10/20 Tests job pictures          # 10/20 unstuck test: new stuck screens  # 10/20: the panel that stuck all night
    pics += [p for p in files_in("bush_misses") if os.path.getmtime(p) > since][:4]
    pics += [p for p in files_in(os.path.join("picked_trees", "seen")) if os.path.getmtime(p) > since][:4]   # 10/25
    pics += [p for p in files_in(os.path.join("orchard", "seen")) if os.path.getmtime(p) > since][:8]       # 11/8 cuts
    pics += [p for p in files_in(os.path.join("food_truck", "seen")) if os.path.getmtime(p) > since][:8]   # 11/8 truck hand-ins
    pics += [p for p in files_in("busy_prices") if os.path.getmtime(p) > since][:6]                       # 11/10 price reads
    pics += [p for p in files_in("chef_icons") if os.path.getmtime(p) > since][:4]     # 10/24: task pictures not named yet
    pics += [p for p in files_in("chef_pending") if "chef_trip" in p and os.path.getmtime(p) > since][:2]  # 10/24: a wrong chef trip    # 10/20: "no ripe apple" -- owner sees apples nearby
    pics += [p for p in files_in("reward_headers") if os.path.getmtime(p) > since][:10]   # rank test: coin headers
    pics += [p for p in files_in("count_unknown") if os.path.getmtime(p) > since][:10]    # unreadable card amounts
    pics += [p for p in files_in("training_shots") if os.path.getmtime(p) > since][:15]
    pics += [p for p in files_in("ad_training") if os.path.getmtime(p) > since][:4]       # 11/1 ad spotter pictures
    pics += _ad_recording_pictures(files_in("ad_training", recursive=True), since)       # 11/1 Record ad frames + taps
    try:                                                                               # 11/2 live ad pictures (ad_player)
        _root = os.path.join(BOT, "templates", "ad_training")
        _live = sorted(n for n in os.listdir(_root) if n.startswith("live_") and os.path.isdir(os.path.join(_root, n)))
        _live = [n for n in _live if os.path.getmtime(os.path.join(_root, n)) > since - 3600]   # 11/4: every ad
        for _n in _live[-6:]:                                                                # since the last send
            _d = os.path.join(_root, _n)
            pics += [os.path.join(_d, f) for f in sorted(os.listdir(_d)) if f.endswith(".jpg")]
    except Exception:                                                                  # noqa: BLE001
        pass
    play = [p for p in files_in("let_me_play", recursive=True) if os.path.getmtime(p) > since]   # 10/25 Let Me Play
    # 10/25 (Muse P23): 40 jpgs = only the last 20 taps of a 142-tap session. The marked "before" picture shows
    # the screen AND the tap, so send those first (up to 40, ~150 KB each under the 8 MB cap) and only a few "after" pictures.
    pics += ([p for p in play if p.endswith(".jsonl")][:5] + [p for p in play if p.endswith("_pre_marked.jpg")][:40]
             + [p for p in play if p.endswith("_post.jpg")][:5])
    pics += files_in("recipe_test", recursive=True)[:60]
    pics += [p for p in files_in("learned") if os.path.getmtime(p) > since][:6]         # 10/28: cards the bot learned
    # 10/18: sends of ~50 MB (25 full screenshots at ~2 MB) timed out at "100%" (HTTP 408 on a home upload).
    # Keep the pictures under PICS_MAX_MB, newest first; the log itself is always sent.
    # 10/27: 36 chosen, 0 staged -- the first-claim pier pictures (and others from the last 24 h) had ALREADY been sent,
    # filled the 8 MB again every time and pushed every new picture (owner's board screenshots) out. Skip what git
    # already tracks before the cap.
    if os.path.exists(SHARED_MARKER):
        # Shared copies (built by tools/build_share_zip.py) have no private repo
        # to push to and no git at all: Send logs posts to Discord instead. Same
        # trigger, same log file, same pictures. The owner's copy has no .shared
        # file, so it always takes the git path below, unchanged.
        return _send_logs_discord(progress, end, pics)
    _rc, tracked_txt = _git("ls-files", "--", "templates")
    tracked = {ln.strip().replace("\\", "/") for ln in tracked_txt.splitlines() if ln.strip()}
    pics = [p for p in pics if os.path.relpath(p, BOT).replace("\\", "/") not in tracked]
    pics = _cap_pics(pics)
    mb = sum(os.path.getsize(p) for p in pics) / 1e6
    # 10/18: if Claude pushes a fix while the logs are on their way, GitHub refuses the send ("cannot lock ref").
    # Then catch up again and send once more -- up to 3 tries.
    out = ""
    for attempt in range(1, 5):
        progress("Send logs: step 2 of 4, catching up with GitHub (your files are not changed)..."
                 + (f" (try {attempt})" if attempt > 1 else ""), 0.3)
        rc, out = _git("fetch", "-q", "origin", "main", timeout=60)
        if rc != 0:
            return False, "Send logs: could not reach GitHub. Check the internet and try again."
        _git("reset", "-q", "origin/main")
        progress("Send logs: step 3 of 4, adding the log and pictures...", 0.5)
        add_err = ""
        for p in pics:
            arc, aout = _git("add", "-f", "--", os.path.relpath(p, BOT))     # 10/27: -f, and keep the first refusal
            if arc != 0 and not add_err:
                add_err = f"{os.path.relpath(p, BOT)}: {aout.strip()[-200:]}"
        _rc, staged_txt = _git("diff", "--cached", "--name-only")
        staged = sum(1 for ln in staged_txt.splitlines() if ln.strip().startswith("templates"))
        _line = (f"[send logs] {len(pics)} picture(s) chosen ({mb:.1f} MB), {staged} staged"
                 + (f"; first refused: {add_err}" if add_err else "") + ".")
        if pics and staged == 0:                        # 10/27: 36 chosen, 0 staged, no error -- ask git why
            rel = os.path.relpath(pics[0], BOT)
            for args in (("rev-parse", "--show-toplevel"), ("config", "--get", "core.sparseCheckout"),
                         ("check-ignore", "-v", "--no-index", "--", rel), ("ls-files", "-s", "--", rel),
                         ("status", "--porcelain", "--ignored", "--", rel), ("add", "-v", "-f", "--", rel),
                         ("diff", "--cached", "--stat")):
                _r, _o = _git(*args)
                _line += f"\n[send logs] git {' '.join(args)} -> rc {_r}: {_o.strip()[-300:]!r}"
            _line += f"\n[send logs] picture path: {pics[0]!r}; bot folder: {BOT!r}; exists {os.path.exists(pics[0])}"
        _note(_line)
        try:                                            # this send's own log carries the line too
            with open(os.path.join(BOT, "logs", "latest_log.txt"), "a", encoding="utf-8") as fh:
                fh.write(_line + "\n")
        except OSError:
            pass
        _git("add", "--", "logs/latest_log.txt")
        _git("commit", "-q", "-m", "Logs for Claude")
        progress(f"Send logs: step 4 of 4, sending {len(pics)} pictures ({mb:.1f} MB) to GitHub...", 0.75)

        def watch(text, n=len(pics), size=mb):         # git's own "Writing objects: 45% (12/27), 3.20 MiB | 150 KiB/s"
            hits = re.findall(r"Writing objects:\s+(\d+)%[^,\r\n]*(?:,\s*([\d.]+ \w?i?B))?(?:\s*\|\s*([\d.]+ \w?i?B/s))?",
                              text)
            if hits and hits[-1][0] == "100":         # sent; GitHub still has to store it -- say so, or it looks stuck
                progress(f"Send logs: upload done ({size:.1f} MB) -- GitHub is saving it, this can take a minute...", 0.97)
                return
            if hits:
                pct, done, speed = hits[-1]
                progress(f"Send logs: step 4 of 4, uploading {pct}%"
                         + (f" \u00b7 {done}" if done else "") + (f" \u00b7 {speed}" if speed else "")
                         + f" ({n} pictures, {size:.1f} MB)", 0.75 + 0.25 * int(pct) / 100)
        rc, out = _git("push", "--progress", "origin", "HEAD:main", timeout=300, watch=watch)
        if rc == 0:
            try:                                        # remember where this send stopped
                import json
                with open(SENT_MARK, "w", encoding="utf-8") as fh:
                    json.dump({"pos": end, "t": time.time()}, fh)
            except OSError:
                pass
            return True, (f"Send logs: ✓ sent ({staged} pictures). Tell Claude: check the logs." if pics else
                          "Send logs: ✓ sent the log (pictures left out: the upload was too big). "
                          "Tell Claude: check the logs.")
        too_big = any(w in out for w in ("408", "RPC failed", "hung up", "unexpected disconnect", "took longer"))
        if too_big and pics:                           # 10/18: the upload timed out -- send the log alone
            progress("Send logs: the upload was too big for the connection -- sending the log without pictures...", 0.3)
            pics, mb = [], 0.0
            continue
        if "rejected" not in out and "lock ref" not in out and "non-fast-forward" not in out:
            break                                      # not a race -- a retry will not help
    return False, f"SENDING FAILED: {out[-300:]}"
